﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RND.CBP.APP.Filters
{
    public class AuthorizationActionFilter : ActionFilterAttribute
    {
        private readonly IConfiguration _config;

        public AuthorizationActionFilter(IConfiguration config)
        {
            _config = config;
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var token = context.HttpContext.Request.Headers["Token"];

            if (token.ToString() != _config["Authentication:token"].ToString())
                context.Result = new UnauthorizedResult();
        }

        public override void OnActionExecuted(ActionExecutedContext context)
        {
            // do something after the action executes
        }

    }
}
