﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace RND.CBP.APP.Controllers
{
    public class HomeController : Controller
    {
        const string sessionKey = "isLogged";

        [HttpGet]
        public IActionResult Index()
        {
            var isLogged = HttpContext.Session.GetString(sessionKey);

            if (!string.IsNullOrEmpty(isLogged) && isLogged.Equals("true"))
            {
                ViewBag.AcessoNegado = string.Empty;
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Login");
            }
        }

        [HttpGet]
        public IActionResult AccessDenied()
        {
            ViewBag.MensagemErro = "Você não possui permissão para acessar essa página";
            return View("Error");
        }

        [HttpGet]
        public IActionResult Error()
        {
            ViewBag.MensagemErro = "Ocorreu um erro inesperado. Tente novamente mais tarde!";
            return View("Error");
        }
    }
}
