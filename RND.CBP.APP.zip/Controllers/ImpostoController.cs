﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace RND.CBP.APP.Controllers
{
    [Route("[controller]")]
    public class ImpostoController : Controller
    {
        const string sessionKey = "isLogged";

        [HttpGet]
        public IActionResult Index()
        {
            var isLogged = HttpContext.Session.GetString(sessionKey);

            if (!string.IsNullOrEmpty(isLogged) && isLogged.Equals("true"))
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Login");
            }
        }
    }
}