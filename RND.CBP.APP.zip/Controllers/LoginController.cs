﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RND.CBP.APP.Base;
using RND.CBP.APP.Models;
using RND.CBP.CrossCutting;
using RND.CBP.Domain.DTOs;
using RND.CBP.Infra.Data.Transactions;
using System.Net;
using HttpMethods = RND.CBP.CrossCutting.HttpMethods;

namespace RND.CBP.APP.Controllers
{
    public class LoginController : BaseController
    {
        const string sessionKey = "isLogged";
        const string sessionUser = "UserLogged";
        const string sessionUserId = "UserIdLogged";
        const string sessionPermissionUser = "PermissionUser";

        public LoginController(IUnitOfWork unitOfWork, IConfiguration configuration):base(unitOfWork, configuration)
        {
         
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public ActionResult Index()
        {
            var isLogged = HttpContext.Session.GetString(sessionKey);

            if (!string.IsNullOrEmpty(isLogged) && isLogged.Equals("true"))
            {
                return RedirectToAction("Index", "Home");
            }

            return View();
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public ActionResult Logout()
        {
            HttpContext.Session.SetString(sessionKey, "false");

            return View("Index");
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public string Autenticar(string login, string senha)
        {
            var usuarioAcesso = new Acesso();

            usuarioAcesso.Login = login;
            usuarioAcesso.Dominio = _configuration["AppSettings:dominio"].ToString();
            usuarioAcesso.Chave = _configuration["AppSettings:chave"].ToString();
            usuarioAcesso.Senha = CriptografiaAES.CriptografarUnicode(senha, usuarioAcesso.Chave);
            usuarioAcesso.TipoEncodeSenha = "Unicode";

            usuarioAcesso.Login = usuarioAcesso.Login.Contains("@") ? usuarioAcesso.Login.Split('@')[0] : usuarioAcesso.Login;

            HttpMethods httpMethods = new HttpMethods(_configuration["AppSettings:urlAuthentication"].ToString());
            
            var retornoApi = httpMethods.Post("login/Autenticar", usuarioAcesso, _configuration["AppSettings:token"].ToString());

            if (retornoApi.Content.Contains("415"))
            {
                usuarioAcesso.Senha = CriptografiaAES.CriptografarBigEndianUnicode(senha, usuarioAcesso.Chave);
                usuarioAcesso.TipoEncodeSenha = "BigEndianUnicode";

                retornoApi = httpMethods.Post("login/Autenticar", usuarioAcesso, _configuration["AppSettings:token"].ToString());
            }

            if (retornoApi.Content.Contains("200"))
            {
                var usuarioLogado = BuscarUsuario(usuarioAcesso.Login);

                if(usuarioLogado == null)
                {
                    return "{\"status\":403,\"result\":\"O usuário não possui acesso ao CBP\"}";
                }
                HttpContext.Session.SetString(sessionUser, usuarioLogado.Nome);
                HttpContext.Session.SetString(sessionUserId, usuarioLogado.Id.ToString());
                HttpContext.Session.SetString(sessionPermissionUser, JsonConvert.SerializeObject(usuarioLogado.UsuarioFuncionalidade));
                HttpContext.Session.SetString(sessionKey, "true");
            }
            else
            {
                HttpContext.Session.SetString(sessionKey, "false");
            }
            
            return retornoApi.Content;
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public Usuario BuscarUsuario(string usuarioAD)
        {
            HttpMethods httpMethods = new HttpMethods(_configuration["AppSettings:urlAuthentication"].ToString());

            var retornoFiltro = httpMethods.Get("Usuario/Buscar?usuarioAD=" + usuarioAD, 1, _configuration["AppSettings:token"].ToString());

            var usuario = JsonConvert.DeserializeObject<Usuario>(retornoFiltro.Content);

            return usuario;
        }
    }

}