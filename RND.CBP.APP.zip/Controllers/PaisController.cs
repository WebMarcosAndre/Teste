﻿using Microsoft.AspNetCore.Mvc;
using RND.CBP.Domain.Interfaces.Services;

namespace RND.CBP.APP.Controllers
{
    [Route("[controller]")]
    public class PaisController : Controller
    {
        private readonly IPaisService _paisService;

        public PaisController(IPaisService paisService)
        {
            _paisService = paisService;
        }

        [HttpPost]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [Route("Importar")]
        public ActionResult ImportarPaises([FromBody] string listaPaises)
        {
            try
            {
                return Ok("");
            }
            catch (System.Exception ex)
            {
                return null;
            }
        }
    }
}