﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using RND.CBP.APP.Filters;
using RND.CBP.Domain.DTOs;
using RND.CBP.Domain.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace RND.CBP.APP.Controllers
{
    public class TarifaController : Controller
    {
        private readonly IEmpresaService _empresaService;        
        private readonly ITipoAplicacaoService _tipoAplicacaoService;
        private readonly IBancoRemessaService _bancoRemessaService;
        private readonly ITarifaDetalheService _tarifaDetalheService;
        private readonly IPaisService _paisService;
        private readonly IMoedaService _moedaService;
        private readonly IEmpresaGrupoService _empresaGrupoService;
        private readonly ISistemaService _sistemaService;

        const string sessionKey = "isLogged";
        const string sessionUserId = "UserIdLogged";

        public TarifaController(IEmpresaService empresaService,
                                ITipoAplicacaoService tipoAplicacaoService,
                                IBancoRemessaService bancoRemessaService,
                                ITarifaDetalheService tarifaDetalheService,
                                IPaisService paisService,
                                IMoedaService moedaService,
                                IEmpresaGrupoService empresaGrupoService,
                                ISistemaService sistemaService)
        {
            _empresaService = empresaService;
            _tipoAplicacaoService = tipoAplicacaoService;
            _bancoRemessaService = bancoRemessaService;
            _tarifaDetalheService = tarifaDetalheService;
            _paisService = paisService;
            _moedaService = moedaService;
            _empresaGrupoService = empresaGrupoService;
            _sistemaService = sistemaService;
        }

        [Authorize(Policy = "Tarifa")]
        [ApiExplorerSettings(IgnoreApi = true)]
        public IActionResult Index()
        {
            var isLogged = HttpContext.Session.GetString(sessionKey);

            if (!string.IsNullOrEmpty(isLogged) && isLogged.Equals("true"))
            {
                ViewBag.CustoDenied = "false";
                ViewBag.TarifaDenied = "false";

                PreencheViewBags();

                return View();
            }
            else
            {
                return RedirectToAction("Index", "Login");
            }
        }

        public IActionResult Acesso()
        {
            var isLogged = HttpContext.Session.GetString(sessionKey);

            if (!string.IsNullOrEmpty(isLogged) && isLogged.Equals("true"))
            {
                var funcionalidadesUsuario = JsonConvert.DeserializeObject<List<UsuarioFuncionalidade>>(HttpContext.Session.GetString("PermissionUser"));
                ViewBag.CustoDenied = "false";
                ViewBag.TarifaDenied = "false";

                if (funcionalidadesUsuario.Any())
                {
                    var possuiAcesso = funcionalidadesUsuario.Where(x => x.FuncionalidadeId == 3).Count();
                    var possuiCusto = funcionalidadesUsuario.Where(x => x.FuncionalidadeId == 4).Count();
                    var possuiTarifa = funcionalidadesUsuario.Where(x => x.FuncionalidadeId == 5).Count();

                    PreencheViewBags();

                    if (possuiCusto == 0)
                    {
                        ViewBag.CustoDenied = "true";
                    }
                    if (possuiTarifa == 0)
                    {
                        ViewBag.TarifaDenied = "true";
                    }

                    if (possuiAcesso == 0)
                        return new RedirectToActionResult("AccessDenied", "Home", null);
                    else
                        return View("Index");
                }
                else
                {
                    return new RedirectToActionResult("AccessDenied", "Home", null);
                }
            }
            else
            {
                return RedirectToAction("Index", "Login");
            }            

        }

        public void PreencheViewBags()
        {
            ViewBag.ListaSistema = _sistemaService.ListarSistemas();
            ViewBag.ListaEmpresa = _empresaService.ListarEmpresas();
            ViewBag.ListaEmpresaGrupo = _empresaGrupoService.ListarEmpresaGrupo();
            ViewBag.ListaTipoAplicacao = _tipoAplicacaoService.ListarTipoAplicacao();
            ViewBag.ListaCodigoMoeda = JsonConvert.SerializeObject(_moedaService.ListarCodigoMoedas());
            ViewBag.ListaPaises = JsonConvert.SerializeObject(_paisService.ListarPaises());
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public JsonResult BuscarDadosTabela(int sistema, int empresaGrupo, int empresa, string tipoRemessa, string tipoAplicacao)
        {
            var listaBancoRemessa = _tarifaDetalheService.BuscarPorFiltroDaPagina(sistema, empresaGrupo, empresa, tipoRemessa, tipoAplicacao);

            return Json(listaBancoRemessa);
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public bool UpsertTarifaDetalhe(int sistemaId, 
                                        int empresaGrupoId, 
                                        int empresaId, 
                                        string tipoRemessa, 
                                        string tipoAplicacaoSelecionado, 
                                        List<TarifaDetalheRequest> requests)
        {
            try
            {
                var usuarioId = Convert.ToInt32(HttpContext.Session.GetString(sessionUserId));
                _tarifaDetalheService.Upsert(usuarioId, sistemaId, empresaGrupoId, empresaId, tipoRemessa, tipoAplicacaoSelecionado, requests);

                return true;
            }
            catch (System.Exception)
            {
                return false;
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public bool CadastraTarifaDetalhe(int sistemaId,
                                        int empresaGrupoId,
                                        int empresaId,
                                        string tipoRemessa,
                                        string tipoAplicacaoSelecionado,
                                        List<TarifaDetalheRequest> requests)
        {
            try
            {
                var usuarioId = Convert.ToInt32(HttpContext.Session.GetString(sessionUserId));
                _tarifaDetalheService.InsertPorEmpresa(usuarioId, sistemaId, empresaGrupoId, empresaId, tipoRemessa, tipoAplicacaoSelecionado, requests);

                return true;
            }
            catch (System.Exception)
            {
                return false;
            }
        }

        public bool Excluir(int idTarifaDetalhe, string tipoAplicacao)
        {
            try
            {
                _tarifaDetalheService.DeletarTarifa(idTarifaDetalhe, tipoAplicacao);

                return true;
            }
            catch (System.Exception)
            {
                return false;
            }
        }

        [HttpGet]
        [Route("Tarifa/BuscarMenorTarifa")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ServiceFilter(typeof(AuthorizationActionFilter))]
        public ActionResult BuscarMenorTarifa(string tipoPessoa, int sistemaId, decimal valorOperacao, string nomePais, string codigoMoedaRemessa, int clienteId, string tipoOp, string formaEntrega)
        {
            try
            {
                return Ok(_tarifaDetalheService.BuscarMenorTarifaComFiltro(tipoPessoa,sistemaId,valorOperacao, nomePais, codigoMoedaRemessa, clienteId, tipoOp, formaEntrega));
            }
            catch (System.Exception ex)
            {
                return BadRequest(new { Status = HttpStatusCode.InternalServerError, Result = $"{ex.Message}" });
            }
        }
    }
}