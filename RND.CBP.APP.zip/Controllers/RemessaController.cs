﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Services;
using System;
using System.Collections.Generic;

namespace RND.CBP.APP.Controllers
{
    public class RemessaController : Controller
    {
        private readonly IRemessaService _remessaService;
        private IMemoryCache _cache;
        const string sessionKeyUserLogged = "isLogged";
        const string cacheKeyListaNomeUsuarios = "ListaNomeClientes";

        public RemessaController(IRemessaService remessaService, IMemoryCache cache)
        {
            _remessaService = remessaService;
            _cache = cache;
        }

        [Authorize(Policy = "Remessa")]
        [ApiExplorerSettings(IgnoreApi = true)]
        public IActionResult Index()
        {
            List<TblClientes> lstClientes = new List<TblClientes>();

            if (_cache.Get(cacheKeyListaNomeUsuarios) == null)
            {
                lstClientes = _remessaService.BuscarNomesClientesIkVarejo();
                _cache.Set(cacheKeyListaNomeUsuarios, lstClientes);
            }
            MemoryCacheEntryOptions cacheExpirationOptions = new MemoryCacheEntryOptions();
            cacheExpirationOptions.AbsoluteExpiration = DateTime.Now.AddMinutes(30);
            cacheExpirationOptions.Priority = CacheItemPriority.Normal;
            //_cache.Set(lstClientes, DateTime.Now.ToString(), cacheExpirationOptions);

            var isLogged = HttpContext.Session.GetString(sessionKeyUserLogged);

            if (!string.IsNullOrEmpty(isLogged) && isLogged.Equals("true"))
            {
                var dataInicial = DateTime.Now.AddDays(-1);
                var dataFinal = DateTime.Now;

                switch (dataInicial.Day)
                {
                    case (int)DayOfWeek.Sunday:
                        dataInicial.AddDays(-2);
                        break;
                    case (int)DayOfWeek.Saturday:
                        dataInicial.AddDays(-1);
                        break;
                }

                ViewBag.DataInicial = dataInicial.ToShortDateString();
                ViewBag.DataFinal = dataFinal.ToShortDateString();

                return View();
            }
            else
            {
                return RedirectToAction("Index", "Login");
            }
            
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public JsonResult BuscarRemessas(bool primeiraConsulta, string dataDe, string dataAte, char? codigoStatusRemessa, string pesquisarPor, string txtPesquisarPor, string tipoPessoa, string statusCliente)
        {
            var listaRemessa = _remessaService.FiltarRemessa(primeiraConsulta, dataDe, dataAte, codigoStatusRemessa, pesquisarPor, txtPesquisarPor, tipoPessoa, statusCliente);

            return Json(listaRemessa);
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public JsonResult GetSearchValue(string search, List<TblClientes> listaClientes)
        {
            List<TblClientes> lstClientes = _cache.Get<List<TblClientes>>(cacheKeyListaNomeUsuarios);
            var listaNomes = _remessaService.GetSearchValue(search, lstClientes);

            return Json(listaNomes);
        }
    }
}