﻿using Microsoft.AspNetCore.Mvc;
using RND.CBP.Domain.Interfaces.Services;

namespace RND.CBP.APP.Controllers
{
    [Route("[controller]")]
    public class DominioController : Controller
    {
        private readonly IDominioService _dominioService;

        public DominioController(IDominioService dominioService)
        {
            _dominioService = dominioService;
        }

        [HttpGet]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [Route("Buscar")]
        public ActionResult Buscar()
        {
            try
            {
                var listaDominios = _dominioService.ListarDominios();

                return Ok(listaDominios);
            }
            catch (System.Exception ex)
            {
                return null;
            }
        }
    }
}