﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RND.CBP.APP.Base;
using RND.CBP.Domain.DTOs;
using RND.CBP.Infra.Data.Transactions;
using System;
using System.Collections.Generic;
using System.Linq;
using HttpMethods = RND.CBP.CrossCutting.HttpMethods;

namespace RND.CBP.APP.Controllers
{
    public class AcessoController : BaseController
    {
        const string sessionKey = "isLogged";
        private IMemoryCache _cache;
        const string cacheKey = "ListaUsuariosAD";

        public AcessoController(IUnitOfWork unitOfWork, IConfiguration configuration, IMemoryCache cache) : base(unitOfWork, configuration)
        {
            _cache = cache;
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [Authorize(Policy = "Acesso")]
        public ActionResult Index()
        {
            var isLogged = HttpContext.Session.GetString(sessionKey);

            if (!string.IsNullOrEmpty(isLogged) && isLogged.Equals("true"))
            {
                BuscarFuncionalidades();
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Login");
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public JsonResult BuscarUsuarios(string nome, string usuarioAD, string houveAtualizacao)
        {
            nome = nome ?? string.Empty;
            usuarioAD = usuarioAD ?? string.Empty;

            HttpMethods httpMethods = new HttpMethods(_configuration["AppSettings:urlAuthentication"].ToString());
            var dominio = _configuration["AppSettings:dominio"].ToString();
            var listaUsuarios = new List<Usuario>();

            if (_cache.Get(cacheKey) == null)
            {
                var retornoFiltro = httpMethods.Get("Usuario/Filtrar?Nome=&UsuarioAD=&Dominio=" + dominio, 1, _configuration["AppSettings:token"].ToString());

                _cache.Set(cacheKey, JsonConvert.DeserializeObject<List<Usuario>>(retornoFiltro.Content));

                listaUsuarios = (List<Usuario>)_cache.Get(cacheKey);
            }
            else if (houveAtualizacao == "true")
            {
                var retornoFiltro = httpMethods.Get("Usuario/Filtrar?Nome=" + nome + "&UsuarioAD=" + usuarioAD + "&Dominio=" + dominio, 1, _configuration["AppSettings:token"].ToString());

                listaUsuarios = JsonConvert.DeserializeObject<List<Usuario>>(retornoFiltro.Content);

                _cache.Remove(cacheKey);
            }
            else
                listaUsuarios = (List<Usuario>)_cache.Get(cacheKey);
            
            var listaRetorno = listaUsuarios.Where(x => x.Nome.ToUpper().Contains(nome.ToUpper()) && x.UsuarioAd.Contains(usuarioAD));

            MemoryCacheEntryOptions cacheExpirationOptions = new MemoryCacheEntryOptions();
            cacheExpirationOptions.AbsoluteExpiration = DateTime.Now.AddHours(2);
            cacheExpirationOptions.Priority = CacheItemPriority.Normal;

            return Json(listaRetorno);
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public void BuscarFuncionalidades()
        {
            HttpMethods httpMethods = new HttpMethods(_configuration["AppSettings:urlAuthentication"].ToString());

            var retornoFiltroMenu = httpMethods.Get("Funcionalidade/ListarHierarquia?idSistema=1", 1, _configuration["AppSettings:token"].ToString());
            var lista = JsonConvert.DeserializeObject<List<Menu>>(retornoFiltroMenu.Content);

            ViewBag.listaFuncionalidades = lista;
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public string SalvarControleAcesso(int idUsuario, string nomeUsuario, string usuarioAd, List<int> listaFuncionalidades)
        {
            HttpMethods httpMethods = new HttpMethods(_configuration["AppSettings:urlAuthentication"].ToString());

            var usuarioFuncionalidade = new UsuarioFuncionalidadeRequest();

            if (listaFuncionalidades.Count() > 0)
            {
                usuarioFuncionalidade = new UsuarioFuncionalidadeRequest()
                {
                    IdUsuario = idUsuario,
                    Nome = nomeUsuario,
                    UsuarioAD = usuarioAd,
                    Funcionalidades = listaFuncionalidades
                };

                var retornoFuncionalidade = httpMethods.Post("Usuario/SalvarFuncionalidade", usuarioFuncionalidade, _configuration["AppSettings:token"].ToString());

                if (retornoFuncionalidade.Content.Contains("200"))
                {
                    return "Dados salvos com sucesso!";
                }
                else
                {
                    return retornoFuncionalidade.Content;
                }
            }
            else
            {
                return "Nenhuma funcionalidade adicionada";
            }
        }
    }
}