﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RND.CBP.APP.Filters;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Service.Helper;
using System.Linq;
using System.Net;

namespace RND.CBP.APP.Controllers
{
    public class SistemaController : Controller
    {
        private readonly ISistemaService _sistemaService;
        private readonly IStatusSistemaService _statusSistemaService;
        private readonly IParametroRemessaService _parametroRemessaService;
        private readonly ITipoPeriodoService _tipoPeriodoService;
        private readonly IEmpresaGrupoService _empresaGrupoService;
        private readonly IElmahService _elmahService;

        const string sessionKey = "isLogged";

        public SistemaController(ISistemaService sistemaService
                                 , IStatusSistemaService statusSistemaService
                                 , IParametroRemessaService parametroRemessaService
                                 , ITipoPeriodoService tipoPeriodoService
                                 , IEmpresaGrupoService empresaGrupoService
                                 , IElmahService elmahService)
        {
            _sistemaService = sistemaService;
            _statusSistemaService = statusSistemaService;
            _parametroRemessaService = parametroRemessaService;
            _tipoPeriodoService = tipoPeriodoService;
            _empresaGrupoService = empresaGrupoService;
            _elmahService = elmahService;
        }

        [Authorize(Policy = "Sistema")]
        [ApiExplorerSettings(IgnoreApi = true)]
        public IActionResult Cadastro()
        {
            return View();
        }

        [Authorize(Policy = "Horario")]
        [ApiExplorerSettings(IgnoreApi = true)]
        public IActionResult Horario()
        {
            ViewBag.ListaSistemas = _sistemaService.ListarSistemas();
            ViewBag.ListaEmpresas = _empresaGrupoService.ListarEmpresaGrupo();

            return View();
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public JsonResult BuscarDadosTabela()
        {
            var listaSistemas = _sistemaService.ListarSistemas();

            return Json(listaSistemas);
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public JsonResult BuscarDadosTabelaHorarios(int sistema, int empresa, string tipoPessoa)
        {
            var listaItems = _parametroRemessaService.ListarParametroRemessaPorFiltro(sistema, empresa, tipoPessoa);

            return Json(listaItems);
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public JsonResult ListarStatusSistema()
        {
            var listaStatusSistemas = _statusSistemaService.ListarStatusSistema().ToList();

            return Json(listaStatusSistemas);
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public JsonResult ListarTipoPeriodo()
        {
            var listaTipoPeriodo = _tipoPeriodoService.ListarTipoPeriodo().ToList();

            return Json(listaTipoPeriodo);
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public bool UpsertSistema(int idSistema, string inputNomeSistema, string inputUrlSistema, int idStatusSistema)
        {
            try
            {
                return _sistemaService.UpsertSistema(idSistema, inputNomeSistema, inputUrlSistema, idStatusSistema);
            }
            catch (System.Exception ex)
            {
                _elmahService.ResponseExceptionAsync(ex);
                return false;
            }
        }

        [HttpPost]
        [ApiExplorerSettings(IgnoreApi = true)]
        public JsonResult UpsertParametroRemessa(Domain.DTOs.ParametroRemessaRequest objRequest)
        {
            try
            {
                var retornoValidacao = ValidaHorario(objRequest);

                if (retornoValidacao)
                {
                    _parametroRemessaService.UpsertParametroRemessa(objRequest);
                    return Json(new { success = true, responseText = "Ok" });
                }
                else return Json(new { success = true, responseText = "Já existe outro período cadastrado que abrange o mesmo horário informado" });
            }
            catch (System.Exception ex)
            {
                _elmahService.ResponseExceptionAsync(ex);
                return Json(new { success = false, responseText = "Ocorreu um erro durante o cadastro do horário." });
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public bool ExcluirParametroRemessa(int idParametroRemessa)
        {
            try
            {
                _parametroRemessaService.Excluir(idParametroRemessa);

                return true;
            }
            catch (System.Exception ex)
            {
                _elmahService.ResponseExceptionAsync(ex);
                return false;
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public bool ExcluirSistema(int idSistema)
        {
            try
            {
                _sistemaService.Excluir(idSistema);

                return true;
            }
            catch (System.Exception ex)
            {
                _elmahService.ResponseExceptionAsync(ex);
                return false;
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public bool ValidaHorario(Domain.DTOs.ParametroRemessaRequest parametro)
        {
            var listaConsultaParametros = _parametroRemessaService.BuscarParametroRemessaParaValidacao(parametro.SistemaId, 
                                                                                                    parametro.EmpresaGrupoId, 
                                                                                                    parametro.TipoPeriodoId, 
                                                                                                    parametro.CodigoTipoRemessa,
                                                                                                    parametro.TipoPessoa);

            foreach (var param in listaConsultaParametros)
            {
                if (parametro.Id > 0 && parametro.Id == param.Id && param.TipoPeriodoId == parametro.TipoPeriodoId)
                    return true;
                else
                {
                    var horaInicioOk = Helper.HoraInicioValida(parametro.HoraInicio, param.HoraInicioPeriodo, param.HoraFimPeriodo);
                    var horaFimOk = Helper.HoraFimValida(parametro.HoraFim, param.HoraInicioPeriodo, param.HoraFimPeriodo);

                    if (!horaInicioOk || !horaFimOk)
                        return false;
                }
            }

            return true;
        }

        [HttpGet]
        [Route("Sistema/Buscar")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ServiceFilter(typeof(AuthorizationActionFilter))]
        public ActionResult Buscar(int id, int empresa, string remessa, string horario, string tipoPessoa)
        {
            try
            {
                return Ok(_sistemaService.BuscarDadosSistema(id, empresa, remessa, horario, tipoPessoa));
            }
            catch (System.Exception ex)
            {
                return BadRequest(new { Status = HttpStatusCode.InternalServerError, Result = $"{ex.Message}" });
            }
        }

        [HttpGet]
        [Route("Sistema/StatusSistema")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ServiceFilter(typeof(AuthorizationActionFilter))]
        public ActionResult StatusSistema(int id)
        {
            try
            {
                return Ok(_sistemaService.StatusSistema(id));
            }
            catch (System.Exception ex)
            {
                return BadRequest(new { Status = HttpStatusCode.InternalServerError, Result = $"{ex.Message}" });
            }
        }
    }
}