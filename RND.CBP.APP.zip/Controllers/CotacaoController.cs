﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using RND.CBP.APP.Filters;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Services;

namespace RND.CBP.APP.Controllers
{
    public class CotacaoController : Controller
    {
        private readonly ICotacaoService _cotacaoService;

        public CotacaoController(ICotacaoService cotacaoService)
        {
            _cotacaoService = cotacaoService;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        [EnableCors("_permissaoOrigem")]
        [Route("Cotacao/Buscar")]
        [ProducesResponseType(typeof(Cotacao),200)]
        [ProducesResponseType(400)]  
        [ServiceFilter(typeof(AuthorizationActionFilter))]
        public ActionResult Buscar(string tipoPessoa, string numeroDocumento, decimal valor, string moedaSigla, DateTime dataHora)
        {
            try
            {
                return Ok(_cotacaoService.Buscar(tipoPessoa, numeroDocumento, valor, moedaSigla, dataHora));
            }
            catch (System.Exception ex)
            {
                return BadRequest(new { Status = HttpStatusCode.InternalServerError, Result = $"{ex.Message}" });
            }
        }
        [HttpGet]
        [Route("Cotacao/BuscarValor")]
        [ProducesResponseType(typeof(Cotacao), 200)]
        [ProducesResponseType(400)]
        [ServiceFilter(typeof(AuthorizationActionFilter))]
        public ActionResult BuscarValor(string tipoPessoa, string numeroDocumento, int Sistema, decimal valor, string moedaSigla, DateTime dataHora)
        {
            try
            {
                return Ok();
            }
            catch (System.Exception ex)
            {
                return BadRequest(new { Status = HttpStatusCode.InternalServerError, Result = $"{ex.Message}" });
            }
        }
    }
}