﻿namespace RND.CBP.APP.Models
{
    public class Acesso
    {
        public string Dominio { get; set; }
        public string Login { get; set; }
        public string Senha { get; set; }
        public string TipoEncodeSenha { get; set; }
        public string Chave { get; set; }
    }
}