﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using RND.CBP.Infra.Data.Transactions;

namespace RND.CBP.APP.Base
{
    public class BaseController : Controller
    {
        protected readonly IUnitOfWork _unitOfWork;
        protected readonly IConfiguration _configuration;

        public BaseController(IUnitOfWork unitOfWork, IConfiguration config)
        {
            _unitOfWork = unitOfWork;
            _configuration = config;
        }

        protected void Commit()
        {
            _unitOfWork.Commit();
        }

        protected new HttpResponseMessage Response(bool isValid, IList<string> Erros)
        {
            if (isValid)
            {
                _unitOfWork.Commit();
                return new HttpResponseMessage(HttpStatusCode.OK);
            }
            else
            {
                return new HttpResponseMessage(HttpStatusCode.OK);
            }

        }

        protected void ResponseExceptionAsync(Exception ex)
        {
            //var sqlErrorLog = new ElmahCore.Sql.SqlErrorLog(_configuration["ConnectionStrings:APIInMesaCambio"].ToString());
            //sqlErrorLog.Log(new ElmahCore.Error(ex));
        }

        protected override void Dispose(bool disposing)
        {
            if (_unitOfWork != null)
                _unitOfWork.Dispose();

            base.Dispose(disposing);
        }
    }
}