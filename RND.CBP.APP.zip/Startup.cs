﻿using ElmahCore.Mvc;
using ElmahCore.Sql;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RND.CBP.APP.Filters;
using RND.CBP.Domain.DTOs.Authorization;
using RND.CBP.Domain.Interfaces;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Infra.Data.Context;
using RND.CBP.Infra.Data.Repository;
using RND.CBP.Infra.Data.Transactions;
using RND.CBP.Service.Services;
using RND.CBP.Service.Validators;
using Swashbuckle.AspNetCore.Swagger;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RND.CBP.APP
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("_permissaoOrigem",
                builder =>
                {
                    builder.WithOrigins("http://cotacao.com.br");
                });
            });

            services.AddMvc();
            services.AddMemoryCache();

            #region AuthorizationPolicy
            services.AddSingleton<IAuthorizationHandler, AcessoHandler>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddAuthorization(options =>
            {
                options.AddPolicy("Acesso", policy => policy.Requirements.Add(new PaginaRequirement(1)));
                options.AddPolicy("Remessa", policy => policy.Requirements.Add(new PaginaRequirement(2)));
                options.AddPolicy("Tarifa", policy => policy.Requirements.Add(new PaginaRequirement(3)));
                options.AddPolicy("TarifaCusto", policy => policy.Requirements.Add(new PaginaRequirement(4)));
                options.AddPolicy("TarifaValor", policy => policy.Requirements.Add(new PaginaRequirement(5)));
                options.AddPolicy("Sistema", policy => policy.Requirements.Add(new PaginaRequirement(6)));
                options.AddPolicy("Horario", policy => policy.Requirements.Add(new PaginaRequirement(7)));
            });
            #endregion

            #region Injeção de Dependência
            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddScoped<IEmpresaService, EmpresaService>();
            services.AddScoped<IEmpresaRepository, EmpresaRepository>();
            services.AddScoped<ITipoAplicacaoService, TipoAplicacaoService>();
            services.AddScoped<ITipoAplicacaoRepository, TipoAplicacaoRepository>();
            services.AddScoped<IBancoRemessaRepository, BancoRemessaRepository>();
            services.AddScoped<ITarifaDetalheService, TarifaDetalheService>();
            services.AddScoped<ITarifaDetalheRepository, TarifaDetalheRepository>();
            services.AddScoped<ITarifaRepository, TarifaRepository>();
            services.AddScoped<IBancoRemessaService, BancoRemessaService>();
            services.AddScoped<IRemessaRepository, RemessaRepository>();
            services.AddScoped<IRemessaService, RemessaService>();
            services.AddScoped<IDominioService, DominioService>();
            services.AddScoped<IDominioRepository, DominioRepository>();
            services.AddScoped<IPaisService, PaisService>();
            services.AddScoped<IPaisRepository, PaisRepository>();
            services.AddScoped<ISistemaService, SistemaService>();
            services.AddScoped<ISistemaRepository, SistemaRepository>();
            services.AddScoped<IStatusSistemaService, StatusSistemaService>();
            services.AddScoped<IStatusSistemaRepository, StatusSistemaRepository>();
            services.AddScoped<IParametroRemessaService, ParametroRemessaService>();
            services.AddScoped<IParametroRemessaRepository, ParametroRemessaRepository>();
            services.AddScoped<ITipoPeriodoService, TipoPeriodoService>();
            services.AddScoped<ITipoPeriodoRepository, TipoPeriodoRepository>();
            services.AddScoped<IFeriadoRepository, FeriadoRepository>();
            services.AddScoped<IEmpresaGrupoService, EmpresaGrupoService>();
            services.AddScoped<IEmpresaGrupoRepository, EmpresaGrupoRepository>();
            services.AddScoped<ICotacaoService, CotacaoService>();
            services.AddScoped<ICotacaoRepository, CotacaoRepository>();
            services.AddScoped<IMoedaService, MoedaService>();
            services.AddScoped<IMoedaRepository, MoedaRepository>();
            services.AddScoped<IMoedaCambioOnlineRepository, MoedaCambioOnlineRepository>();
            #endregion

            #region Elmah

            services.AddScoped<IElmahService, ElmahService>();
            services.AddScoped<IELMAH_ErrorRepository, ELMAH_ErrorRepository>();

            services.AddElmah<SqlErrorLog>(options =>
            {
                options.Path = new PathString("/elmah");
                options.ConnectionString = options.ConnectionString = Configuration.GetConnectionString("CBP");
            });

            #endregion         

            #region Filters

            services.AddScoped<AuthorizationActionFilter>();

            #endregion

            #region Swagger

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    Title = "CBP API",
                    Description = "Description CBP API",
                    TermsOfService = "None",

                    Contact = new Contact() { Name = "CrossBorderPayment", Email = "jefferson.paulo.ext@cotacao.com.br", Url = "www.rendimento.com" }

                });
                c.AddSecurityDefinition("Token",
                     new ApiKeyScheme
                     {
                         In = "header",
                         Description = "Please enter into field the word 'Token' following by space and JWT",
                         Name = "Token",
                         Type = "apiKey"
                     });
                c.AddSecurityRequirement(new Dictionary<string, IEnumerable<string>> {
                    { "Token", Enumerable.Empty<string>() }
                });
            });

            #endregion

            services.AddSession();

            services.AddSession(options => {
                options.IdleTimeout = TimeSpan.FromMinutes(30); 
            });

            services.AddDbContext<SqlContext>(option => option.UseSqlServer(Configuration.GetConnectionString("CBP"), opt => opt.UseRowNumberForPaging()));
            services.AddDbContext<IkVarejoContext>(option => option.UseSqlServer(Configuration.GetConnectionString("Varejo"), opt => opt.UseRowNumberForPaging()));
            services.AddDbContext<DbFeriadoContext>(option => option.UseSqlServer(Configuration.GetConnectionString("DBFERIADO"), opt => opt.UseRowNumberForPaging()));
            services.AddDbContext<VarejoContext>(option => option.UseSqlServer(Configuration.GetConnectionString("TMoeda"), opt => opt.UseRowNumberForPaging()));
            services.AddDbContext<DBVarejoContext>(option => option.UseSqlServer(Configuration.GetConnectionString("DbVarejo"), opt => opt.UseRowNumberForPaging()));
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseBrowserLink();
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseDeveloperExceptionPage();
                //app.UseExceptionHandler("/Home/Error");
            }

            app.UseCors("_permissaoOrigem");

            app.UseStaticFiles();

            app.UseSession();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Login}/{action=Index}/{id?}");
            });

            #region Swagger

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("../swagger/v1/swagger.json", "CrossBorderPayment API V 1.0");

            });

            #endregion

            #region ElmahCore

            app.UseElmah();

            #endregion
        }
    }
}
