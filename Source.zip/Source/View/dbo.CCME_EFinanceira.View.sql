USE IK_Varejo

GO
        
ALTER VIEW [dbo].[CCME_EFinanceira]              
AS              
--View CCME_EFinanceira              
             
--declare @DataInicio date              
--declare @DataFim date              
--set @DataInicio ='2016-01-01 00:00:00.000'              
--set @DataFim ='2016-06-30 00:00:00.000'               
           
              
SELECT               
ID,              
TipoArquivo,              
AmbienteDados,              
AplicativoUtilizado,              
VersaoSistemaInfoCCME,              
cnpjDeclarante,              
tpNI_Declarado,              
tpDeclarado,              
NIDeclarado,              
NomeDoDeclarado,              
DataNasc_Declarado,              
EnderecoLivre_Declarado,              
isnull(PaisEndereco_Declarado,'') PaisEnderecoDeclarado,              
isnull(PaisNacionalidade_Declarado,'') PaisNacionalidadeDeclarado,              
isnull(tpNI_Proprietario,'') tpNIProprietario,              
isnull(NIPropriet�rio,'') NIPropriet�rio,              
isnull(CampoNome_Proprietario,'') CampoNomeProprietario,              
isnull(EnderecoLivre_Proprietario,'') EnderecoLivreProprietario,              
isnull(PaisEndereco_Proprietario,'') PaisEnderecoProprietario,              
isnull(PaisResid_Proprietario,'') PaisResidProprietario,              
isnull(PaisNacionalidade_Proprietario,'') PaisNacionalidadeProprietario,              
DataNasc_Proprietario,              
isnull(Reportavel_Pais,'') ReportavelPais,              
anomescaixa,              
isnull(PAIS,'') PAIS,              
subTipoConta,              
tpNumConta,          
--AgenciaConta,              
NumConta,              
tpRelacaoDeclarado,              
NoTitulares,              
dtEncerramentoConta,              
isnull(vlrUltDia,0) ValorUltDia,              
PgtosAcum,              
tpPgto,              
totPgtoAcum,              
--mov_cliente,               
--mov_moeda,               
--moe_codigo,              
isnull(Sum(totCreditos),0) TotalCreditos,              
isnull(sum(totDebitos),0) TotalDebitos,              
totCreditosMesmaTitularidade,              
totDebitosMesmaTitularidade,          
AgenciaConta          
--Venda              
              
FROM              
              
(select               
'ID'+substring(c.cl_num_doc,1,11) ID,              
'1' TipoArquivo, -- 1 - Arquivo original /2 - Retificacao espontanea/3 - Retificacao a pedido da Receita              
'1' AmbienteDados, -- 1 producao / 2 homologacao              
'1' AplicativoUtilizado, -- 1 = emissao p/ Receita com aplicativo da empresa / 2 = outros              
'4.3.1' VersaoSistemaInfoCCME, -- Vers�o do Sistema utilizado CCME.              
'68900810000138' cnpjDeclarante,              
case when c.cl_tip_doc = 'CNPJ' then 2 else 1 end tpNI_Declarado,              
--case when c.cl_nacionalidade = 'ESTADOS UNIDOS' THEN 'FATCA105' ELSE '' END tpDeclarado,               
TPDECLARADO tpDeclarado,          
c.cl_num_doc NIDeclarado,              
case when c.cl_tip_doc = 'CNPJ' then substring(c.cl_razao_social,1,100) else substring(c.cl_nome,1,100) end NomeDoDeclarado,              
case when c.cl_dt_nasc is null then '' else c.cl_dt_nasc end DataNasc_Declarado,              
substring((c.cl_endereco+' '+c.cl_complemento+' '+c.cl_bairro+' '+c.cl_cidade+' '+c.cl_estado),1,200) EnderecoLivre_Declarado,              
isnull(P1.SWIFT,'') PaisEndereco_Declarado,              
isnull(Pessoas.CODPAIS,'') PaisNacionalidade_Declarado,          
--isnull(P.SWIFT,'') PaisNacionalidade_Declarado,            
isnull(TIPO_Proprietario,'') tpNI_Proprietario,              
isnull(NIPropriet�rio,'') NIPropriet�rio,              
isnull(CampoNome_Proprietario,'') CampoNome_Proprietario,              
isnull(EnderecoLivre_Proprietario,'') EnderecoLivre_Proprietario,              
isnull(PaisEndereco_Proprietario,'') PaisEndereco_Proprietario,              
isnull(PaisResid_Proprietario,'') PaisResid_Proprietario,              
isnull(PaisNacionalidade_Proprietario,'') PaisNacionalidade_Proprietario,              
'' DataNasc_Proprietario, -- N�o tem Autbank              
isnull(PaisNacionalidade_Proprietario,'') Reportavel_Pais,              
CONVERT(CHAR(4),YEAR(m.mov_data2))+               
REPLICATE('0',2-LEN((CONVERT(CHAR(2),MONTH(m.mov_data2)))) )+(CONVERT(CHAR(2),MONTH(m.mov_data2)))anomescaixa,              
'' PAIS,              
'101' subTipoConta,              
'OECD605' tpNumConta,              
'0001' AgenciaConta,          
rtrim(ltrim(cast(C.id_cliente as varchar(30)))) NumConta, -- Utilizar o id_cliente como numero da conta.              
'1' tpRelacaoDeclarado,              
'1' NoTitulares,               
'' dtEncerramentoConta, -- Verificar com Igor. N�o achei info preenchida no campo ct_data_encerramento              
case when MONTH(m.mov_data2)= 12 then vlrUltDia else 0 end vlrUltDia,              
-- Se data encerramento preenchida saldo � do �ltimo dia antes do fechamento.              
-- Se anomescaixa = 12 - saldo do ultima dia do ano. - Verificar com Igor.              
999 PgtosAcum,               
999 tpPgto,               
0.00 totPgtoAcum,               
m.mov_cliente,               
m.mov_moeda,               
mo.moe_codigo,              
--m.mov_tipo,               
-- m.mov_valor, -- Neste valor pode vir a tarifa junto.              
ISNULL((case               
     when mov_tipo='C' and m.mov_moeda <> 'BRL' then ISNULL(sum(m.mov_valor),0) * isnull(PTAX_VENDA.Venda,0)               
     when mov_tipo='C' and m.mov_moeda = 'BRL' then ISNULL(sum(m.mov_valor),0) End ),0) totCreditos,              
ISNULL((case               
     when mov_tipo='D' and m.mov_moeda <> 'BRL' then ISNULL(sum(m.mov_valor),0) * isnull(PTAX_VENDA.Venda,0)               
     when mov_tipo='D' and m.mov_moeda = 'BRL' then ISNULL(sum(m.mov_valor),0) End),0) totDebitos,              
totCreditosMesmaTitularidade=0.00,              
totDebitosMesmaTitularidade=0.00,              
isnull(PTAX_VENDA.Venda,0) PTAX_VENDA              
              
from TBL_ME_MOVIMENTACAO M with(nolock)              
left join TBL_ME_HISTORICO H with(nolock) on M.mov_historico=H.his_codigo               
left join TBL_CLIENTES C with(nolock) on C.id_cliente = M.mov_cliente               
              
left join TBL_Paises PA1 with(nolock) on c.cl_pais = PA1.Pais                
left join LKD_CAMBIO.CAMBIO.dbo.DB03 P1 with(nolock) on c.cl_pais=P1.NOMEP or PA1.Codigo=P1.PAIS               
              
left join TBL_Paises PA with(nolock) on c.cl_nacionalidade = PA.Pais                
--left join LKD_CAMBIO.CAMBIO.dbo.DB03 P with(nolock) on c.cl_nacionalidade=P.NOMEP or PA.Codigo=P.PAIS               
left join (           
             
select               
isnull(p.nome,'') as CampoNome_Proprietario              
, isnull(p.TIPOPESSOA,'') as TIPO_Proprietario              
, isnull(p.CGC_CPF,'') as NIPropriet�rio              
, isnull(p.CODPAIS,'') as PaisNacionalidade_Proprietario              
, isnull(par.PERPARTICIPACAO,0) as porcent              
,isnull(par.NOME,'') as nome_emp              
, isnull(par.CGCGRUPO,0) as cnpj_emp              
, isnull(ende.ENDERECO,'') as EnderecoLivre_Proprietario              
, isnull(ende.CODPAIS,'') as PaisEndereco_Proprietario              
, isnull(p.CODPAIS_DOMICILIADO_EXTERIOR,'') as PaisResid_Proprietario              
from autbank_lks.ab_infobanc.dbo.PARTICIPACOES as par              
left join autbank_lks.ab_infobanc.dbo.PESSOAS as p              
on par.CGC_CPF = p.CGC_CPF              
left join autbank_lks.ab_infobanc.dbo.ENDERECOS as ende              
on par.CGC_CPF = ende.CGC_CPF          
          
) Acionista on Acionista.cnpj_emp=C.cl_num_doc               
          
left join TBL_MOEDAS MO on MO.moe_simbolo=m.mov_moeda              
left join (              
Select Venda=Lvenda, MOEDA, data  from               
LKD_CAMBIO.CAMBIO.dbo.DB05 WITH(NOLOCK)               
where tipo = 1               
) PTAX_VENDA on PTAX_VENDA.MOEDA = mo.moe_codigo and PTAX_VENDA.DATA = dbo.fc_Verifica_FinaldeSemanaFeriado_anterior(DATEADD(d, -DAY(m.mov_data2),DATEADD(m,1,m.mov_data2)))      
            
left join (              
select             
id_cliente,            
sub_data_historico,            
sum(isnull(vlrReais,0)) vlrUltDia            
from            
(select             
h.id_cliente,            
h.sub_data_historico,            
case                 
    when h.cod_moeda <> 'BRL' then isnull(h.sub_sdodia0,0)* isnull(PTAX.Lvenda,0)             
    else isnull(h.sub_sdodia0,0)end vlrReais            
from TBL_ME_SUBCONTA_HISTORICO H with(nolock)              
left join LKD_CAMBIO.CAMBIO.dbo.DB05 PTAX WITH(NOLOCK) on PTAX.MOEDA = h.id_moeda            
where tipo = 1 and            
day(h.sub_data_historico)= DAY(PTAX.data)and            
month(h.sub_data_historico)= month(PTAX.data) and            
year(h.sub_data_historico)= year(PTAX.data)) as SaldoUltimoDia            
group by             
id_cliente,            
sub_data_historico            
) SaldoDia on SaldoDia.id_cliente = c.id_cliente and               
month(SaldoDia.sub_data_historico)= MONTH (DATEADD(d, -DAY(m.mov_data2),DATEADD(m,1,m.mov_data2))) and              
year(SaldoDia.sub_data_historico)= year (DATEADD(d, -DAY(m.mov_data2),DATEADD(m,1,m.mov_data2))) and              
day(SaldoDia.sub_data_historico)= day (dbo.fc_Verifica_FinaldeSemanaFeriado_anterior(DATEADD(d, -DAY(m.mov_data2),DATEADD(m,1,m.mov_data2))))              
          
left join (          
SELECT DISTINCT CGC_CPF CGC_CPF,           
    NOME NOME,           
    CODFATCA CODFATCA,          
    CODPAIS CODPAIS,           
    CASE WHEN CODFATCA IN ('01', '03') AND CODPAIS = 'US' THEN 'FATCA104'          
       WHEN CODFATCA IN ('04', '06', '07') AND CODPAIS = 'US' THEN 'FATCA101'          
       WHEN CODFATCA IN ('10') AND CODPAIS = 'US' THEN 'FATCA102'          
       WHEN CODFATCA IN ('05') AND CODPAIS = 'US' THEN 'FATCA103'          
       WHEN CODFATCA IN ('11') AND CODPAIS = 'US' THEN 'FATCA105'           
       ELSE '' END AS TPDECLARADO          
FROM autbank_lks.ab_infobanc.dbo.PESSOAS          
WHERE CODFATCA IN  ('01', '03', '04', '06', '07', '10', '05', '11')          
)  TipoDeclarado  on TipoDeclarado.CGC_CPF=C.cl_num_doc            
              
left join (          
select CODPAIS,CGC_CPF from autbank_lks.ab_infobanc.dbo.PESSOAS with(nolock) ) Pessoas          
on Pessoas.CGC_CPF=C.cl_num_doc           
              
where               
-- m.mov_data2 >= @DataInicio and m.mov_data2 <= @DataFim and               
--m.mov_data2 >= '2017-03-01 00:00:00.000' and m.mov_data2 < '2017-05-01 00:00:00.000' and        
h.his_descricao not like '%estorno%' and               
m.mov_flag_disp <> 'B' -- Saldo bloqueado n�o considerar.              
              
group by              
              
'ID'+substring(c.cl_num_doc,1,11),               
case when c.cl_tip_doc = 'CNPJ' then 2 else 1 end,              
TPDECLARADO,          
--case when c.cl_nacionalidade = 'ESTADOS UNIDOS' THEN 'FATCA105' ELSE '' END,               
c.cl_num_doc,              
case when c.cl_tip_doc = 'CNPJ' then substring(c.cl_razao_social,1,100) else substring(c.cl_nome,1,100) end,              
case when c.cl_dt_nasc is null then '' else c.cl_dt_nasc end,              
substring((c.cl_endereco+' '+c.cl_complemento+' '+c.cl_bairro+' '+c.cl_cidade+' '+c.cl_estado),1,200),              
P1.SWIFT,              
Pessoas.CODPAIS,          
--P.SWIFT,              
TIPO_Proprietario,              
NIPropriet�rio,              
CampoNome_Proprietario,              
EnderecoLivre_Proprietario,              
PaisEndereco_Proprietario,              
PaisResid_Proprietario,               
PaisNacionalidade_Proprietario,              
PaisNacionalidade_Proprietario,              
CONVERT(CHAR(4),YEAR(m.mov_data2))+               
REPLICATE('0',2-LEN((CONVERT(CHAR(2),MONTH(m.mov_data2)))) )+(CONVERT(CHAR(2),MONTH(m.mov_data2))),             
rtrim(ltrim(cast(C.id_cliente as varchar(30)))),               
MONTH(m.mov_data2),              
m.mov_cliente,               
m.mov_moeda,               
mo.moe_codigo,              
PTAX_VENDA.Venda,              
M.mov_tipo,            
SaldoDia.vlrUltDia) CCME_EFINANCEIRA              
              
group by              
              
ID,              
TipoArquivo,              
AmbienteDados,              
AplicativoUtilizado,              
VersaoSistemaInfoCCME,              
cnpjDeclarante,              
tpNI_Declarado,              
tpDeclarado,              
NIDeclarado,              
NomeDoDeclarado,              
DataNasc_Declarado,              
EnderecoLivre_Declarado,              
PaisEndereco_Declarado,      
PaisNacionalidade_Declarado,              
tpNI_Proprietario,              
NIPropriet�rio,              
CampoNome_Proprietario,              
EnderecoLivre_Proprietario,              
PaisEndereco_Proprietario,              
PaisResid_Proprietario,              
PaisNacionalidade_Proprietario,              
DataNasc_Proprietario,              
Reportavel_Pais,              
anomescaixa,              
PAIS,              
subTipoConta,              
tpNumConta,           
AgenciaConta,             
NumConta,              
tpRelacaoDeclarado,              
NoTitulares,              
dtEncerramentoConta,              
PgtosAcum,              
tpPgto,              
totPgtoAcum,              
totCreditosMesmaTitularidade,              
totDebitosMesmaTitularidade,            
vlrUltDia              
              
--Venda              
              
-- Dt Encerramento ou se mescaixa = 12              
-- Saldo um dia antes do encerramento.              
-- Criar outro select para somar valores, ao agrupar considera um nao soma...              
              
-- Ver com Igor saldo da CCME. -- Apos 5 da tarde - rotina. (Verificar um horario mais tarde)              
-- Criar uma rotina para gravar o saldo todos os dias da CCME - Fotografia.              
-- Criar job para carregar dados.              
              
-- Fechamento da conta:               
--select * from tbl_me_subconta / TBL_ME_SUBCONTA_HISTORICO-- Saldo conta - Criar uma tabela para compor saldo.              
-- id_cliente e moeda              
-- Data consulta da view              
              
/*              
              
                select top 100 *               
from TBL_MEWEB_LOG  as l with(nolock)              
inner join tbl_users  as u with(nolock) on u.id_user = l.log_li_id              
where log_descricao like '%desativou%'              
order by log_li_id desc              
              
select from TBL_MEWEB_LOG               
where log_descricao like '%desativou%'              
              
select cl_nome ,* from TBL_CLIENTES               
where id_cliente = 82              
              
Usu�rio CCME WEB Admin desativou a conta ATD do cliente VICTORIANO VILLANUEVA ACUNA              
              
*/              
/*              
              
select * from TBL_ME_MOVIMENTACAO               
where mov_cliente = 133350 and mov_tipo = 'D' and mov_moeda = 'USD' and year(mov_data2)=2015 and              
MONTH(mov_data2) = 11              
              
and mov_valor = 77.012 */ 