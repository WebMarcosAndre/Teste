Use IK_Varejo
go

if object_id('fn_QuebraEm100')is not null
	Drop Function dbo.fn_QuebraEm100
;
go


CREATE FUNCTION dbo.fn_QuebraEm100 
(
	@Texto	Varchar(max)
)
RETURNS Varchar(max)	
AS
-- ===========================================================================================
-- Author:		C�ssio Drezza
-- Create date: 31/out/2018
-- Description:	Adiciona LF+TAB a cada 100 caracteres para uso em hint de relat�rios SSRS
--				o TAB foi trocado por Espa�o n�o separ�vel '�'=Char(160) para garantir a formata��o em HTML
--				563454-629931 - Controle de Compliance por Cliente p/ Relat�rio	[Controle de Compliance por Cliente.rdl]
--				563452-629926 - Controle de Cr�dito por Cliente p/ Relat�rio	[Controle de Credito por Cliente.rdl]
--	19-11-2018 -Retorna o texto "Nenhum coment�rio." caso seja vazio
--	24/01/2019 -Retorna vazio caso seja NULL
-- ===========================================================================================
/*

DECLARE @texto VARCHAR(max) = '2015-08-21'+char(10)+'Bispo da Diocese de S�o Luis de Montes Belos, esteve na Filial em 2008 por Indica��o do Sr. Francisco Julio da CNBB em Bras�lia, para realizar trocas de cheques em euros de sua conta pessoal no exterior
 referente a valores enviados como doa��o feita pela CONFERENCIA EPISCOPAL DO VATICANO para pagamentos de despesas feitas no Brasil. Temos experi�ncias anteriores em trocas de cheques desse cliente. J� realizamos c�mbio de at�  EUR 100.000,00 que na �poca
 foi aprovado pelo Sr. Abramo. Rog�rio se sente confort�vel com esse c�mbio.
Estamos solicitando ficha de cadastro atualizada, c�pia da RNE com nova validade e comprovante de resid�ncia para atualiza��o de cadastro.'
--*/
BEGIN
	Declare @tl VarChar(2) = Char(10) ,
			@Qb SmallInt   = 140
	;
	Declare @i int = 0
		  , @l int = 0
		  , @f int = 0		-- Soma um char(10) no texto para garantir q a �ltima linha apare�a
		  , @t Varchar(max) = Replace( Replace( IsNull(@texto,'') +Char(10) , Char(13)+Char(10), Char(10)) , Char(10), @tl )
		  , @h Varchar(max)
		  , @p Varchar(max)
	;
	Declare @a table ( seq int Primary key, Linha VarChar(max) )
	Declare @b table ( seq int Primary key, Linha VarChar(max) )
	;
	-- insere as linha na tabela @a
	Set @h=@t
	;--print @t; print CharIndex(@tl, @h, 0 ) ; 
	While CharIndex( @tl, @h, 0 )>0 begin
		Insert @a ( seq, Linha )
			Select @i, Left( @h, CharIndex(@tl, @h, 0 ) )
		;
		Set @h=Substring( @h, CharIndex(@tl, @h, 0 )+Len(@tl), len(@h) )
		;
		Set @i = @i + 100
		;
	End
	;
	Set @i = 0
	;
	Declare @PP int = 0
	-- Insere LF no espa�o mais pr�ximo a cada @Qb+Space caracteres
	While @i <= ( Select Max( seq ) From @a ) Begin
		Select @p=Linha, @l=Len(Linha), @f=Seq From @a Where Seq=@i
		;
		if @l>=@Qb Begin
			Select @PP = Len(@p)
			;
			While @PP>=@Qb Begin
				Set @PP = CharIndex(' ', @p, @Qb)		-- Pega a posi��o do 1� espa�o ap�s a base da quebra de linha @Qb
				;										-- Print  'ln.64 @PP: '+ Cast( @PP as Varchar)
				if @PP=0 Set @PP = @Qb -- Len(@p)		-- Se n�o tiver um espa�o @PP=0 p�e a proxima posi��o  = @Qb
				;										-- 
				Insert @b ( seq, Linha )				-- 
					Select @f, Left( @p, @PP )			-- insere a por��o do texto at� @PP (proxima posi��o)
				;										-- 
				Set @p = Substring( @p, @PP+1, len(@p) )	-- retira do texto @p a parte j� inserida 
				; -- Select @i 							-- 
				Set @PP = CharIndex(' ', @p, @Qb)		-- Pega a posi��o do 1� espa�o ap�s a base da quebra de linha @Qb no texto j� cortado
				;										-- 
				if @PP=0 Set @PP = Len(@p)				-- Se n�o tiver um espa�o @PP=0 p�e a proxima posi��o  = comprim.do texto 
				;										-- 
				-- print '@l: '+ Cast( @l as Varchar) +'-- @PP: '+ Cast( @PP as Varchar) +' CharIndex: '+ Cast( CharIndex(' ', @p, @Qb) as Varchar) +' @p: '+ @p
				Set @f = @f + 1							-- Soma 1 na Seq de linha 100,200,etc
				;										-- 
			End
			;
			Insert @b ( seq, Linha )					-- Insere o final do texto
				Select @f, @p -- +Case When CharIndex(@tl, @p, 0)>0 then '' Else @tl End
			;
			Set @l = Len(@p)							-- p�e o compr.da �lt.linha
			;
		  End
		Else
			Insert @b ( seq, Linha )
				Select @i, @p
		;
		Set @i = @i + 100	-- vai p/ a prox. Seq de linha 100,200,etc
		;
	End
	;
	Update @b set Linha = Replace( Linha, char(10), '')
	;
	Set @T=''
	; -- Monta o texto novamente agora com as quebras de linha em @Qb+Space e identa��o TAB+Space(6) Space(21)=Replicate(10
	Select @T= @T + Replace(Case Right(cast(seq as varchar),2)
								When '0'  then lTrim(Linha)
								When '00' then Char(10)+Space(21)+ lTrim(Linha)
								Else Char(10)+Space(21+6) + lTrim(Linha)
							End 
						,' ', Char(160) ) -- Espa�o n�o separ�vel '�'=Char(160) para garantir a formata��o em HTML
		From @b where Len(rTrim(linha))>0 
		Order by Seq
	;  -- Print @t
	Select @T = Case when lTrim(rTrim( @T ))='' then 'Nenhum coment�rio.' else @T End
	;
--Select * from @a ; Select Right(cast(seq as varchar),2) ,* from @b ; 
	RETURN @T
	;
END
;
