Use Ik_Varejo
go

if object_id('fn_TextoRel')is not null
	Drop Function dbo.fn_TextoRel
;
go


CREATE FUNCTION dbo.fn_TextoRel 
(
	  @id Int
	, @tp Char(2)
	, @ni VarChar(8)=Null
)
RETURNS VarChar(max)
AS
/*
-- ===========================================================================================
-- Author:		C�ssio Drezza
-- Create date: 21/nov/2018
-- Description:	Retorna o Texto de Compliance ou Credito j� formatado para os relat�rios SSRS
--				563454-629931 - Controle de Compliance por Cliente p/ Relat�rio	[Controle de Compliance por Cliente.rdl]
--				563452-629926 - Controle de Cr�dito por Cliente p/ Relat�rio	[Controle de Credito por Cliente.rdl]
-- Alterado em 13/dez/18 : Retirado o texto '�N�o houve mudan�a de n�vel' e datas p/[dd.mmm.aaaa], a pedido da Cinthia
--			   02/jan/19 : Acertado o g�nero do texto do Status e sempre apresentar os coment�rios
--			   24/jan/19 : Corrigido o par�metro para pesquisa de altera��o de n�vel/sem alterar de n�vel
-- ===========================================================================================

--DECLARE @id int =  7647, @ni VarChar(8)='5', @tp Char(2)='CO'
--DECLARE @id int = 13846, @ni VarChar(8)='D', @tp Char(2)='CR'
--*/
BEGIN
	Declare @T VarChar(max) ='', @LF char(1)=Char(10), @st char(1), @s char(1)='.'
	;
	If @ni is null Set @st='O' Else Set @st='C' -- @ni=NULL Traz a �ltima aprova��o de sem alterar de n�vel
	;
	Select @T = 
	  IsNull(( SELECT Top 1  '�[Dat.Solic'+@s+']: '+lower(Replace(Convert(Varchar(11), IsNull(Sol_Data, '1900-1-1'),106),' ','.')) -- De[aaaa-mm-dd]121 p/[dd.mmm.aaaa]106
				+@LF+'[STATUS   ]: [' + Case IsNull(sol_reprovada,'S') 
											when 'S' then 'REPROVADO'
											when 'N' then 'APROVADO em '
														+lower(Replace(Convert(Varchar(11), IsNull(sol_data_aprovacao, '1900-1-1'),106),' ','.')) -- De[aaaa-mm-dd]121 p/[dd.mmm.aaaa]106  
											Else '-' End + ']'	
				+@LF+'[N�v.Atual ]: [' + IsNull(sol_ni_atual,'') + ']'
				+@LF+'[N�v.Solic. ]: [' + IsNull(sol_ni_novo,'')  + ']'
				+@LF+'[Descri��o]: ' + dbo.fn_QuebraEm100( Cast(s.sol_descricao as VarChar(max)) )
				+@LF+'[Coment.OP:'+ dbo.fn_RN(sol_cod_ap_operador)  +']: ' + dbo.fn_QuebraEm100( Cast(s.sol_coment_operador  as VarChar(max)) )  
				+@LF+'[Coment.GC:'+ dbo.fn_RN(sol_cod_ap_gerente_c) +']: ' + dbo.fn_QuebraEm100( Cast(s.sol_coment_gerente_c as VarChar(max)) )
				+@LF+'[Coment.GB:'+ dbo.fn_RN(sol_cod_ap_gerente_b) +']: ' + dbo.fn_QuebraEm100( Cast(s.sol_coment_gerente_b as VarChar(max)) )
				+@LF+'[Coment.D1:'+ dbo.fn_RN(sol_cod_ap_diretor1)  +']: ' + dbo.fn_QuebraEm100( Cast(s.sol_coment_diretor1  as VarChar(max)) )  
				+@LF+'[Coment.D2:'+ dbo.fn_RN(sol_cod_ap_diretor2)  +']: ' + dbo.fn_QuebraEm100( Cast(s.sol_coment_diretor2  as VarChar(max)) )  
			FROM dbVarejo.dbo.TBL_Solicitacoes s with(nolock)
			WHERE id_cliente = @id 
				AND sol_tipo = @tp  -- COmpliance ou CR�dito
				AND sol_sub_tipo = @st 
				AND sol_ni_novo = isNull(@ni, sol_ni_novo)
			--	AND sol_ni_atual = @tp_Atu
			ORDER BY sol_data DESC 
			)
		, '' )	-- Retirado a pedido da Cinthia em 13/dez/18 '�N�o houve mudan�a de n�vel'
	+ IsNull(( SELECT Top 1  '�[Dat.Solic'+@s+']: '+lower(Replace(Convert(Varchar(11), IsNull(Sol_Data, '1900-1-1'),106),' ','.'))-- De[aaaa-mm-dd]121 p/[dd.mmm.aaaa]106
				+@LF+'[STATUS   ]: [' + Case IsNull(sol_reprovada,'S')  
											when 'S' then 'REPROVADO'
											when 'N' then 'APROVADO em '
														+lower(Replace(Convert(Varchar(11), IsNull(sol_data_aprovacao, '1900-1-1'),106),' ','.')) -- De[aaaa-mm-dd]121 p/[dd.mmm.aaaa]106  
											Else '-' End + ']'
				+@LF+'[N�v.Atual ]: [' + IsNull(sol_ni_atual,'') + ']'
				+@LF+'[N�v.Solic. ]: [' + IsNull(sol_ni_novo,'')  + ']'
				+@LF+'[Descri��o]: ' + dbo.fn_QuebraEm100( Cast(s.sol_descricao as VarChar(max)) )
				+@LF+'[Coment.OP:'+ dbo.fn_RN(sol_cod_ap_operador)  +']: ' + dbo.fn_QuebraEm100( Cast(s.sol_coment_operador  as VarChar(max)) )  
				+@LF+'[Coment.GC:'+ dbo.fn_RN(sol_cod_ap_gerente_c) +']: ' + dbo.fn_QuebraEm100( Cast(s.sol_coment_gerente_c as VarChar(max)) )
				+@LF+'[Coment.GB:'+ dbo.fn_RN(sol_cod_ap_gerente_b) +']: ' + dbo.fn_QuebraEm100( Cast(s.sol_coment_gerente_b as VarChar(max)) )
				+@LF+'[Coment.D1:'+ dbo.fn_RN(sol_cod_ap_diretor1)  +']: ' + dbo.fn_QuebraEm100( Cast(s.sol_coment_diretor1  as VarChar(max)) )  
				+@LF+'[Coment.D2:'+ dbo.fn_RN(sol_cod_ap_diretor2)  +']: ' + dbo.fn_QuebraEm100( Cast(s.sol_coment_diretor2  as VarChar(max)) )    --  select *--top 9 *
			FROM IK_Varejo.dbo.TBL_Solicitacoes s with(nolock)
			WHERE id_cliente = @id 
				AND sol_tipo = @tp  -- COmpliance ou CR�dito 
				AND sol_sub_tipo = @st 
				AND sol_ni_novo = isNull(@ni, sol_ni_novo)
			--	AND sol_ni_atual = @tp_Atu
			ORDER BY sol_data DESC 
			)
		, '' )	-- Retirado a pedido da Cinthia em 13/dez/18 '�N�o houve mudan�a de n�vel'
	;
	Return @T
	;
END
;
