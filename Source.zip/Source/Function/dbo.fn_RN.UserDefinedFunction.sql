Use IK_Varejo
go

if object_id('fn_RN')is not null
	Drop Function dbo.fn_RN
;
go

CREATE FUNCTION dbo.fn_RN 
(
	@id	Int
)
RETURNS Varchar(200)
AS
-- ===========================================================================================
-- Author:		C�ssio Drezza
-- Create date: 13/nov/2018
-- Description:	Retorna o nome do usu�rio
--	 563454-629931 - Controle de Compliance por Cliente p/ Relat�rio	[Controle de Compliance por Cliente.rdl]
--	 563452-629926 - Controle de Cr�dito por Cliente p/ Relat�rio		[Controle de Credito por Cliente.rdl]
-- ===========================================================================================
/*
DECLARE @id int = 2003
--*/
BEGIN
	RETURN IsNull((select ur_username from tbl_users(nolock) where id_user = @id ),'')
	;
END
;
GO

Select dbo.fn_RN(2004)

