USE [IK_VAREJO]
GO

/****** Object:  UserDefinedFunction [dbo].[fc_Verifica_FinaldeSemana_anterior]    Script Date: 08/30/2016 12:42:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE Function fc_Verifica_FinaldeSemanaFeriado_anterior
(@Data_Base as smalldatetime)

Returns smalldatetime
AS
Begin
	DECLARE @VALIDOU INT
	declare @DiaSemana as int = datepart(weekday,@Data_Base)
	
	SET @VALIDOU = 0
	
	WHILE @VALIDOU = 0 
	BEGIN
		IF DATEPART(WEEKDAY, @Data_Base) NOT IN (7,1) AND NOT EXISTS (SELECT Feriado_id FROM [DBFeriado].[dbo].tbl_feriado WHERE Dia = datePart(dd,@Data_Base) AND Mes = datePart(MM,@Data_Base) AND Ano = datePart(yyyy,@Data_Base) AND ativo = 1 AND TipoFeriado_id = 1)
		-- Verifica se a data digitada � ou n�o final de semana antes de dar continuidade...
		BEGIN
			SET @VALIDOU = 1
		END
		ELSE
		BEGIN
			IF (@DiaSemana = 1) 
			BEGIN
				Set @Data_Base = DateAdd(dd,-2,@Data_Base)
			END 
			ELSE IF (@DiaSemana = 7) 
			BEGIN
				Set @Data_Base = DateAdd(dd,-1,@Data_Base)
			END
			ELSE
			BEGIN 
				Set @Data_Base = DateAdd(dd,-1,@Data_Base)	
			END
		END
	END	 
		--------------------------------------------------------------------------------------------
		 RETURN (Select @Data_Base as 'Data_Base')
END 

GO