Use IK_Varejo
go

if object_id('fn_TextoRel2x')is not null
	Drop Function dbo.fn_TextoRel2x
;
go


CREATE FUNCTION dbo.fn_TextoRel2x 
(
	  @id Int
	, @tp Char(2)
	, @ni VarChar(8)=Null
)
RETURNS VarChar(max)
AS
/*
-- ===========================================================================================
-- Author:		C�ssio Drezza
-- Create date: 21/nov/2018
-- Description:	Retorna o Texto de Compliance ou Credito j� formatado para os relat�rios SSRS
--				Usa "�"=Char(175) indicador de �ltimo coment�rio mais recente q a troca de N�vel
--				563454-629931 - Controle de Compliance por Cliente p/ Relat�rio	[Controle de Compliance por Cliente.rdl]
--				563452-629926 - Controle de Cr�dito por Cliente p/ Relat�rio	[Controle de Credito por Cliente.rdl]
-- Alterado em: 24/jan/19 : Corrigido o par�metro para pesquisa de altera��o de n�vel/sem alterar de n�vel na dbo.fn_TextoRel( 
-- ===========================================================================================

DECLARE @id int = 7647, @ni VarChar(8)='5', @tp Char(2)='CO'
--*/
BEGIN
	Declare @T VarChar(max) ='', @U VarChar(max) ='', @LF char(1)=Char(10), @st char(1) 
	;
	Select @T = IsNull( dbo.fn_TextoRel( @id, @tp, @ni  ), '') -- Traz a �ltima altera��o de n�vel
	;
	Select @U = IsNull( dbo.fn_TextoRel( @id, @tp, Null ), '') -- Traz a �ltima aprova��o de sem alterar de n�vel
	;
	If @T<>@U Set @T=@T+@LF+'�'+@U -- "�"=Char(175) indicador de �ltimo coment�rio mais recente q a troca de N�vel - evita duplica��o
	;
	Return @T
	;
END
;
