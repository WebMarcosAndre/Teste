USE IK_VAREJO
GO

IF EXISTS(SELECT * FROM sys.tables WHERE name = N'TBL_WS_TRADERATE_LOG_PPV' AND SCHEMA_ID = SCHEMA_ID(N'dbo'))
BEGIN
	DROP TABLE [dbo].[TBL_WS_TRADERATE_LOG_PPV]
END
GO

CREATE TABLE [dbo].[TBL_WS_TRADERATE_LOG_PPV]
(
	[FxRateType] CHAR(1) NULL,  
    [FxRateId] INT NULL,              
    [LogDate] DATETIME, 
    [DefaultFxRate]  FLOAT,
    [InformedFxRate] FLOAT,  
    [Amount] DECIMAL,  
    [ExpirationDate] DATETIME NULL,  
    [Status] VARCHAR(30),  
    [DescriptionStatus] VARCHAR(300)  
)
GO