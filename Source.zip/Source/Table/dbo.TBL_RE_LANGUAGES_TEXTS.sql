USE [IK_VAREJO]
GO

/****** Object:  Table [dbo].[TBL_RE_LANGUAGES]    Script Date: 08/29/2016 12:50:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TBL_RE_LANGUAGES_TEXTS](
	[id] [int] IDENTITY NOT NULL,
	[id_language] [int] NOT NULL,
	[id_ret_text] [int] NOT NULL,
	[text] [varchar] (500) NOT NULL,
	[link1][varchar] (500) NULL,
	[link2][varchar] (500) NULL	
) ON [PRIMARY]

GO


