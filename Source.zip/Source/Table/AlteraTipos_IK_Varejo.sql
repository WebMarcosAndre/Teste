-- =====================================================================================================================================
-- Author:		C�ssio Drezza
-- Create date: 24/abr/19
-- Description:	Altera tipos Image ==> Binary(Max)
--							 Text  ==> VarChar(Max)
--							 Ntext ==> nVarChar(Max)
-------------------------------------------------------------------------------------------------
-- 683751.694173 - Projeto Migra��o SQL 2016 - Varejo
-------------------------------------------------------------------------------------------------
-- Hist�rico Altera��es
-- *********************
-- PRG______________________ Data_____ Autor________ Descri��o__________________________________________
-- AlteraTipos_IK_Varejo.sql 24/abr/19 C�ssio Drezza 683751.694173 - Projeto Migra��o SQL 2016 - Varejo
-- =====================================================================================================================================
Use ik_Varejo
Go

Alter table TBL_DOCUMENTOS                                     alter column doc_obs                       VarChar(Max) -- text  
Alter table tbl_users_TEMP                                     alter column ur_obs                        VarChar(Max) -- text  
Alter table TBL_RE_PRE_BOLETO_JUSTIFICATIVA                    alter column Justificativa                 VarChar(Max) -- text  
Alter table TBL_NATUREZA                                       alter column nat_obs                       VarChar(Max) -- text  
Alter table TBL_NATUREZA                                       alter column portal_roteiro                VarChar(Max) -- text  
Alter table TBL_NATUREZA                                       alter column portal_documentos             VarChar(Max) -- text  
Alter table TBL_NATUREZA                                       alter column portal_documentos_ccme        VarChar(Max) -- text  
Alter table TBL_NATUREZA                                       alter column portal_documentos_compra      VarChar(Max) -- text  
Alter table TBL_NATUREZA                                       alter column portal_roteiro_compra         VarChar(Max) -- text  
Alter table TBL_NATUREZA                                       alter column portal_natureza_sobre_compra  VarChar(Max) -- text  
Alter table TBL_NATUREZA                                       alter column portal_natureza_sobre         VarChar(Max) -- text  
Alter table TBL_RE_PRE_BOLETO_JUSTIFICATIVA_TARIFA_PROMOCIONAL alter column Justificativa                 VarChar(Max) -- text  
Alter table TBL_DOCTED_DEBUG                                   alter column params                        VarChar(Max) -- text  
Alter table TBL_DOCTED_DEBUG                                   alter column valores                       VarChar(Max) -- text  
Alter table ELMAH_Error                                        alter column AllXml                        nVarChar(Max)-- ntext 
Alter table TBL_CLIENTES_EXCLUIDOS                             alter column cl_obs                        VarChar(Max) -- text  
Alter table TBL_CLIENTES_EXCLUIDOS                             alter column cl_filiais                    VarChar(Max) -- text  
Alter table TBL_CLIENTES_EXCLUIDOS                             alter column cl_inf_operador               VarChar(Max) -- text  
Alter table LOG_ROBO_RIA_RE                                    alter column evento                        nVarChar(Max)-- ntext 
Alter table TBL_RE_HISTORICOPERMISSAODEACESSO                  alter column justificativa                 nVarChar(Max)-- ntext 
Alter table TBL_COL_PARAMCLI_bkp_201705050817                  alter column param_msg_especifica          VarChar(Max) -- text  
Alter table Tbl_Re_Crm_Evento                                  alter column msg_crm                       VarChar(Max) -- text  
Alter table TBL_COL_PARAMCLI_backup_20170508_1321              alter column param_msg_especifica          VarChar(Max) -- text  
Alter table TBL_COL_PARAMCLI_BKP_20170523                      alter column param_msg_especifica          VarChar(Max) -- text  
Alter table log_robo_ria_tarefa                                alter column inf_complementar              nVarChar(Max)-- ntext 
Alter table TBL_EMAIL                                          alter column CORPO_EMAIL                   VarChar(Max) -- text  
Alter table tbl_re_historico_permissao                         alter column justificativa                 nVarChar(Max)-- ntext 
Alter table Clientes_access                                    alter column info_complementar_padrao      VarChar(Max) -- text  
Alter table TBL_CLIENTES                                       alter column cl_obs                        VarChar(Max) -- text  
Alter table TBL_CLIENTES                                       alter column cl_filiais                    VarChar(Max) -- text  
Alter table TBL_CLIENTES                                       alter column cl_inf_operador               VarChar(Max) -- text  
Alter table TBL_REENVIAR_EMAIL                                 alter column Dados                         VarChar(Max) -- text  
Alter table TBL_PRE_BOLETO                                     alter column op_inf_compl                  VarChar(Max) -- text  
Alter table TBL_PRE_BOLETO                                     alter column op_inf_operacao               VarChar(Max) -- text  
Alter table tbl_temporario                                     alter column op_inf_compl                  VarChar(Max) -- text  
Alter table tbl_temporario                                     alter column op_inf_operacao               VarChar(Max) -- text  
Alter table TBL_USERS                                          alter column ur_obs                        VarChar(Max) -- text  
Alter table TBL_VOL_NATUREZA                                   alter column nat_obs                       VarChar(Max) -- text  
Alter table LOG_DOC_SUCESSO                                    alter column doc_msg_erro                  VarChar(Max) -- text  
Alter table TBL_PROCURACAO_CLIENTE                             alter column HASH_PROCURACAO               nVarChar(Max)-- ntext 
Alter table TBL_RE_BOLETO_CANCELADO_REVERTIDO                  alter column observacao                    VarChar(Max) -- text  
Alter table TBL_BOLETO_ASSINADO_DIGITALMENTE                   alter column HASH_DOCUMENTO                nVarChar(Max)-- ntext 
Alter table TBL_FILIAIS                                        alter column FI_OBS                        VarChar(Max) -- text  
Alter table TBL_OPERACOES                                      alter column op_inf_compl                  VarChar(Max) -- text  
Alter table TBL_OPERACOES                                      alter column op_inf_operacao               VarChar(Max) -- text  

/*
-------------------------------------------------- ---------------------------- ----- -------------- ------------------------- ---------- -------
Tabela                                             name                         Tipo  system_type_id Server.DB_Name			   type_desc  Nschema
-------------------------------------------------- ---------------------------- ----- -------------- ------------------------- ---------- -------
TBL_DOCUMENTOS                                     doc_obs                      text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
tbl_users_TEMP                                     ur_obs                       text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_RE_PRE_BOLETO_JUSTIFICATIVA                    Justificativa                text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_NATUREZA                                       nat_obs                      text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_NATUREZA                                       portal_roteiro               text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_NATUREZA                                       portal_documentos            text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_NATUREZA                                       portal_documentos_ccme       text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_NATUREZA                                       portal_documentos_compra     text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_NATUREZA                                       portal_roteiro_compra        text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_NATUREZA                                       portal_natureza_sobre_compra text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_NATUREZA                                       portal_natureza_sobre        text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_RE_PRE_BOLETO_JUSTIFICATIVA_TARIFA_PROMOCIONAL Justificativa                text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_DOCTED_DEBUG                                   params                       text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_DOCTED_DEBUG                                   valores                      text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
ELMAH_Error                                        AllXml                       ntext 99             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_CLIENTES_EXCLUIDOS                             cl_obs                       text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_CLIENTES_EXCLUIDOS                             cl_filiais                   text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_CLIENTES_EXCLUIDOS                             cl_inf_operador              text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
LOG_ROBO_RIA_RE                                    evento                       ntext 99             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_RE_HISTORICOPERMISSAODEACESSO                  justificativa                ntext 99             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_COL_PARAMCLI_bkp_201705050817                  param_msg_especifica         text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
Tbl_Re_Crm_Evento                                  msg_crm                      text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_COL_PARAMCLI_backup_20170508_1321              param_msg_especifica         text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_COL_PARAMCLI_BKP_20170523                      param_msg_especifica         text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
log_robo_ria_tarefa                                inf_complementar             ntext 99             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_EMAIL                                          CORPO_EMAIL                  text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
tbl_re_historico_permissao                         justificativa                ntext 99             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
Clientes_access                                    info_complementar_padrao     text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_CLIENTES                                       cl_obs                       text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_CLIENTES                                       cl_filiais                   text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_CLIENTES                                       cl_inf_operador              text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_REENVIAR_EMAIL                                 Dados                        text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_PRE_BOLETO                                     op_inf_compl                 text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_PRE_BOLETO                                     op_inf_operacao              text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
tbl_temporario                                     op_inf_compl                 text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
tbl_temporario                                     op_inf_operacao              text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_USERS                                          ur_obs                       text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_VOL_NATUREZA                                   nat_obs                      text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
LOG_DOC_SUCESSO                                    doc_msg_erro                 text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_PROCURACAO_CLIENTE                             HASH_PROCURACAO              ntext 99             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_RE_BOLETO_CANCELADO_REVERTIDO                  observacao                   text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_BOLETO_ASSINADO_DIGITALMENTE                   HASH_DOCUMENTO               ntext 99             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_FILIAIS                                        FI_OBS                       text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_OPERACOES                                      op_inf_compl                 text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
TBL_OPERACOES                                      op_inf_operacao              text  35             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo
dtproperties                                       lvalue                       image 34             REND-SRVDSQL-05.IK_VAREJO USER_TABLE dbo    
-------------------------------------------------- ---------------------------- ----- -------------- ------------------------- ---------- -------
(46 row(s) affected)
*/
