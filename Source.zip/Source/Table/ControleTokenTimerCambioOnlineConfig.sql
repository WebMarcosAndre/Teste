USE IK_VAREJO
GO

IF EXISTS(SELECT TOP 1 NAME FROM sys.TABLES WHERE name = 'ControleTokenTimerCambioOnlineConfig')
	DROP TABLE ControleTokenTimerCambioOnlineConfig

GO

CREATE TABLE ControleTokenTimerCambioOnlineConfig
(
ID INT Identity(1,1) NOT NULL,
TipoClienteID INT,
Descricao VARCHAR(250),
Valor TIME NOT NULL,
DataCriacao DATETIME DEFAULT(GETDATE())

)

ALTER TABLE ControleTokenTimerCambioOnlineConfig ADD CONSTRAINT pk_ControleTokenTimerCambioOnlineConfig PRIMARY KEY (Id)

--	INSERT

INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, Valor) VALUES ('DEFAULT','00:00:30')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Portal - CORRETORA', 0,'00:00:30')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Portal - AGENCIA', 1,'00:00:30')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Portal - INTERCAMBIO', 2,'00:00:30')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Portal - PJ', 3,'00:00:30')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Portal - PF', 4,'00:05:00')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Portal - EMBAIXADA', 5,'00:00:30')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Portal - DIPLOMATA', 6,'00:00:30')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Portal - ORGANISMOS', 7,'00:00:30')

														
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Cota��o - CORRETORA', 0,'00:00:30')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Cota��o - AGENCIA', 1,'00:00:30')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Cota��o - INTERCAMBIO', 2,'00:00:30')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Cota��o - PJ', 3,'00:00:30')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Cota��o - PF', 4,'00:05:00')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Cota��o - EMBAIXADA', 5,'00:00:30')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Cota��o - DIPLOMATA', 6,'00:00:30')
INSERT INTO ControleTokenTimerCambioOnlineConfig (Descricao, TipoClienteId, Valor) VALUES ('Cota��o - ORGANISMOS', 7,'00:00:30')

SELECT * FROM ControleTokenTimerCambioOnlineConfig

