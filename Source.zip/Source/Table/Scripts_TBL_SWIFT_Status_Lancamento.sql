USE IK_VAREJO
GO


IF NOT EXISTS (SELECT 1 FROM sys.tables  WHERE Name = N'TBL_SWIFT_Status_Lancamento')
BEGIN
	CREATE TABLE TBL_SWIFT_Status_Lancamento
	(
		StatusLancamentoId INT PRIMARY KEY NOT NULL IDENTITY(1,1),
		StatusId INT NOT NULL,
		Status VARCHAR(50) NOT NULL
	)
	INSERT INTO TBL_SWIFT_Status_Lancamento VALUES(-1, '')
	INSERT INTO TBL_SWIFT_Status_Lancamento VALUES(0, 'Pré-lançamento')
	INSERT INTO TBL_SWIFT_Status_Lancamento VALUES(1, 'Finalizado')
	INSERT INTO TBL_SWIFT_Status_Lancamento VALUES(2, 'Erro')
	INSERT INTO TBL_SWIFT_Status_Lancamento VALUES(3, 'Recusado')
	INSERT INTO TBL_SWIFT_Status_Lancamento VALUES(4, 'Aguardando lançamento CCME ou Geração Pré-Boleto')
	INSERT INTO TBL_SWIFT_Status_Lancamento VALUES(5, 'Rejeitado')
	INSERT INTO TBL_SWIFT_Status_Lancamento VALUES(6, 'Devolvido')
	INSERT INTO TBL_SWIFT_Status_Lancamento VALUES(7, 'Baixado')
END

IF NOT EXISTS (SELECT 1 FROM sys.tables  WHERE Name = N'TBL_SWIFT_Parametros')
BEGIN
	CREATE TABLE TBL_SWIFT_Parametros
	(
		SwiftParametrosId INT PRIMARY KEY NOT NULL IDENTITY(1,1),
		DataInicioGPI DATETIME NOT NULL,
		Sequencial INT NOT NULL,
		BicTracker VARCHAR(50) NOT NULL,
		HorarioCorte DATETIME NOT NULL,
		HorarioEnviarEmailPendentes DATETIME NOT NULL,
		HorarioProcessarPendentes DATETIME NOT NULL,
		BicRendimento VARCHAR(50) NOT NULL,
		EmailPendencia VARCHAR(250) NOT NULL,
		SistemaIdEmailRemetente INT NOT NULL,
		IntervaloExecucaoMt199 INT NOT NULL
	)
	
	INSERT INTO TBL_SWIFT_Parametros VALUES('2019-06-28', 1, 'TRCKCHZ0VAL', '1990-01-01 16:00', '1990-01-01 07:00', '1990-01-01 15:30', 'RENDBRS0AXX', '', 12, 5)
END

IF NOT EXISTS (SELECT 1 FROM sys.tables  WHERE Name = N'TBL_GPI_Status')
BEGIN
	CREATE TABLE TBL_GPI_Status
	(
		GpiStatusId INT PRIMARY KEY IDENTITY(1,1),
		Status VARCHAR(50) NOT NULL,
		Descricao VARCHAR(200) NOT NULL,
		StatusFinal CHAR(1) NOT NULL,
		Tipo VARCHAR(50) NOT NULL
	)

	INSERT INTO TBL_GPI_Status VALUES('ACSP/G000', 'Pagamento enviado para membro GPI', 'N', 'Progresso')
	INSERT INTO TBL_GPI_Status VALUES('ACSP/G001', 'Pagamento enviado para não GPI', 'N', 'Progresso')
	INSERT INTO TBL_GPI_Status VALUES('ACSP/G002', 'Pendente. Os fundos não serão creditados em D0', 'N', 'Progresso')
	INSERT INTO TBL_GPI_Status VALUES('ACSP/G003', 'Pendente. Documentação solicitada para o beneficiário', 'N', 'Progresso')
	INSERT INTO TBL_GPI_Status VALUES('ACSP/G004', 'Pendente. Aguardando fundos', 'N', 'Progresso')
	INSERT INTO TBL_GPI_Status VALUES('ACSC', 'Fundos disponibilizados', 'S', 'Finalizado')
	INSERT INTO TBL_GPI_Status VALUES('RJCT', 'Rejeitada', 'S', 'Rejeitado')
END

IF NOT EXISTS (SELECT 1 FROM sys.tables  WHERE Name = N'TBL_SWIFT_HistoricoEnviosGPI')
BEGIN
	CREATE TABLE TBL_SWIFT_HistoricoEnviosGPI
	(
		HistoricoEnvioGpiId INT PRIMARY KEY NOT NULL IDENTITY(1,1),
		SwiftOrdemId INT NOT NULL,
		DataEnvioTracker DATETIME NOT NULL,
		StatusEnviado INT NULL,
		StatusFinal INT NULL
	)
END

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = Object_ID('TBL_MEWEB_MT103') And name = 'StatusGPIFinalEnviado') 
BEGIN
	ALTER TABLE TBL_MEWEB_MT103
	ADD StatusGPIFinalEnviado INT
END

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = Object_ID('TBL_MEWEB_MT103') And name = 'StatusGPIIntermediarioEnviado') 
BEGIN
	ALTER TABLE TBL_MEWEB_MT103
	ADD StatusGPIIntermediarioEnviado INT
END
