USE [ik_Varejo]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[TBL_RE_REGRA_PAISES](
    [Id] [int] IDENTITY(1,1) NOT NULL,
	[IdPais] [int] NOT NULL,
	[Nome] [varchar](150) NOT NULL,
	[Regra] [bit] NOT NULL 

) 
GO
SET ANSI_PADDING OFF

GO

if NOT exists( select * from sys.all_columns c where c.name='Entrega24h' and c.object_id=object_id('TBL_RE_REGRA_PAISES') )
	begin
		Alter Table TBL_RE_REGRA_PAISES add Entrega24h Bit	;
		Update r Set Entrega24h=0 From TBL_RE_REGRA_PAISES r Where Entrega24h is null	;
		Print 'Coluna Entrega24h criada na tabela TBL_RE_REGRA_PAISES'
	end
  Else
	Print 'Coluna Entrega24h j� existe na tabela TBL_RE_REGRA_PAISES'
;

