USE IK_Varejo 
GO

--CONTA LINHAS AFETADAS
CREATE TABLE #QCount(LinhaAffe int) INSERT #QCount(LinhaAffe)VALUES('0')
-------------------------------------------------------------------------------------------------------------------------
-- CRIA CAMPOS QUE FORAM CRIADOS EM HOMOLOGA��O POR UMA RFC, QUE NAO FORAM CRIADAS EM DEV
-------------------------------------------------------------------------------------------------------------------------
BEGIN TRAN

		update TBL_MEWEB_CARACTERES set char_to = null where char_to = ' '
		UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
		GO


		


	SELECT CONVERT(VARCHAR(10),LinhaAffe) +' PARAMETROS SETADOS COM SUCESSO!!!' FROM #QCount
COMMIT TRAN
DROP TABLE #QCount


