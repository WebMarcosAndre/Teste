USE [IK_VAREJO]
GO

/****** Object:  Table [dbo].[TBL_ME_SUBCONTA_REAIS_LOG]    Script Date: 03/14/2017 15:30:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
IF OBJECT_ID('dbo.TBL_ME_SUBCONTA_REAIS_LOG', 'U') IS NOT NULL 
  DROP TABLE dbo.TBL_ME_SUBCONTA_REAIS_LOG
GO 
CREATE TABLE [dbo].[TBL_ME_SUBCONTA_REAIS_LOG](
	[id_sub_conta] [int] NOT NULL,
	[versao] [numeric](10, 0) NULL,
	[data_inclusao] [datetime] NULL,
	[id_usuario] [int] NULL,
	[id_agencia] [int] NOT NULL,
	[id_cliente] [int] NOT NULL,
	[id_moeda] [int] NOT NULL,
	[id_user] [int] NULL,
	[cod_moeda] [varchar](4) NULL,
	[sub_tipo] [char](1) NULL,
	[sub_dataatu] [datetime] NULL,
	[sub_data_abertura] [datetime] NULL,
	[sub_sdodia0] [money] NULL,
	[sub_sdodia1] [money] NULL,
	[sub_sdodia2] [money] NULL,
	[sub_sdobloq0] [money] NULL,
	[sub_sdobloq1] [money] NULL,
	[sub_sdobloq2] [money] NULL,
	[sub_saldo_bloq_debitar] [money] NULL,
	[sub_saldo_bloq_creditar] [money] NULL,
	[sub_dt_ult_mov] [datetime] NULL,
	[sub_dt_saldo_atu] [datetime] NULL,
	[sub_juro_a_lancar] [money] NULL,
	[sub_juro_acumulado] [money] NULL,
	[SUB_DT_JUROS_ATU] [datetime] NULL,
	[SUB_DT_LANCA_JUROS] [datetime] NULL,
	[SUB_TAR_REC] [money] NULL,
	[SUB_TAR_ENV] [money] NULL,
	[SUB_ARBITRAGEM] [money] NULL,
	[SUB_DEPOSITO] [money] NULL,
	[SUB_CH_FIXO] [money] NULL,
	[SUB_CH_PERC] [money] NULL,
	[SUB_MANUTENCAO] [money] NULL,
	[SUB_PERC_TAXA] [money] NULL,
	[SUB_VALIDADE_TX] [datetime] NULL,
	[SUB_SAQUE] [money] NULL,
	[SUB_FIXO_TC] [money] NULL,
	[SUB_PERC_TC] [money] NULL,
	[SUB_MOEDA_TARIFA] [char](1) NULL,
	[sub_limite_spermissao] [money] NULL,
	[sub_cobrararbitragem] [char](1) NULL,
	[sub_val_de1] [money] NULL,
	[sub_val_ate1] [money] NULL,
	[sub_tarifa1] [money] NULL,
	[sub_val_de2] [money] NULL,
	[sub_val_ate2] [money] NULL,
	[sub_tarifa2] [money] NULL,
	[sub_val_de3] [money] NULL,
	[sub_val_ate3] [money] NULL,
	[sub_tarifa3] [money] NULL,
	[sub_val_de4] [money] NULL,
	[sub_tarifa4] [money] NULL,
	[sub_cobrarir] [char](1) NULL,
	[sub_inatividade] [money] NULL,
	[sub_perc_remuneracao] [money] NULL,
	[sub_remuacumulada] [money] NULL,
	[sub_tc_de1] [money] NULL,
	[sub_tc_ate1] [money] NULL,
	[sub_tc_tarifa1] [money] NULL,
	[sub_tc_de2] [money] NULL,
	[sub_tc_ate2] [money] NULL,
	[sub_tc_tarifa2] [money] NULL,
	[sub_tc_de3] [money] NULL,
	[sub_tc_ate3] [money] NULL,
	[sub_tc_tarifa3] [money] NULL,
	[sub_swift_de1] [money] NULL,
	[sub_swift_ate1] [money] NULL,
	[sub_swift_tarifa1] [money] NULL,
	[sub_swift_de2] [money] NULL,
	[sub_swift_ate2] [money] NULL,
	[sub_swift_tarifa2] [money] NULL,
	[sub_swift_de3] [money] NULL,
	[sub_swift_ate3] [money] NULL,
	[sub_swift_tarifa3] [money] NULL,
	[sub_outrosl] [money] NULL,
	[sub_status] [char](1) NULL,
	[sub_ch_fixo_usa] [money] NULL,
	[sub_ch_perc_usa] [money] NULL,
	[sub_data_inicio_mov] [datetime] NULL,
	[sub_transf] [money] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[TBL_ME_SUBCONTA_REAIS_LOG] ADD  CONSTRAINT [DF_TBL_ME_SUBCONTA_REAIS_LOG_sub_juro_a_lancar]  DEFAULT (0) FOR [sub_juro_a_lancar]
GO

ALTER TABLE [dbo].[TBL_ME_SUBCONTA_REAIS_LOG] ADD  CONSTRAINT [DF_TBL_ME_SUBCONTA_REAIS_LOG_sub_juro_acumulado]  DEFAULT (0) FOR [sub_juro_acumulado]
GO

ALTER TABLE [dbo].[TBL_ME_SUBCONTA_REAIS_LOG] ADD  DEFAULT (getdate()) FOR [sub_data_inicio_mov]
GO


ALTER TABLE TBL_ME_SUBCONTA_REAIS_LOG ADD SUB_SPREAD INT DEFAULT NULL 