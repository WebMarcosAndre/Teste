USE [IK_VAREJO]
GO

/****** Object:  Table [dbo].[TBL_RE_SPREAD_FLEXIVEL]    Script Date: 04/20/2018 14:32:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TBL_RE_COMP_BB_CIP](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[PROCESSAMENTO] [varchar](1) NOT NULL,
	[LIMITE_COMP_CIP] [decimal](18,2) NOT NULL 
) ON [PRIMARY]

GO






