USE IK_Varejo 
GO

--CONTA LINHAS AFETADAS
CREATE TABLE #QCount(LinhaAffe int) INSERT #QCount(LinhaAffe)VALUES('0')
-------------------------------------------------------------------------------------------------------------------------
-- CRIA CAMPOS QUE FORAM CRIADOS EM HOMOLOGA��O POR UMA RFC, QUE NAO FORAM CRIADAS EM DEV
-------------------------------------------------------------------------------------------------------------------------
BEGIN TRAN

		IF NOT EXISTS (SELECT 1 FROM sys.tables  WHERE Name = N'TBL_ANEXO')
		BEGIN		
			CREATE TABLE [dbo].[TBL_ANEXO](
				[ID_ANEXO] [int] IDENTITY(1,1) NOT NULL,
				[ID_EMAIL] [int] NOT NULL,
				[ARQUIVO_ANEXO] [VARCHAR](1000) NOT NULL,
				[DATA_ANEXO] [DATETIME] NOT NULL
	
			) ON [PRIMARY]
		END 
		UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
		GO
		IF NOT EXISTS (SELECT 1 FROM sys.tables  WHERE Name = N'TBL_EMAIL')
		BEGIN
			CREATE TABLE [dbo].[TBL_EMAIL](
				[ID_EMAIL] [int] IDENTITY(1,1) NOT NULL,
				[ID_SISTEMA] [int] NOT NULL,
				[DESTINO_EMAIL] [VARCHAR](1000) NOT NULL,
				[COPIAOCULTA_EMAIL] [VARCHAR](800) NOT NULL,
				[ASSUNTO_EMAIL] [VARCHAR](255) NOT NULL,
				[CORPO_EMAIL] [TEXT] NULL,
				[DATA_EMAIL] [DATETIME] NULL,
				[ENVIADO] [VARCHAR](1) NULL, 
				[CORRETORA] [VARCHAR](500) NULL, 
				[TIPO] [VARCHAR](1)
	
				) ON [PRIMARY]
		END
		UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
		GO
		IF NOT EXISTS (SELECT 1 FROM sys.tables  WHERE Name = N'TBL_LOGO_CCME')
		  BEGIN
		  CREATE TABLE TBL_LOGO_CCME (
				id 			INT IDENTITY(1,1) PRIMARY KEY NOT NULL
			   ,id_cli		INT NOT NULL
			   ,path		VARCHAR(MAX) NOT NULL
			   ,website		VARCHAR(80) NULL
			   ,create_date DATETIME NOT NULL
			   ,ativo	    BIT NOT NULL
			);
		   END
		   UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
		GO
		IF NOT EXISTS (SELECT 1 FROM sys.tables  WHERE Name = N'TBL_LOG_LOGO_CCME')
		  BEGIN
	
			CREATE TABLE TBL_LOG_LOGO_CCME (
				 id			  INT IDENTITY(1,1) PRIMARY KEY NOT NULL
				,id_usr		  INT NOT NULL
				,nome_usr	  VARCHAR(80) NOT NULL
				,operacao	  VARCHAR(20) NOT NULL
				,data_op	  DATETIME NOT NULL
				,id_logo_ccme INT NOT NULL
				,CONSTRAINT FK_TBL_LOGO_CCME_TBL_LOG_LOGO_CCME FOREIGN KEY (id_logo_ccme) REFERENCES TBL_LOGO_CCME(id)
			);
			UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
		  END

		SELECT CONVERT(VARCHAR(10),LinhaAffe) +' cria��o de tabelas para salvar as informa��es de logos dos clientes CRIADOS COM SUCESSO!!!' FROM #QCount

COMMIT TRAN
UPDATE #QCount SET  LinhaAffe=0
GO
-------------------------------------------------------------------------------------------------------------------------
-- CRIA CAMPOS QUE FORAM CRIADOS EM HOMOLOGA��O POR UMA RFC, QUE NAO FORAM CRIADAS EM DEV
-------------------------------------------------------------------------------------------------------------------------
BEGIN TRAN

	IF  NOT EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_CORRETORAS' AND B.[name] ='CO_DIVISAO_TITULO')
	BEGIN
	   ALTER TABLE TBL_CORRETORAS ADD CO_DIVISAO_TITULO BIT NOT NULL DEFAULT 0 
	   UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF  NOT EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_MEWEB_CONFIG' AND B.[name] ='DIRETORIO_LOGO')
	BEGIN
	   ALTER TABLE dbo.TBL_MEWEB_CONFIG ADD DIRETORIO_LOGO VARCHAR(100) NULL
	   UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1

	END
	GO
	IF  NOT EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_MEWEB_CONFIG_LOG' AND B.[name] ='DIRETORIO_LOGO')
	BEGIN
	   ALTER TABLE dbo.TBL_MEWEB_CONFIG_LOG ADD DIRETORIO_LOGO VARCHAR(100) NULL
	   UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1

	END
	GO
		IF  NOT EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
				WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_CLIENTES' AND B.[name] ='CL_IBAN')
		BEGIN
		   ALTER TABLE dbo.TBL_CLIENTES ADD CL_IBAN VARCHAR(100) NULL
		UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1

	END
	GO

	IF  NOT EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='[Tbl_Re_Lote]' AND B.[name] IN ('NOME_ARQUIVO_PDF','NOME_ARQUIVO_EXCEL'))
	BEGIN		   
		ALTER TABLE [dbo].[Tbl_Re_Lote] ADD [NOME_ARQUIVO_PDF] [varchar](500) NULL
		ALTER TABLE [dbo].[Tbl_Re_Lote] ADD [NOME_ARQUIVO_EXCEL] [varchar](500) NULL
		UPDATE #QCount SET  LinhaAffe = LinhaAffe + 2
	END
	GO

	-------------------------------------------------------------------------------------------------------------------------
	-- COMPLIANC
	-------------------------------------------------------------------------------------------------------------------------
	IF  NOT EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_APROVACAO_COMPLIANCE' AND B.[name] IN('comp_ver_data_permanencia','log_ver_data_permanencia'))
	BEGIN
		ALTER TABLE TBL_APROVACAO_COMPLIANCE ADD comp_ver_data_permanencia BIT
		ALTER TABLE LOG_APROVACAO_COMPLIANCE ADD log_ver_data_permanencia BIT
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 2
		UPDATE TBL_APROVACAO_COMPLIANCE SET comp_ver_data_permanencia = CASE WHEN comp_nivel IN ('0', '1') THEN 0 ELSE 1 END
	END
	GO
	IF  NOT EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_APROVACAO_CREDITO' AND B.[name] IN('cr_ver_data_permanencia','log_ver_data_permanencia'))
	BEGIN
		ALTER TABLE TBL_APROVACAO_CREDITO ADD cr_ver_data_permanencia BIT
		ALTER TABLE LOG_APROVACAO_CREDITO ADD log_ver_data_permanencia BIT
		UPDATE TBL_APROVACAO_CREDITO SET cr_ver_data_permanencia = CASE WHEN cr_nivel = 'A' THEN 0 ELSE 1 END
		UPDATE #QCount SET  LinhaAffe = LinhaAffe + 2

	END
	GO
	IF  NOT EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_CLIENTES' AND B.[name] IN('CL_DATA_PORTE_EMPRESA'))
	BEGIN
			ALTER TABLE TBL_CLIENTES ADD CL_DATA_PORTE_EMPRESA DATETIME
			UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1

	END
	GO
	IF  NOT EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_CLIENTES' AND B.[name] IN('CL_DATA_PORTE_EMPRESA'))
	BEGIN
			ALTER TABLE TBL_CLIENTES ADD CL_DATA_PORTE_EMPRESA DATETIME
			UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1

	END
	GO
	IF  NOT EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_LOGIN_INTEGRADO' AND B.[name] IN('li_Data_Nascimento','li_DDD','li_Celular'))
	BEGIN
			ALTER TABLE TBL_LOGIN_INTEGRADO ADD li_Data_Nascimento datetime NULL;
			ALTER TABLE TBL_LOGIN_INTEGRADO ADD li_DDD [char](3) NULL;
			ALTER TABLE TBL_LOGIN_INTEGRADO ADD li_Celular [char](16) NULL;
			UPDATE #QCount SET  LinhaAffe = LinhaAffe + 3

	END
	GO


	SELECT CONVERT(VARCHAR(10),LinhaAffe) +' CAMPOS COMPLIANC RENDIMENTO/ADICIONADOS COM SUCESSO!!!' FROM #QCount
COMMIT TRAN
	UPDATE #QCount SET  LinhaAffe=0
GO
-------------------------------------------------------------------------------------------------------------------------
--Altera os campos das tabelas/VIEW de text para nvarchar(max)
-------------------------------------------------------------------------------------------------------------------------
BEGIN TRAN

	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_RE_Lembretes' AND B.[name] ='Txt_Orientacao')
	BEGIN
		ALTER TABLE  TBL_RE_Lembretes	ALTER COLUMN  Txt_Orientacao	nvarchar(max) 
		UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_DOCUMENTOS' AND B.[name] ='doc_obs')
	BEGIN
		ALTER TABLE  TBL_DOCUMENTOS		ALTER COLUMN  doc_obs	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='tbl_users_TEMP' AND B.[name] ='ur_obs')
	BEGIN
		ALTER TABLE  tbl_users_TEMP		ALTER COLUMN  ur_obs	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_RE_PRE_BOLETO_JUSTIFICATIVA' AND B.[name] ='Justificativa')
	BEGIN
		ALTER TABLE  TBL_RE_PRE_BOLETO_JUSTIFICATIVA		ALTER COLUMN  Justificativa	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_NATUREZA' AND B.[name] 
			IN ('nat_obs','portal_roteiro','portal_documentos','portal_documentos_ccme',
			'portal_documentos_compra','portal_roteiro_compra','portal_natureza_sobre_compra' ,'portal_natureza_sobre'))
	BEGIN
		ALTER TABLE  TBL_NATUREZA										ALTER COLUMN  nat_obs						nvarchar(max) 
		ALTER TABLE  TBL_NATUREZA										ALTER COLUMN  portal_roteiro				nvarchar(max) 
		ALTER TABLE  TBL_NATUREZA										ALTER COLUMN  portal_documentos				nvarchar(max) 
		ALTER TABLE  TBL_NATUREZA										ALTER COLUMN  portal_documentos_ccme		nvarchar(max) 
		ALTER TABLE  TBL_NATUREZA										ALTER COLUMN  portal_documentos_compra		nvarchar(max) 
		ALTER TABLE  TBL_NATUREZA										ALTER COLUMN  portal_roteiro_compra			nvarchar(max) 
		ALTER TABLE  TBL_NATUREZA										ALTER COLUMN  portal_natureza_sobre_compra  nvarchar(max) 
		ALTER TABLE  TBL_NATUREZA										ALTER COLUMN  portal_natureza_sobre			nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 8
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_RE_PRE_BOLETO_JUSTIFICATIVA_TARIFA_PROMOCIONAL' AND B.[name] ='Justificativa')
	BEGIN
		ALTER TABLE  TBL_RE_PRE_BOLETO_JUSTIFICATIVA_TARIFA_PROMOCIONAL		ALTER COLUMN  Justificativa	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_DOCTED_DEBUG' AND B.[name] in('params','valores'))
	BEGIN
		ALTER TABLE  TBL_DOCTED_DEBUG		ALTER COLUMN  params	nvarchar(max) 
		ALTER TABLE  TBL_DOCTED_DEBUG		ALTER COLUMN  valores	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 2
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_DOCTED_DEBUG' AND B.[name] ='valores')
	BEGIN
		ALTER TABLE  TBL_DOCTED_DEBUG		ALTER COLUMN  valores	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_CLIENTES_EXCLUIDOS' AND B.[name] in('cl_obs','cl_filiais','cl_inf_operador'))
	BEGIN
		ALTER TABLE  TBL_CLIENTES_EXCLUIDOS								ALTER COLUMN  cl_obs						nvarchar(max) 
		ALTER TABLE  TBL_CLIENTES_EXCLUIDOS								ALTER COLUMN  cl_filiais					nvarchar(max) 
		ALTER TABLE  TBL_CLIENTES_EXCLUIDOS								ALTER COLUMN  cl_inf_operador				nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 3
	
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_COL_PARAMCLI_bkp_201705050817' AND B.[name] ='param_msg_especifica')
	BEGIN
		ALTER TABLE  TBL_COL_PARAMCLI_bkp_201705050817		ALTER COLUMN  param_msg_especifica	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='Tbl_Re_Crm_Evento' AND B.[name] ='msg_crm')
	BEGIN
		ALTER TABLE  Tbl_Re_Crm_Evento		ALTER COLUMN  msg_crm	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO	
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_COL_PARAMCLI_backup_20170508_1321' AND B.[name] ='param_msg_especifica')
	BEGIN
		ALTER TABLE  TBL_COL_PARAMCLI_backup_20170508_1321		ALTER COLUMN  param_msg_especifica	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO	
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_COL_PARAMCLI_BKP_20170523' AND B.[name] ='param_msg_especifica')
	BEGIN
		ALTER TABLE  TBL_COL_PARAMCLI_BKP_20170523		ALTER COLUMN  param_msg_especifica	nvarchar(max)
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1 
	END
	GO	
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='Clientes_access' AND B.[name] ='info_complementar_padrao')
	BEGIN
		ALTER TABLE  Clientes_access		ALTER COLUMN  info_complementar_padrao	nvarchar(max)
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1 
	END
	GO	
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_CLIENTES' AND B.[name] in('cl_obs','cl_filiais','cl_inf_operador'))
	BEGIN			
		ALTER TABLE  TBL_CLIENTES										ALTER COLUMN  cl_obs						nvarchar(max) 
		ALTER TABLE  TBL_CLIENTES										ALTER COLUMN  cl_filiais					nvarchar(max) 
		ALTER TABLE  TBL_CLIENTES										ALTER COLUMN  cl_inf_operador				nvarchar(max) 
		UPDATE #QCount SET  LinhaAffe = LinhaAffe + 3	
	END
	GO		
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_REENVIAR_EMAIL' AND B.[name] ='Dados')
	BEGIN
		ALTER TABLE  TBL_REENVIAR_EMAIL		ALTER COLUMN  Dados	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_PRE_BOLETO' AND B.[name] in('op_inf_compl','op_inf_operacao'))
	BEGIN
		ALTER TABLE  TBL_PRE_BOLETO		ALTER COLUMN  op_inf_compl					nvarchar(max) 
		ALTER TABLE  TBL_PRE_BOLETO		ALTER COLUMN  op_inf_operacao				nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 3
	
	END
	GO	
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='tbl_temporario' AND B.[name] in('op_inf_compl','op_inf_operacao'))
	BEGIN
		ALTER TABLE  tbl_temporario		ALTER COLUMN  op_inf_compl					nvarchar(max) 
		ALTER TABLE  tbl_temporario		ALTER COLUMN  op_inf_operacao				nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 2
	
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_USERS' AND B.[name] ='ur_obs')
	BEGIN
		ALTER TABLE  TBL_USERS		ALTER COLUMN  ur_obs	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_VOL_NATUREZA' AND B.[name] ='nat_obs')
	BEGIN
		ALTER TABLE  TBL_VOL_NATUREZA		ALTER COLUMN  nat_obs	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='LOG_DOC_SUCESSO' AND B.[name] ='doc_msg_erro')
	BEGIN
		ALTER TABLE  LOG_DOC_SUCESSO		ALTER COLUMN  doc_msg_erro	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_RE_BOLETO_CANCELADO_REVERTIDO' AND B.[name] ='observacao')
	BEGIN
		ALTER TABLE  TBL_RE_BOLETO_CANCELADO_REVERTIDO		ALTER COLUMN  observacao	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_FILIAIS' AND B.[name] ='FI_OBS')
	BEGIN
		ALTER TABLE  TBL_FILIAIS		ALTER COLUMN  FI_OBS	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO		
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_OPERACOES' AND B.[name] in('op_inf_compl','op_inf_operacao'))
	BEGIN
		ALTER TABLE  TBL_OPERACOES		ALTER COLUMN  op_inf_compl	nvarchar(max)
		ALTER TABLE  TBL_OPERACOES		ALTER COLUMN  op_inf_operacao	nvarchar(max)
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 2
 
	END
	GO	

COMMIT TRAN
-------------------------------------------------------------------------------------------------------------------------
--Altera os campos das tabelas/VIEW de ntext para nvarchar(max)
-------------------------------------------------------------------------------------------------------------------------
BEGIN TRAN
	
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='ELMAH_Error' AND B.[name] ='AllXml')
	BEGIN
		ALTER TABLE  ELMAH_Error		ALTER COLUMN  AllXml	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='LOG_ROBO_RIA_RE' AND B.[name] ='evento')
	BEGIN
		ALTER TABLE  LOG_ROBO_RIA_RE		ALTER COLUMN  evento	nvarchar(max)
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1 
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_RE_HISTORICOPERMISSAODEACESSO' AND B.[name] ='justificativa')
	BEGIN
		ALTER TABLE  TBL_RE_HISTORICOPERMISSAODEACESSO		ALTER COLUMN  justificativa	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='log_robo_ria_tarefa' AND B.[name] ='inf_complementar')
	BEGIN
		ALTER TABLE  log_robo_ria_tarefa		ALTER COLUMN  inf_complementar	nvarchar(max)
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1 
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='tbl_re_historico_permissao' AND B.[name] ='justificativa')
	BEGIN
		ALTER TABLE  tbl_re_historico_permissao		ALTER COLUMN  justificativa	nvarchar(max) 
		 UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO

	-----------------------------------------------------------------------------------------------------------------------
	--Obs.: no sqlserver2016 nao aceita usar o alter para objeto em lote
	--ser� necessario drop o objeto e recria-lo
	IF  EXISTS (SELECT * FROM sys.objects  WHERE object_id = OBJECT_ID('vw_re_historico_permissao'))
	BEGIN
	   DROP VIEW  vw_re_historico_permissao;
	END
	GO
	CREATE VIEW vw_re_historico_permissao  as (select  us.ur_username  as usuario,          
													co_nome, fi_nome, hp.operaremessaexpressa,     
													hp.operaApenasPendenteDeRecebimento, hp.operasemconsRFB, hp.edita_ordem,        
													hp.GeraArquivoFinanceiro,          
													hp.TipoDeArquivo, hp.PastaDestino, data_alteracao, us_ed.ur_username as usuario_edicao,         
													hp.id_user,  hp.id_user_edicao, hp.id_filial, hp.id_corretora, hp.justificativa
    
													FROM tbl_re_historico_permissao hp (nolock)        
													left join tbl_filiais fi (nolock) on fi.id_filial = hp.id_filial        
													left join tbl_corretoras co (nolock) on co.id_corretora = hp.id_corretora         
													left join tbl_users us (nolock) on us.id_user = hp.id_user         
													left join tbl_users us_ed (nolock) on us_ed.id_user = hp.id_user_edicao  )  
													GO
													UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
													

	GO
	-----------------------------------------------------------------------------------------------------------------------
	IF  EXISTS (SELECT * FROM sys.objects  WHERE object_id = OBJECT_ID('vw_re_historico_permissao'))
	BEGIN
	   DROP VIEW  vw_re_historico_permissao;
	END
	GO
	CREATE VIEW vw_re_historico_permissao  as (select  us.ur_username  as usuario,          
													co_nome, fi_nome, hp.operaremessaexpressa,     
													hp.operaApenasPendenteDeRecebimento, hp.operasemconsRFB, hp.edita_ordem,        
													hp.GeraArquivoFinanceiro,          
													hp.TipoDeArquivo, hp.PastaDestino, data_alteracao, us_ed.ur_username as usuario_edicao,         
													hp.id_user,  hp.id_user_edicao, hp.id_filial, hp.id_corretora, hp.justificativa
    
													FROM tbl_re_historico_permissao hp (nolock)        
													left join tbl_filiais fi (nolock) on fi.id_filial = hp.id_filial        
													left join tbl_corretoras co (nolock) on co.id_corretora = hp.id_corretora         
													left join tbl_users us (nolock) on us.id_user = hp.id_user         
													left join tbl_users us_ed (nolock) on us_ed.id_user = hp.id_user_edicao  )  
													GO
													UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1

	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_PROCURACAO_CLIENTE' AND B.[name] ='HASH_PROCURACAO')
	BEGIN
		ALTER TABLE  TBL_PROCURACAO_CLIENTE		ALTER COLUMN  HASH_PROCURACAO	nvarchar(max) 
		UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO
	IF EXISTS (SELECT A.[name] AS tabela,B.[name] AS coluna FROM sys.objects A JOIN sys.columns B ON B.[object_id] = A.[object_id]
			WHERE  A.is_ms_shipped = 0 AND  A.[name] ='TBL_BOLETO_ASSINADO_DIGITALMENTE' AND B.[name] ='HASH_DOCUMENTO')
	BEGIN
		ALTER TABLE  TBL_BOLETO_ASSINADO_DIGITALMENTE		ALTER COLUMN  HASH_DOCUMENTO	nvarchar(max) 
		UPDATE #QCount SET  LinhaAffe = LinhaAffe + 1
	END
	GO

	SELECT CONVERT(VARCHAR(10),LinhaAffe) +' CAMPOS TABELAS/VIEWS ALTERADOS PARA VARCHAR(MAX) COM SUCESSO!!!' FROM #QCount


COMMIT TRAN
DROP TABLE #QCount


