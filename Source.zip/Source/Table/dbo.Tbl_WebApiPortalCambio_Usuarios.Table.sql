USE [IK_VAREJO]
GO

/****** Object:  Table [dbo].[Tbl_WebApiPortalCambio_Usuarios]    Script Date: 08/30/2017 11:36:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Tbl_WebApiPortalCambio_Usuarios](
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[Login] [varchar](50) NOT NULL,
	[Senha] [varchar](15) NOT NULL,
	[Observacao] [varchar](200) NULL,
	[SpreadPF] [decimal](18, 4) NOT NULL,
	[SpreadPJ] [decimal](18, 4) NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Tbl_WebApiPortalCambio_Usuarios] ADD  CONSTRAINT [DF_Tbl_WebApiPortalCambio_Usuarios_SpreadPF]  DEFAULT ((0)) FOR [SpreadPF]
GO

ALTER TABLE [dbo].[Tbl_WebApiPortalCambio_Usuarios] ADD  CONSTRAINT [DF_Tbl_WebApiPortalCambio_Usuarios_SpreadPJ]  DEFAULT ((0)) FOR [SpreadPJ]
GO


