USE [IK_Varejo] 
GO

/****** Object:  Table [dbo].[TBL_REVERSAO_INBOUND]    Script Date: 11/13/2017 13:50:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TBL_REVERSAO_INBOUND](
	[ID_CANC_IN] [int] IDENTITY(1,1) NOT NULL,
	[DATACANC] [datetime] NULL,
	[OP_N_BOLETO] [int] NULL,
	[OP_N_BOLETO_VENDA] [int] NULL,
	[VALOR_ME] [decimal](18, 2) NULL,
	[VALOR_MN] [decimal](18, 2) NULL,
	[VALOR_IOF] [decimal](18, 2) NULL
) ON [PRIMARY]

GO


