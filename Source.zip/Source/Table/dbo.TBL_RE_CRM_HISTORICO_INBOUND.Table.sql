USE [IK_Varejo] 
GO

/****** Object:  Table [dbo].[TBL_RE_CRM_HISTORICO_INBOUND]    Script Date: 11/13/2017 15:04:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TBL_RE_CRM_HISTORICO_INBOUND](
	[id_crm_ocorrencia] [int] IDENTITY(1,1) NOT NULL,
	[op_n_boleto] [int] NULL,
	[dt_crm_ocorrencia] [datetime] NULL,
	[codigoEvento] [int] NULL,
	[dt_followup] [datetime] NULL,
	[descricao] [nvarchar](2000) NULL,
	[id_user] [int] NULL,
 CONSTRAINT [PK_Tbl_Re_Crm_Historico_Inbound] PRIMARY KEY CLUSTERED 
(
	[id_crm_ocorrencia] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[TBL_RE_CRM_HISTORICO_INBOUND] ADD  CONSTRAINT [DF_TBL_RE_CRM_OCORRENCIA_dt_crm_ocorrencia_inbound]  DEFAULT (getdate()) FOR [dt_crm_ocorrencia]
GO


