-- =====================================================================================================================================
-- Author:		C�ssio Drezza
-- Create date: 24/abr/19
-- Description:	Altera tipos Image ==> Binary(Max)
--							 Text  ==> VarChar(Max)
--							 Ntext ==> nVarChar(Max)
-------------------------------------------------------------------------------------------------
-- 683751.694173 - Projeto Migra��o SQL 2016 - Varejo
-------------------------------------------------------------------------------------------------
-- Hist�rico Altera��es
-- *********************
-- PRG_____________________ Data_____ Autor________ Descri��o__________________________________________
-- AlteraTipos_dbVarejo.sql 24/abr/19 C�ssio Drezza 683751.694173 - Projeto Migra��o SQL 2016 - Varejo
-- =====================================================================================================================================
Use dbVarejo	--	ATEN��O Esse script deve ser rodado ap�s a altera��o das colunas no IK_Varejo
Go
/****** Object:  View [dbo].[TBL_FILIAIS]    Script Date: 24/04/2019 14:12:01 ******/
ALTER VIEW [dbo].[TBL_FILIAIS] AS ( SELECT * FROM IK_VAREJO.dbo.TBL_FILIAIS )
Go
/****** Object:  View [dbo].[TBL_REENVIAR_EMAIL]    Script Date: 24/04/2019 14:13:23 ******/
ALTER VIEW [dbo].[TBL_REENVIAR_EMAIL] AS ( SELECT * FROM IK_VAREJO.dbo.TBL_REENVIAR_EMAIL )
Go
/****** Object:  View [dbo].[TBL_BOLETO_ASSINADO_DIGITALMENTE]    Script Date: 24/04/2019 14:16:27 ******/
ALTER VIEW [dbo].[TBL_BOLETO_ASSINADO_DIGITALMENTE] AS ( SELECT * FROM IK_VAREJO.dbo.TBL_BOLETO_ASSINADO_DIGITALMENTE WITH(NOLOCK) )
Go
/****** Object:  View [dbo].[TBL_PROCURACAO_CLIENTE]    Script Date: 24/04/2019 14:19:33 ******/
ALTER VIEW [dbo].[TBL_PROCURACAO_CLIENTE] AS ( SELECT * FROM IK_VAREJO.dbo.TBL_PROCURACAO_CLIENTE WITH(NOLOCK) )
Go
/****** Object:  View [dbo].[TBL_NATUREZA]    Script Date: 24/04/2019 14:21:17 ******/
ALTER VIEW [dbo].[TBL_NATUREZA] AS ( SELECT * FROM IK_VAREJO.dbo.TBL_NATUREZA WITH(NOLOCK) )
Go
/****** Object:  View [dbo].[TBL_CLIENTES]    Script Date: 24/04/2019 14:23:28 ******/
ALTER VIEW [dbo].[TBL_CLIENTES] AS ( SELECT * FROM IK_VAREJO.dbo.TBL_CLIENTES WITH(NOLOCK) )
Go
/*------------------------------- ---------------------------- ----- -------------- ------------------------- --------- -------
Tabela                            name                         name  system_type_id Server.DB_Name			  type_desc Nschema
--------------------------------- ---------------------------- ----- -------------- ------------------------- --------- -------
TBL_FILIAIS                       FI_OBS                       text  35             REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_REENVIAR_EMAIL                Dados                        text  35	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_BOLETO_ASSINADO_DIGITALMENTE  HASH_DOCUMENTO               ntext 99	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_PROCURACAO_CLIENTE            HASH_PROCURACAO              ntext 99	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_NATUREZA                      nat_obs                      text  35	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_NATUREZA                      portal_roteiro               text  35	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_NATUREZA                      portal_documentos            text  35	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_NATUREZA                      portal_documentos_ccme       text  35	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_NATUREZA                      portal_documentos_compra     text  35	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_NATUREZA                      portal_roteiro_compra        text  35	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_NATUREZA                      portal_natureza_sobre_compra text  35	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_NATUREZA                      portal_natureza_sobre        text  35	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_CLIENTES                      cl_obs                       text  35	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_CLIENTES                      cl_filiais                   text  35	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
TBL_CLIENTES                      cl_inf_operador              text  35	            REND-SRVDSQL-05.DBVarejo  VIEW      dbo    
--------------------------------- ---------------------------- ----- -------------- ------------------------- --------- -------
(15 row(s) affected)
*/