USE [IK_Varejo] 
GO

/****** Object:  Table [dbo].[TBL_RE_INBOUND]    Script Date: 11/13/2017 10:07:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[TBL_RE_INBOUND](
	[id_inbound] [int] IDENTITY(1,1) NOT NULL,
	[id_operacao] [int] NOT NULL,
	[numeroReferencia] [varchar](20) NOT NULL,
	[numeroConveniado] [varchar](8) NOT NULL,
	[numeroToken] [varchar](20) NOT NULL,
	[codigoLoja] [varchar](20) NOT NULL,
	[numeroTokenLoja] [varchar](2) NOT NULL,
	[versaoServico] [varchar](5) NOT NULL,
	[versaoApi] [varchar](5) NOT NULL,
	[codigoUsuario] [varchar](10) NOT NULL,
	[Recebedor] [varchar](150) NOT NULL,
	[dataHoraOperacao] [varchar](30) NOT NULL,
	[paisOrigem] [varchar](4) NOT NULL,
	[nmOpcaoEntrega] [varchar](50) NOT NULL,
	[Pagador] [varchar](150) NOT NULL,
	[moedaEnvio] [varchar](5) NOT NULL,
	[valorEnviado] [varchar](100) NOT NULL,
	[dataHoraResposta] [varchar](30) NOT NULL,
	[PerguntaTeste] [varchar](300) NOT NULL,
	[RespostaTeste] [varchar](300) NOT NULL,
	[Msg1] [varchar](300) NOT NULL,
	[Msg2] [varchar](300) NOT NULL,
	[TaxaCambioOriginalMG] [float] NULL,
	[MoedaOriginal] [char](3) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


