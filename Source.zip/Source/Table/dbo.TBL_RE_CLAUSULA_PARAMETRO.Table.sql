USE [IK_Varejo] 
GO

/****** Object:  Table [dbo].[TBL_RE_CLAUSULA_PARAMETRO]    Script Date: 11/14/2017 14:54:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[TBL_RE_CLAUSULA_PARAMETRO](
	[id_param] [int] IDENTITY(1,1) NOT NULL,
	[tipo_clausula] [varchar](1) NOT NULL,
	[descricao] [varchar](8000) NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


