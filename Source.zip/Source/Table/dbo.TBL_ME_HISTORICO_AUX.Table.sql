USE IK_VAREJO

-- TBL_ME_HISTORICO_AUX
CREATE TABLE TBL_ME_HISTORICO_AUX
(
	id_his INT NOT NULL IDENTITY PRIMARY KEY,
	tag VARCHAR(25),
	his_descricao VARCHAR(255),
	his_descricao_ingles VARCHAR(255),
	his_descricao_espanhol VARCHAR(255)
)

INSERT INTO TBL_ME_HISTORICO_AUX(tag, his_descricao, his_descricao_ingles, his_descricao_espanhol) 
						  VALUES('SALDO_ANTERIOR', 'SALDO ANTERIOR', 'BALANCE BEFORE', 'SALDO ANTERIOR')

INSERT INTO TBL_ME_HISTORICO_AUX(tag, his_descricao, his_descricao_ingles, his_descricao_espanhol) 
						  VALUES('SALDO_ATUAL', 'SALDO ATUAL', 'CURRENT BALANCE', 'SALDO ACTUAL')