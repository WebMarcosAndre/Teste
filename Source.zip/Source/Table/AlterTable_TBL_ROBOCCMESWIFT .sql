use IK_VAREJO
go

alter table TBL_ROBOCCMESWIFT add SWIFT_RESTRITIVA varchar(500) null
go

alter table TBL_ROBOCCMESWIFT add SWIFT_RESTRITIVA_LIDOS varchar(500) null
go

alter table TBL_ROBOCCMESWIFT add SWIFT_TRACKER varchar(500) null
go