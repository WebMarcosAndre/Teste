USE IK_VAREJO
GO 

/****** Object:  Table [dbo].[Tbl_Re_Tp_Solicitacao_CRM]    Script Date: 29/11/2017 12:57:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Tbl_Re_Tp_Solicitacao_CRM](
	[id_tp_solic_CRM] [int] IDENTITY(1,1) NOT NULL,
	[id_user] [int] NULL,
	[desc_solic_CRM] [varchar](200) NULL,
	[st_tp_solic_CRM] [char](1) NULL,
	[TIPO_OPERACAO_CRM] [varchar](15) NOT NULL DEFAULT ('Outbound'),
 CONSTRAINT [PK_Tbl_Re_Tp_Solicitacao_CRM] PRIMARY KEY CLUSTERED 
(
	[id_tp_solic_CRM] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE TBL_RE_TP_SOLICITACAO ADD TIPO_OPERACAO VARCHAR(15) NOT NULL DEFAULT 'Outbound'







