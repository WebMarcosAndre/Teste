USE [IK_VAREJO]
GO

/****** Object:  Table [dbo].[TBL_MEWEB_IDIOMAS]    Script Date: 06/27/2017 09:48:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
IF OBJECT_ID('dbo.TBL_LOG_EXTRATO_ANTIGO', 'U') IS NOT NULL 
  DROP TABLE dbo.TBL_LOG_EXTRATO_ANTIGO
GO 
CREATE TABLE [dbo].[TBL_LOG_EXTRATO_ANTIGO](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[id_Cliente] [int] NOT NULL,
	[dataSolic] [datetime] NOT NULL,
	[tipoRel] [varchar](10) NOT NULL,
    [dataInical] [datetime] NOT NULL,
    [dataFinal] [datetime] NOT NULL,
    [Status] [char](1) NULL,
    [dataAtualizacao] [datetime] NULL,
    [numeroAnexo][varchar](100)NULL,
    [codMoeda][varchar](10)NOT NULL
 )
	


