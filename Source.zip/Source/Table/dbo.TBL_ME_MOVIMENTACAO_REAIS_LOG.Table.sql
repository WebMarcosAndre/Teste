USE [IK_Varejo]
GO

/****** Object:  Table [dbo].[TBL_ME_MOVIMENTACAO_REAIS_LOG]    Script Date: 03/22/2017 16:12:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
IF OBJECT_ID('dbo.TBL_ME_MOVIMENTACAO_REAIS_LOG', 'U') IS NOT NULL 
  DROP TABLE dbo.TBL_ME_MOVIMENTACAO_REAIS_LOG
GO 
CREATE TABLE [dbo].[TBL_ME_MOVIMENTACAO_REAIS_LOG](
	[id_mov_log] [int] IDENTITY(1,1) NOT NULL,
	[id_mov] [int] NULL,
	[mov_cliente] [int] NULL,
	[mov_moeda] [varchar](10) NULL,
	[mov_tipo] [varchar](1) NULL,
	[mov_tipo_op] [varchar](10) NULL,
	[mov_qtde_cheque] [int] NULL,
	[mov_valor_cheque] [decimal](13, 2) NULL,
	[mov_historico] [int] NULL,
	[mov_valor] [decimal](13, 2) NULL,
	[mov_tipo_user] [char](1) NULL,
	[mov_user] [int] NULL,
	[mov_dt_disp] [datetime] NULL,
	[mov_moeda2] [varchar](10) NULL,
	[mov_paridade] [decimal](10, 6) NULL,
	[mov_tarifa] [decimal](10, 6) NULL,
	[mov_perc_tarifa] [decimal](10, 6) NULL,
	[mov_obs] [text] NULL,
	[mov_data] [datetime] NULL,
	[mov_data2] [datetime] NULL,
	[mov_flag_disp] [char](1) NULL,
	[mov_flag_bloq] [char](2) NULL,
	[mov_dt_lib] [datetime] NULL,
	[mov_obs_lib] [varchar](2000) NULL,
	[mov_observacao] [varchar](255) NULL,
	[mov_hist_tarifa] [int] NULL,
	[MOV_PARIDADE_MANUAL_DEBITO] [decimal](10, 6) NULL,
	[MOV_PARIDADE_MANUAL_CREDITO] [decimal](10, 6) NULL,
	[mov_tarifa_mov] [decimal](16, 2) NULL,
	[ID_MOV_TARIFA] [int] NULL,
	[ID_MOV_ORIGEM] [int] NULL,
	[ID_MOV_DESTINO] [int] NULL,
	[mov_status] [char](1) NULL,
	[integrado] [char](1) NULL,
	[data_integracao] [datetime] NULL,
	[COD_RECEIVER] [varchar](20) NULL,
	[ID_ORDEM] [int] NULL,
	[DATA_LIBERACAO] [smalldatetime] NULL,
	[MOV_CBR_VTM_DE] [datetime] NULL,
	[MOV_CBR_VTM_ATE] [datetime] NULL,
	[integrado_COTACAO] [char](1) NULL,
	[DATA_INTEGRACAO_Cotacao] [datetime] NULL,
	[ID_USER_EXCLUSAO] [int] NULL,
	[DATA_EXCLUSAO] [smalldatetime] NULL,
	[ACAO_EXCLUSAO] [varchar](50) NULL,
	[STATUS_EXCLUSAO] [int] NULL,
 CONSTRAINT [PK_TBL_ME_MOVIMENTACAO_REAIS_LOG] PRIMARY KEY CLUSTERED 
(
	[id_mov_log] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO



Alter Table dbo.TBL_ME_MOVIMENTACAO_REAIS_LOG	alter column Mov_Obs VarChar(2000);
