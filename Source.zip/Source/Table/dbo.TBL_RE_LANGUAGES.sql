USE [IK_VAREJO]
GO

/****** Object:  Table [dbo].[TBL_RE_LANGUAGES]    Script Date: 08/29/2016 12:50:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TBL_RE_LANGUAGES](
	[id] [int] IDENTITY NOT NULL,
	[id_language] [int] NOT NULL,
	[language] [VARCHAR] (15) NOT NULL,
	[title] [VARCHAR] (70) NOT NULL,	
	[select_lang] [VARCHAR] (70) NOT NULL	
) ON [PRIMARY]

GO

