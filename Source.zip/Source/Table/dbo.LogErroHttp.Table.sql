USE IK_VAREJO
GO

/*
TABELA PARA ARMAZENAR OS LOGS DE RROS HTTP
*/
IF NOT EXISTS(SELECT 0 FROM SYS.tables WHERE name = 'LogErroHttp')
BEGIN
	CREATE TABLE dbo.LogErroHttp
	(
		LogErroHttpId INT IDENTITY PRIMARY KEY
		, Aplicacao VARCHAR(40)
		, Codigo VARCHAR(10)
		, Numero INT
		, Descricao VARCHAR(250)
		, Arquivo VARCHAR(250)
		, NumeroLinha SMALLINT
		, Url VARCHAR(250)
		, UrlAnterior VARCHAR(2000)
		, DadosGet VARCHAR(2000)
		, DadosPost VARCHAR(5000)
		, DadosSessao VARCHAR(2000)
		, IpCliente VARCHAR(40)
		, DataInclusao DATETIME
		, Verificado BIT
	)
END
GO