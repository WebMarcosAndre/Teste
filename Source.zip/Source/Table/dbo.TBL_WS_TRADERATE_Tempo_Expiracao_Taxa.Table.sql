USE [IK_VAREJO]
GO

/****** Object:  Table [dbo].[TBL_Tempo_Expiracao_Taxa]    Script Date: 05/09/2017 14:56:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[TBL_WS_TRADERATE_Tempo_Expiracao_Taxa](
	[IdExpiracao] [int] IDENTITY(1,1) NOT NULL,
	[Cod_Empresa] [varchar](15) NOT NULL,
	[TempoExpiracao] [int] NOT NULL,
[Ativo] [bit] NOT NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
