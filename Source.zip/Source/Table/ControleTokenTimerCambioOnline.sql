USE IK_VAREJO
GO

IF EXISTS(SELECT TOP 1 NAME FROM sys.TABLES WHERE name = 'ControleTokenTimerCambioOnline')
	DROP TABLE ControleTokenTimerCambioOnline

GO

CREATE TABLE ControleTokenTimerCambioOnline
(
Token VARCHAR(100) NOT NULL,
LiId INT NOT NULL,
TokenConfigId INT NULL,
SimboloMoeda VARCHAR(5) NOT NULL,
QuantidadeMoeda DECIMAL(18,2) NOT NULL,
TaxaMoeda DECIMAL (18,2) NOT NULL,
IOF DECIMAL (18,2) NOT NULL,
Utilizado BIT DEFAULT(0),
PreBoletoID INT NULL,
DataCriacao DATETIME DEFAULT(GETDATE())
)

ALTER TABLE ControleTokenTimerCambioOnline ADD CONSTRAINT pk_ControleTokenTimerCambioOnline PRIMARY KEY (Token)

SELECT * FROM ControleTokenTimerCambioOnline
