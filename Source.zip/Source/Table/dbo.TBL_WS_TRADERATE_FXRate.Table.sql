USE [IK_VAREJO]
GO

/****** Object:  Table [dbo].[TBL_SellingTradeRate]    Script Date: 05/09/2017 16:01:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[TBL_WS_TRADERATE_FXRate](
	[FXRateId] [int] IDENTITY(1,1) NOT NULL,
	[Taxa] [float] NOT NULL,
	[ExpirationDate] [datetime] NOT NULL,
	[Cod_Empresa] [varchar](15) NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO
