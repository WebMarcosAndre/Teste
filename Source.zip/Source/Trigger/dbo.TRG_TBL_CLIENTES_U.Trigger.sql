USE IK_Varejo
GO

ALTER TRIGGER [dbo].[TRG_TBL_CLIENTES_U]
ON [dbo].[TBL_CLIENTES]
AFTER UPDATE
AS
BEGIN
	SET NOCOUNT ON

	-- CONSULTA O ID DO USUARIO NA TABELA GLOBAL
	DECLARE @ID_USUARIO INT
	EXEC dbo.PR_USER_TRG_TBL_CLIENTES @ID_USUARIO OUTPUT
	
	-- INCLUI NO CRM SOMENTE OS VALORES DIFERNETES
	INSERT INTO TBL_CRM (id_usuario, id_corretora, crm_cpf_cnpj, crm_nboleto, crm_data, crm_ocorrencia)
	SELECT ISNULL(@ID_USUARIO, 0), CORRETORA, CPF_CNPJ, 0, GETDATE()
		, 'Cliente Alterado - ' + VALOR
	FROM (
		SELECT
			D.cl_num_doc AS CPF_CNPJ
			, D.ID_CORRETORA AS CORRETORA
			, dbo.FN_MSG_TRG_CLIENTES_U('Corretora', D.id_corretora, I.id_corretora) AS id_corretora
			, dbo.FN_MSG_TRG_CLIENTES_U('Assessor', D.id_assessor, I.id_assessor) AS id_assessor
			, dbo.FN_MSG_TRG_CLIENTES_U('Apresentatante', D.id_apresentante, I.id_apresentante) AS id_apresentante
			, dbo.FN_MSG_TRG_CLIENTES_U('Nome', D.cl_nome, I.cl_nome) AS cl_nome
			, dbo.FN_MSG_TRG_CLIENTES_U('Sobrenome', D.cl_sobrenome, I.cl_sobrenome) AS cl_sobrenome
			, dbo.FN_MSG_TRG_CLIENTES_U('Endere�o', D.cl_endereco, I.cl_endereco) AS cl_endereco
			, dbo.FN_MSG_TRG_CLIENTES_U('Complemento', D.cl_complemento, I.cl_complemento) AS cl_complemento
			, dbo.FN_MSG_TRG_CLIENTES_U('Bairro', D.cl_bairro, I.cl_bairro) AS cl_bairro
			, dbo.FN_MSG_TRG_CLIENTES_U('Cidade', D.cl_cidade, I.cl_cidade) AS cl_cidade
			, dbo.FN_MSG_TRG_CLIENTES_U('EStado', D.cl_estado, I.cl_estado) AS cl_estado
			, dbo.FN_MSG_TRG_CLIENTES_U('CEP', D.cl_cep, I.cl_cep) AS cl_cep
			, dbo.FN_MSG_TRG_CLIENTES_U('Pais', D.cl_pais, I.cl_pais) AS cl_pais
			, dbo.FN_MSG_TRG_CLIENTES_U('Residente no Brasil', D.cl_residente, I.cl_residente) AS cl_residente
			, dbo.FN_MSG_TRG_CLIENTES_U('Telefone', D.cl_tel_res, I.cl_tel_res) AS cl_tel_res
			, dbo.FN_MSG_TRG_CLIENTES_U('Celular', D.cl_celular, I.cl_celular) AS cl_celular
			, dbo.FN_MSG_TRG_CLIENTES_U('Email', D.cl_email, I.cl_email) AS cl_email
			, dbo.FN_MSG_TRG_CLIENTES_U('Pa�s de Nacionalidade', D.cl_nacionalidade, I.cl_nacionalidade) AS cl_nacionalidade
			, dbo.FN_MSG_TRG_CLIENTES_U('Estado C�vil', D.cl_estado_civil, I.cl_estado_civil) AS cl_estado_civil
			, dbo.FN_MSG_TRG_CLIENTES_U('Nome do Pai', D.nome_pai, I.nome_pai) AS nome_pai
			, dbo.FN_MSG_TRG_CLIENTES_U('Nome da M�e', D.nome_mae, I.nome_mae) AS nome_mae
			, dbo.FN_MSG_TRG_CLIENTES_U('Dade de Nascimento', D.cl_dt_nasc, I.cl_dt_nasc) AS cl_dt_nasc
			, dbo.FN_MSG_TRG_CLIENTES_U('Local de Nascimento', D.cl_local_nasc, I.cl_local_nasc) AS cl_local_nasc
			, dbo.FN_MSG_TRG_CLIENTES_U('RG', D.cl_rg, I.cl_rg) AS cl_rg
			, dbo.FN_MSG_TRG_CLIENTES_U('Org�o Emissor', D.cl_orgao_exp, I.cl_orgao_exp) AS cl_orgao_exp
			, dbo.FN_MSG_TRG_CLIENTES_U('Tipo de Documento', D.cl_tip_doc, I.cl_tip_doc) AS cl_tip_doc
			, dbo.FN_MSG_TRG_CLIENTES_U('N�mero do Documento', D.cl_num_doc, I.cl_num_doc) AS cl_num_doc
			, dbo.FN_MSG_TRG_CLIENTES_U('Profiss�o', D.cl_profissao, I.cl_profissao) AS cl_profissao
			, dbo.FN_MSG_TRG_CLIENTES_U('CPF', D.doc_cpf, I.doc_cpf) AS doc_cpf
			, dbo.FN_MSG_TRG_CLIENTES_U('Conta de Luz', D.doc_luz, I.doc_luz) AS doc_luz
			, dbo.FN_MSG_TRG_CLIENTES_U('Identidade', D.doc_rg, I.doc_rg) AS doc_rg
			, dbo.FN_MSG_TRG_CLIENTES_U('Escrituras', D.doc_escrituras, I.doc_escrituras) AS doc_escrituras
			, dbo.FN_MSG_TRG_CLIENTES_U('Declara��o de Bens', D.doc_bens, I.doc_bens) AS doc_bens
			, dbo.FN_MSG_TRG_CLIENTES_U('�ltimo Holerite', D.doc_holerite, I.doc_holerite) AS doc_holerite
			, dbo.FN_MSG_TRG_CLIENTES_U('Cadastro', D.doc_cadastro, I.doc_cadastro) AS doc_cadastro
			, dbo.FN_MSG_TRG_CLIENTES_U('Cart�o de Assinatura', D.doc_cartao_ass, I.doc_cartao_ass) AS doc_cartao_ass
			, dbo.FN_MSG_TRG_CLIENTES_U('IR', D.doc_ir, I.doc_ir) AS doc_ir
			, dbo.FN_MSG_TRG_CLIENTES_U('Procura��es', D.doc_procuracao, I.doc_procuracao) AS doc_procuracao
			, dbo.FN_MSG_TRG_CLIENTES_U('Recebido em', D.doc_recebido, I.doc_recebido) AS doc_recebido
			, dbo.FN_MSG_TRG_CLIENTES_U('Vencimento', D.doc_vencimento, I.doc_vencimento) AS doc_vencimento
			, dbo.FN_MSG_TRG_CLIENTES_U('Contrato Social', D.doc_contrato_social, I.doc_contrato_social) AS doc_contrato_social
			, dbo.FN_MSG_TRG_CLIENTES_U('Ficha Cadastro', D.doc_ficha_cadastro, I.doc_ficha_cadastro) AS doc_ficha_cadastro
			, dbo.FN_MSG_TRG_CLIENTES_U('Cadastro de S�cios', D.doc_cadastro_socios, I.doc_cadastro_socios) AS doc_cadastro_socios
			, dbo.FN_MSG_TRG_CLIENTES_U('C�pia CNPJ', D.doc_copia_cnpj, I.doc_copia_cnpj) AS doc_copia_cnpj
			, dbo.FN_MSG_TRG_CLIENTES_U('Status', 
					CASE D.cl_status WHEN 'A' THEN 'Ativo' WHEN 'B' THEN 'Bloqueado' WHEN 'I' THEN 'Inativo' END, 
					CASE I.cl_status WHEN 'A' THEN 'Ativo' WHEN 'B' THEN 'Bloqueado' WHEN 'I' THEN 'Inativo' END) AS cl_status
			, dbo.FN_MSG_TRG_CLIENTES_U('Cadastro Vencido', D.cl_cad_venc, I.cl_cad_venc) AS cl_cad_venc
			--, dbo.FN_MSG_TRG_CLIENTES_U('Informa��es do Cliente', CAST(D.cl_obs AS VARCHAR(2000)), CAST(I.cl_obs AS VARCHAR(2000))) AS cl_obs
			, dbo.FN_MSG_TRG_CLIENTES_U('Raz�o Social', D.cl_razao_social, I.cl_razao_social) AS cl_razao_social
			, dbo.FN_MSG_TRG_CLIENTES_U('Nome Fantasia', D.cl_nome_fantasia, I.cl_nome_fantasia) AS cl_nome_fantasia
			, dbo.FN_MSG_TRG_CLIENTES_U('Inscri��o Estadual', D.cl_insc_estadual, I.cl_insc_estadual) AS cl_insc_estadual
			, dbo.FN_MSG_TRG_CLIENTES_U('Inscri��o Municipal', D.cl_insc_municipal, I.cl_insc_municipal) AS cl_insc_municipal
			, dbo.FN_MSG_TRG_CLIENTES_U('Nome do Grupo Banc�rio', D.cl_nome_grupo, I.cl_nome_grupo) AS cl_nome_grupo
			, dbo.FN_MSG_TRG_CLIENTES_U('Data de sucess�o', D.cl_dt_sucessao, I.cl_dt_sucessao) AS cl_dt_sucessao
			, dbo.FN_MSG_TRG_CLIENTES_U('Empresa a que sucede', D.cl_empresa_sucede, I.cl_empresa_sucede) AS cl_empresa_sucede
			--, dbo.FN_MSG_TRG_CLIENTES_U('Filiais', CAST(D.cl_filiais AS VARCHAR(2000)), CAST(I.cl_filiais AS VARCHAR(2000))) AS cl_filiais
			, dbo.FN_MSG_TRG_CLIENTES_U('Ramo Atividade', D.cl_ramo_ativ, I.cl_ramo_ativ) AS cl_ramo_ativ
			, dbo.FN_MSG_TRG_CLIENTES_U('N�mero de Empregados', D.cl_num_empregados, I.cl_num_empregados) AS cl_num_empregados
			, dbo.FN_MSG_TRG_CLIENTES_U('Vendas do �ltimo exerc�cio', D.cl_faturamento, I.cl_faturamento) AS cl_faturamento
			, dbo.FN_MSG_TRG_CLIENTES_U('Importa', D.cl_imp_exp, I.cl_imp_exp) AS cl_imp_exp
			--, dbo.FN_MSG_TRG_CLIENTES_U('Informa��es para o Operador', CAST(D.cl_inf_operador AS VARCHAR(2000)), CAST(I.cl_inf_operador AS VARCHAR(2000))) AS cl_inf_operador
			, dbo.FN_MSG_TRG_CLIENTES_U('Banco', D.cl_banco, I.cl_banco) AS cl_banco
			, dbo.FN_MSG_TRG_CLIENTES_U('Conta', D.cl_conta, I.cl_conta) AS cl_conta
			, dbo.FN_MSG_TRG_CLIENTES_U('C�digo do Banco', D.cl_cod_banco, I.cl_cod_banco) AS cl_cod_banco
			, dbo.FN_MSG_TRG_CLIENTES_U('Ag�ncia', D.cl_agencia, I.cl_agencia) AS cl_agencia
			, dbo.FN_MSG_TRG_CLIENTES_U('Tarifa', D.cl_tarifa, I.cl_tarifa) AS cl_tarifa
			, dbo.FN_MSG_TRG_CLIENTES_U('Tipo Conta', D.cl_tipo_conta, I.cl_tipo_conta) AS cl_tipo_conta
			, dbo.FN_MSG_TRG_CLIENTES_U('Data de Abertura', D.cl_data_abertura, I.cl_data_abertura) AS cl_data_abertura
			, dbo.FN_MSG_TRG_CLIENTES_U('Banco 2', D.cl_banco2, I.cl_banco2) AS cl_banco2
			, dbo.FN_MSG_TRG_CLIENTES_U('Conta 2', D.cl_conta2, I.cl_conta2) AS cl_conta2
			, dbo.FN_MSG_TRG_CLIENTES_U('C�digo do Banco 2', D.cl_cod_banco2, I.cl_cod_banco2) AS cl_cod_banco2
			, dbo.FN_MSG_TRG_CLIENTES_U('Ag�ncia 2', D.cl_agencia2, I.cl_agencia2) AS cl_agencia2
			, dbo.FN_MSG_TRG_CLIENTES_U('Tipo de Conta 2', D.cl_tipo_conta2, I.cl_tipo_conta2) AS cl_tipo_conta2
			, dbo.FN_MSG_TRG_CLIENTES_U('Data de Abertura 2', D.cl_data_abertura2, I.cl_data_abertura2) AS cl_data_abertura2
			, dbo.FN_MSG_TRG_CLIENTES_U('Banco 3', D.cl_banco3, I.cl_banco3) AS cl_banco3
			, dbo.FN_MSG_TRG_CLIENTES_U('Conta 3', D.cl_conta3, I.cl_conta3) AS cl_conta3
			, dbo.FN_MSG_TRG_CLIENTES_U('C�digo do Banco 3', D.cl_cod_banco3, I.cl_cod_banco3) AS cl_cod_banco3
			, dbo.FN_MSG_TRG_CLIENTES_U('Ag�ncia 3', D.cl_agencia3, I.cl_agencia3) AS cl_agencia3
			, dbo.FN_MSG_TRG_CLIENTES_U('Tipo de Conta 3', D.cl_tipo_conta3, I.cl_tipo_conta3) AS cl_tipo_conta3
			, dbo.FN_MSG_TRG_CLIENTES_U('Data de Abertura 3', D.cl_data_abertura3, I.cl_data_abertura3) AS cl_data_abertura3
			, dbo.FN_MSG_TRG_CLIENTES_U('Passaporte', D.CL_PASSAPORTE, I.CL_PASSAPORTE) AS CL_PASSAPORTE
			, dbo.FN_MSG_TRG_CLIENTES_U('Comercial', D.cl_tel_com, I.cl_tel_com) AS cl_tel_com
			, dbo.FN_MSG_TRG_CLIENTES_U('Principal Contato', D.CL_CONTATO, I.CL_CONTATO) AS CL_CONTATO
			, dbo.FN_MSG_TRG_CLIENTES_U('Endere�o de Correspond�ncia � igual', D.CL_TIPO_END_CORRESP, I.CL_TIPO_END_CORRESP) AS CL_TIPO_END_CORRESP
			, dbo.FN_MSG_TRG_CLIENTES_U('Empresa Vinculada', D.CL_EM_VINCULADA, I.CL_EM_VINCULADA) AS CL_EM_VINCULADA
			, dbo.FN_MSG_TRG_CLIENTES_U('Data Follow Up', D.CL_DATA_FOLLOW_UP, I.CL_DATA_FOLLOW_UP) AS CL_DATA_FOLLOW_UP
			, dbo.FN_MSG_TRG_CLIENTES_U('Permite ME', D.CL_FLAG_CONTAME, I.CL_FLAG_CONTAME) AS CL_FLAG_CONTAME
			, dbo.FN_MSG_TRG_CLIENTES_U('IOF Isento', D.IOF_Isento, I.IOF_Isento) AS IOF_Isento
			, dbo.FN_MSG_TRG_CLIENTES_U('Cliente � isento de IR', D.IR_Isento, I.IR_Isento) AS IR_Isento
			, dbo.FN_MSG_TRG_CLIENTES_U('Efetiva��o autom�tica para Ordens GOOGLE', D.flg_aceita_efet_auto_ordem, I.flg_aceita_efet_auto_ordem) AS flg_aceita_efet_auto_ordem
			, dbo.FN_MSG_TRG_CLIENTES_U('Cliente possui valor diferenciado', D.flg_valor_diferenciado, I.flg_valor_diferenciado) AS flg_valor_diferenciado
			, dbo.FN_MSG_TRG_CLIENTES_U('Assina contrato digitalmente (E-Contrato)', D.Flg_Assina_Digitalmente, I.Flg_Assina_Digitalmente) AS Flg_Assina_Digitalmente
			, dbo.FN_MSG_TRG_CLIENTES_U('Classifica��o do Cliente', D.CL_COD_VENDEDOR, I.CL_COD_VENDEDOR) AS CL_COD_VENDEDOR
			, dbo.FN_MSG_TRG_CLIENTES_U('Opera somente no Banco', D.cl_OperaSomenteBanco, I.cl_OperaSomenteBanco) AS cl_OperaSomenteBanco
			, dbo.FN_MSG_TRG_CLIENTES_U('CNPJ da institui��o financeira', D.CL_CNPJ_INST, I.CL_CNPJ_INST) AS CL_CNPJ_INST
			, dbo.FN_MSG_TRG_CLIENTES_U('CNPJ da institui��o financeira 2', D.CL_CNPJ_INST2, I.CL_CNPJ_INST2) AS CL_CNPJ_INST2
			, dbo.FN_MSG_TRG_CLIENTES_U('CNPJ da institui��o financeira 3', D.CL_CNPJ_INST3, I.CL_CNPJ_INST3) AS CL_CNPJ_INST3
			, dbo.FN_MSG_TRG_CLIENTES_U('Recebe Pr�-Boleto autom�tico', D.PreBoletoCompraAutomatico, I.PreBoletoCompraAutomatico) AS PreBoletoCompraAutomatico
			, dbo.FN_MSG_TRG_CLIENTES_U('Pa�s de Nacionalidade', D.COD_PAIS_NACIONALIDADE, I.COD_PAIS_NACIONALIDADE) AS COD_PAIS_NACIONALIDADE
			, dbo.FN_MSG_TRG_CLIENTES_U('NIF', D.cl_nif, I.cl_nif) AS cl_nif
			, dbo.FN_MSG_TRG_CLIENTES_U('Data Emiss�o Passaporte', D.cl_dt_passaporte, I.cl_dt_passaporte) AS cl_dt_passaporte
			, dbo.FN_MSG_TRG_CLIENTES_U('Permitido IR na Sa�da', D.IR_SAIDA, I.IR_SAIDA) AS IR_SAIDA
			, dbo.FN_MSG_TRG_CLIENTES_U('Processa Google Portal', D.flg_ProcessaGooglePortal, I.flg_ProcessaGooglePortal) AS flg_ProcessaGooglePortal
			, dbo.FN_MSG_TRG_CLIENTES_U('Porte da Empresa', D.CL_PORTE_EMPRESA, I.CL_PORTE_EMPRESA) AS CL_PORTE_EMPRESA
			, dbo.FN_MSG_TRG_CLIENTES_U('Data Perman�ncia no N�vel Compliance', D.CL_DT_LIMITE_NIVEL_COMP, I.CL_DT_LIMITE_NIVEL_COMP) AS CL_DT_LIMITE_NIVEL_COMP
			, dbo.FN_MSG_TRG_CLIENTES_U('Data Perman�ncia no N�vel Cr�dito', D.CL_DT_LIMITE_NIVEL_CRED, I.CL_DT_LIMITE_NIVEL_CRED) AS CL_DT_LIMITE_NIVEL_CRED
		FROM INSERTED I
		INNER JOIN DELETED D
			ON D.ID_CLIENTE = I.ID_CLIENTE
	) AS SEL
	UNPIVOT (
		VALOR FOR COLUNA IN(id_corretora, id_assessor, id_apresentante, cl_nome, cl_sobrenome, cl_endereco, cl_complemento, cl_bairro, cl_cidade, cl_estado, cl_cep, cl_pais, cl_residente, cl_tel_res, cl_celular, cl_email
				, cl_nacionalidade, cl_estado_civil, nome_pai, nome_mae, cl_dt_nasc, cl_local_nasc, cl_rg, cl_orgao_exp, cl_tip_doc, cl_num_doc, cl_profissao, doc_cpf, doc_luz, doc_rg, doc_escrituras, doc_bens, doc_holerite
				, doc_cadastro, doc_cartao_ass, doc_ir, doc_procuracao, doc_recebido, doc_vencimento, doc_contrato_social, doc_ficha_cadastro, doc_cadastro_socios, doc_copia_cnpj, cl_status, cl_cad_venc, cl_razao_social
				, cl_nome_fantasia, cl_insc_estadual, cl_insc_municipal, cl_nome_grupo, cl_dt_sucessao, cl_empresa_sucede, cl_ramo_ativ, cl_num_empregados, cl_faturamento, cl_imp_exp, cl_banco, cl_conta, cl_cod_banco
				, cl_agencia, cl_tarifa, cl_tipo_conta, cl_data_abertura, cl_banco2, cl_conta2, cl_cod_banco2, cl_agencia2, cl_tipo_conta2, cl_data_abertura2, cl_banco3, cl_conta3, cl_cod_banco3, cl_agencia3, cl_tipo_conta3
				, cl_data_abertura3, CL_PASSAPORTE, cl_tel_com, CL_CONTATO, CL_TIPO_END_CORRESP, CL_EM_VINCULADA, CL_DATA_FOLLOW_UP, CL_FLAG_CONTAME, IOF_Isento, IR_Isento, flg_aceita_efet_auto_ordem, flg_valor_diferenciado
				, Flg_Assina_Digitalmente, CL_COD_VENDEDOR, cl_OperaSomenteBanco, CL_CNPJ_INST, CL_CNPJ_INST2, CL_CNPJ_INST3, PreBoletoCompraAutomatico, COD_PAIS_NACIONALIDADE, cl_nif, cl_dt_passaporte, IR_SAIDA, flg_ProcessaGooglePortal
				, CL_PORTE_EMPRESA, CL_DT_LIMITE_NIVEL_COMP, CL_DT_LIMITE_NIVEL_CRED)
	) AS UPVT
	WHERE VALOR <> ''

	SET NOCOUNT OFF
END
