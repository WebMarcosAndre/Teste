CREATE PROCEDURE SP_Trata_Telefone (

@TELEFONE       VARCHAR(30)
)
AS
BEGIN 
--SET @TELEFONE = '11999664153'
--SET @TELEFONE = '01132941890'
--SET @TELEFONE = '+55 11-32941890 333333333'


SET NOCOUNT ON 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED 

DECLARE @CONTA                                 INT
DECLARE @ATUAL                                 INT
DECLARE @CONTADOR_GERAL                  INT
DECLARE @LINHA                                 INT
DECLARE @POSICAO                         INT
DECLARE @TAMANHO                         INT
DECLARE @POSITION                        INT

DECLARE @STRING_ORIGINAL                 VARCHAR(50)
DECLARE @CODIGO_PAIS                     VARCHAR(10)
DECLARE @DDD                                   VARCHAR(10)
DECLARE @TELEFONE1                             VARCHAR(10)
DECLARE @TELEFONE2                             VARCHAR(10)
DECLARE @STRING_REST                     VARCHAR(50)
DECLARE @STRING                     VARCHAR(50)

DECLARE @TBL_TELEFONES_TRATADO TABLE 
(
      ID_LINHA          INT,
      TELEFONE_ERRO     VARCHAR(30),
        CODIGO_PAIS           VARCHAR(10),
      DDD               VARCHAR(10),
      TELEFONE1         VARCHAR(10),
      TELEFONE2         VARCHAR(10),
      STRING_REST       VARCHAR(30)
)

IF LEN(RTRIM(LTRIM(@TELEFONE))) < 8 
BEGIN
      GOTO SAIDA
END

INSERT INTO @TBL_TELEFONES_TRATADO
(ID_LINHA, TELEFONE_ERRO)
SELECT 1, 
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
      REPLACE(UPPER(@TELEFONE),'  ',' '),'A',''),'B',''),'C',''),'D',''),'E','')
      ,'F',''),'G',''),'H',''),'I',''),'J',''),'K',''),'L',''),'M',''),'N','')
      ,'O',''),'P',''),'Q',''),'R',''),'S',''),'T',''),'U',''),'V',''),'W',''),'X',''),'Y',''),'Z','')

SELECT @CONTA = 1

SET @ATUAL = 1
SET @LINHA = 0 
SET @POSICAO = 0
SET @TAMANHO = 0 

WHILE @ATUAL <= @CONTA
BEGIN 

      --------------TRATA O DDD
        SET @CODIGO_PAIS = ''
      SET @DDD = ''
      SET @TELEFONE1 = ''
      SET @TELEFONE2 = ''
      SET @STRING_REST = ''
      SET @TAMANHO = 0  


      SELECT 
      @STRING_ORIGINAL = TELEFONE_ERRO,
      @CODIGO_PAIS = 
            CASE WHEN SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),CHARINDEX('+', TELEFONE_ERRO),1) = '+' THEN 
                  CASE WHEN SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),CHARINDEX(' ', TELEFONE_ERRO),1) = ' ' THEN 
                        RTRIM(LTRIM(
                             REPLACE(                     
                                   REPLACE(
                                                           SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),(CHARINDEX('+', TELEFONE_ERRO) + 1),  
                                         CHARINDEX(' ', TELEFONE_ERRO) - (CHARINDEX('+', TELEFONE_ERRO))), '+', '')
                                   ,' ','')
                             ))
                        
                  ELSE
                        ''
                  END
            ELSE
                  --CASE WHEN SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),4,1) = ' ' THEN 
                  --      SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),2,2)
                  --ELSE
                  --      CASE WHEN SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),3,1) = ' ' THEN 
                  --           SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),1,2)
                  --      ELSE
                  --           CASE WHEN SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),3,1) = '-' THEN 
                  --                 SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),1,2)
                  --           ELSE
                                   ''
                  --           END
                  --      END
                  --END
            END,

      @STRING_REST = 
            CASE WHEN SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),CHARINDEX('+', TELEFONE_ERRO),1) = '+' THEN 
                  CASE WHEN SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),CHARINDEX(' ', TELEFONE_ERRO),1) = ' ' THEN 
                        SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),(CHARINDEX(' ', TELEFONE_ERRO) + 1),
                        (LEN(RTRIM(LTRIM(TELEFONE_ERRO))) - CHARINDEX(' ', TELEFONE_ERRO)))
                  ELSE
                        ''
                  END
            ELSE
                  --CASE WHEN SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),4,1) = ' ' THEN 
                  --      SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),5,(LEN(RTRIM(LTRIM(TELEFONE_ERRO))) - 4))
                  --ELSE
                  --      CASE WHEN SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),3,1) = ' ' THEN 
                  --            SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),4,(LEN(RTRIM(LTRIM(TELEFONE_ERRO))) - 3))
                  --      ELSE
                  --           CASE WHEN SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),3,1) = '-' THEN 
                  --                 SUBSTRING(RTRIM(LTRIM(TELEFONE_ERRO)),4,(LEN(RTRIM(LTRIM(TELEFONE_ERRO))) - 3))
                  --           ELSE
                                   ''
                  --           END
                  --      END
                  --END
            END,
      @STRING = RTRIM(LTRIM(TELEFONE_ERRO))
      FROM @TBL_TELEFONES_TRATADO
      WHERE ID_LINHA = @ATUAL
      
      SELECT 
      @STRING_REST = RTRIM(LTRIM(TELEFONE_ERRO))
      FROM @TBL_TELEFONES_TRATADO
      WHERE ID_LINHA = @ATUAL
      AND LTRIM(RTRIM(@STRING_REST)) = ''
      
      --SELECT @CODIGO_PAIS, @STRING_ORIGINAL, @DDD, @STRING_REST, @STRING
      
      

      SELECT 
      --@STRING_ORIGINAL = TELEFONE_ERRO,
      @DDD = 
            CASE WHEN SUBSTRING(RTRIM(LTRIM(@STRING_REST)),CHARINDEX('(', @STRING_REST),1) = '(' THEN 
                  CASE WHEN SUBSTRING(RTRIM(LTRIM(@STRING_REST)),CHARINDEX(')', @STRING_REST),1) = ')' THEN 
                        RTRIM(LTRIM(
                             REPLACE(                     
                                   REPLACE(
                                         SUBSTRING(RTRIM(LTRIM(@STRING_REST)),(CHARINDEX('(', @STRING_REST) + 1),  
                                         CHARINDEX(')', @STRING_REST) - (CHARINDEX('(', @STRING_REST))), '(', '')
                                   ,')','')
                             ))
                        
                  ELSE
                        ''
                  END
            ELSE
                  CASE WHEN SUBSTRING(RTRIM(LTRIM(@STRING_REST)),4,1) = ' ' THEN 
                        SUBSTRING(RTRIM(LTRIM(@STRING_REST)),2,2)
                  ELSE
                        CASE WHEN SUBSTRING(RTRIM(LTRIM(@STRING_REST)),3,1) = ' ' THEN 
                             SUBSTRING(RTRIM(LTRIM(@STRING_REST)),1,2)
                        ELSE
                             CASE WHEN SUBSTRING(RTRIM(LTRIM(@STRING_REST)),3,1) = '-' THEN 
                                   SUBSTRING(RTRIM(LTRIM(@STRING_REST)),1,2)
                             ELSE
                                   ''
                             END
                        END
                  END
            END,

      @STRING_REST = 
            CASE WHEN SUBSTRING(RTRIM(LTRIM(@STRING_REST)),CHARINDEX('(', @STRING_REST),1) = '(' THEN 
                  CASE WHEN SUBSTRING(RTRIM(LTRIM(@STRING_REST)),CHARINDEX(')', @STRING_REST),1) = ')' THEN 
                        SUBSTRING(RTRIM(LTRIM(@STRING_REST)),(CHARINDEX(')', @STRING_REST) + 1),
                        (LEN(RTRIM(LTRIM(@STRING_REST))) - CHARINDEX(')', @STRING_REST)))
                  ELSE
                        ''
                  END
            ELSE
                  CASE WHEN SUBSTRING(RTRIM(LTRIM(@STRING_REST)),4,1) = ' ' THEN 
                        SUBSTRING(RTRIM(LTRIM(@STRING_REST)),5,(LEN(RTRIM(LTRIM(@STRING_REST))) - 4))
                  ELSE
                        CASE WHEN SUBSTRING(RTRIM(LTRIM(@STRING_REST)),3,1) = ' ' THEN 
                              SUBSTRING(RTRIM(LTRIM(@STRING_REST)),4,(LEN(RTRIM(LTRIM(@STRING_REST))) - 3))
                        ELSE
                             CASE WHEN SUBSTRING(RTRIM(LTRIM(@STRING_REST)),3,1) = '-' THEN 
                                   SUBSTRING(RTRIM(LTRIM(@STRING_REST)),4,(LEN(RTRIM(LTRIM(@STRING_REST))) - 3))
                             ELSE
                                   ''
                             END
                        END
                  END
            END,
      @STRING = RTRIM(LTRIM(@STRING_REST))
      FROM @TBL_TELEFONES_TRATADO
      WHERE ID_LINHA = @ATUAL
      
      SELECT 
      @STRING_REST = RTRIM(LTRIM(TELEFONE_ERRO))
      FROM @TBL_TELEFONES_TRATADO
      WHERE ID_LINHA = @ATUAL
      AND LTRIM(RTRIM(@STRING_REST)) = ''
      
      --------------TRATA O TELEFONE
      IF LEN(REPLACE(
                        REPLACE(                     
                             REPLACE(
                                   REPLACE(RTRIM(LTRIM(@STRING_REST)),'-',''),'/',''),'.',''),' ','')) IN (11)
      BEGIN
                  IF SUBSTRING(REPLACE(
                        REPLACE(                     
                             REPLACE(
                                   REPLACE(RTRIM(LTRIM(@STRING_REST)),'-',''),'/',''),'.',''),' ',''),1,1) = '0'
                                   BEGIN
                                                           SELECT @DDD = SUBSTRING(
                                                                                        REPLACE(
                                                                                              REPLACE(                     
                                                                                                    REPLACE(
                                                                                                          REPLACE(RTRIM(LTRIM(@STRING_REST)),'-',''),'/',''),'.',''),' ',''), 1,3)
                                                           SELECT @TELEFONE1 = SUBSTRING(
                                                                                        REPLACE(
                                                                                              REPLACE(                     
                                                                                                    REPLACE(
                                                                                                          REPLACE(RTRIM(LTRIM(@STRING_REST)),'-',''),'/',''),'.',''),' ',''), 4,8)
                                                           SELECT @STRING_REST = ''
                                                  END                                                                                                          
                                                  ELSE BEGIN
                                                           SELECT @DDD = SUBSTRING(
                                                                                        REPLACE(
                                                                                              REPLACE(                     
                                                                                                    REPLACE(
                                                                                                          REPLACE(RTRIM(LTRIM(@STRING_REST)),'-',''),'/',''),'.',''),' ',''), 1,2)
                                                           SELECT @TELEFONE1 = SUBSTRING(
                                                                                        REPLACE(
                                                                                              REPLACE(                     
                                           REPLACE(
                                                                                                          REPLACE(RTRIM(LTRIM(@STRING_REST)),'-',''),'/',''),'.',''),' ',''), 3,9)
                                                           SELECT @STRING_REST = ''
                                   END
                  
      END
      
      --------------TRATA O TELEFONE
      IF LEN(REPLACE(
                        REPLACE(                     
                             REPLACE(
                                   REPLACE(RTRIM(LTRIM(@STRING_REST)),'-',''),'/',''),'.',''),' ','')) IN (8,9,10) 
      BEGIN
            SELECT @TELEFONE1 = 
                  REPLACE(
                        REPLACE(                     
                             REPLACE(
                                   REPLACE(RTRIM(LTRIM(@STRING_REST)),'-',''),'/',''),'.',''),' ','')
      END
      

      --------TRATA O TELEFONE1 QUANDO TEM MAIS DE UM N�MERO NA MESMA STRING
      IF @TELEFONE1 = '' 
      BEGIN
            SELECT
                  @TELEFONE1 = 
                        CASE WHEN CHARINDEX('/', @STRING_REST) > 8 THEN 
                             SUBSTRING(RTRIM(LTRIM(@STRING_REST)),1,CHARINDEX('/', @STRING_REST))
                        ELSE
                             CASE WHEN CHARINDEX(' ', @STRING_REST) > 8 THEN 
                                   SUBSTRING(RTRIM(LTRIM(@STRING_REST)),1,CHARINDEX(' ', @STRING_REST))
                             ELSE
                                   ''
                             END
                        END,
                  @STRING_REST = 
                        SUBSTRING(RTRIM(LTRIM(@STRING_REST)),(CHARINDEX('/', @STRING_REST) + 1),LEN(@STRING_REST) - (CHARINDEX('/', @STRING_REST) - 1))
            FROM @TBL_TELEFONES_TRATADO
            WHERE ID_LINHA = @ATUAL
            AND @TELEFONE1 = ''
            
            SELECT
                  @TELEFONE2 = RTRIM(LTRIM(@STRING_REST)),
                  @STRING_REST = REPLACE(@STRING_REST,@TELEFONE2,'')
            FROM @TBL_TELEFONES_TRATADO
            WHERE ID_LINHA = @ATUAL
            AND @TELEFONE2 = ''
            
            IF LEN(@TELEFONE2) < 8 
            BEGIN
                  SELECT @TELEFONE2 = 
                        CASE WHEN LEN(@TELEFONE1) = 8 THEN
                             SUBSTRING(@TELEFONE1,1,4) + @TELEFONE2
                        ELSE
                             CASE WHEN LEN(@TELEFONE1) = 9 THEN
                                   SUBSTRING(@TELEFONE1,1,5) + @TELEFONE2
                             ELSE
                                   @TELEFONE2
                             END
                        END
                  FROM @TBL_TELEFONES_TRATADO
                  WHERE ID_LINHA = @ATUAL
                  AND @TELEFONE2 <> ''
            END
            
            IF @TELEFONE1 = @TELEFONE2 
            BEGIN
                  SET @TELEFONE2 = ''
            END
      END
      
      IF ISNUMERIC(RTRIM(LTRIM(@STRING_REST))) = 1 BEGIN
            IF RTRIM(LTRIM(@TELEFONE2)) = '' BEGIN
                  SELECT @TELEFONE2 = RTRIM(LTRIM(@STRING_REST))
            END
            ELSE BEGIN
                  IF ISNUMERIC(RTRIM(LTRIM(@STRING_REST))) = 1 BEGIN
                        SELECT @TELEFONE2 = RTRIM(LTRIM(@STRING_REST))
                  END
            END
      END
      

      UPDATE @TBL_TELEFONES_TRATADO
      SET 
                CODIGO_PAIS           = @CODIGO_PAIS,
            DDD               = @DDD,
            STRING_REST       = @STRING_REST,
            TELEFONE1         = REPLACE(
                                         REPLACE(                     
                                               REPLACE(
                                                     REPLACE(RTRIM(LTRIM(@TELEFONE1)),'-',''),'/',''),'.',''),' ',''),
            TELEFONE2         = REPLACE(
                                         REPLACE(                     
                                               REPLACE(
                                                     REPLACE(RTRIM(LTRIM(@TELEFONE2)),'-',''),'/',''),'.',''),' ','')
      WHERE ID_LINHA = @ATUAL

      SET @ATUAL = @ATUAL + 1
END

SELECT 
TELEFONE_ERRO, 
CODIGO_PAIS, 
DDD, 
TELEFONE1, 
TELEFONE2 
FROM @TBL_TELEFONES_TRATADO


SAIDA:
END