Use IK_Varejo
Go

If Object_id('SP_REC_OPERACOES_CANCELADAS_Excel') is not null
	Drop Proc SP_REC_OPERACOES_CANCELADAS_Excel
;
Go
 
Create PROCEDURE [dbo].[SP_REC_OPERACOES_CANCELADAS_Excel]
(
	  @DATA_INICIAL DATETIME		-- '2018-07-24 00:00'
	, @DATA_FINAL DATETIME			-- '2018-08-01 22:22'
	, @ID_Corretora INT = NULL
	, @NUM_REGISTROS INT = 0
)
AS	
BEGIN
	Set NoCount On
	/*
	Declare  @DATA_INICIAL Datetime='2019-01-03 12:14:15.993', @DATA_FINAL Datetime='2019-01-09 12:19:25.993', @NUM_REGISTROS int=200, @id_Corretora Varchar(9)=NULL 
	-- Dados q duplicaram 
	Exec [SP_REC_OPERACOES_CANCELADAS_Excel]   @DATA_INICIAL	= '2019-03-01 16:00:45.453' -- In�cio do carnaval 2019
			   , @DATA_FINAL	= '2019-03-02 01:20:29.240' 
			   , @NUM_REGISTROS = 200
			   , @id_Corretora = '657'
		   ;
	-- Declare @DATA_INICIAL Datetime='2018-07-26 00:00', @DATA_FINAL Datetime='2018-08-01 22:22', @NUM_REGISTROS int=200, @id_Corretora Varchar(9)='657'-- Todos de HOMOLOG com tx as 9h30min	Set NoCount On -- OFF	-- REND-SRVDSQL-05.IK_VAREJO
	--*/
	-- 584109 - 682103 Integra��o Doc/Ted - Fase II - PPV - TW - Cria tabela com a lista de dias para verifica��o de Feriado e Tx_Ajustada
	/*
	  Campo Taxa Ajustada Cria��o (posi��o AA)
		Com base nas informa��es dos campos Data/Hora Cancelamento, Dia Semana Cancelamento, Feriado Cancelamento, Fora de Mercado Cancelamento, 
		pode-se obter a Taxa ajustada seguindo as regras:
		Se feriado, utilizaremos como taxa de Refer�ncia, a taxa do Dia seguinte.
		Caso n�o seja feriado, por�m n�o seja dia �til, s�bado ou domingo, utilizaremos a taxa de abertura do pr�ximo dia �til.
		Para os demais dias de semana, n�o feriado, seguimos a tabela abaixo:
		+-------------------------------------+
		|    Das    |    At�    | Obs. Taxa   |
		|-----------+-----------+-------------|
		| 00h00m00s | 08h59m59s | Dia Atual   |
		| 09h00m00s | 17h59m59s | Tx Opera��o |
		| 18h00m00s | 23h59m59s | Dia Seguinte|
		+-------------------------------------+ 
	*/ 
	if @DATA_INICIAL < '2019-01-01'	-- 584109.682103 - Task 1227 - Incluir Data Limite no Intervalo INICIAL caso seja menor que 01/jan/2019
		Set @DATA_INICIAL = '2019-01-01'
	;
	Declare @Hinic char(5)='09:00' ;
	-- Inicio da busca otimizada da taxa real de cancelamento ---------------------------------------------------------------
	--    Declare @DATA_INICIAL Date='2018-06-01 00:55', @DATA_FINAL Date='2018-09-01', @ID_Corretora INT = NULL, @NUM_REGISTROS int
	If Object_id('TempDB..#Aux') is not null							Drop Table #Aux								;
	If Object_id('TempDB..#VerificacaoDatasCancelamento') is not null	Drop Table #VerificacaoDatasCancelamento	;
	If Object_id('TempDB..#OpCanc') is not null							Drop Table #OpCanc							;
	If Object_id('TempDB..#Au2') is not null							Drop Table #Au2								;
	If Object_id('TempDB..#VerificacaoDatasCriacao') is not null		Drop Table #VerificacaoDatasCriacao			;

	Create Table #Aux ( DataCancAj DateTime, DataIncAj DateTime, Moeda Char(3), Tx_Orig Float, Tx_Ajust Float, DtCompOri DateTime, Qtd Int, Seq int Identity(1,1) Primary key, op_data_inclusao DateTime, Tx_AjustCriacao Float, Data_Cancelamento DateTime )-- , DataInclAj DateTime
	;
	Select * into #Au2 From #Aux
	;
	Create Table #VerificacaoDatasCancelamento ( DataCancAj DateTime, DataIncAj DateTime, Moeda Char(3), Tx_Orig Float, Tx_Ajust Float, DtCompOri DateTime, Qtd Int, Obs VarChar(Max), cWeek int, Feriado Int, ForaMerc Int, Seq int Identity(1,1) Primary key, op_data_inclusao DateTime, cWeek_i int, Feriado_i Int, ForaMerc_i Int, Taxa_09_30 Float, Tx_AjustCriacao Float, Data_Cancelamento DateTime )
	; -- Convert( VarChar(16), Max(o.Data_Cancelamento), 121) -- aaaa-mm-dd hh:mm
	Select * into #VerificacaoDatasCriacao From #VerificacaoDatasCancelamento
	;
	Create Table #OpCanc ( op_n_boleto Int, op_n_ordem Int, op_val_Moeda Float, op_val_reais Float, Moeda Char(3), op_data_status DateTime, taxa_cambio Float, taxa_cambio_cancelamento Float, op_taxa_banco Float, Corretora VarChar(999), Beneficiario VarChar(999), Remetente VarChar(999), op_data_inclusao DateTime, Data_Cancelamento DateTime, op_tx_operacao Float, op_taxa_pronto_d Float, Tx_TradeRate Float, nat_codigo VarChar(999), nat_descricao VarChar(999), vlr_iof Float, op_tarifa_operacao Float, op_spread Float, valor_Corretora Float, valor_brsa Float, NET Float, dif_mercado Float )
	;
	Insert #OpCanc
		Exec SP_REC_OPERACOES_CANCELADAS
			  @DATA_INICIAL 
			, @DATA_FINAL 
			, @ID_Corretora 
			, @NUM_REGISTROS
	;

	-- Select * from #OpCanc

	-- Inicio da busca otimizada da taxa real de cancelamento ---------------------------------------------------------------
	Insert #Aux
	  Select  DataCancAj		= Case  -- Ser� reajustada pela DbFeriado..SPBR_Verifica_Proxima_Data_Vigente 
									When Max(o.Data_Cancelamento) >= Convert( VarChar(10), Max(o.Data_Cancelamento), 121)+' 00:00' 
									 And Max(o.Data_Cancelamento) <  Convert( VarChar(10), Max(o.Data_Cancelamento), 121)+' '+@Hinic 
										Then Convert( VarChar(10), Max(o.Data_Cancelamento), 121)+' 08:08'
									When Max(o.Data_Cancelamento) >= Convert( VarChar(10), Max(o.Data_Cancelamento), 121)+' '+@Hinic 
									 And Max(o.Data_Cancelamento) <  Convert( VarChar(10), Max(o.Data_Cancelamento), 121)+' 18:00' 
										Then Convert( VarChar(10), Max(o.Data_Cancelamento), 121)+' 14:14'
									Else	 Convert( VarChar(10), Max(o.Data_Cancelamento), 121)+' 22:22' 
								  End
			, DataIncAj			= Null
			, Moeda				= o.Moeda
			, Tx_Orig			= o.taxa_cambio_cancelamento
			, Tx_Ajust			= Max(op_taxa_pronto_d) -- Null -- Ser� alimentada pela rotina em fun��o da DataIncAj, se for "Fora de Mercado" sen�o mantem a op_taxa_pronto_d
			, DtCompOri			= Convert( VarChar(16), (o.Data_Cancelamento), 121) -- S� com hh:mm
			, Qtd				= Count(1)
			, op_data_inclusao	= Max(o.op_data_inclusao)
			, Tx_AjustCriacao	= Null -- Ser� alimentada Rotina em fun��o da op_data_inclusao
			, Data_Cancelamento = Max(Data_Cancelamento)
		From #OpCanc o with(nolock)
		Group By -- Agrupada por Moeda, Taxa_cambio_cancelamento e Data_Cancelamento
			o.Moeda
		  , o.taxa_cambio_cancelamento
		  , Convert( VarChar(16), o.Data_Cancelamento, 121) -- S� com hh:mm
		-- 
	;	-- Select * from #Aux
	Insert #VerificacaoDatasCancelamento
		Select 
				DataCancAj		= Max(a.DataCancAj)
			  , DataIncAj		= null
			  , Moeda			= (a.Moeda)
			  , Tx_Orig			= (a.Tx_Orig)
			  , Tx_Ajust		= Max(Tx_Ajust) -- Null -- Ser� alimentada pela rotina em fun��o da DataCancAj, se for "Fora de Mercado sen�o mantem a op_taxa_pronto_d
			  , DtCompOri		= a.DtCompOri  -- S� com hh:mm
			  , Qtd				= Sum(a.Qtd) + Count(1)
			  , Obs				= ' Qtd['+Cast(Sum(a.Qtd) as varchar)+']+['+Cast(Count(1) as varchar)+'] '
			  , cWeek			= DatePart( WeekDay, Max(a.DataCancAj) )
			  , Feriado			= null
			  , ForaMerc		= null
			  , op_data_inclusao= Max(op_data_inclusao)
			  , cWeek_i			= null
			  , Feriado_i		= null
			  , ForaMerc_i		= null
			  , Taxa_09_30		= null
			  , Tx_AjustCriacao	= Null -- Ser� alimentada Rotina em fun��o da op_data_inclusao
			  , Data_Cancelamento = Max(Data_Cancelamento)
		From #Aux a
		Where a.DataCancAj is not null
		Group by -- Agrupada por DtCompOri, Moeda e Tx_Orig, resumindo as tx q ser�o usadas
			a.DtCompOri  -- S� com hh:mm
		  , a.Moeda
		  , a.Tx_Orig
	;	-- Select * from #VerificacaoDatasCancelamento

--*/	-- Inicio da busca otimizada da taxa real da Cria��o Fora do Mercado ---------------------------------------------------------------
	Insert #Au2
	  Select  DataCancAj		= Null
			, DataIncAj			= Case  -- Ser� reajustada pela DbFeriado..SPBR_Verifica_Proxima_Data_Vigente
									When Max(o.op_data_inclusao) >= Convert( VarChar(10), Max(o.op_data_inclusao), 121)+' 00:00' 
									 And Max(o.op_data_inclusao) <  Convert( VarChar(10), Max(o.op_data_inclusao), 121)+' '+@Hinic 
										Then Convert( VarChar(10), Max(o.op_data_inclusao), 121)+' 08:08'
									When Max(o.op_data_inclusao) >= Convert( VarChar(10), Max(o.op_data_inclusao), 121)+' '+@Hinic 
									 And Max(o.op_data_inclusao) <  Convert( VarChar(10), Max(o.op_data_inclusao), 121)+' 18:00' 
										Then Convert( VarChar(10), Max(o.op_data_inclusao), 121)+' 14:14'
									Else	 Convert( VarChar(10), Max(o.op_data_inclusao), 121)+' 22:22' 
								  End
			, Moeda				= o.Moeda
			, Tx_Orig			= o.taxa_cambio
			, Tx_Ajust			= Max(op_taxa_pronto_d) -- Null -- Ser� alimentada pela rotina em fun��o da DataIncAj, se for "Fora de Mercado" sen�o mantem a op_taxa_pronto_d
			, DtCompOri			= Convert( VarChar(22), (o.op_data_inclusao), 121) -- S� com hh:mm
			, Qtd				= Count(1)
			, op_data_inclusao	= Max(o.op_data_inclusao)
			, Tx_AjustCriacao	= Null -- Ser� alimentada Rotina em fun��o da op_data_inclusao
			, Data_Cancelamento = Max(Data_Cancelamento)
		From #OpCanc o with(nolock)
		/* Anulado pq faltar� valores de todas as datas */
		Where Cast( o.op_data_inclusao as time)>'18:00' 
		   or Cast( o.op_data_inclusao as time)<@Hinic
		   or DatePart( WeekDay, o.op_data_inclusao) in( 1, 7 )
		Group By -- Agrupada por Moeda, Taxa_cambio e op_data_inclusao S� para operac. fora do mercado
			o.Moeda
		  , o.taxa_cambio
		  , Convert( VarChar(22), o.op_data_inclusao, 121) -- S� com hh:mm
	;	-- Select * from #Au2
	Insert #VerificacaoDatasCriacao
		Select 
				DataCancAj		= Null
			  , DataIncAj		= Max(a.DataIncAj )
			  , Moeda			= (a.Moeda)
			  , Tx_Orig			= (a.Tx_Orig) -- da Cria��o
			  , Tx_Ajust		= Max(Tx_Ajust) -- Null -- Ser� alimentada pela rotina em fun��o da DataIncAj, se for "Fora de Mercado sen�o mantem a op_taxa_pronto_d
			  , DtCompOri		= DtCompOri  -- op_data_inclusao S� com hh:mm
			  , Qtd				= Sum(a.Qtd) + Count(1)
			  , Obs				= ' Qtd['+Cast(Sum(a.Qtd) as varchar)+']+['+Cast(Count(1) as varchar)+'] '
			  , cWeek			= DatePart( WeekDay, Max(a.op_data_inclusao) )
			  , Feriado			= null
			  , ForaMerc		= null
			  , op_data_inclusao= Max(a.op_data_inclusao)
			  , cWeek_i			= DatePart( WeekDay, Max(a.op_data_inclusao) )
			  , Feriado_i		= null
			  , ForaMerc_i		= null
			  , Taxa_09_30		= null
			  , Tx_AjustCriacao	= Null -- Ser� alimentada Rotina em fun��o da op_data_inclusao		 Select * 
			  , Data_Cancelamento = Max(Data_Cancelamento)
		From #Au2 a
		Where a.DataIncAj is not null
		Group by -- Agrupada por DtCompOri, Moeda e Tx_Orig, resumindo as tx q ser�o usadas
			a.DtCompOri	-- op_data_inclusao S� com hh:mm
		  , a.Moeda
		  , a.Tx_Orig	-- da Cria��o
	;	-- Select * from #VerificacaoDatasCriacao
--*/
	--Update a set DataCancAj = '2017-12-25 00:00:52.467' from #VerificacaoDatasCancelamento a where DtCompOri='2017-12-26 00:00:52.467' -- Teste de feriado
	-- 60 e 61 tem 24 e 26/dez/17 em DESENV		60.
	Declare @i int = 1, @DataCancAj DateTime, @DataIncAj DateTime, @Moeda Char(3), @Tx_Orig Float , @Tx_Ajust Float, @Tx_AjustCriacao Float
	;
	Declare @Week				Int			= 0 -- Dia Semana Cancelamento, 
		  , @Feriado			Int			= 0	-- Feriado Cancelamento, 
		  , @ForaMerc			Int			= 0	-- Fora de Mercado Cancelamento
		  , @TipoFeriad			VarChar(999)=''
		  , @TipoFeriadCanc		VarChar(999)=''
		  , @TipoFeriadCria		VarChar(999)=''
		  , @Data_HOJE			Date -- Deve ser s� DATE sen�o n�o a SPBR_Verifica_Proxima_Data_Vigente n�o retorna NADA
		  , @DataMN				DateTime
		  , @DataME				DateTime
		  , @op_data_inclusao	DateTime
		  , @Week_i				Int	
		  , @Feriado_i			Int			= 0	-- Feriado op_data_inclusao, 	
		  , @ForaMerc_i			Int			= 0	-- Fora de Mercado op_data_inclusao	
		  , @DataMN_i			DateTime
		  , @DataORIG			DateTime, @MsgForaMerc VarChar(999)=''
	;
	Declare @Tab Table ( dd Char(4), D_MN DateTime, D_ME DateTime, TipoFeriad VarChar(999) )
	;-- Analisa todas as datas de cancelamento
	While @i <= ( select Max(Seq) from #VerificacaoDatasCancelamento ) -- 70 -- select * from #VerificacaoDatasCancelamento
	  Begin
		Select @DataCancAj = DataCancAj, @Moeda = Moeda, @Tx_Orig = Tx_Orig, @Feriado = 0, @ForaMerc = 0,@Feriado_i = 0, @DataORIG = a.Data_Cancelamento
		From #VerificacaoDatasCancelamento a 
		Where Seq = @i
		; 
		-- DataCancAj
		Select @Week = DatePart( WeekDay, @DataCancAj ), @Week_i = DatePart( WeekDay, @op_data_inclusao )
		;
		Set @Data_HOJE = Cast(@DataCancAj as Date)-- Deve ser s� DATE sen�o n�o a SP n�o retorna NADA
		;
		Delete @Tab
		;
		Insert @Tab
			EXEC DbFeriado..SPBR_Verifica_Proxima_Data_Vigente 
				  @DataBASE  = @Data_HOJE						, @QTDDIASME = 0, @QTDDIASMN = 0  , @PRACA	 = 'SP'
				, @Moeda	 = @Moeda							, @IDSISTEMA = 2, @IDOPERACAO= 'V'
				, @DataMEOUT = @DataME OUTPUT
				, @DataMNOUT = @DataMN OUTPUT
		;
		Select @TipoFeriad = IsNull(TipoFeriad, '') From @Tab
		;
		IF @TipoFeriad<>'' -- IF @Week Not in (1,7) And Cast(@DataCancAj as Date) <> @DataMN -- Se a @DataCancAj n�o � FDS e a dataMN � diferente ent�o � um feriado
		  Begin Set @Feriado=1 ; Set @TipoFeriadCanc='Feriado(Canc['+@TipoFeriad+']). Dia Ajustado em '+Cast( DateDiff(dd, @DataMN, @DataCancAj) as VarChar)+' dia(s).' ; End
		;
		Set @ForaMerc = Case When @Feriado = 1 OR @Week in (1,7) OR Cast(@DataORIG as Time)>'18:00' OR Cast(@DataORIG as Time)<@Hinic Then 1 Else 0 End
		; -- select "@i"=@i, "@ForaMerc"=@ForaMerc, "@TipoFeriad"=@TipoFeriad, "@Feriado"=@Feriado, "@Week"=@Week, "@DataORIG"=@DataORIG, "@Hinic"=@Hinic
		-- Acerto da Data
		Update a Set 
			   DataCancAj= Case When @ForaMerc = 0 -- se n�o est� fora do mercado p�e um hor�rio dentro do mercado
							Then Convert( VarChar(10), @DataMN, 121) + ' 14:14:00'
							Else Convert( VarChar(10), @DataMN, 121) + Right( Convert( VarChar(19), @DataCancAj, 121), 9) -- ' hh:mm:ss'
						   End
								-- Select *
			From #VerificacaoDatasCancelamento a With(nolock)
			Where Seq = @i
		;
		Set @MsgForaMerc ='Dia Ajustado em '+Cast( DateDiff(dd, @DataMN, @DataCancAj) as VarChar)+' dia(s) @DataCancAj('+Cast( DatePart( WeekDay, @DataCancAj ) as VarChar )+'�)=[' +Convert( VarChar(16), @DataCancAj, 121 ) + '] @DataMN('+Cast( DatePart( WeekDay, @DataMN ) as VarChar )+'�)=['+Convert( VarChar(22), @DataMN, 121 )+'] DtCompOri['+Convert( VarChar(22), IsNull(@op_data_inclusao,0), 121)+']'
		-- Acerto da TAXA -- begin Declare @i int=10, @Moeda Char(3)='USD',@Week int=8, @ForaMerc int =1, @Feriado int=1, @TipoFeriad varchar(999) = '@TipoFeriad'
		Update a Set 
			--  Select Top 1 Data, Tx_Banco, iWeek=@Week, Feriado=@Feriado, ForaMerc=@ForaMerc, a.DtCompOri, a.Seq,
				  Tx_Ajust		  = IsNull( m.Tx_Banco, a.tx_Orig )
				, Obs= 'Tx_Ajust =['+LTrim( IsNull(Cast(m.Tx_Banco as VarChar(999))
													,'Sem Tx_Banco p/'+Convert( VarChar(10), a.DataCancAj, 121)
													+' 09:30 Moeda('+@Moeda+') usada a TX_Orig='+Cast( a.tx_Orig as VarChar(max))
												)
												+'] ')
						+ IsNull(Case When @ForaMerc = 1 -- @Feriado = 0 and @Week in (1,7) 
								 Then Case When @Feriado = 1 Then 'Feriado Tipo['+ @TipoFeriadCanc + ']. '+@MsgForaMerc
										   When Cast(@DataORIG as Time)>'18:00' OR Cast(@DataORIG as Time)<@Hinic Then 'Fora do Hor�rio['+Left(Cast(@DataORIG as Time),5)+'].' 
										Else 'Final de Semana. '+@MsgForaMerc
										End
							Else /*@TipoFeriad +*/'Dia N�O alterado @DataCancAj('+Cast( DatePart( WeekDay, @DataCancAj ) as VarChar )+'�)[' 
									+Convert( VarChar(16), @DataCancAj, 121 ) + ']= @DataMN('+Cast( DatePart( WeekDay, @DataMN ) as VarChar )+'�)['
									+Convert( VarChar(16), @DataMN, 121 )+'] DtCompOri['+Convert( VarChar(16), IsNull(DtCompOri,0), 121)+']'
							End , '' )
						+ IsNull(Obs,' Null na #VerificacaoDatasCancelamento')
				, cWeek		= @Week
				, Feriado	= @Feriado
				, ForaMerc	= @ForaMerc
				, cWeek_i	= @Week_i
				, Feriado_i	= @Feriado_i
				, ForaMerc_i= @ForaMerc_i					-- Declare @Moeda char(3)='USD' ; Select a.*,"|"='|',m.*,m=Convert( VarChar(16), m.Data, 121),"="='=', a=Convert( VarChar(10), a.DataCancAj, 121)+' 09:30'
			From #VerificacaoDatasCancelamento a with (nolock) 
			Left Join VAREJO.dbo.TBL_TMoedas_HistoricoAbertura m with (nolock) -- Busca a taxa da data do Cancelamento 
				ON Convert( VarChar(16), m.Data, 121) = Convert( VarChar(10), a.DataCancAj, 121)+' 09:30'  -- +' 09:30'
				And m.Cod_Moeda						  = @Moeda
			Where Seq = @i
		;
		Set @i+=1
	  End
	;
	-- Select * from #VerificacaoDatasCancelamento	Where DtCompOri is not null order by DataCancAj
	;
	-- Fim da busca otimizada da taxa real de cancelamento ---------------------------------------------------------------
	
	-- Inicio da busca otimizada da taxa real de Cria��o -----------------------------------------------------------------
	Select @i = 1, @DataCancAj=null, @DataIncAj=null, @Moeda=null, @Tx_Orig=null, @Tx_Ajust=null, @Tx_AjustCriacao=null, @Week= 0 -- Dia Semana Cancelamento, 
		  , @Feriado		= 0	-- Feriado Cancelamento, 
		  , @ForaMerc		= 0	-- Fora de Mercado Cancelamento
		  , @TipoFeriad		= '', @TipoFeriadCanc='', @TipoFeriadCria=''
		  , @Data_HOJE		= null	-- Deve ser s� DATE sen�o n�o a SPBR_Verifica_Proxima_Data_Vigente n�o retorna NADA
		  , @DataMN			= null, @DataME =null , @op_data_inclusao=null , @Week_i =null
		  , @Feriado_i		= 0	-- Feriado op_data_inclusao, 	
		  , @ForaMerc_i		= 0	-- Fora de Mercado op_data_inclusao	
		  , @DataMN_i		= null, @DataORIG		=null
	;
	Delete @Tab
	;
	While @i <= ( select Max(Seq) from #VerificacaoDatasCriacao ) -- 70 --
	  Begin
		Select @DataCancAj = DataCancAj, @Moeda = Moeda, @Tx_Orig = Tx_Orig, @Feriado = 0, @ForaMerc = 0, @Feriado_i = 0, @ForaMerc_i = 0, @DataORIG = op_data_inclusao, @op_data_inclusao=op_data_inclusao
		From #VerificacaoDatasCriacao a 
		Where Seq = @i
		; 
		-- DataCancAj
		Select @Week_i = DatePart( WeekDay, @op_data_inclusao )
		;
		Set @Data_HOJE = @op_data_inclusao-- Deve ser s� DATE sen�o n�o a SP n�o retorna NADA
		;
		Delete @Tab
		;
		Insert @Tab
			EXEC DbFeriado..SPBR_Verifica_Proxima_Data_Vigente 
				  @DataBASE  = @Data_HOJE						, @QTDDIASME = 0, @QTDDIASMN = 0  , @PRACA	 = 'SP'
				, @Moeda	 = @Moeda							, @IDSISTEMA = 2, @IDOPERACAO= 'V'
				, @DataMEOUT = @DataME   OUTPUT
				, @DataMNOUT = @DataMN_i OUTPUT
		;
		Select @TipoFeriadCria = IsNull(TipoFeriad, '') From @Tab
		;
		IF @TipoFeriadCria<>'' -- @Week_i Not in (1,7) And Cast(@op_data_inclusao as Date) <> @DataMN_i -- Se a @op_data_inclusao n�o � FDS e a dataMN_i � diferente ent�o � um feriado
		  Begin Set @Feriado_i = 1 ; Set @TipoFeriadCria = 'Feriado(CRIA['+@TipoFeriadCria+']). Dia Ajustado em '+Cast( DateDiff(dd, @DataMN_i, @op_data_inclusao) as VarChar)+' dia(s).' ; End
		;
		Set @ForaMerc_i = Case When @Feriado_i = 1 OR @Week in (1,7) OR Cast(@DataORIG as Time)>'18:00' OR Cast(@DataORIG as Time)<@Hinic Then 1 Else 0 End
		; -- select "@i"=@i, "@ForaMerc"=@ForaMerc, "@TipoFeriad"=@TipoFeriad, "@Feriado"=@Feriado, "@Week"=@Week, "@DataORIG"=@DataORIG, "@Hinic"=@Hinic
		Set @DataIncAj = Case When @ForaMerc_i = 0 -- se n�o est� fora do mercado p�e um hor�rio dentro do mercado
							Then Convert( VarChar(10), @DataMN_i, 121) + ' 14:14:00'
							Else Convert( VarChar(10), @DataMN_i, 121) + Right( Convert( VarChar(19), @op_data_inclusao, 121), 9) -- ' hh:mm:ss'
						   End
		;
		Delete @Tab
		;
		-- Acerto da Data
		Update a Set 
			   DataIncAj =	@DataIncAj							-- Select *
			From #VerificacaoDatasCriacao a With(nolock)
			Where Seq = @i
		;
		Set @MsgForaMerc ='Dia Ajustado em '+Cast( DateDiff(dd, @DataMN_i, @DataIncAj) as VarChar)+' dia(s) @DataIncAj('+Cast( DatePart( WeekDay, @DataIncAj ) as VarChar )+'�)=[' +Convert( VarChar(22), @DataIncAj, 121 ) + '] @DataMN('+Cast( DatePart( WeekDay, @DataMN_i ) as VarChar )+'�)=['+Convert( VarChar(22), @DataMN_i, 121 )+'] DtCriaOri['+Convert( VarChar(22), IsNull(@op_data_inclusao,0), 121)+']'
		-- Acerto da TAXA -- begin Declare @i int=10, @Moeda Char(3)='USD',@Week int=8, @ForaMerc int =1, @Feriado int=1, @TipoFeriad varchar(999) = '@TipoFeriad'
		Update a Set 
			--  Select Top 1 Data, Tx_Banco, a.tx_Orig, iWeek=@Week, Feriado=@Feriado, ForaMerc=@ForaMerc, a.DtCompOri, a.Seq,
				  Tx_AjustCriacao = IsNull( c.Tx_Banco, a.tx_Orig )
				, Obs= 'Tx_AjustCriacao =['
						+LTrim( IsNull(Cast(c.Tx_Banco as VarChar(999))
													,'Sem Tx_Banco p/'+Convert( VarChar(10), a.DataIncAj, 121)
													+' 09:30 Moeda('+@Moeda+') usada a TX_Orig='+Cast( a.tx_Orig as VarChar(max))
												)
												+'] '
						+ IsNull(Case When @ForaMerc_i = 1 -- @Feriado = 0 and @Week in (1,7) 
								Then Case When @Feriado_i = 1 Then 'Feriado Tipo['+ @TipoFeriadCria + ']. '+@MsgForaMerc
										  When Cast(@DataORIG as Time)>'18:00' OR Cast(@DataORIG as Time)<@Hinic Then 'Fora do Hor�rio['+Left(Cast(@DataORIG as Time),5)+'].' 
										Else 'Final de Semana. '+@MsgForaMerc
										End
							Else /*@TipoFeriad +*/'Dia N�O alterado @DataIncAj('+Cast( DatePart( WeekDay, @DataIncAj ) as VarChar )+'�)[' 
									+Convert( VarChar(22), @DataIncAj, 121 ) + ']= @DataMN('+Cast( DatePart( WeekDay, @DataMN_i ) as VarChar )+'�)['
									+Convert( VarChar(22), @DataMN_i, 121 )+'] DtCriaOri['+Convert( VarChar(22), IsNull(@op_data_inclusao,0), 121)+']'
							End , '' )
						+ IsNull(Obs,' Null na #VerificacaoDatasCriacao')
						)
				, cWeek		= @Week
				, Feriado	= @Feriado
				, ForaMerc	= @ForaMerc
				, cWeek_i	= @Week_i
				, Feriado_i	= @Feriado_i
				, ForaMerc_i= @ForaMerc_i					-- Declare @Moeda char(3)='USD' ; Select a.*,"|"='|',c.*,c=Convert( VarChar(22), c.Data, 121),"="='=', a=Convert( VarChar(10), a.DataIncAj, 121)+' 09:30'
			From #VerificacaoDatasCriacao a with (nolock) 
			Left Join VAREJO.dbo.TBL_TMoedas_HistoricoAbertura c with (nolock) -- Busca a taxa da data de Cria��o 
				ON Convert( VarChar(16), c.Data, 121) = Convert( VarChar(10), a.DataIncAj, 121)+' 09:30'  -- +' 09:30'
				And c.Cod_Moeda						  = @Moeda
			Where Seq = @i
		;
		--Select "@Data_HOJE"=@Data_HOJE, "@TipoFeriadCria"=@TipoFeriadCria,* From #VerificacaoDatasCriacao a with (nolock) Where Seq = @i;
		Set @i+=1
	  End
	;
	--Select * from #VerificacaoDatasCriacao	Where DtCompOri is not null order by op_data_inclusao
	;
	-- Fim da busca otimizada da taxa real de Cria��o ---------------------------------------------------------------

	Select
		  op_n_boleto
		, op_n_ordem
		, op_val_moeda
		, op_val_reais
		, o.Moeda
		, op_data_status
		, taxa_cambio
		, taxa_cambio_cancelamento
		, op_taxa_banco
		, Corretora
		, Beneficiario
		, Remetente
		, Cast( o.op_data_inclusao as Date) as op_data_inclusao
		, Cast( o.Data_Cancelamento  as Date) as Data_Cancelamento
		, op_tx_operacao
		, op_taxa_pronto_d
		, o.Tx_TradeRate
		, nat_codigo
		, nat_descricao
		, vlr_iof
		, op_tarifa_operacao
		, op_spread
		, valor_Corretora
		, valor_brsa
		, NET
		, dif_mercado

		-- 584109 - 682103 Integra��o Doc/Ted - Fase II - PPV - TW - Inclus�o de novos campos
		, Hr_Inclus�o					= Cast( o.op_data_inclusao as Time ) -- ((@w-1)*3)+1
		, Dia_Semana_Inclus�o			= SUBSTRING( 'DomSegTerQuaQuiSexS�b', ((DatePart( WeekDay, o.op_data_inclusao )-1)*3)+1 , 3)
		, Feriado_Inclus�o				= SUBSTRING( 'N�oSim', ( IsNull(Tda.Feriado_i , 0) *3 ) +1, 3)
		, Fora_de_Mercado_Inclus�o		= SUBSTRING( 'N�oSim', ( IsNull(Tda.ForaMerc_i, Case When DatePart( WeekDay, o.op_data_inclusao )In(1,7) Then 1 Else 0 End) *3 ) +1, 3)
		, Hr_Cancelamento				= Cast( o.Data_Cancelamento as Time )	 
		, Dia_Semana_Cancelamento		= SUBSTRING( 'DomSegTerQuaQuiSexS�b', ((DatePart( WeekDay, o.Data_Cancelamento )-1)*3)+1 , 3) 
		, Feriado_Cancelamento			= SUBSTRING( 'N�oSim', ( IsNull(Tdc.Feriado , 0) *3 ) +1, 3)
		, Fora_de_Mercado_Cancelamento	= SUBSTRING( 'N�oSim', ( IsNull(Tdc.ForaMerc, Case When DatePart( WeekDay, o.Data_Cancelamento )In(1,7) Then 1 Else 0 End) *3 ) +1, 3)
		, TokenTaxa						= o.Tx_TradeRate
		, Taxa_09_30					= ( Select m.Tx_Banco 
											From VAREJO.dbo.TBL_TMoedas_HistoricoAbertura m with (nolock) 
											Where Convert( VarChar(16), m.Data, 121) = Convert( VarChar(10), o.Data_Cancelamento, 121)+' 09:30'
												And m.Cod_moeda						 = (o.Moeda)  collate Latin1_General_CI_AS
										  ) 
		, Taxa_Ajustada_Criacao			= IsNull( Tda.Tx_AjustCriacao, o.op_taxa_pronto_d ) -- � a taxa, da data da cria��o, ajustada pelas regras de dia util e feriados
		, Spread_Token					= Cast( (( op_tx_operacao / (o.Tx_TradeRate) ) - 1) * 100 AS VarChar(12) )+'%'	-- ((Taxa Opera��o / Taxa Token ) -1) * 100	unidade em %																							  (
		, Spread_x_Pronto				= Cast( (( op_tx_operacao / op_taxa_pronto_d ) - 1) * 100 AS VarChar(12) )+'%'	-- ((Taxa Opera��o / Taxa Pronto) -1) * 100	unidade em %
		, Validacao_Taxa_de_Cancelamento= ( Tdc.Tx_Ajust ) - taxa_cambio_cancelamento					-- taxa_cambio_cancelamento
		, Diferenca_Taxa_Abertura		= ( op_taxa_pronto_d - IsNull( Tda.Tx_AjustCriacao, o.op_taxa_pronto_d ) ) * op_val_moeda	-- (Taxa Pronto - TaxaAjustadaCria��o) * Valor ME
		, Diferenca_Ops_Canceladas		= ( taxa_cambio_cancelamento - IsNull(Tda.Tx_AjustCriacao, o.op_taxa_pronto_d)  ) * op_val_moeda-- (Taxa Cancelamento - Taxa Ajustada Cria��o) * Valor ME
		, Observacoes					= lTrim( IsNull( Tdc.Obs, '' ) -- 584109.682103 Corre��o A�lton ^^^
						+' Taxa_09_30=['+ IsNull( Cast(
														( Select m.Tx_Banco 
															From VAREJO.dbo.TBL_TMoedas_HistoricoAbertura m with (nolock) 
															Where Convert( VarChar(16), m.Data, 121) = Convert( VarChar(10), o.Data_Cancelamento, 121)+' 09:30'
																And m.Cod_moeda						 = (o.Moeda)  collate Latin1_General_CI_AS
														  )
														 As Varchar(999))
											, '] Sem Tx_Banco p/'+Convert( VarChar(10), o.Data_Cancelamento, 121)+' 09:30 Moeda('+o.MOEDA+')' )
						+ Case When IsNull(Tdc.ForaMerc, Case When IsNull(IsDate(o.Data_Cancelamento),0)=1 then '1' else '' end )='' 
							Then '] Fora_de_Mercado_Cancelamento=[Null] intuido como [N�O]' 
							Else ']' 
						  End
						+' Data_Cancelamento=['+ IsNull( Left(Convert( VarChar(999), o.Data_Cancelamento, 121),16), ' Data_Cancelamento=[Null]')
						+'] Tx_Orig=['+ IsNull( Cast(Tdc.Tx_Orig as VarChar(999)), ' Tx_Orig=[Null')+']'
						+' TokenTaxa=['+ IsNull( Cast(o.Tx_TradeRate as VarChar(999)), 'Tx_TradeRate n�o encontrada na TBL_WS_TradeRATE_FXRate')+']'
						) -- Select Tab_OpCanc='', o.*, Tab_Tdc='------', Tdc.* , Tab_Tda='------', Tda.*, Tda=Tda.op_data_inclusao, '=', o=o.op_data_inclusao
	From #OpCanc o with(nolock)
	Left Join #VerificacaoDatasCancelamento Tdc with(nolock) 
		On Tdc.DtCompOri = Convert( VarChar(16), o.Data_Cancelamento, 121) -- S� com hh:mm --	Tda.Tx_Orig = o.o.taxa_cambio_cancelamento
		AND Tdc.Moeda = o.Moeda collate Latin1_General_CI_AS
	Left Join #VerificacaoDatasCriacao Tda with(nolock) -- S� com as taxas ajustadas para opera��es criadas fora do mercado sen�o usa a op_tx_operacao
		On Convert( VarChar(22), Tda.op_data_inclusao, 121) = Convert( VarChar(22), o.op_data_inclusao, 121) -- Com hh:mm:ss.ms p/� duplicar
		AND Tda.Moeda = o.Moeda collate Latin1_General_CI_AS
	;
END
;
Go
-----------------------------------------------------------------------------------------------------------------------
-- 584109.682103 - Task 1226 - Ajuste no script/Retirar trechos DEBUG
