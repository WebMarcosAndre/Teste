USE [IK_VAREJO]
GO
/****** Object:  StoredProcedure [dbo].[SPBCCME_Inserir_EMAIL_BENEFICIARIO]    Script Date: 04/10/2017 09:40:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[SPBCCME_INSERIR_EMAIL_BENEFICIARIO]
(
	@id_cliente INT,
	@cl_email VARCHAR(100)
)
AS
DELETE FROM [dbo].[TBL_ME_EMAIL_BENEFICIARIO]
WHERE  id_cliente = @id_cliente
INSERT INTO [dbo].[TBL_ME_EMAIL_BENEFICIARIO]
           ([id_cliente]
           ,[cl_email])
     VALUES
           (@id_cliente,
			@cl_email)
