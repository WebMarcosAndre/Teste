USE [IK_VAREJO]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[SPBCCME_Listar_Aprovacoes]    Script Date: 09/07/2019 09:03:53 ******/
-- =====================================================================================================================================
-- Author:		
-- Create date: 
-- Description:	
-------------------------------------------------------------------------------------------------
-- 683751.1273 - Projeto Migra��o SQL 2016 - Varejo
--					- Select com asterisco
--					- (nolock) sem With
-------------------------------------------------------------------------------------------------
-- Hist�rico Altera��es
-- *********************
-- PRG______________________________________________ Data_____ Autor________ Descri��o__________________________________________
-- dbo.SPBCCME_Listar_Aprovacoes.StoredProcedure.sql 09/jul/19 C�ssio Drezza 683751.1273 - Projeto Migra��o SQL 2016 - Varejo
-- =====================================================================================================================================
ALTER PROCEDURE [dbo].[SPBCCME_Listar_Aprovacoes]
(
   @ID_CLIENTE INT,
   @MOEDA VARCHAR(10)
)
AS
BEGIN

EXEC SPBCCME_ATUALIZAR_SALDO @ID_CLIENTE = @ID_CLIENTE
;
DECLARE @ID_TRANSF INT
;
DECLARE @TBL_APROVACOES TABLE(ID_MOV INT, MOV_DATA DATETIME, MOV_DT_DISP DATETIME, MOV_TIPO_OP VARCHAR(100), MOV_HISTORICO INT, 
                              MOE_DESCCCME VARCHAR(4), MOV_VALOR MONEY, MOV_OBS VARCHAR(2000), HIS_DESCRICAO VARCHAR(255))  
;
---------------------------------------------------------------------------
-- INSERE NA TABELA TEMPORARIA AS TRANSFERENCIAS PENDENTES DE PROCESSAMENTO 
---------------------------------------------------------------------------
INSERT INTO @TBL_APROVACOES 
     SELECT A.ID_TRANSF AS ID_MOV, A.DATA_INCLUSAO AS MOV_DATA, A.DATA_DEBITO AS MOV_DT_DISP, 'TRANSF' AS MOV_TIPO_OP,
            A.ID_HISTORICO AS MOV_HISTORICO, MO.MOE_DESCCCME, A.VALOR_DEBITO AS MOV_VALOR, CAST(A.OBSERVACAO AS VARCHAR(2000)) + ' | Benef.: ' + 
            (SELECT TOP 1 CASE WHEN C.CL_TIP_DOC = 'CPF' THEN C.CL_NOME ELSE C.CL_RAZAO_SOCIAL END 
               FROM TBL_CLIENTES C With(NoLock) 
              WHERE C.ID_CLIENTE = A.ID_CLIENTE_DESTINO) AS MOV_OBS,
            H.HIS_DESCRICAO 
       FROM TBL_MEWEB_AGENDA_TRANSFERENCIA A With(NoLock)
      INNER JOIN TBL_ME_HISTORICO H With(NoLock) ON H.HIS_CODIGO = A.ID_HISTORICO
      INNER JOIN TBL_MOEDAS MO With(NoLock) ON A.MOEDA_DEBITO = MO.MOE_SIMBOLO
      WHERE A.ID_CLIENTE_ORIGEM = @ID_CLIENTE
        AND A.MOEDA_DEBITO = @MOEDA
        AND A.STATUS = 'A'
;
----------------------------------------------------------------
-- INSERE S TARIFA DAS TRANSFERENCIAS PENDENTES DE PROCESSAMENTO 
----------------------------------------------------------------
INSERT INTO @TBL_APROVACOES
     SELECT A.ID_TRANSF, A.DATA_INCLUSAO, A.DATA_DEBITO, 'TRANSF' AS MOV_TIPO_OP, H.HIS_TARIFA AS MOV_HISTORICO, 
            MO.MOE_DESCCCME, A.VALOR_TARIFA AS MOV_VALOR, 
            'Tarifa Transfer�ncia: ' + CAST(A.ID_TRANSF AS VARCHAR) + ' | Benef.: ' + 
            (SELECT TOP 1 CASE WHEN C.CL_TIP_DOC = 'CPF' THEN C.CL_NOME ELSE C.CL_RAZAO_SOCIAL END 
               FROM TBL_CLIENTES C With(NoLock) 
              WHERE C.ID_CLIENTE = A.ID_CLIENTE_DESTINO) + 
            ' | Valor: ' + mo.moe_descccme  + ' ' + CAST(A.VALOR_DEBITO AS VARCHAR) AS MOV_OBS, 
            HIS_DESCRICAO = (SELECT H2.HIS_DESCRICAO FROM TBL_ME_HISTORICO H2 With(NoLock) WHERE H2.HIS_CODIGO = H.HIS_TARIFA)
       FROM TBL_MEWEB_AGENDA_TRANSFERENCIA A With(NoLock)
      INNER JOIN TBL_ME_HISTORICO H With(NoLock) ON H.HIS_CODIGO = A.ID_HISTORICO
      INNER JOIN TBL_MOEDAS MO With(NoLock) ON A.MOEDA_TARIFA = MO.MOE_SIMBOLO
      WHERE A.ID_CLIENTE_ORIGEM = @ID_CLIENTE
        AND A.MOEDA_TARIFA = @MOEDA
        AND A.STATUS = 'A'
;
-------------------------------------
-- INSERE AS MOVIMENTACOES BLOQUEADAS
-------------------------------------
INSERT INTO @TBL_APROVACOES
     SELECT M.ID_MOV, M.MOV_DATA, M.MOV_DT_DISP, M.MOV_TIPO_OP, M.MOV_HISTORICO, 
            MO.MOE_DESCCCME, M.MOV_VALOR, CAST(M.MOV_OBS AS VARCHAR(2000)) AS MOV_OBS, H.HIS_DESCRICAO
       FROM TBL_ME_MOVIMENTACAO M With(NoLock)
      INNER JOIN TBL_ME_HISTORICO H With(NoLock) ON H.HIS_CODIGO = M.MOV_HISTORICO
      INNER JOIN TBL_MOEDAS MO With(NoLock) ON M.MOV_MOEDA = MO.MOE_SIMBOLO
      WHERE M.MOV_CLIENTE = @ID_CLIENTE
        AND M.MOV_MOEDA = @MOEDA
        AND M.MOV_FLAG_DISP = 'B'
;
  SELECT ID_MOV, MOV_DATA, MOV_DT_DISP, MOV_TIPO_OP, MOV_HISTORICO, MOE_DESCCCME, MOV_VALOR, MOV_OBS, HIS_DESCRICAO -- * 
    FROM @TBL_APROVACOES 
   WHERE MOV_DT_DISP >= GETDATE() 
ORDER BY MOV_DT_DISP
;
END
;
Go

-- Teste
-- Exec SPBCCME_Listar_Aprovacoes 2342, 'USD'
