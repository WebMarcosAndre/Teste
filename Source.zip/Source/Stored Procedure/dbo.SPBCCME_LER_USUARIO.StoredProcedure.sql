USE IK_VAREJO
GO


IF EXISTS(SELECT NAME FROM SYSOBJECTS WHERE NAME = 'SPBCCME_LER_USUARIO')
	DROP PROC DBO.SPBCCME_LER_USUARIO
GO

/***
	Nome: SPBCCME_LER_USUARIO
	Desc: 
	Autor: 
	Data:  
	***********************
	Hist�rico de Altera��es
	***********************
	PR					Date		Autor				Description
	SPBCCME_LER_USUARIO	04/04/2019	Cidicley Rodrigues  Incluir os campos li_Data_Nascimento, li_DDD e li_Celular 
	SPBCCME_LER_USUARIO	22/04/2019	Cidicley Rodrigues  Incluir o campo li_DDI
***/


CREATE PROCEDURE [dbo].[SPBCCME_LER_USUARIO]    
(    
  @LI_DOC VARCHAR(25),
  @ID_CLIENTE INT = NULL    
)    
AS    
BEGIN
	IF @ID_CLIENTE IS NULL
	BEGIN     
		 SELECT LI.LI_DOC, LI.LI_DATA_PRIMEIRO_ACESSO, LI.LI_DATA_ENVIO_SENHA, LI.LI_TERMO_ASSINADO,   
			 LI.LI_TERMO_ASS_ELETR, LI.LI_DATA_ASS_TERMO, LI.LI_DATA_ULTIMO_ACESSO, LI.LI_TIPOCLIENTE ,  
			 LI.LI_ID, LI.LI_OPERA_IMPORTACAO, LI.LI_CPF_RESPONSAVEL, LI.LI_EMAIL, LI.LI_IDCLIENTE,  
			 LI.LI_USER_EXT_INDETERMINADO, LI.LI_DATA_LIBERACAO_EXT,LI.LI_VALIDADE,  
			 PM.LI_DOC, PM.param_status_col, PM.param_nivel_complice, PM.param_autoriza_nivel_complice,  
			 PM.param_proc_eletronica, PM.param_spread_especial, PM.param_grupo_spread,  
			 PM.param_taxa_spread, PM.param_limite_operacao, PM.param_operacao_compra,  
			 PM.param_operacao_venda, PM.param_msg_especifica, PM.PARAM_EMAIL_AUTOMATICO,  
			 PM.PARAM_DIASLIQ_VENDAS, PM.PARAM_DIASLIQ_VENDASME, PM.PARAM_DIASLIQ_COMPRAS, PM.PARAM_DIASLIQ_COMPRASME,
			 LI.LI_NOME,
			 LI.li_Data_Nascimento, LI.li_DDD, LI.li_Celular, LI.li_DDI 
		   FROM TBL_LOGIN_INTEGRADO LI LEFT JOIN TBL_COL_PARAMCLI PM   
			ON RTRIM(LTRIM(LI.LI_DOC)) = RTRIM(LTRIM(PM.LI_DOC))  
			WHERE RTRIM(LTRIM(LI.LI_DOC)) = RTRIM(LTRIM(@LI_DOC))  
	END
	ELSE
	BEGIN
		SELECT LI.LI_DOC, LI.LI_DATA_PRIMEIRO_ACESSO, LI.LI_DATA_ENVIO_SENHA, LI.LI_TERMO_ASSINADO,   
			 LI.LI_TERMO_ASS_ELETR, LI.LI_DATA_ASS_TERMO, LI.LI_DATA_ULTIMO_ACESSO, LI.LI_TIPOCLIENTE ,  
			 LI.LI_ID, LI.LI_OPERA_IMPORTACAO, LI.LI_CPF_RESPONSAVEL, LI.LI_EMAIL, LI.LI_IDCLIENTE,  
			 LI.LI_USER_EXT_INDETERMINADO, LI.LI_DATA_LIBERACAO_EXT,LI.LI_VALIDADE,  
			 PM.LI_DOC, PM.param_status_col, PM.param_nivel_complice, PM.param_autoriza_nivel_complice,  
			 PM.param_proc_eletronica, PM.param_spread_especial, PM.param_grupo_spread,  
			 PM.param_taxa_spread, PM.param_limite_operacao, PM.param_operacao_compra,  
			 PM.param_operacao_venda, PM.param_msg_especifica, PM.PARAM_EMAIL_AUTOMATICO,  
			 PM.PARAM_DIASLIQ_VENDAS, PM.PARAM_DIASLIQ_VENDASME, PM.PARAM_DIASLIQ_COMPRAS, PM.PARAM_DIASLIQ_COMPRASME,
			 LI.LI_NOME,
			 LI.li_Data_Nascimento, LI.li_DDD, LI.li_Celular, LI.li_DDI
		   FROM TBL_LOGIN_INTEGRADO LI LEFT JOIN TBL_COL_PARAMCLI PM   
		  ON RTRIM(LTRIM(LI.LI_DOC)) = RTRIM(LTRIM(PM.LI_DOC))
		  WHERE LI.LI_IDCLIENTE = @ID_CLIENTE
	END  
END   
