USE [IK_VAREJO]
GO

/****** Object:  StoredProcedure [dbo].[SP_PPV_CONSULTA_PRODUCAO_PARCEIRO]    Script Date: 10/01/2018 15:01:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
Nome:  [SP_PPV_CONSULTA_PRODUCAO_PARCEIRO]
Desc:  Consulta opera��es para consultar relat�rio de producao x parceiro
Autor: Regina Yuriko Utiyama
Data:  01/10/2018
************************
Hist�rico de Altera��es
************************

Exemplo:
EXEC dbo.[SP_PPV_CONSULTA_PRODUCAO_PARCEIRO] @DATAINI = '2018-06-01', @DATAFIM = '2018-06-30', @CORRETORA  = 657
EXEC dbo.SP_PPV_CONSULTA_PRODUCAO_PARCEIRO @DATAINI = '2018-6-01',@DATAFIM   = '2018-6-30',@CORRETORA  = 657

*/
CREATE PROCEDURE [dbo].[SP_PPV_CONSULTA_PRODUCAO_PARCEIRO] (
@DATAINI   VARCHAR(10),
@DATAFIM   VARCHAR(10),
@CORRETORA VARCHAR(10))
AS
BEGIN  

SET NOCOUNT ON
DECLARE @DATA VARCHAR(10)
DECLARE @_DATA VARCHAR(10)
DECLARE @LINHAS INT
DECLARE @QTDE_GERADAS  INT
DECLARE @QTDE_CANCELADAS  INT
DECLARE @QTDE_APROVADAS INT
DECLARE @QTDE_AGUARD_PAGTO INT
DECLARE @PERC VARCHAR(10)
DECLARE @VALOR_REAIS_GERADAS  DECIMAL (15,2)
DECLARE @VALOR_REAIS_CANCELADAS  DECIMAL (15,2)
DECLARE @VALOR_REAIS_APROVADAS DECIMAL (15,2)
DECLARE @VALOR_REAIS_AGUARD_PAGTO DECIMAL (15,2)
DECLARE @VALOR_MOEDA_GERADAS  DECIMAL (15,2)
DECLARE @VALOR_MOEDA_CANCELADAS  DECIMAL (15,2)
DECLARE @VALOR_MOEDA_APROVADAS DECIMAL (15,2)
DECLARE @VALOR_MOEDA_AGUARD_PAGTO DECIMAL (15,2)

CREATE TABLE #GERAL 

(DATA DATETIME
,QTDE_GERADAS  INT
,QTDE_CANCELADAS  INT
,QTDE_APROVADAS INT
,QTDE_AGUARD_PAGTO INT
,VALOR_REAIS_GERADAS  DECIMAL (15,2)
,VALOR_REAIS_CANCELADAS  DECIMAL (15,2)
,VALOR_REAIS_APROVADAS DECIMAL (15,2)
,VALOR_REAIS_AGUARD_PAGTO DECIMAL (15,2)

,VALOR_MOEDA_GERADAS  DECIMAL (15,2)
,VALOR_MOEDA_CANCELADAS  DECIMAL (15,2)
,VALOR_MOEDA_APROVADAS DECIMAL (15,2)
,VALOR_MOEDA_AGUARD_PAGTO DECIMAL (15,2)
,PERC VARCHAR(10)
)

SELECT 
DISTINCT REPLACE(CONVERT(VARCHAR(10),op_data_boleto,102),'.','-') DATA_PROC
INTO #DATAS_PROC
FROM
 TBL_PRE_BOLETO with (nolock) where id_corretora = @corretora  and 
op_data_boleto between @DATAINI + ' 00:00:00.000' and @DATAFIM + ' 23:59:59.000'
GROUP BY pre_boleto_status,op_data_boleto


SELECT TOP 1 @DATA = DATA_PROC  FROM #DATAS_PROC

SELECT @LINHAS = COUNT(*)  FROM #DATAS_PROC 

--
WHILE @LINHAS > 0
BEGIN
SELECT TOP 1 @DATA = DATA_PROC  FROM #DATAS_PROC

SELECT 
@_DATA = CONVERT(VARCHAR(10),op_data_boleto,103),
@QTDE_GERADAS = (SELECT count(pre_boleto_status) from TBL_PRE_BOLETO with (nolock) where id_corretora = @corretora  and op_data_boleto between @DATA + ' 00:00:00.000' and @DATA + ' 23:59:59.999'),
@VALOR_REAIS_GERADAS = (SELECT sum(Isnull(op_val_reais,0)) from TBL_PRE_BOLETO with (nolock) where id_corretora = @corretora  and op_data_boleto between @DATA + ' 00:00:00.000' and @DATA + ' 23:59:59.999'),
@VALOR_MOEDA_GERADAS = (SELECT sum(Isnull(op_val_moeda,0)) from TBL_PRE_BOLETO with (nolock) where id_corretora = @corretora  and op_data_boleto between @DATA + ' 00:00:00.000' and @DATA + ' 23:59:59.999'),
@QTDE_CANCELADAS = (SELECT count(pre_boleto_status) from TBL_PRE_BOLETO with (nolock) where id_corretora = @corretora  and pre_boleto_status = 3 and op_data_boleto between @DATA + ' 00:00:00.000' and @DATA + ' 23:59:59.999'),
@VALOR_REAIS_CANCELADAS = (SELECT sum(Isnull(op_val_reais,0)) from TBL_PRE_BOLETO with (nolock) where id_corretora = @corretora  and pre_boleto_status = 3 and op_data_boleto between @DATA + ' 00:00:00.000' and @DATA + ' 23:59:59.999'),
@VALOR_MOEDA_CANCELADAS = (SELECT sum(Isnull(op_val_moeda,0)) from TBL_PRE_BOLETO with (nolock) where id_corretora = @corretora  and pre_boleto_status = 3 and op_data_boleto between @DATA + ' 00:00:00.000' and @DATA + ' 23:59:59.000'),
@QTDE_APROVADAS = (SELECT count(pre_boleto_status) from TBL_PRE_BOLETO with (nolock) where id_corretora = @corretora  and pre_boleto_status = 2 and op_data_boleto between @DATA + ' 00:00:00.000' and @DATA + ' 23:59:59.000'),
@VALOR_REAIS_APROVADAS = (SELECT sum(Isnull(op_val_reais,0)) from TBL_PRE_BOLETO with (nolock) where id_corretora = @corretora  and pre_boleto_status = 2 and op_data_boleto between @DATA + ' 00:00:00.000' and @DATA + ' 23:59:59.000'),
@VALOR_MOEDA_APROVADAS = (SELECT sum(Isnull(op_val_moeda,0)) from TBL_PRE_BOLETO with (nolock) where id_corretora = @corretora  and pre_boleto_status = 2 and op_data_boleto between @DATA + ' 00:00:00.000' and @DATA + ' 23:59:59.000'),
@QTDE_AGUARD_PAGTO = (SELECT count(pre_boleto_status) from TBL_PRE_BOLETO with (nolock) where id_corretora = @corretora  and pre_boleto_status = 0 and op_data_boleto between @DATA + ' 00:00:00.000' and @DATA + ' 23:59:59.000') ,
@VALOR_REAIS_AGUARD_PAGTO = (SELECT sum(Isnull(op_val_reais,0)) from TBL_PRE_BOLETO with (nolock) where id_corretora = @corretora  and pre_boleto_status = 0 and op_data_boleto between @DATA + ' 00:00:00.000' and @DATA + ' 23:59:59.000') ,
@VALOR_MOEDA_AGUARD_PAGTO = (SELECT sum(Isnull(op_val_moeda,0)) from TBL_PRE_BOLETO with (nolock)  where id_corretora = @corretora  and pre_boleto_status = 0 and op_data_boleto between @DATA + ' 00:00:00.000' and @DATA + ' 23:59:59.000') 
  from TBL_PRE_BOLETO with (nolock)  where id_corretora = @corretora  and 
op_data_boleto between @DATAINI + ' 00:00:00.000' and @DATAFIM + ' 23:59:59.999'
GROUP BY pre_boleto_status,op_data_boleto


SET @PERC  = CONVERT(VARCHAR(10),(100*@QTDE_CANCELADAS /@QTDE_GERADAS)) + '%' 


INSERT INTO #GERAL VALUES (@DATA,@QTDE_GERADAS,@QTDE_CANCELADAS,@QTDE_APROVADAS,@QTDE_AGUARD_PAGTO ,@VALOR_REAIS_GERADAS ,@VALOR_REAIS_CANCELADAS ,@VALOR_REAIS_APROVADAS ,@VALOR_REAIS_AGUARD_PAGTO,@VALOR_MOEDA_GERADAS ,@VALOR_MOEDA_CANCELADAS  ,@VALOR_MOEDA_APROVADAS,@VALOR_MOEDA_AGUARD_PAGTO,@PERC)

DELETE  #DATAS_PROC WHERE DATA_PROC  = @DATA
SELECT @LINHAS = COUNT(*) FROM #DATAS_PROC

END

SET NOCOUNT OFF
SELECT CONVERT(CHAR(10),DATA,103) DATA ,
QTDE_GERADAS  
,replace(isnull(VALOR_REAIS_GERADAS,0),'.',',' ) VALOR_REAIS_GERADAS
,replace(isnull(VALOR_MOEDA_GERADAS,0),'.',',' ) VALOR_MOEDA_GERADAS
,replace(isnull(QTDE_CANCELADAS,0) ,'.',',' ) QTDE_CANCELADAS
,replace(isnull(VALOR_REAIS_CANCELADAS,0) ,'.',',' ) VALOR_REAIS_CANCELADAS 
,replace(isnull(VALOR_MOEDA_CANCELADAS,0) ,'.',',' ) VALOR_MOEDA_CANCELADAS 
,CONVERT(VARCHAR(10),(100* isnull(QTDE_CANCELADAS,0)/isnull(QTDE_GERADAS,0)))  + '%' PERC
,replace(isnull(QTDE_APROVADAS,0) ,'.',',' ) QTDE_APROVADAS 
,replace(isnull(VALOR_REAIS_APROVADAS,0),'.',',' ) VALOR_REAIS_APROVADAS
,replace(isnull(VALOR_MOEDA_APROVADAS,0) ,'.',',' ) VALOR_MOEDA_APROVADAS 
,replace(isnull(QTDE_AGUARD_PAGTO,0) ,'.',',' ) QTDE_AGUARD_PAGTO 
,replace(isnull(VALOR_REAIS_AGUARD_PAGTO,0),'.',',' ) VALOR_REAIS_AGUARD_PAGTO
,replace(isnull(VALOR_MOEDA_AGUARD_PAGTO,0) ,'.',',' ) VALOR_MOEDA_AGUARD_PAGTO 
FROM #GERAL
ORDER BY DATA
END



