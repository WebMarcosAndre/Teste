USE [IK_VAREJO]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[PR_GET_STATUS_CIP]    Script Date: 11/06/2019 16:23:40 ******/
-- =====================================================================================================================================
-- Author:		
-- Create date: 
-- Description:	
-------------------------------------------------------------------------------------------------
-- 683751.1273 - Projeto Migra��o SQL 2016 - Varejo
--					- Select com asterisco
-------------------------------------------------------------------------------------------------
-- Hist�rico Altera��es
-- *********************
-- PRG______________________________________ Data_____ Autor________ Descri��o__________________________________________
-- dbo.PR_GET_STATUS_CIP.StoredProcedure.sql 12/jun/19 C�ssio Drezza 683751.1273 - Projeto Migra��o SQL 2016 - Varejo
-- =====================================================================================================================================
ALTER PROCEDURE [dbo].[PR_GET_STATUS_CIP] (
	   @OP_N_BOLETO INT       
    )
AS 
BEGIN 

	SELECT id, OP_N_BOLETO, TIPO_DE_BAIXA, DATA_INCLUSAO, STATUS_CIP
	  FROM TBL_RE_BAIXA_BOLETO_BANCARIO WITH(NOLOCK)
	 WHERE OP_N_BOLETO = @OP_N_BOLETO
	;
END 
;

Go

