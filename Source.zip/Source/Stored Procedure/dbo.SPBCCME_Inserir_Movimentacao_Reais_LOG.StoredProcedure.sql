USE IK_VAREJO
--SP_HELPTEXT SPBCCME_INSERIR_MOVIMENTACAO_LOG
IF OBJECT_ID('dbo.SPBCCME_Inserir_Movimentacao_Reais_LOG', 'P') IS NOT NULL 
  DROP PROCEDURE dbo.SPBCCME_Inserir_Movimentacao_Reais_LOG
GO   
CREATE PROCEDURE [dbo].[SPBCCME_Inserir_Movimentacao_Reais_LOG]  
(  
 @ID_MOV INT,  
 @ID_USER_EXCLUSAO INT,  
 @ACAO_EXCLUSAO VARCHAR(50),  
 @STATUS_EXCLUSAO INT,  
 @EXECUTAR INT  
)  
AS  
BEGIN  
  
IF(@EXECUTAR = 1)  
 BEGIN  
  INSERT INTO TBL_ME_MOVIMENTACAO_reais_LOG  
  (id_mov, mov_cliente, mov_moeda, mov_tipo, mov_tipo_op, mov_qtde_cheque, mov_valor_cheque, mov_historico, mov_valor, mov_tipo_user, mov_user, mov_dt_disp, mov_moeda2, mov_paridade, mov_tarifa, mov_perc_tarifa, mov_obs, mov_data, mov_data2, mov_flag_disp
, mov_flag_bloq, mov_dt_lib, mov_obs_lib, mov_observacao, mov_hist_tarifa, MOV_PARIDADE_MANUAL_DEBITO, MOV_PARIDADE_MANUAL_CREDITO, mov_tarifa_mov, ID_MOV_TARIFA, ID_MOV_ORIGEM, ID_MOV_DESTINO, mov_status, integrado, data_integracao, COD_RECEIVER, ID_ORDEM, DATA_LIBERACAO, MOV_CBR_VTM_DE, MOV_CBR_VTM_ATE, integrado_COTACAO, DATA_INTEGRACAO_Cotacao, ID_USER_EXCLUSAO, DATA_EXCLUSAO, ACAO_EXCLUSAO, STATUS_EXCLUSAO)  
  
  (SELECT id_mov, mov_cliente, mov_moeda, mov_tipo, mov_tipo_op, mov_qtde_cheque, mov_valor_cheque, mov_historico, mov_valor, mov_tipo_user, mov_user, mov_dt_disp, mov_moeda2, mov_paridade, mov_tarifa, mov_perc_tarifa, mov_obs, mov_data, mov_data2, mov_flag_disp, mov_flag_bloq, mov_dt_lib, mov_obs_lib, mov_observacao, mov_hist_tarifa, MOV_PARIDADE_MANUAL_DEBITO, MOV_PARIDADE_MANUAL_CREDITO, mov_tarifa_mov, ID_MOV_TARIFA, ID_MOV_ORIGEM, ID_MOV_DESTINO, mov_status, integrado, data_integracao, COD_RECEIVER, 
ID_ORDEM, DATA_LIBERACAO, MOV_CBR_VTM_DE, MOV_CBR_VTM_ATE, integrado_COTACAO, DATA_INTEGRACAO_Cotacao, @ID_USER_EXCLUSAO, GETDATE(), @ACAO_EXCLUSAO, @STATUS_EXCLUSAO  
  FROM TBL_ME_MOVIMENTACAO_reais WITH(NOLOCK)  
  WHERE id_mov = @ID_MOV);  
 END  
ELSE  
BEGIN  
  
 UPDATE TBL_ME_MOVIMENTACAO_reais_LOG SET STATUS_EXCLUSAO = 0  
 WHERE id_mov = @ID_MOV;  
  
END  
  
END  