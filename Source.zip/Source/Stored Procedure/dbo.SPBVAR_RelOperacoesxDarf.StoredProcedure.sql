USE ik_Varejo
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[SPBVAR_RelOperacoesXDarf]    Script Date: 23/04/2019 14:08:05 ******/
-- =====================================================================================================================================
-- Author:		
-- Create date: 
-- Description:	
-------------------------------------------------------------------------------------------------
-- 683751.694173 - Projeto Migra��o SQL 2016 - Varejo
--					- ORDER BY Num�rico
-------------------------------------------------------------------------------------------------
-- Hist�rico Altera��es
-- *********************
-- PRG_____________________________________________ Data_____ Autor________ Descri��o__________________________________________
-- dbo.SPBVAR_RelOperacoesXDarf.StoredProcedure.sql 23/abr/19 C�ssio Drezza 683751.694173 - Projeto Migra��o SQL 2016 - Varejo
-- =====================================================================================================================================
ALTER PROCEDURE [dbo].[SPBVAR_RelOperacoesXDarf]   
(    
	@DATA_INICIO	DATETIME	= NULL,    
	@DATA_FIM		DATETIME = NULL,    
	@SISTEMA_ORIGEM	VARCHAR(30) = NULL,  
	@NOME_CLIENTE   VARCHAR(300)= NULL,    
	@NUM_DOC        VARCHAR(18) = NULL,    
	@STATUS			INT  
)    
AS    
BEGIN
		SELECT 
				DTINCLUSAO						=CONVERT(VARCHAR,B.OP_DATA_INCLUSAO,103),
				SISTEMAORIGEM					=B.SISTEMA_ORIGEM,
				CLIENTE							=CASE WHEN C.CL_TIP_DOC = 'CNPJ' THEN C.CL_RAZAO_SOCIAL ELSE C.CL_NOME END,
				DOCUMENTO						=C.CL_NUM_DOC,
				STATUSBOLETO					=B.PRE_BOLETO_STATUS,
				BOLETO							=B.OP_N_BOLETO,
				OBSERVACOESBACEN				=LTRIM(RTRIM(B.OP_INF_OBS)),
				BOLETOTEMDARF					=CASE WHEN ISNULL(B.RETORNO_DARF_IR,0) = 0 THEN 'N' ELSE 'S' END,   
				DARFEXISTENTE					=CASE WHEN ISNULL(D.ID_DARF,0) = 0 THEN 'N' ELSE 'S' END,   
				DARFPAGO						=D.PAGO,
				CODIGONATUREZA					=N.NAT_CODIGO,
				DESCRICAONATUREZA				=N.NAT_DESCRICAO,
				CODIGOPAIS						=P.CODIGO,
				PAIS							=P.PAIS,
				TAXABANCO						=B.OP_TAXA_BANCO,
				TAXAOPERACAO					=B.OP_TX_OPERACAO,
				TAXAPTAXBOLETO					=B.TX_PTAX_IR,
				BOLETOCHANGE					=B.OP_N_BOLETO_CHANGE,
				BOLETOREVERSAO					=B.OP_BOLETO_REVERSAO,
				TIPOOPERACAO					=B.OP_TIPO_OPERACAO,
				TIPOENTREGA						=B.OP_TIPO_ENTREGA,
				MOEDA							=B.OP_TIPO_MOEDA,
				ME								=B.OP_VAL_MOEDA,
				MN								=B.OP_VAL_REAIS,
				DATAMN							=CONVERT(VARCHAR,B.OP_DATA_MN,103),
				DATAME							=CONVERT(VARCHAR,B.OP_DATA_ME,103),
				VALUTA							=B.AUX_DATAMNME, 
				RECOLHIMENTOBOLETO				=B.OP_REC_IR,
				TAXAIRBOLETO					=B.TAXA_IR,
				ALIQUOTABOLETO					=B.OP_TIPO_ALIQUOTA_IR,
				VALORIRBOLETO					=B.VLR_IR,
				CODIGODARFIR					=B.COD_DARF_IR,
				DATAPERIODORECOLHIMENTODARF		=CONVERT(VARCHAR,D.DATA_PERIODO_DARF,103), 
				CODIGORECEITADARF				=D.COD_RECEITA_DARF,
				VALORPRINCIPALDARF				=D.VLR_PRINCIPAL_DARF,
				FORMAPAGAMENTODARF				=D.FORMA_PAGAMENTO,
				MENSAGEMERRORECOLHIMENTODARF	=D.MSG_ERRO,
				PERMITIUDUPLICARDARF			=D.PERMITEDUPLICAR 
		FROM TBL_PRE_BOLETO B WITH(NOLOCK)
		LEFT JOIN DARF.[DBO].[TBL_DARF] D WITH(NOLOCK) ON D.ID_DARF = B.RETORNO_DARF_IR
		LEFT JOIN TBL_NATUREZA N WITH(NOLOCK) ON N.ID_NATUREZA = B.OP_NATUREZA  
		LEFT JOIN TBL_PAISES P WITH(NOLOCK) ON P.CODIGO = B.OP_PAISES
		LEFT JOIN TBL_CLIENTES C WITH(NOLOCK) ON C.ID_CLIENTE = B.ID_CLIENTE  
		WHERE B.OP_TIPO_OPERACAO = 'V' 
			AND B.OP_INF_OBS LIKE '%DARF%'
			-- FILTROS DO RELAT�RIO
			AND 
					(
						(
						B.OP_DATA_INCLUSAO BETWEEN CONVERT(VARCHAR(10),@DATA_INICIO,112) 
						AND DATEADD(DAY, 1,CONVERT(VARCHAR(10),@DATA_FIM,112))
						)
					)
				AND (
							@SISTEMA_ORIGEM IS NULL
							OR 
								(
									B.SISTEMA_ORIGEM = (@SISTEMA_ORIGEM)
								)
					)
				AND (
						@NOME_CLIENTE IS NULL
						OR 
							(
								C.CL_NOME LIKE '%' + @NOME_CLIENTE + '%' 
								OR C.CL_RAZAO_SOCIAL LIKE '%' + @NOME_CLIENTE + '%'
							)
					)

				AND (
						@NUM_DOC IS NULL 
						OR	
							(
							CONVERT(VARCHAR,C.CL_NUM_DOC) = CONVERT(VARCHAR,@NUM_DOC)
							)
					)
				AND (	
						@STATUS IS NULL
						OR
						(
							B.PRE_BOLETO_STATUS = @STATUS
						)
					)
	ORDER BY CONVERT(VARCHAR(10),B.OP_DATA_INCLUSAO,112)
			, B.SISTEMA_ORIGEM -- 2
	;
END
/*FIM PROCEDURE SPBVAR_RelOperacoesxDarf - Jose Luis de Moraes - 29/11/2016*/

Go

