USE [IK_VAREJO]
GO
/****** Object:  StoredProcedure [dbo].[SP_TradeRate_GetSellingTradeRate]    Script Date: 05/29/2017 14:40:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE  [dbo].[SP_TradeRate_GetSellingTradeRate]
    @Cod_Moeda as varchar(6),
	@Cod_Empresa as int,	
	@Amount as decimal
AS
BEGIN
SET NOCOUNT ON

	DECLARE @TAXA_PRONTO AS FLOAT = 0
	DECLARE @TAXA_RETORNO AS FLOAT = 0
	DECLARE @DATA_EXPIRACAO AS datetime
	DECLARE @FxRateId AS INT = 0

	SELECT 
		@TAXA_PRONTO = tm.TX_BANCO		
		,@TAXA_RETORNO = CAST((tm.TX_BANCO * (s.SpreadCompra /100+1)) AS NUMERIC (15,4))
		,@DATA_EXPIRACAO = DATEADD (MINUTE,ISNULL(TET.TempoExpiracao,0),getdate())		
	FROM VAREJO..TMoedas TM 
		INNER JOIN TBL_WS_TRADERATE_SPREAD S ON TM.Cod_moeda COLLATE SQL_Latin1_General_CP1_CI_AS = MOEDA
		INNER JOIN TBL_WS_TRADERATE_Tempo_Expiracao_Taxa TET ON TET.Cod_Empresa = S.Cod_Empresa
	WHERE 
		TM.Cod_moeda = @Cod_Moeda
		AND S.Cod_Empresa = @Cod_Empresa
		AND @Amount >= S.ValorMinimo  and @Amount <= S.ValorMaximo
		AND S.Ativo = 1

	IF 	@TAXA_PRONTO = 0 OR @TAXA_RETORNO = 0 or @DATA_EXPIRACAO is null 
		BEGIN
				
		--Isere o Log da consulta
		INSERT INTO [IK_VAREJO].[dbo].[TBL_WS_TRADERATE_LOG_PPV]
			   (
					[FxRateType]
					,FxRateId            
				   ,[LogDate]
				   ,[DefaultFxRate]
				   ,[InformedFxRate]
				   ,[Amount]
				   ,[ExpirationDate]
				   ,[Status]
				   ,[DescriptionStatus]
			   )
		 VALUES
			   (
					'S'
					, NULL
				   ,GETDATE()
				   ,@TAXA_PRONTO  
				   ,@TAXA_RETORNO 
				   ,@Amount 
				   ,@DATA_EXPIRACAO 
					,'Erro'
					,'Erro 21 - ' + 'Empresa:' + CONVERT(VARCHAR,@Cod_Empresa) + ' - N�o foi configurado o Spread para a moeda ' + @Cod_Moeda + ' nesta faixa de valores ou n�o foi configurado o tempo de expira��o para a taxa'
				)	
		END
		
		--Insere a consulta para valida��o posterior ao processar os arquivos no Rob�	
		INSERT TBL_WS_TRADERATE_FXRate (Taxa,ExpirationDate,Cod_Empresa) VALUES (@TAXA_RETORNO, @DATA_EXPIRACAO,@Cod_Empresa)	
		SELECT @TAXA_RETORNO AS FxRate ,@DATA_EXPIRACAO AS ExpirationDate, @@identity AS FxRateId
		
		IF 	@TAXA_PRONTO <> 0 AND @TAXA_RETORNO <> 0 AND @DATA_EXPIRACAO is not null 
		BEGIN
				
		--Isere o Log da consulta
		INSERT INTO [IK_VAREJO].[dbo].[TBL_WS_TRADERATE_LOG_PPV]
			   (
					[FxRateType]
					,FxRateId            
				   ,[LogDate]
				   ,[DefaultFxRate]
				   ,[InformedFxRate]
				   ,[Amount]
				   ,[ExpirationDate]
				   ,[Status]
				   ,[DescriptionStatus]
			   )
		 VALUES
			   (
					'S'
					, @@identity
				   ,GETDATE()
				   ,@TAXA_PRONTO  
				   ,@TAXA_RETORNO 
				   ,@Amount 
				   ,@DATA_EXPIRACAO 
					,'Sucesso'
					,'Sucesso'
				)	
		END
END
