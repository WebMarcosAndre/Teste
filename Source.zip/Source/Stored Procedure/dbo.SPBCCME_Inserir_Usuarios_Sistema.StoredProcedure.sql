USE IK_VAREJO
GO


IF EXISTS(SELECT NAME FROM SYSOBJECTS WHERE NAME = 'SPBCCME_Inserir_Usuarios_Sistema')
	DROP PROC DBO.SPBCCME_Inserir_Usuarios_Sistema
GO

/***
	Nome: SPBCCME_Inserir_Usuarios_Sistema
	Desc: 
	Autor: 
	Data:  
	***********************
	Hist�rico de Altera��es
	***********************
	PR									Date		Autor				Description
	SPBCCME_Inserir_Usuarios_Sistema	04/04/2019	Cidicley Rodrigues  Incluir os campos li_Data_Nascimento, li_DDD e li_Celular.
	SPBCCME_Inserir_Usuarios_Sistema	22/04/2019	Cidicley Rodrigues  Incluir o campo li_DDI.

***/

CREATE PROCEDURE [dbo].[SPBCCME_Inserir_Usuarios_Sistema]      
(
  @ID_CLIENTE	  INT,      
  @LI_DOC         NVARCHAR(25),      
  @LI_SENHA       VARCHAR(45),      
  @LI_STATUS      CHAR(1),      
  @LI_NOME        VARCHAR(300),      
  @LI_EMAIL       VARCHAR(200),      
  @LI_OPERA_VOL   CHAR(1),      
  @LI_VALIDADE    DATETIME,      
  @LI_SISTEMA     INT = 1,      
  @LI_CORRETORA   CHAR(1) = NULL,      
  @LI_EDITA_OP    CHAR(1) = NULL,      
  @LI_CANCELA_OP  CHAR(1) = NULL,    
  @LI_TIPOCLIENTE CHAR(1) = NULL,    
  @LI_DOC_MASTER  NVARCHAR(25) = NULL,  
  @LI_APROVA_OP   CHAR(1) = NULL,  
  @LI_CPF		  VARCHAR(11) = NULL,  
  @LI_HABILITA_INTEGRACAO BIT = 0,
  @LI_DATA_NASCIMENTO datetime,
  @LI_DDD		  CHAR(3),
  @LI_CELULAR    CHAR(16),
  @LI_DDI		  CHAR(3)  
)        
AS        
BEGIN        
    
   IF NOT EXISTS (SELECT LI_DOC FROM TBL_LOGIN_INTEGRADO WHERE LI_DOC = @LI_DOC)      
   BEGIN        
       
  DECLARE @FLAG_HABILITA_CAMBIO_COTACAO CHAR(1)
  
  SET @FLAG_HABILITA_CAMBIO_COTACAO = (SELECT FLAG_HABILITA_CAMBIO_COTACAO FROM TBL_LOGIN_INTEGRADO WITH(NOLOCK) WHERE LI_IDCLIENTE = @ID_CLIENTE AND LI_TIPO = 'M')
       
  INSERT INTO TBL_LOGIN_INTEGRADO       
   (LI_DOC, LI_SENHA, LI_STATUS, LI_ERROS, LI_TIPO, LI_NOME, LI_EMAIL, LI_OPERA_VOL,       
    LI_VALIDADE, LI_SISTEMA, LI_ALTERARSENHA, LI_CORRETORA, LI_EDITA_OP, LI_CANCELA_OP,     
    LI_TIPOCLIENTE, LI_IDCLIENTE, LI_ACESSO_CCMEWEB, LI_APROVA_OP, LI_CPF, FLAG_HABILITA_CAMBIO_COTACAO, LI_HABILITA_INTEGRACAO,
	LI_DATA_NASCIMENTO, LI_DDD, LI_CELULAR, LI_DDI)      
  VALUES      
   (@LI_DOC, PWDENCRYPT(@LI_SENHA), 'A', 0, 'U', @LI_NOME, @LI_EMAIL, @LI_OPERA_VOL,       
    @LI_VALIDADE, @LI_SISTEMA, 1, @LI_CORRETORA, @LI_EDITA_OP, @LI_CANCELA_OP,     
    @LI_TIPOCLIENTE, @ID_CLIENTE, 'S', @LI_APROVA_OP, @LI_CPF, @FLAG_HABILITA_CAMBIO_COTACAO, @LI_HABILITA_INTEGRACAO,
	@LI_DATA_NASCIMENTO, @LI_DDD, @LI_CELULAR, @LI_DDI)  
  
  --SELECT IDENT_CURRENT('TBL_LOGIN_INTEGRADO') AS ID_USUARIO  
  SELECT @@IDENTITY AS ID_USUARIO  
    
   END  
       
END
