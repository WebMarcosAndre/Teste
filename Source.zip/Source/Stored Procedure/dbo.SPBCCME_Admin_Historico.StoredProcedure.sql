USE [IK_Varejo]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[SPBCCME_Admin_Historico]    Script Date: 05/07/2019 17:13:15 ******/
-- =====================================================================================================================================
-- Author:		
-- Create date: 
-- Description:	
-------------------------------------------------------------------------------------------------
-- 683751.1273 - Projeto Migra��o SQL 2016 - Varejo
--					- Select com asterisco
--					- (No|ock) sem With
-------------------------------------------------------------------------------------------------
-- Hist�rico Altera��es
-- *********************
-- PRG____________________________________________ Data_____ Autor____________ Descri��o__________________________________________
-- SPBCCME_Admin_Historico						  16/04/2019 Leonardo Nogueira Adi��o de par�metros @HIS_DESCRICAO_INGLES e @HIS_DESCRICAO_ESPANHOL
-- dbo.SPBCCME_Admin_Historico.StoredProcedure.sql 05/jul/19 C�ssio Drezza     683751.1273 - Projeto Migra��o SQL 2016 - Varejo
-- =====================================================================================================================================
ALTER PROCEDURE [dbo].[SPBCCME_Admin_Historico]
 (
   @ACAO                    VARCHAR(30),
   @HIS_DESCRICAO           VARCHAR(50)  = NULL,
   @HIS_ID                  INT          = NULL,
   @HIS_CODIGO              VARCHAR(10)  = NULL,
   @HIS_CODIGO_COTA         VARCHAR(10)  = NULL,
   @HIS_TIPO                VARCHAR(10)  = NULL,   
   @HIS_AUTO_MANUAL         CHAR(1)      = NULL,
   @HIS_STATUS              CHAR(1)      = NULL,
   @HIS_TIPO_OPERACAO       VARCHAR(25)  = NULL,
   @HIS_CONTABILIZA         CHAR(1)      = NULL,   
   @HIS_CONTABILIZA_COTA    CHAR(1)      = NULL,   
   @HIS_TARIFA              INT          = NULL,
   @HIS_TIPO_CONTA_D        CHAR(1)      = NULL,
   @HIS_CONTA_DEBITO        VARCHAR(20)  = NULL,
   @HIS_TIPO_TITULAR_D      CHAR(1)      = NULL,
   @HIS_TITULAR_DEBITO      VARCHAR(20)  = NULL,
   @HIS_TIPO_CONTA_C        CHAR(1)      = NULL,
   @HIS_CONTA_CREDITO       VARCHAR(20)  = NULL,
   @HIS_TIPO_TITULAR_C      CHAR(1)      = NULL,
   @HIS_TITULAR_CREDITO     VARCHAR(20)  = NULL,
   @HIS_CUSTO_TARIFA        MONEY        = NULL,
   @HIS_EMITE_COMPROVANTE   VARCHAR(1)   = NULL,
   @MSG                     VARCHAR(500) = NULL OUTPUT,
   @HIS_CREDITO             INT          = NULL,
   @HIS_REVERSAO            INT          = NULL,
   @ID_USUARIO              INT          = NULL,
   @HIS_DESCRICAO_INGLES    VARCHAR(50)  = NULL,  
   @HIS_DESCRICAO_ESPANHOL  VARCHAR(50)  = NULL  
 )

AS

BEGIN

   SET NOCOUNT ON

	 IF @ACAO = 'COMBO_HISTORICO_REFERENCIA'

	 BEGIN
		 SELECT HIS_CODIGO, convert(varchar(400),HIS_CODIGO) + ' - ' + CONVERT(varchar(400),HIS_DESCRICAO) as HIS_DESCRICAO
            FROM TBL_ME_HISTORICO a With(NoLock)
            WHERE his_contabiliza_cota = 'S'
            and not exists (select 1 from TBL_ME_HISTORICO b With(NoLock) where b.his_codigo <> @HIS_CODIGO AND b.his_codigo_cota = a.HIS_CODIGO)
	 END



      IF @ACAO = 'LISTAR'
      BEGIN

         SELECT ID_HIS, HIS_CODIGO, HIS_TIPO, (CASE WHEN HIS_STATUS = 'A' THEN 'ATIVO' ELSE 'INATIVO' END) AS HIS_STATUS, 
                HIS_TIPO_OPERACAO, (CASE WHEN HIS_AUTO_MANUAL = 'A' THEN 'AUTOMATICO' ELSE 'MANUAL' END) AS HIS_AUTO_MANUAL
				,-- *	--	id_his, his_codigo, his_tipo, his_status, his_tipo_operacao, his_auto_manual, 
				his_descricao, his_data, his_contabiliza, his_tarifa, HIS_TIPO_CONTA_D, HIS_CONTA_DEBITO, HIS_TIPO_CONTA_C, HIS_CONTA_CREDITO, HIS_TIPO_TITULAR_D, HIS_TITULAR_DEBITO, HIS_TIPO_TITULAR_C, HIS_TITULAR_CREDITO, HIS_CUSTO_TARIFA, HIS_EMITE_COMPROVANTE, HIS_CREDITO, HIS_REVERSAO, his_contabiliza_cota, his_codigo_cota, HIS_DESCRICAO_INGLES, HIS_DESCRICAO_ESPANHOL
           FROM TBL_ME_HISTORICO With(NoLock)
          WHERE HIS_DESCRICAO LIKE (@HIS_DESCRICAO + '%') OR
				HIS_DESCRICAO_INGLES LIKE (@HIS_DESCRICAO + '%') OR  
				HIS_DESCRICAO_ESPANHOL LIKE (@HIS_DESCRICAO + '%')  
          ORDER BY HIS_DESCRICAO

      END

      IF @ACAO = 'EDITAR'
      BEGIN

         SELECT 
			id_his, his_codigo, his_tipo, his_descricao, his_status, his_data, his_tipo_operacao, his_contabiliza, his_auto_manual, his_tarifa, HIS_TIPO_CONTA_D, HIS_CONTA_DEBITO, HIS_TIPO_CONTA_C, HIS_CONTA_CREDITO, HIS_TIPO_TITULAR_D, HIS_TITULAR_DEBITO, HIS_TIPO_TITULAR_C, HIS_TITULAR_CREDITO, HIS_CUSTO_TARIFA, HIS_EMITE_COMPROVANTE, HIS_CREDITO, HIS_REVERSAO, his_contabiliza_cota, his_codigo_cota, HIS_DESCRICAO_INGLES, HIS_DESCRICAO_ESPANHOL -- *
		 FROM TBL_ME_HISTORICO With(NoLock) WHERE ID_HIS = @HIS_ID

      END

      IF @ACAO = 'NOVO_CODIGO'
      BEGIN

         SELECT (MAX(ISNULL(HIS_CODIGO, 0)) + 1) AS HIS_CODIGO
           FROM TBL_ME_HISTORICO With(NoLock)
          WHERE HIS_CODIGO <> 9999

      END

      IF @ACAO = 'COMBO_TIPO_OPERACAO'
      BEGIN
         SELECT MOV_TIPO FROM TBL_ME_TIPO_MOVIMENTACAO With(NoLock) ORDER BY MOV_TIPO
      END

      IF @ACAO = 'COMBO_TIPO_MOVIMENTACAO'
      BEGIN
         SELECT HIS_TIPO_OPERACAO 
         FROM TBL_ME_HISTORICO With(NoLock)
         WHERE HIS_AUTO_MANUAL = 'M'
         GROUP BY HIS_TIPO_OPERACAO
         ORDER BY HIS_TIPO_OPERACAO
      END

      IF @ACAO = 'COMBO_TARIFAS'
      BEGIN
         SELECT HIS_CODIGO, HIS_DESCRICAO
           FROM TBL_ME_HISTORICO With(NoLock)
          WHERE HIS_TIPO_OPERACAO = 'TARIFA'
      END

      IF @ACAO = 'COMBO_ESTORNO'
      BEGIN
         SELECT HIS_CODIGO, HIS_DESCRICAO
           FROM TBL_ME_HISTORICO With(NoLock)
          WHERE HIS_TIPO_OPERACAO IN ('TRANSFERENCIA','TARIFA','SWIFT')
      END

      IF @ACAO = 'COMBO_REVERSAO'
      BEGIN
SELECT HIS_CODIGO, HIS_DESCRICAO
           FROM TBL_ME_HISTORICO With(NoLock)
          WHERE HIS_TIPO_OPERACAO = 'TRANSFERENCIA'
      END

      IF @ACAO = 'COMBO_HISTORICO'
      BEGIN
         SELECT HIS_CODIGO, HIS_DESCRICAO
           FROM TBL_ME_HISTORICO With(NoLock)
          WHERE HIS_TIPO_OPERACAO = @HIS_TIPO_OPERACAO
            AND HIS_TIPO = @HIS_TIPO
            AND HIS_AUTO_MANUAL = 'M'
            AND (his_contabiliza_cota IS NULL OR his_contabiliza_cota = 'N')
      END


      IF @ACAO = 'COMBO_COMPROVANTE'
		BEGIN
         SELECT DISTINCT HIS_TIPO_OPERACAO
           FROM TBL_ME_HISTORICO With(NoLock)
          WHERE HIS_EMITE_COMPROVANTE = 'S'
          ORDER BY HIS_TIPO_OPERACAO
		END

      IF @ACAO = 'LER_HISTORICO'
      BEGIN
         SELECT H2.HIS_CODIGO, H2.HIS_DESCRICAO,
                CASE WHEN RTRIM(LTRIM(H2.HIS_TIPO)) = 'CREDITO' THEN 'C' ELSE 'D' END AS HIS_TIPO
           FROM TBL_ME_HISTORICO H1 With(NoLock)
          INNER JOIN TBL_ME_HISTORICO H2 With(NoLock) ON H2.HIS_CODIGO = H1.HIS_TARIFA
		   WHERE H1.HIS_CODIGO = @HIS_CODIGO
      END

      IF @ACAO = 'ATUALIZAR'
      BEGIN

         ----------------------------------------------------
         -- GRAVA COPIA DO REGISTRO ANTERIOR NA TABELA DE LOG
         ----------------------------------------------------
         DECLARE @VERSAO INT
  
         SELECT TOP 1 @VERSAO = (MAX(VERSAO) + 1) 
           FROM TBL_ME_HISTORICO_LOG With(NoLock)
          WHERE ID_HIS = @HIS_ID

         IF @VERSAO IS NULL
         BEGIN
            SET @VERSAO = 0
         END

         INSERT INTO TBL_ME_HISTORICO_LOG
                    (ID_HIS, VERSAO, DATA_INCLUSAO, ID_USUARIO, HIS_CODIGO, HIS_DESCRICAO, HIS_TIPO, HIS_AUTO_MANUAL, 
                     HIS_STATUS, HIS_DATA, HIS_TIPO_OPERACAO, HIS_CONTABILIZA, HIS_CONTABILIZA_COTA, HIS_TARIFA, 
                     HIS_TIPO_CONTA_D, HIS_CONTA_DEBITO, HIS_TIPO_TITULAR_D, HIS_TITULAR_DEBITO, 
                     HIS_TIPO_CONTA_C, HIS_CONTA_CREDITO, HIS_TIPO_TITULAR_C, HIS_TITULAR_CREDITO,
                     HIS_CUSTO_TARIFA, HIS_EMITE_COMPROVANTE, HIS_CREDITO, HIS_REVERSAO, HIS_CODIGO_COTA,
                     HIS_DESCRICAO_INGLES, HIS_DESCRICAO_ESPANHOL)  
              SELECT ID_HIS, @VERSAO, GETDATE(), @ID_USUARIO, HIS_CODIGO, HIS_DESCRICAO, HIS_TIPO, HIS_AUTO_MANUAL, 
                     HIS_STATUS, HIS_DATA, HIS_TIPO_OPERACAO, HIS_CONTABILIZA, HIS_CONTABILIZA_COTA,  HIS_TARIFA, 
                     HIS_TIPO_CONTA_D, HIS_CONTA_DEBITO, HIS_TIPO_TITULAR_D, HIS_TITULAR_DEBITO, 
                     HIS_TIPO_CONTA_C, HIS_CONTA_CREDITO, HIS_TIPO_TITULAR_C, HIS_TITULAR_CREDITO,
                     HIS_CUSTO_TARIFA, HIS_EMITE_COMPROVANTE, HIS_CREDITO, HIS_REVERSAO, HIS_CODIGO_COTA,
                     HIS_DESCRICAO_INGLES, HIS_DESCRICAO_ESPANHOL 
                FROM TBL_ME_HISTORICO With(NoLock)
               WHERE ID_HIS = @HIS_ID


         --------------------
         -- ALTERA O REGISTRO
         --------------------
         UPDATE TBL_ME_HISTORICO
            SET HIS_CODIGO             = @HIS_CODIGO,
				HIS_CODIGO_COTA        = @HIS_CODIGO_COTA,
                HIS_DESCRICAO          = @HIS_DESCRICAO,
                HIS_TIPO               = @HIS_TIPO,
                HIS_AUTO_MANUAL        = @HIS_AUTO_MANUAL,
                HIS_STATUS             = @HIS_STATUS,
                HIS_TIPO_OPERACAO      = @HIS_TIPO_OPERACAO,
                HIS_CONTABILIZA        = @HIS_CONTABILIZA,
				HIS_CONTABILIZA_COTA   = @HIS_CONTABILIZA_COTA,
                HIS_TARIFA             = @HIS_TARIFA,
                HIS_TIPO_CONTA_D       = @HIS_TIPO_CONTA_D,
                HIS_CONTA_DEBITO       = @HIS_CONTA_DEBITO,
                HIS_TIPO_TITULAR_D     = @HIS_TIPO_TITULAR_D,
                HIS_TITULAR_DEBITO     = @HIS_TITULAR_DEBITO,
                HIS_TIPO_CONTA_C       = @HIS_TIPO_CONTA_C,
                HIS_CONTA_CREDITO      = @HIS_CONTA_CREDITO,
                HIS_TIPO_TITULAR_C     = @HIS_TIPO_TITULAR_C,
                HIS_TITULAR_CREDITO    = @HIS_TITULAR_CREDITO,
                HIS_CUSTO_TARIFA       = @HIS_CUSTO_TARIFA,
                HIS_EMITE_COMPROVANTE  = @HIS_EMITE_COMPROVANTE,
                HIS_CREDITO            = @HIS_CREDITO,
                HIS_REVERSAO           = @HIS_REVERSAO,
                HIS_DESCRICAO_INGLES   = @HIS_DESCRICAO_INGLES,  
				HIS_DESCRICAO_ESPANHOL = @HIS_DESCRICAO_ESPANHOL  
          WHERE ID_HIS = @HIS_ID
          SET @MSG = 'Hist�rico ' + CAST(@HIS_CODIGO AS VARCHAR(10)) + ' foi atualizado com sucesso!'
      END

      IF @ACAO = 'INCLUIR'
      BEGIN
         IF EXISTS(SELECT 1 FROM TBL_ME_HISTORICO With(NoLock) WHERE HIS_CODIGO = @HIS_CODIGO)
         BEGIN
              SET @MSG = 'Erro: Hist�rico ' + CAST(@HIS_CODIGO AS VARCHAR(10)) + 'j� est� cadastrado!'
         END
         ELSE
         BEGIN
            INSERT INTO TBL_ME_HISTORICO
                     (HIS_CODIGO, HIS_DESCRICAO, HIS_TIPO, HIS_AUTO_MANUAL,
                      HIS_STATUS, HIS_TIPO_OPERACAO, HIS_CONTABILIZA, HIS_CONTABILIZA_COTA, HIS_TARIFA,
                      HIS_TIPO_CONTA_D, HIS_CONTA_DEBITO, HIS_TIPO_TITULAR_D, HIS_TITULAR_DEBITO,
                      HIS_TIPO_CONTA_C, HIS_CONTA_CREDITO, HIS_TIPO_TITULAR_C, HIS_TITULAR_CREDITO, 
                      HIS_CUSTO_TARIFA, HIS_EMITE_COMPROVANTE, HIS_CREDITO, HIS_REVERSAO, HIS_CODIGO_COTA,
                      HIS_DESCRICAO_INGLES, HIS_DESCRICAO_ESPANHOL)  
              VALUES
                     (@HIS_CODIGO, @HIS_DESCRICAO, @HIS_TIPO, @HIS_AUTO_MANUAL,
                      @HIS_STATUS, @HIS_TIPO_OPERACAO, @HIS_CONTABILIZA, @HIS_CONTABILIZA_COTA, @HIS_TARIFA,
                      @HIS_TIPO_CONTA_D, @HIS_CONTA_DEBITO, @HIS_TIPO_TITULAR_D, @HIS_TITULAR_DEBITO,
                      @HIS_TIPO_CONTA_C, @HIS_CONTA_CREDITO, @HIS_TIPO_TITULAR_C, @HIS_TITULAR_CREDITO, 
                      @HIS_CUSTO_TARIFA, @HIS_EMITE_COMPROVANTE, @HIS_CREDITO, @HIS_REVERSAO, @HIS_CODIGO_COTA,
                      @HIS_DESCRICAO_INGLES, @HIS_DESCRICAO_ESPANHOL)  

            SET @MSG = 'Hist�rico ' + CAST(@HIS_CODIGO AS VARCHAR(10)) + ' foi cadastrado com sucesso!'
         END
      END

   SET NOCOUNT OFF

END
;
Go

-- Teste
-- Exec SPBCCME_Admin_Historico @acao='Listar'
-- 
-- Exec SPBCCME_Admin_Historico @acao='EDITAR'
