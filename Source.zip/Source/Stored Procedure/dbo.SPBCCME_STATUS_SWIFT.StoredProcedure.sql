USE IK_VAREJO
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SPBCCME_STATUS_SWIFT]
(
    @ACAO VARCHAR(30),
    @IDSWIFT INT,
    @IDUSUARIO INT = NULL,
    @UR_USERNAME VARCHAR(30) = NULL
)
AS
BEGIN
	DECLARE @MOEDA NCHAR(10)
    DECLARE @VALOR VARCHAR(1000)
	DECLARE @DECIMALVALOR DECIMAL

    IF @ACAO = 'DEVOLVER'
    BEGIN
		SELECT TOP 1 
        @MOEDA = SUBSTRING(M32A_VDateCurrencyInterbank,7,3),
        @VALOR = REPLACE(SUBSTRING(M32A_VDateCurrencyInterbank,10,15),',','.')
        FROM TBL_MEWEB_MT103 WHERE idSwift = @IDSWIFT


        BEGIN TRANSACTION
        BEGIN TRY
    
			SET @DECIMALVALOR =  CONVERT(DECIMAL,dbo.FULL_TRIM(@VALOR))

            UPDATE TBL_MEWEB_MT103
            SET status_lanc = 9
            WHERE idSwift = @IDSWIFT
                
            EXEC SPBCCME_GRAVAR_LOG_CCMESWIFT
            @id_swift = @IDSWIFT,
            @CdMsg =  '2010',
            @DsMsgLog = 'Fundos devolvidos para a origem',
            @id_user = @IDUSUARIO,
            @OrMoeda = @MOEDA,
            @OrValor = @DECIMALVALOR,
            @TpLog = 'A',
            @ID_Lanc = NULL,
            @OP_N_BOLETO = NULL,
            @OP_N_BOLETO_EMPRESA = NULL,
            @OP_N_BOLETO_SISTEMA = NULL,
            @OrigemLog = 'LC',
            @ur_username = @UR_USERNAME

            COMMIT TRANSACTION
        END TRY
        BEGIN CATCH
            ROLLBACK TRANSACTION
        END CATCH
    END
END
