USE IK_VAREJO
GO

IF EXISTS(SELECT NAME FROM SYSOBJECTS WHERE NAME = 'SPBCCME_Update_Usuarios_Sistema')
	DROP PROC DBO.SPBCCME_Update_Usuarios_Sistema
GO

/***
	Nome: SPBCCME_Update_Usuarios_Sistema
	Desc: 
	Autor: 
	Data:  
	***********************
	Hist�rico de Altera��es
	***********************
	PR									Date		Autor				Description
	SPBCCME_Update_Usuarios_Sistema		05/04/2019	Cidicley Rodrigues  Incluir os campos li_Data_Nascimento, li_DDD e li_Celular.
	SPBCCME_Update_Usuarios_Sistema		22/04/2019	Cidicley Rodrigues  Incluir o campo li_DDI.

***/

CREATE PROCEDURE [dbo].[SPBCCME_Update_Usuarios_Sistema]    
(    
  @LI_ID          INT,    
  @LI_STATUS      CHAR(1),    
  @LI_NOME        VARCHAR(300),    
  @LI_EMAIL       VARCHAR(200),    
  @LI_OPERA_VOL   CHAR(1),    
  @LI_VALIDADE    DATETIME,    
  @LI_CORRETORA   CHAR(1),    
  @LI_EDITA_OP    CHAR(1),    
  @LI_CANCELA_OP  CHAR(1),
  @LI_APROVA_OP   CHAR(1),
  @LI_CPF		  VARCHAR(11) = NULL,
  @LI_HABILITA_INTEGRACAO BIT = 0,
  @LI_DATA_NASCIMENTO datetime,
  @LI_DDD		  CHAR(3),
  @LI_CELULAR    CHAR(16),
  @LI_DDI		  CHAR(3)  
 )    
AS    
  
	UPDATE TBL_LOGIN_INTEGRADO    
	   SET LI_STATUS				= @LI_STATUS,    
		   LI_NOME					= @LI_NOME,    
		   LI_EMAIL					= @LI_EMAIL,    
		   LI_OPERA_VOL				= @LI_OPERA_VOL,    
		   LI_VALIDADE				= @LI_VALIDADE,    
		   LI_CORRETORA				= @LI_CORRETORA,    
		   LI_DTALTERACAO			= GETDATE(),    
		   LI_EDITA_OP				= @LI_EDITA_OP,    
		   LI_CANCELA_OP			= @LI_CANCELA_OP,
		   LI_APROVA_OP				= @LI_APROVA_OP,
		   LI_CPF					= @LI_CPF,
		   LI_HABILITA_INTEGRACAO	= @LI_HABILITA_INTEGRACAO,
		   LI_DATA_NASCIMENTO		= @LI_DATA_NASCIMENTO , 
		   LI_DDD					= @LI_DDD, 
		   LI_CELULAR				= @LI_CELULAR,
		   li_DDI					= @LI_DDI 
	 WHERE LI_ID = @LI_ID
