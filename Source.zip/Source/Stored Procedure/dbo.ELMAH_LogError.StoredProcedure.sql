USE [IK_VAREJO]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[ELMAH_LogError]    Script Date: 26/04/2019 09:25:04 ******/
-- =====================================================================================================================================
-- Author:		
-- Create date: 
-- Description:	
-------------------------------------------------------------------------------------------------
-- 683751.694173 - Projeto Migra��o SQL 2016 - Varejo
--					- tipo nText  ==> nVarChar(Max)
-------------------------------------------------------------------------------------------------
-- Hist�rico Altera��es
-- *********************
-- PRG___________________________________ Data_____ Autor________ Descri��o__________________________________________
-- dbo.ELMAH_LogError.StoredProcedure.sql 26/abr/19 C�ssio Drezza 683751.694173 - Projeto Migra��o SQL 2016 - Varejo
-- =====================================================================================================================================
ALTER PROCEDURE [dbo].[ELMAH_LogError]
(
    @ErrorId UNIQUEIDENTIFIER,
    @Application NVARCHAR(60),
    @Host NVARCHAR(30),
    @Type NVARCHAR(100),
    @Source NVARCHAR(60),
    @Message NVARCHAR(500),
    @User NVARCHAR(50),
    @AllXml nVarChar(Max),		-- NTEXT,
    @StatusCode INT,
    @TimeUtc DATETIME
)
AS

    SET NOCOUNT ON

    INSERT
    INTO
        [ELMAH_Error]
        (
            [ErrorId],
            [Application],
            [Host],
            [Type],
            [Source],
            [Message],
            [User],
            [AllXml],
            [StatusCode],
            [TimeUtc]
        )
    VALUES
        (
            @ErrorId,
            @Application,
            @Host,
            @Type,
            @Source,
            @Message,
            @User,
            @AllXml,
            @StatusCode,
            @TimeUtc
        )

;
Go
