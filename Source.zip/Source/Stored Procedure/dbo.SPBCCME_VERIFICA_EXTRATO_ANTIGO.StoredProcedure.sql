USE [IK_VAREJO]
IF OBJECT_ID('dbo.SPBCCME_VERIFICA_EXTRATO_ANTIGO', 'P') IS NOT NULL 
  DROP PROCEDURE dbo.SPBCCME_VERIFICA_EXTRATO_ANTIGO
GO  
CREATE PROCEDURE SPBCCME_VERIFICA_EXTRATO_ANTIGO
AS 
SET NOCOUNT ON    
SELECT	
		id
		,id_Cliente
		,tipoRel
		,dataInical
		,dataFinal
		,codMoeda 
INTO
		#TMP
FROM 
		TBL_LOG_EXTRATO_ANTIGO 
WHERE 
		[Status] = 'P'

UPDATE TBL_LOG_EXTRATO_ANTIGO SET 
Status = 'R',
dataAtualizacao = GETDATE()
WHERE id IN (SELECT DISTINCT IDSOLICITACAO FROM TBL_EXTRATO_TEMP
WHERE DATEDIFF(DD,DATECREATE,GETDATE()) >= 15)

DELETE FROM TBL_EXTRATO_TEMP
WHERE DATEDIFF(DD,DATECREATE,GETDATE()) >= 15 

DECLARE 
		@id INT 
		,@id_Cliente INT 
		,@tipoRel varchar(10)
		,@dataInical datetime
		,@dataFinal datetime
		,@codMoeda VARCHAR(10)

WHILE(SELECT COUNT(*) FROM #TMP) >= 1 BEGIN 
	SELECT 
			@id = id 
			,@id_Cliente = id_Cliente 
			,@tipoRel = tipoRel
			,@dataInical = dataInical
			,@dataFinal = dataFinal
			,@codMoeda = codMoeda 
	FROM 
			#TMP
			
	INSERT INTO TBL_EXTRATO_TEMP
	EXEC [SPBCCME_EXTRATOS_RETROATIVO] @id_Cliente,@codMoeda,@dataInical,@dataFinal,@tipoRel,@id		
	
	DELETE
	FROM	
			#TMP
	WHERE	
			id = @id
	UPDATE TBL_LOG_EXTRATO_ANTIGO SET 
	Status = 'D', 
	dataAtualizacao = GETDATE()+ 15 
	WHERE id = @id
END 
DROP TABLE #TMP




 