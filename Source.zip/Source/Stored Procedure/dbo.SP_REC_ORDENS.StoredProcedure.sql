USE [IK_VAREJO]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
/****** Object:  StoredProcedure [dbo].[SP_REC_ORDENS]    Script Date: 02/07/2019 11:08:47 ******/
/*
Nome:  SP_REC_ORDENS
Desc:  Consultar Ordens(Relat�rios\Acompanhamento de Ordens)
Autor: 
Data:  
-------------------------------------------------------------------------------------------------
-- 683751.1273 - Projeto Migra��o SQL 2016 - Varejo	ATEN��O fonte DIFERENTE no dbVAREJO
--					- (nolock) sem With
-------------------------------------------------------------------------------------------------
Hist�rico de Altera��es
************************
Date        Author                Description
29/Ago/18   Regina Yuriko Utiyama Inclus�o do campo Valor do IOF
02/jul/19   C�ssio Drezza         683751.1273 - Projeto Migra��o SQL 2016 - Varejo
Exemplo:
EXEC SP_REC_ORDENS @DATA_INICIAL = '2017-11-01', @DATA_FINAL = '2017-11-20'
*/
ALTER PROCEDURE [dbo].[SP_REC_ORDENS]
(
    @DATA_INICIAL DATETIME
    , @DATA_FINAL   DATETIME
    , @OP_N_BOLETO  INT          = NULL
    , @OP_N_BOLETOC INT          = NULL
    , @OP_STATUS    INT          = NULL
    , @ID_CORRETORA INT          = NULL
    , @NOME         VARCHAR(200) = NULL
)
AS
BEGIN
    SET NOCOUNT ON
    
    DECLARE 
        @BoletoBanco INT = NULL
        , @BoletoPai INT = NULL
        , @BoletoFilho INT = NULL
        , @BoletoWU INT = NULL

    IF @NOME IS NULL
        SET @NOME = ''
    
    IF @OP_N_BOLETO = ''
        SET @OP_N_BOLETO = NULL
    
    IF @OP_N_BOLETOC = ''
        SET @OP_N_BOLETOC = NULL

    IF @OP_N_BOLETO IS NOT NULL AND @OP_N_BOLETOC IS NOT NULL
    BEGIN
        SELECT @BoletoBanco = CASE WHEN Princ.ID_Rec_BoletoPai IS NULL THEN Princ.OP_N_Boleto ELSE Princ.ID_Rec_BoletoPai END
        FROM TBL_Pre_Boleto Princ With(NoLock)
        LEFT JOIN TBL_Rec_Ordens_WU PrincWU With(NoLock) ON PrincWU.OP_N_Boleto = Princ.OP_N_Boleto
        LEFT JOIN TBL_Pre_Boleto Sec With(NoLock) ON Sec.ID_Rec_BoletoPai = PrincWU.OP_N_Boleto
        LEFT JOIN TBL_Rec_Ordens_WU SecWU With(NoLock) ON SecWU.OP_N_Boleto = Sec.OP_N_Boleto
        WHERE Princ.OP_N_Boleto = @OP_N_BOLETO
        
        IF @BoletoBanco IS NOT NULL -- Achou boleto... ELSE o boleto n�o existe!
        BEGIN
            SELECT @BoletoFilho = OP_N_Boleto
            FROM TBL_Pre_Boleto With(NoLock)
            WHERE ID_Rec_BoletoPai = @BoletoBanco
            
            SELECT @BoletoWU = OP_N_Ordem
            FROM TBL_Rec_Ordens_WU With(NoLock)
            WHERE OP_N_Boleto = @BoletoBanco
                AND OP_N_Ordem = @OP_N_BOLETOC
            
            IF @BoletoWU IS NULL
            BEGIN
                SELECT @BoletoWU = 0
            END
        END
        ELSE
        BEGIN
            -- N�o achou boleto... joga zero pro SELECT se virar...
            SELECT @BoletoBanco = 0
            SELECT @BoletoWU    = 0
        END
    END
    ELSE IF @OP_N_BOLETO IS NOT NULL
    BEGIN
        SELECT @BoletoBanco = CASE WHEN Princ.ID_Rec_BoletoPai IS NULL THEN Princ.OP_N_Boleto ELSE Princ.ID_Rec_BoletoPai END
        FROM TBL_Pre_Boleto Princ With(NoLock)
        LEFT JOIN TBL_Rec_Ordens_WU PrincWU With(NoLock) ON PrincWU.OP_N_Boleto = Princ.OP_N_Boleto
        LEFT JOIN TBL_Pre_Boleto Sec With(NoLock) ON Sec.ID_Rec_BoletoPai = PrincWU.OP_N_Boleto
        LEFT JOIN TBL_Rec_Ordens_WU SecWU With(NoLock) ON SecWU.OP_N_Boleto = Sec.OP_N_Boleto
        WHERE Princ.OP_N_Boleto = @OP_N_BOLETO
        
        IF @BoletoBanco IS NOT NULL
        BEGIN
            SELECT @BoletoFilho = OP_N_Boleto
            FROM TBL_Pre_Boleto With(NoLock)
            WHERE ID_Rec_BoletoPai = @BoletoBanco
        END
        ELSE
        BEGIN
            SELECT @BoletoBanco = 0
        END
    END
    ELSE IF @OP_N_BOLETOC IS NOT NULL
    BEGIN
        SELECT @BoletoWU = OP_N_Ordem--, @BoletoBanco = OP_N_Boleto
        FROM TBL_Rec_Ordens_WU With(NoLock)
        WHERE OP_N_Ordem = @OP_N_BOLETOC
        
        IF @BoletoWU IS NULL
        BEGIN
            SELECT @BoletoWU = 0
        END
    END
    
    SELECT 
        ID_OPERACAO        = PB.ID_OPERACAO
        , ORDEM            = ISNULL(WU.OP_N_ORDEM, ' ')
        , BOLETO        = PB.OP_N_BOLETO
        , BOLETO_TARIFA    = (SELECT ISNULL(OP_N_Boleto, '') FROM TBL_Pre_Boleto With(NoLock) WHERE ID_REC_BOLETOPAI = PB.OP_N_BOLETO)
        , REMETENTE        = CL.CL_NOME
        , BENEFICIARIO    =    CASE
                                WHEN nat.nat_RelAcompaBeneficiario_PPV = 1 THEN
                                    CASE
                                        WHEN ISNULL(LTRIM(RTRIM(WU.MERCHANTS_SUPP)), '') = '' THEN 'Pendente de Benefici�rio'
                                        ELSE LTRIM(RTRIM(WU.MERCHANTS_SUPP))
                                    END
                                ELSE ISNULL(CL.cl_nome, CL.cl_razao_social)
                            END
        , MOEDA            = pb.op_tipo_moeda
        , DATA            = PB.OP_DATA_BOLETO
        , OP_VAL_REAIS    = PB.OP_VAL_REAIS
        , OP_VAL_MOEDA    = PB.OP_VAL_MOEDA
        , ID_STATUS        = ST.ID_STATUS
        , SITUACAO_PT    = ST.DESCRICAO_PT
        , SITUACAO_EN    = ST.DESCRICAO_EN
        , OP_VAL_IOF    = ISNULL(PB.VLR_IOF, 0) 
        , OP_VAL_MOEDA_TARIFA = COALESCE(PBT.OP_VAL_MOEDA, PB.OP_TARIFA_BANCO_D, 0)
        , OP_VAL_REAIS_TARIFA = COALESCE(PBT.OP_VAL_REAIS, PB.OP_TARIFA_OPERACAO, 0)
        , TOTAL_MN        = ((ISNULL(PB.OP_VAL_REAIS, 0)  + ISNULL(PB.OP_TARIFA_OPERACAO, 0)  + ISNULL(PB.VLR_IOF, 0))
                            + (ISNULL(PBT.OP_VAL_REAIS, 0) + ISNULL(PBT.OP_TARIFA_OPERACAO, 0) + ISNULL(PBT.VLR_IOF, 0)))
        , TOTAL_ME        = ((ISNULL(PB.OP_VAL_MOEDA, 0)  + ISNULL(PB.OP_TARIFA_BANCO_D, 0))
                            + (ISNULL(PBT.OP_VAL_MOEDA, 0) + ISNULL(PBT.OP_TARIFA_BANCO_D, 0)))
        , OP_NATUREZA   = isnull(nat.nat_descricao,'')
    FROM TBL_PRE_BOLETO PB With(NoLock)
    INNER JOIN TBL_REC_ORDENS_WU WU With(NoLock)
        ON WU.OP_N_BOLETO = PB.OP_N_BOLETO
    INNER JOIN TBL_CLIENTES CL With(NoLock)
        ON CL.ID_CLIENTE = PB.ID_CLIENTE
    INNER JOIN TBL_REC_STATUS ST With(NoLock)
        ON ST.ID_STATUS = WU.OP_STATUS
    LEFT JOIN TBL_PRE_BOLETO PBT With(NoLock) 
        ON PBT.ID_REC_BOLETOPAI = PB.OP_N_BOLETO
    LEFT JOIN TBL_RE_BENEFICIARIO BN With(NoLock)
        ON BN.ID_RE_BENEFICIARIO = PB.ID_BENEFICIARIO
    LEFT JOIN TBL_NATUREZA nat With(NoLock)
        ON nat.id_natureza = PB.op_natureza
    WHERE PB.OP_TIPO_ENTREGA  in ('TELE','REMXPRE')
        AND PB.OP_DATA_BOLETO >= @DATA_INICIAL
        AND PB.OP_DATA_BOLETO <= DATEADD(D, 1, CONVERT(DATETIME, @DATA_FINAL))
        AND WU.OP_N_ORDEM = COALESCE(@OP_N_BOLETOC, WU.OP_N_ORDEM)
        AND PB.OP_N_BOLETO = COALESCE(@BoletoBanco, PB.OP_N_BOLETO)
        AND ((@OP_STATUS = 14 -- Retorna as ordens com valor a devolver [387202]
                AND PB.pre_boleto_status = 3
                AND (PB.aprovacao_contrapartida = 'S'
                    OR EXISTS(SELECT '0' FROM TBL_REC_HISTORICO_ORDEM With(NoLock) 
                                WHERE ID_ORDEM = WU.OP_N_ORDEM AND ID_STATUS = 10)
                )
            ) OR (
                WU.OP_STATUS = ISNULL(@OP_STATUS, WU.OP_STATUS)
            )
        )
        AND PB.ID_CORRETORA = ISNULL(@ID_CORRETORA, PB.ID_CORRETORA)
        AND (CL.CL_NOME LIKE (@NOME + '%') OR BN.NOME + ' ' + BN.NOMEDOMEIO + ' ' + BN.SOBRENOME LIKE (@NOME + '%'))
    ORDER BY PB.OP_N_BOLETO
    
    SET NOCOUNT OFF
END
;
Go

-- Teste
-- EXEC SP_REC_ORDENS @DATA_INICIAL = '2017-11-01', @DATA_FINAL = '2017-11-20'

