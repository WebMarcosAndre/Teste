USE IK_Varejo

GO
/***
	Nome: SPBCCME_MEWEB_MT103_LANCAMENTO
	Desc: 
	Autor: 
	Data:  
	***********************
	Hist�rico de Altera��es
	***********************
	PR								Date		Autor				Description
	SPBCCME_MEWEB_MT103_LANCAMENTO	10/01/2019	Cidicley Rodrigues  Na a��o GERAR_LANCAMENTOS, incluido o campo CL_STATUS
									28/06/2019	Marcos Costa		Alterado condi��o na a��o "FILTRAR" para a virada de chave GOOGLE
									22/07/2019	Marcos Costa		Alterado retorno da flag geral pq o robo est� esperando o valor de '1' para ativo
									23/07/2019	Jose Paiva			Incluido na ACAO = 'FILTRAR" o filtro de status_lanc = 9-Devolvido
																	Incluida ACAO = 'FILTRAR REJEITADAS' para status_lanc = 8-Rejeitado
																	Incluido na ACAO = 'GERAR_LANCAMENTOS' o filtro de status_lanc = 8-Rejeitado e status_lanc = 9-Devolvido
																	Incluido na ACAO = 'GERAR_PRE_BOLETO' o filtro de status_lanc = 8-Rejeitado e status_lanc = 9-Devolvido
***/
  


ALTER PROCEDURE [dbo].[SPBCCME_MEWEB_MT103_LANCAMENTO]    
(                                                        
 @ACAO VARCHAR(30),                                                        
 @DATAINICIAL DATETIME = NULL,                                                        
 @DATAFINAL DATETIME = NULL,                                                        
 @EMPRESA VARCHAR(100) = NULL,                                                        
 @PERIODO VARCHAR(30) = NULL ,                                                    
 @CLIENTE VARCHAR(300) = NULL,                                                  
 @BENEFICIARIO VARCHAR(300) = NULL,                                                  
 @ORDENANTE VARCHAR(300) = NULL,                                                     
 @IDCLIENTE INT = NULL,                                                    
 @IDUSUARIO INT = NULL,                                                    
 @IDASSOCIACAO INT = NULL,                                                    
 @IDSWIFT INT = NULL,                                                    
 @TIPOLANCAMENTO NCHAR(30) = NULL,                                                    
 @PROCESSADO INT = NULL, -- Valor Null ou 1                                                    
 @EMPROCESSAMENTO INT = NULL,-- Valor Null ou 0                                                    
 @ERRO INT = NULL, -- Valor Null ou 2,                                         
 @RECUSADO INT = NULL, -- Valor Null ou 3                                        
 @APROVADO INT = NULL, -- Valor Null ou 4                                              
 @NAOPROCESSADO INT = NULL, -- Valor Null ou 5,                    
 @BAIXADOS INT = NULL, -- Valor Null ou 7                                 
 @REJEITADOS INT = NULL, -- Valor Null ou 8
 @DEVOLVIDOS INT = NULL, -- Valor Null ou 9
 @LANCADOCHANGE VARCHAR(30) = NULL,   
 @UR_USERNAME VARCHAR(30) = NULL,   
 @FLAG_GOOGLE BIT = NULL, 
 @MENSAGEMLOGLANCAMENTO VARCHAR(500) = NULL,                                                  
 @IDASSOCIACAORETORNO INT = NULL OUTPUT                                
)                                                        
AS         

DECLARE @1IDCLIENTE_NAO_IDENTIFICADO INT = (SELECT TOP 1 ID_CLIENTE FROM TBL_ROBOCCMESWIFT With(NOLOCK) WHERE NomRobo = 'ROBO_CCME_SWIFT')                                                       
     
 DECLARE     
@1ACAO VARCHAR(30),                                                        
 @1DATAINICIAL DATETIME,                                                        
 @1DATAFINAL DATETIME ,                                                        
 @1EMPRESA VARCHAR(100) ,                                                        
 @1PERIODO VARCHAR(30) ,                                                    
 @1CLIENTE VARCHAR(300),                                                  
 @1BENEFICIARIO VARCHAR(300) ,                                                  
 @1ORDENANTE VARCHAR(300) ,                                                     
 @1IDCLIENTE INT ,                                                    
 @1IDUSUARIO INT ,                                                    
 @1IDASSOCIACAO INT ,                                                    
 @1IDSWIFT INT,                                                    
 @1TIPOLANCAMENTO NCHAR(30) ,                                                    
 @1PROCESSADO INT, -- Valor Null ou 1                                                    
 @1EMPROCESSAMENTO INT ,-- Valor Null ou 0                                                    
 @1ERRO INT , -- Valor Null ou 2,                                         
 @1RECUSADO INT , -- Valor Null ou 3                               
 @1APROVADO INT , -- Valor Null ou 4                                              
 @1NAOPROCESSADO INT , -- Valor Null ou 5,                    
 @1BAIXADOS INT , -- Valor Null ou 7         
 @1REJEITADOS INT , -- Valor Null ou 8
 @1DEVOLVIDOS INT , -- Valor Null ou 9                        
 @1LANCADOCHANGE VARCHAR(30) ,   
 @1UR_USERNAME VARCHAR(30) ,   
 @1MENSAGEMLOGLANCAMENTO VARCHAR(500) ,                                                  
 @1IDASSOCIACAORETORNO INT      
        
 SELECT   
 @1ACAO =@ACAO,                                                        
 @1DATAINICIAL =@DATAINICIAL,                                                        
 @1DATAFINAL= @DATAFINAL,                                                        
 @1EMPRESA=@EMPRESA,                                                        
 @1PERIODO =@PERIODO,                                                    
 @1CLIENTE =@CLIENTE,                                                  
 @1BENEFICIARIO =@BENEFICIARIO,                                                  
 @1ORDENANTE =@ORDENANTE,                                                     
 @1IDCLIENTE =@IDCLIENTE,                                                    
 @1IDUSUARIO =@IDUSUARIO,                                                    
 @1IDASSOCIACAO =@IDASSOCIACAO,                                                    
 @1IDSWIFT =@IDSWIFT,                                                    
 @1TIPOLANCAMENTO = @TIPOLANCAMENTO,                                                    
 @1PROCESSADO = @PROCESSADO, -- Valor Null ou 1                                                    
 @1EMPROCESSAMENTO = @EMPROCESSAMENTO,-- Valor Null ou 0                                                    
 @1ERRO = @ERRO, -- Valor Null ou 2,                                         
 @1RECUSADO = @RECUSADO, -- Valor Null ou 3                                        
 @1APROVADO = @APROVADO, -- Valor Null ou 4                                              
 @1NAOPROCESSADO = @NAOPROCESSADO, -- Valor Null ou 5,                    
 @1BAIXADOS = @BAIXADOS, -- Valor Null ou 7                                 
 @1REJEITADOS = @REJEITADOS, -- Valor Null ou 8                                 
 @1DEVOLVIDOS = @DEVOLVIDOS, -- Valor Null ou 9                                 
 @1LANCADOCHANGE = @LANCADOCHANGE,   
 @1UR_USERNAME = @UR_USERNAME,   
 @1MENSAGEMLOGLANCAMENTO = @MENSAGEMLOGLANCAMENTO,                                                  
 @1IDASSOCIACAORETORNO = @IDASSOCIACAORETORNO           
        
DECLARE @FLAG_HABILITA_TELAS_CCME CHAR(1) = NULL

SELECT TOP 1 @FLAG_HABILITA_TELAS_CCME = FLAG_HABILITA_TELAS_CCME FROM TBL_ROBOCCMESWIFT with(nolock) WHERE NomRobo = 'ROBO_CCME_SWIFT'
      
IF @1ACAO = 'FILTRAR'                                                        
BEGIN          

  
	SELECT         
			IDSWIFT ,        
			M59_BENEFICIARYCUSTOMER ,        
			M50K_ORDERINGCUSTOMER ,        
			O50F_ADDITIONALINFORMATION ,        
			M50A_ORDERINGCUSTOMER ,        
			M.ID_CLIENTE,        
			M20_SENDERREF ,        
			M32A_VDATECURRENCYINTERBANK,        
			DATALOTE   ,         
			DATA_LANCAMENTO_ROBO ,        
			STATUS_LANC,        
			DATA_LANCAMENTO ,         
			L.Empresa,         
			DATA_REGISTRO ,       
			ID_LANC,        
			LC_AUTOMATICO,       
			OP_N_BOLETO,        
			STATUS_PREBOLETO,        
			SC.id_sub_conta  AS ID_SUBCONTA  ,  
			m.beneficiario,  
			m.ordenante,  
			NULL AS id_associado,
			FlagGoogle  
			INTO #TBL_TEMP        
	FROM	[IK_VAREJO].[DBO].[TBL_MEWEB_MT103] AS M WITH(NOLOCK)         
		JOIN		[IK_VAREJO].[DBO].[TBL_MEWEB_MT103_LOTE] AS L WITH(NOLOCK) ON M.ID_LOTE = L.LOTE         
		LEFT JOIN	TBL_ME_SUBCONTA SC  WITH(NOLOCK) 
				ON M.ID_CLIENTE = SC.ID_CLIENTE 
						AND SC.SUB_STATUS <> 'I' 
						AND SC.cod_moeda = 
						(
							CASE SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)        
								WHEN 'EUR' THEN 'EURO'             
								WHEN 'GBP' THEN 'STG'     
								WHEN 'AUD' THEN 'ATD'     
								WHEN 'CAD' THEN 'CAN'            
								WHEN 'JPY' THEN 'YEN'      
								ELSE SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)         
								END
						)        
	                            
	WHERE
	(
		FLAGGOOGLE = 0  OR (
								FLAGGOOGLE = 1 
								AND @FLAG_HABILITA_TELAS_CCME = 'S'
								-- VIRADA CHAVE GERAL MARC�O
								AND m.id_cliente IS NOT NULL
								AND m.OP_N_BOLETO IS NULL
							)
	)               
 AND(                                            
(@1PROCESSADO IS NULL AND @1EMPROCESSAMENTO IS NULL AND @1ERRO IS NULL AND @1NAOPROCESSADO IS NULL AND @1RECUSADO IS NULL AND @1APROVADO IS NULL AND @1BAIXADOS IS NULL AND @1DEVOLVIDOS IS NULL) OR                                            
  @1PROCESSADO = STATUS_LANC OR                        
@1EMPROCESSAMENTO = STATUS_LANC OR                                             
  @1ERRO = STATUS_LANC OR                                          
  @1APROVADO = STATUS_LANC OR                                        
  @1RECUSADO = STATUS_LANC OR                         
  @1BAIXADOS = STATUS_LANC OR       
  @1DEVOLVIDOS = STATUS_LANC OR                   
 (@1NAOPROCESSADO = 5 AND STATUS_LANC IS NULL))          
  AND (LEN(@1EMPRESA) = 0 OR ISNULL(@1EMPRESA,'TODAS') = 'TODAS' OR L.Empresa = @1EMPRESA)                                                    
  AND (ISNULL(@1TIPOLANCAMENTO,'TODOS') = 'TODOS' OR (@1TIPOLANCAMENTO = TIPO_LANC OR TIPO_LANC = 'AMBOS'))         
  AND (                                     
    (@1PERIODO = 'DATACREDITO' AND CONVERT(DATE,SUBSTRING(M32A_VDATECURRENCYINTERBANK,1,6),101) BETWEEN CONVERT(DATE,@1DATAINICIAL,101) AND CONVERT(DATE,@1DATAFINAL,101)) OR                                            
    (@1PERIODO = 'DATAREGISTRO' AND CONVERT(DATE,DATA_REGISTRO,101) BETWEEN CONVERT(DATE,@1DATAINICIAL,101) AND CONVERT(DATE,@1DATAFINAL,101)) OR                                     
    (@1PERIODO = 'DATALANCAMENTO' AND CONVERT(DATE,DATA_LANCAMENTO,101) BETWEEN CONVERT(DATE,@1DATAINICIAL,101) AND CONVERT(DATE,@1DATAFINAL,101))                                                        
  )           
        
        
    update   M  
   set       id_associado = a.id  
   from             #TBL_TEMP m  
   join             [TBL_MEWEB_ASSOCIA_CLIENTES] AS A WITH(NOLOCK)  
   on  m.Beneficiario = [DBO].[FULL_TRIM](A.BENEFICIARIO_SWIFT)   
    AND        m.ordenante = [DBO].[FULL_TRIM](A.ORDENANTE_SWIFT)       
          
IF @1PERIODO <> 'DATAASSOCIACAO'        
  BEGIN         
  SELECT DISTINCT                             
  (CASE WHEN A.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END) AS CLIENTE_ASSOCIADO,                                                  
  A.ID_CLIENTE AS ID_CLIENTE_ASSOCIADO,                                                      
  (CASE WHEN S.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END ) AS CLIENTE_SUGESTAO,                                                   
  S.ID_CLIENTE AS ID_CLIENTE_SUGESTAO,                                      
  ltrim(rtrim((CASE WHEN M.ID_CLIENTE IS NOT NULL THEN  ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END))) AS CLIENTE_LANCAMENTO,                                                
  M.ID_CLIENTE AS ID_CLIENTE_LANCAMENTO,                                                   
  A.ID, A.DATAASSOCIA,CONVERT(DATE,SUBSTRING(M32A_VDATECURRENCYINTERBANK,1,6),101) AS DATACREDITO,                                                   
  M.DATA_LANCAMENTO_ROBO,M.STATUS_LANC,M.ID_CLIENTE, M.DATA_LANCAMENTO, M.EMPRESA, M.DATA_REGISTRO,M.IDSWIFT,M.LC_AUTOMATICO,                                                    
  m.BENEFICIARIO AS BENEFICIARIO,                                                       
  m.ordenante as ORDENANTE,      
  (SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,10,15) +' / '+SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)) AS VALOR_MOEDA,   
  ([IK_VAREJO].[dbo].[CALCULA_MOEDA](SUBSTRING(M32A_VDateCurrencyInterbank,7,3),LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(SUBSTRING(M32A_VDateCurrencyInterbank,10,15),CHAR(13),''),CHAR(10),''),',','.'))))) AS VALOR_USD,                                         

 


 
   
  
  
          
  CA.NUMERO AS NUMERO,LO.DATAMSG, LO.CDMSG, M.DATALOTE,M.OP_N_BOLETO,M.STATUS_PREBOLETO,M.ID_SUBCONTA,C.PreBoletoCompraAutomatico, M.ID_LANC,        
  (CASE         
   WHEN M.ID_SUBCONTA IS NOT NULL THEN 2        
   WHEN M.ID_CLIENTE = @1IDCLIENTE_NAO_IDENTIFICADO THEN 1        
 ELSE 0        
  END) AS CONTA_CLIENTE,
  M.FlagGoogle 
FROM             #TBL_TEMP M          
 LEFT JOIN [IK_VAREJO].[DBO].[TBL_MEWEB_ASSOCIA_CLIENTES] AS A WITH(NOLOCK) ON (                   
 m.id_associado = a.id)      
  LEFT JOIN [DBO].[TBL_MEWEB_MT103_SUGEST] AS S WITH(NOLOCK) ON M.IDSWIFT = S.IDSWIFT        
  LEFT JOIN TBL_CLIENTES AS C WITH(NOLOCK) ON C.ID_CLIENTE =  (CASE                       
                  WHEN M.ID_CLIENTE IS NOT NULL THEN M.ID_CLIENTE                      
  WHEN A.ID_CLIENTE IS NOT NULL THEN A.ID_CLIENTE        
                  WHEN S.ID_CLIENTE IS NOT NULL THEN S.ID_CLIENTE                      
ELSE NULL                      
           END)                          
  LEFT JOIN(SELECT IDSWIFT, MAX(NUMERO) AS NUMERO FROM TBL_MEWEB_MT103_CHANGE WITH(NOLOCK) GROUP BY IDSWIFT) AS CA ON M.IDSWIFT = CA.IDSWIFT        
  LEFT JOIN( SELECT B.ID_SWIFT, B.CDMSG, C.DATAMSG               
  FROM TBL_ME_LOG_LANC_CCMESWIFT  B WITH(NOLOCK) INNER JOIN               
  (SELECT ID_SWIFT, MAX(DATAMSG) AS DATAMSG              
  FROM TBL_ME_LOG_LANC_CCMESWIFT  WITH(NOLOCK)               
  WHERE CDMSG IN ('2000','2001')              
  GROUP BY ID_SWIFT) AS C         
  ON B.ID_SWIFT = C.ID_SWIFT  AND B.DATAMSG = C.DATAMSG) AS LO ON M.IDSWIFT = LO.ID_SWIFT          
  WHERE         
  (         
   (@1CLIENTE IS NULL OR LEN(@1CLIENTE) = 0) OR                                                      
   [DBO].[MT103_FORMATA_ORDENANTE] (M.M50K_ORDERINGCUSTOMER,M.O50F_ADDITIONALINFORMATION,M.M50A_ORDERINGCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR                                                    
   [DBO].[MT103_FORMATA_BENEFICIARIO] (M59_BENEFICIARYCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR         
   ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) LIKE '%' + @1CLIENTE +'%' OR        
   CONVERT(VARCHAR,M.OP_N_BOLETO) LIKE @1CLIENTE +'%'        
  )        
  AND (@1LANCADOCHANGE = 'TODOS' OR (ISNULL(@1LANCADOCHANGE,'SIM') = 'SIM' AND CA.NUMERO IS NOT NULL) OR (@1LANCADOCHANGE = 'NAO' AND CA.NUMERO IS NULL))         
        
 END        
         
 ELSE        
 BEGIN        
   SELECT DISTINCT                             
   (CASE WHEN A.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END) AS CLIENTE_ASSOCIADO,                                                  
   A.ID_CLIENTE AS ID_CLIENTE_ASSOCIADO,                                                      
   (CASE WHEN S.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END ) AS CLIENTE_SUGESTAO,                                                   
   S.ID_CLIENTE AS ID_CLIENTE_SUGESTAO,                                      
   LTRIM(RTRIM((CASE WHEN M.ID_CLIENTE IS NOT NULL THEN  ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END))) AS CLIENTE_LANCAMENTO,                                                
   M.ID_CLIENTE AS ID_CLIENTE_LANCAMENTO,                                                   
   A.ID, A.DATAASSOCIA,CONVERT(DATE,SUBSTRING(M32A_VDATECURRENCYINTERBANK,1,6),101) AS DATACREDITO,                                                   
   M.DATA_LANCAMENTO_ROBO,M.STATUS_LANC,M.ID_CLIENTE, M.DATA_LANCAMENTO, M.EMPRESA, M.DATA_REGISTRO,M.IDSWIFT,M.LC_AUTOMATICO,        
    m.BENEFICIARIO AS BENEFICIARIO,                                                        
  m.ordenante as ORDENANTE,      
   (SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,10,15) +' / '+SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)) AS VALOR_MOEDA,  
   ([IK_VAREJO].[dbo].[CALCULA_MOEDA](SUBSTRING(M32A_VDateCurrencyInterbank,7,3),LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(SUBSTRING(M32A_VDateCurrencyInterbank,10,15),CHAR(13),''),CHAR(10),''),',','.'))))) AS VALOR_USD,                  
   CA.NUMERO AS NUMERO,LO.DATAMSG, LO.CDMSG, M.DATALOTE,M.OP_N_BOLETO,M.STATUS_PREBOLETO,M.ID_SUBCONTA,C.PreBoletoCompraAutomatico, M.ID_LANC,     
   (CASE         
WHEN M.ID_SUBCONTA IS NOT NULL THEN 2        
    WHEN M.ID_CLIENTE = @1IDCLIENTE_NAO_IDENTIFICADO THEN 1        
    ELSE 0        
   END) AS CONTA_CLIENTE,
   M.FlagGoogle          
   FROM  #TBL_TEMP  M      
 LEFT JOIN [IK_VAREJO].[DBO].[TBL_MEWEB_ASSOCIA_CLIENTES] AS A WITH(NOLOCK) ON (                   
 m.id_associado = a.id)      
   LEFT JOIN [DBO].[TBL_MEWEB_MT103_SUGEST] AS S WITH(NOLOCK) ON M.IDSWIFT = S.IDSWIFT                                                    
   LEFT JOIN TBL_CLIENTES AS C WITH(NOLOCK) ON C.ID_CLIENTE =  (CASE               
                   WHEN M.ID_CLIENTE IS NOT NULL THEN M.ID_CLIENTE                      
                   WHEN A.ID_CLIENTE IS NOT NULL THEN A.ID_CLIENTE                      
  WHEN S.ID_CLIENTE IS NOT NULL THEN S.ID_CLIENTE                      
          ELSE NULL                      
                   END)                          
   LEFT JOIN(SELECT IDSWIFT, MAX(NUMERO) AS NUMERO FROM TBL_MEWEB_MT103_CHANGE WITH(NOLOCK) GROUP BY IDSWIFT) AS CA ON M.IDSWIFT = CA.IDSWIFT             
   LEFT JOIN( SELECT B.ID_SWIFT, B.CDMSG, C.DATAMSG               
   FROM TBL_ME_LOG_LANC_CCMESWIFT  B WITH(NOLOCK) INNER JOIN               
   (SELECT ID_SWIFT, MAX(DATAMSG) AS DATAMSG              
   FROM TBL_ME_LOG_LANC_CCMESWIFT  WITH(NOLOCK)               
   WHERE CDMSG IN ('2000','2001')              
   GROUP BY ID_SWIFT) AS C              
   ON B.ID_SWIFT = C.ID_SWIFT              
   AND B.DATAMSG = C.DATAMSG) AS LO ON M.IDSWIFT = LO.ID_SWIFT         
  WHERE        
  (         
   (@1CLIENTE IS NULL OR LEN(@1CLIENTE) = 0) OR                                                      
   [DBO].[MT103_FORMATA_ORDENANTE] (M.M50K_ORDERINGCUSTOMER,M.O50F_ADDITIONALINFORMATION,M.M50A_ORDERINGCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR                                                    
   [DBO].[MT103_FORMATA_BENEFICIARIO] (M59_BENEFICIARYCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR         
   ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) LIKE '%' + @1CLIENTE +'%' OR        
   CONVERT(VARCHAR,M.OP_N_BOLETO) LIKE @1CLIENTE +'%'        
  )                                                                              
   AND (@1LANCADOCHANGE = 'TODOS' OR (ISNULL(@1LANCADOCHANGE,'SIM') = 'SIM' AND CA.NUMERO IS NOT NULL) OR (@1LANCADOCHANGE = 'NAO' AND CA.NUMERO IS NULL))          
   AND CONVERT(DATE,DATAASSOCIA,101) BETWEEN CONVERT(DATE,@1DATAINICIAL,101) AND CONVERT(DATE,@1DATAFINAL,101)          
                
 END       
       
  DROP TABLE #TBL_TEMP                                
END          

IF @1ACAO = 'FILTRAR REJEITADAS'                                                        
BEGIN          

  
	SELECT         
			IDSWIFT ,        
			M59_BENEFICIARYCUSTOMER ,        
			M50K_ORDERINGCUSTOMER ,        
			O50F_ADDITIONALINFORMATION ,        
			M50A_ORDERINGCUSTOMER ,        
			M.ID_CLIENTE,        
			M20_SENDERREF ,        
			M32A_VDATECURRENCYINTERBANK,        
			null DATALOTE   ,         
			DATA_LANCAMENTO_ROBO ,        
			STATUS_LANC,        
			DATA_LANCAMENTO ,         
			null Empresa,         
			DATA_REGISTRO ,       
			ID_LANC,        
			LC_AUTOMATICO,       
			OP_N_BOLETO,        
			STATUS_PREBOLETO,        
			SC.id_sub_conta  AS ID_SUBCONTA  ,  
			m.beneficiario,  
			m.ordenante,  
			NULL AS id_associado,
			FlagGoogle  
			INTO #TBL_TEMPREJ        
	FROM	[IK_VAREJO].[DBO].[TBL_MEWEB_MT103] AS M WITH(NOLOCK)         
		LEFT JOIN	TBL_ME_SUBCONTA SC  WITH(NOLOCK) 
				ON M.ID_CLIENTE = SC.ID_CLIENTE 
						AND SC.SUB_STATUS <> 'I' 
						AND SC.cod_moeda = 
						(
							CASE SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)        
								WHEN 'EUR' THEN 'EURO'             
								WHEN 'GBP' THEN 'STG'     
								WHEN 'AUD' THEN 'ATD'     
								WHEN 'CAD' THEN 'CAN'            
								WHEN 'JPY' THEN 'YEN'      
								ELSE SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)         
								END
						)        
	                            
	WHERE
(                                            
(@1PROCESSADO IS NULL AND @1EMPROCESSAMENTO IS NULL AND @1ERRO IS NULL AND @1NAOPROCESSADO IS NULL AND @1RECUSADO IS NULL AND @1APROVADO IS NULL AND @1BAIXADOS IS NULL AND @1REJEITADOS IS NULL AND @1DEVOLVIDOS IS NULL) OR                                            
  @1PROCESSADO = STATUS_LANC OR                        
@1EMPROCESSAMENTO = STATUS_LANC OR                                             
  @1ERRO = STATUS_LANC OR                                          
  @1APROVADO = STATUS_LANC OR                                        
  @1RECUSADO = STATUS_LANC OR                         
  @1BAIXADOS = STATUS_LANC OR       
  @1REJEITADOS = STATUS_LANC OR       
  @1DEVOLVIDOS = STATUS_LANC OR            
 (@1NAOPROCESSADO = 5 AND STATUS_LANC IS NULL))          
  AND (                                     
    (@1PERIODO = 'DATAREGISTRO' AND CONVERT(DATE,DATA_REGISTRO,101) BETWEEN CONVERT(DATE,@1DATAINICIAL,101) AND CONVERT(DATE,@1DATAFINAL,101))
  )           
  AND M.id_Lote is null      
        
    update   M  
   set       id_associado = a.id  
   from             #TBL_TEMPREJ m  
   join             [TBL_MEWEB_ASSOCIA_CLIENTES] AS A WITH(NOLOCK)  
   on  m.Beneficiario = [DBO].[FULL_TRIM](A.BENEFICIARIO_SWIFT)   
    AND        m.ordenante = [DBO].[FULL_TRIM](A.ORDENANTE_SWIFT)       
          
  SELECT DISTINCT                             
  (CASE WHEN A.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END) AS CLIENTE_ASSOCIADO,                                                  
  A.ID_CLIENTE AS ID_CLIENTE_ASSOCIADO,                                                      
  (CASE WHEN S.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END ) AS CLIENTE_SUGESTAO,                                                   
  S.ID_CLIENTE AS ID_CLIENTE_SUGESTAO,                                      
  ltrim(rtrim((CASE WHEN M.ID_CLIENTE IS NOT NULL THEN  ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END))) AS CLIENTE_LANCAMENTO,                                                
  M.ID_CLIENTE AS ID_CLIENTE_LANCAMENTO,                                                   
  A.ID, A.DATAASSOCIA,CONVERT(DATE,SUBSTRING(M32A_VDATECURRENCYINTERBANK,1,6),101) AS DATACREDITO,                                                   
  M.DATA_LANCAMENTO_ROBO,M.STATUS_LANC,M.ID_CLIENTE, M.DATA_LANCAMENTO, M.EMPRESA, M.DATA_REGISTRO,M.IDSWIFT,M.LC_AUTOMATICO,                                                    
  m.BENEFICIARIO AS BENEFICIARIO,                                                       
  m.ordenante as ORDENANTE,      
  (SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,10,15) +' / '+SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)) AS VALOR_MOEDA,   
  ([IK_VAREJO].[dbo].[CALCULA_MOEDA](SUBSTRING(M32A_VDateCurrencyInterbank,7,3),LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(SUBSTRING(M32A_VDateCurrencyInterbank,10,15),CHAR(13),''),CHAR(10),''),',','.'))))) AS VALOR_USD,                                         

 


 
   
  
  
          
  CA.NUMERO AS NUMERO,LO.DATAMSG, LO.CDMSG, M.DATALOTE,M.OP_N_BOLETO,M.STATUS_PREBOLETO,M.ID_SUBCONTA,C.PreBoletoCompraAutomatico, M.ID_LANC,        
  (CASE         
   WHEN M.ID_SUBCONTA IS NOT NULL THEN 2        
   WHEN M.ID_CLIENTE = @1IDCLIENTE_NAO_IDENTIFICADO THEN 1        
 ELSE 0        
  END) AS CONTA_CLIENTE,
  M.FlagGoogle 
FROM             #TBL_TEMPREJ M          
 LEFT JOIN [IK_VAREJO].[DBO].[TBL_MEWEB_ASSOCIA_CLIENTES] AS A WITH(NOLOCK) ON (                   
 m.id_associado = a.id)      
  LEFT JOIN [DBO].[TBL_MEWEB_MT103_SUGEST] AS S WITH(NOLOCK) ON M.IDSWIFT = S.IDSWIFT        
  LEFT JOIN TBL_CLIENTES AS C WITH(NOLOCK) ON C.ID_CLIENTE =  (CASE                       
                  WHEN M.ID_CLIENTE IS NOT NULL THEN M.ID_CLIENTE                      
  WHEN A.ID_CLIENTE IS NOT NULL THEN A.ID_CLIENTE        
                  WHEN S.ID_CLIENTE IS NOT NULL THEN S.ID_CLIENTE                      
ELSE NULL                      
           END)                          
  LEFT JOIN(SELECT IDSWIFT, MAX(NUMERO) AS NUMERO FROM TBL_MEWEB_MT103_CHANGE WITH(NOLOCK) GROUP BY IDSWIFT) AS CA ON M.IDSWIFT = CA.IDSWIFT        
  LEFT JOIN( SELECT B.ID_SWIFT, B.CDMSG, C.DATAMSG               
  FROM TBL_ME_LOG_LANC_CCMESWIFT  B WITH(NOLOCK) INNER JOIN               
  (SELECT ID_SWIFT, MAX(DATAMSG) AS DATAMSG              
  FROM TBL_ME_LOG_LANC_CCMESWIFT  WITH(NOLOCK)               
  WHERE CDMSG IN ('2000','2001')              
  GROUP BY ID_SWIFT) AS C         
  ON B.ID_SWIFT = C.ID_SWIFT  AND B.DATAMSG = C.DATAMSG) AS LO ON M.IDSWIFT = LO.ID_SWIFT          
  WHERE         
  (         
   (@1CLIENTE IS NULL OR LEN(@1CLIENTE) = 0) OR                                                      
   [DBO].[MT103_FORMATA_ORDENANTE] (M.M50K_ORDERINGCUSTOMER,M.O50F_ADDITIONALINFORMATION,M.M50A_ORDERINGCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR                                                    
   [DBO].[MT103_FORMATA_BENEFICIARIO] (M59_BENEFICIARYCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR         
   ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) LIKE '%' + @1CLIENTE +'%' OR        
   CONVERT(VARCHAR,M.OP_N_BOLETO) LIKE @1CLIENTE +'%'        
  )        
       
  DROP TABLE #TBL_TEMPREJ                                
END
        
IF @1ACAO = 'FILTRAR_APROVADOS'                                                        
BEGIN          


  
SELECT         
  IDSWIFT ,        
  M59_BENEFICIARYCUSTOMER ,        
  M50K_ORDERINGCUSTOMER ,        
  O50F_ADDITIONALINFORMATION ,        
  M50A_ORDERINGCUSTOMER ,        
  M.ID_CLIENTE,      
  M20_SENDERREF ,        
  M32A_VDATECURRENCYINTERBANK,        
  DATALOTE   ,         
  DATA_LANCAMENTO_ROBO ,        
  STATUS_LANC,       
  DATA_LANCAMENTO ,        
  L.Empresa,         
  DATA_REGISTRO ,      
  ID_LANC,        
  LC_AUTOMATICO,        
  OP_N_BOLETO,        
  STATUS_PREBOLETO,     
  SC.id_sub_conta AS ID_SUBCONTA,  
  M.BENEFICIARIO,  
  M.ORDENANTE,  
  NULL AS id_associado  
  into #TBL_TEMP1           
 FROM                                      
 [IK_VAREJO].[DBO].[TBL_MEWEB_MT103] AS M WITH(NOLOCK)         
 JOIN [IK_VAREJO].[DBO].[TBL_MEWEB_MT103_LOTE] AS L WITH(NOLOCK) ON M.ID_LOTE = L.LOTE         
 LEFT JOIN TBL_ME_SUBCONTA SC  WITH(NOLOCK) ON M.ID_CLIENTE = SC.ID_CLIENTE AND SC.SUB_STATUS <> 'I' AND SC.cod_moeda = (CASE SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)        
                         WHEN 'EUR' THEN 'EURO'             
                         WHEN 'GBP' THEN 'STG'            
                         WHEN 'AUD' THEN 'ATD'            
                         WHEN 'CAD' THEN 'CAN'    
                  WHEN 'JPY' THEN 'YEN'          
                         ELSE SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)         
                        END)        
                                
 WHERE         
	(
		FLAGGOOGLE = 0  OR (
								FLAGGOOGLE = 1 
								AND @FLAG_HABILITA_TELAS_CCME = 'S'
								-- VIRADA CHAVE GERAL MARC�O
								AND m.OP_N_BOLETO IS NULL
							)
	)               
 AND(                                            
  @1PROCESSADO = STATUS_LANC OR @1PROCESSADO = STATUS_PREBOLETO OR                                             
  @1EMPROCESSAMENTO = STATUS_LANC OR @1EMPROCESSAMENTO = STATUS_PREBOLETO OR                          
  @1APROVADO = STATUS_LANC OR @1APROVADO = STATUS_PREBOLETO       
 )          
  AND (LEN(@1EMPRESA) = 0 OR ISNULL(@1EMPRESA,'TODAS') = 'TODAS' OR L.Empresa = @1EMPRESA)                                                    
  AND (ISNULL(@1TIPOLANCAMENTO,'TODOS') = 'TODOS' OR (@1TIPOLANCAMENTO = TIPO_LANC OR TIPO_LANC = 'AMBOS'))           
  AND (                              
    (@1PERIODO = 'DATACREDITO' AND CONVERT(DATE,SUBSTRING(M32A_VDATECURRENCYINTERBANK,1,6),101) BETWEEN CONVERT(DATE,@1DATAINICIAL,101) AND CONVERT(DATE,@1DATAFINAL,101)) OR                                            
    (@1PERIODO = 'DATAREGISTRO' AND CONVERT(DATE,DATA_REGISTRO,101) BETWEEN CONVERT(DATE,@1DATAINICIAL,101) AND CONVERT(DATE,@1DATAFINAL,101)) OR                                     
    (@1PERIODO = 'DATALANCAMENTO' AND CONVERT(DATE,DATA_LANCAMENTO,101) BETWEEN CONVERT(DATE,@1DATAINICIAL,101) AND CONVERT(DATE,@1DATAFINAL,101))                                                        
  )           
          
    
   UPDATE    M  
   SET       ID_ASSOCIADO = A.ID  
   FROM             #TBL_TEMP1 M  
   JOIN             [TBL_MEWEB_ASSOCIA_CLIENTES] AS A WITH(NOLOCK)  
     ON             [DBO].[FULL_TRIM](M.BENEFICIARIO) = [DBO].[FULL_TRIM](A.BENEFICIARIO_SWIFT)   
    AND     [DBO].[FULL_TRIM](M.ORDENANTE) = [DBO].[FULL_TRIM](A.ORDENANTE_SWIFT)      
  
IF @1PERIODO <> 'DATAASSOCIACAO'        
  BEGIN         
  SELECT DISTINCT                             
  (CASE WHEN A.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END) AS CLIENTE_ASSOCIADO,                                                  
  A.ID_CLIENTE AS ID_CLIENTE_ASSOCIADO,                                                      
  (CASE WHEN S.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END ) AS CLIENTE_SUGESTAO,                                                   
  S.ID_CLIENTE AS ID_CLIENTE_SUGESTAO,                                      
  ltrim(rtrim((CASE WHEN M.ID_CLIENTE IS NOT NULL THEN  ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END))) AS CLIENTE_LANCAMENTO,                   
  M.ID_CLIENTE AS ID_CLIENTE_LANCAMENTO,                                    
  A.ID, A.DATAASSOCIA,CONVERT(DATE,SUBSTRING(M32A_VDATECURRENCYINTERBANK,1,6),101) AS DATACREDITO,                         
  M.DATA_LANCAMENTO_ROBO,M.STATUS_LANC,M.ID_CLIENTE, M.DATA_LANCAMENTO, M.EMPRESA, M.DATA_REGISTRO,M.IDSWIFT,M.LC_AUTOMATICO,              
  M.BENEFICIARIO,  
  M.ORDENANTE,  
  
  (SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,10,15) +' / '+SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)) AS VALOR_MOEDA,                             
  CA.NUMERO AS NUMERO,LO.DATAMSG, LO.CDMSG, M.DATALOTE,M.OP_N_BOLETO,M.STATUS_PREBOLETO,M.ID_SUBCONTA,C.PreBoletoCompraAutomatico,M.ID_LANC,  
    ([IK_VAREJO].[dbo].[CALCULA_MOEDA](SUBSTRING(M32A_VDateCurrencyInterbank,7,3),LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(SUBSTRING(M32A_VDateCurrencyInterbank,10,15),CHAR(13),''),CHAR(10),''),',','.'))))) AS VALOR_USD,        
  (CASE         
   WHEN M.ID_SUBCONTA IS NOT NULL THEN 2        
   WHEN M.ID_CLIENTE = @1IDCLIENTE_NAO_IDENTIFICADO THEN 1        
   ELSE 0        
  END) AS CONTA_CLIENTE,  
 (SELECT COUNT(IDSWIFT)   
 FROM TBL_MEWEB_MT103 WITH(NOLOCK)   
 INNER JOIN TBL_MEWEB_MT103_LOTE WITH(NOLOCK) ON LOTE = ID_LOTE  
 WHERE 	(
		FLAGGOOGLE = 0  OR (
								FLAGGOOGLE = 1 
								AND @FLAG_HABILITA_TELAS_CCME = 'S'
							)
	)              
   AND  (EMPRESA = 'BRSA' AND STATUS_LANC = 1 OR  
     EMPRESA = 'BRSA' AND STATUS_PREBOLETO = 1 OR    
     EMPRESA = 'COTACAO' AND STATUS_LANC = 1 AND STATUS_PREBOLETO IS NULL OR   
     EMPRESA = 'COTACAO' AND STATUS_LANC = 1 AND STATUS_PREBOLETO = 1  )  
    AND BENEFICIARIO = M.BENEFICIARIO AND ORDENANTE = M.ORDENANTE AND ID_CLIENTE = M.ID_CLIENTE AND IDSWIFT <> M.IDSWIFT) AS ASSOCIACAO_ENCONTRADA         
  FROM                  
  #TBL_TEMP1 M                                         
  LEFT JOIN [IK_VAREJO].[DBO].[TBL_MEWEB_ASSOCIA_CLIENTES] AS A WITH(NOLOCK) ON (                   
 m.id_associado = a.id)        
  
  LEFT JOIN [DBO].[TBL_MEWEB_MT103_SUGEST] AS S WITH(NOLOCK) ON M.IDSWIFT = S.IDSWIFT                                                    
  LEFT JOIN TBL_CLIENTES AS C WITH(NOLOCK) ON C.ID_CLIENTE =  (CASE                       
                  WHEN M.ID_CLIENTE IS NOT NULL THEN M.ID_CLIENTE        
                  WHEN A.ID_CLIENTE IS NOT NULL THEN A.ID_CLIENTE                      
                  WHEN S.ID_CLIENTE IS NOT NULL THEN S.ID_CLIENTE                      
                  ELSE NULL                      
                  END)                          
  LEFT JOIN TBL_MEWEB_MT103_CHANGE AS CA WITH(NOLOCK) ON M.IDSWIFT = CA.IDSWIFT        
  LEFT JOIN( SELECT B.ID_SWIFT, B.CDMSG, C.DATAMSG               
  FROM TBL_ME_LOG_LANC_CCMESWIFT  B WITH(NOLOCK) INNER JOIN               
  (SELECT ID_SWIFT, MAX(DATAMSG) AS DATAMSG              
       FROM TBL_ME_LOG_LANC_CCMESWIFT  WITH(NOLOCK)               
       WHERE CDMSG IN ('2000','2001')              
       GROUP BY ID_SWIFT) AS C         
  ON B.ID_SWIFT = C.ID_SWIFT  AND B.DATAMSG = C.DATAMSG) AS LO ON M.IDSWIFT = LO.ID_SWIFT          
  WHERE         
  (         
   (@1CLIENTE IS NULL OR LEN(@1CLIENTE) = 0) OR                                                      
   [DBO].[MT103_FORMATA_ORDENANTE] (M.M50K_ORDERINGCUSTOMER,M.O50F_ADDITIONALINFORMATION,M.M50A_ORDERINGCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR                                                    
   [DBO].[MT103_FORMATA_BENEFICIARIO] (M59_BENEFICIARYCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR         
   ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) LIKE '%' + @1CLIENTE +'%' OR        
   CONVERT(VARCHAR,M.OP_N_BOLETO) LIKE @1CLIENTE +'%'        
  )        
  AND (@1LANCADOCHANGE = 'TODOS' OR (ISNULL(@1LANCADOCHANGE,'SIM') = 'SIM' AND CA.NUMERO IS NOT NULL) OR (@1LANCADOCHANGE = 'NAO' AND CA.NUMERO IS NULL))         
        
 END        
         
 ELSE        
 BEGIN        
   SELECT DISTINCT                             
  (CASE WHEN A.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END) AS CLIENTE_ASSOCIADO  
   , A.ID_CLIENTE AS ID_CLIENTE_ASSOCIADO  
   , (CASE WHEN S.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END ) AS CLIENTE_SUGESTAO  
   , S.ID_CLIENTE AS ID_CLIENTE_SUGESTAO  
   , LTRIM(RTRIM((CASE WHEN M.ID_CLIENTE IS NOT NULL THEN  ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END))) AS CLIENTE_LANCAMENTO  
   , M.ID_CLIENTE AS ID_CLIENTE_LANCAMENTO  
   , A.ID, A.DATAASSOCIA,CONVERT(DATE,SUBSTRING(M32A_VDATECURRENCYINTERBANK,1,6),101) AS DATACREDITO      
   , M.DATA_LANCAMENTO_ROBO,M.STATUS_LANC,M.ID_CLIENTE, M.DATA_LANCAMENTO, M.EMPRESA, M.DATA_REGISTRO,M.IDSWIFT,M.LC_AUTOMATICO  
   , M.BENEFICIARIO  
   , M.ordenante  
   , (SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,10,15) +' / '+SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)) AS VALOR_MOEDA  
   , CA.NUMERO AS NUMERO,LO.DATAMSG, LO.CDMSG, M.DATALOTE,M.OP_N_BOLETO,M.STATUS_PREBOLETO,M.ID_SUBCONTA,C.PreBoletoCompraAutomatico,M.ID_LANC,   
     ([IK_VAREJO].[dbo].[CALCULA_MOEDA](SUBSTRING(M32A_VDateCurrencyInterbank,7,3),LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(SUBSTRING(M32A_VDateCurrencyInterbank,10,15),CHAR(13),''),CHAR(10),''),',','.'))))) AS VALOR_USD,       
    (CASE WHEN M.ID_SUBCONTA IS NOT NULL THEN 2        
    WHEN M.ID_CLIENTE = @1IDCLIENTE_NAO_IDENTIFICADO THEN 1        
    ELSE 0        
   END) AS CONTA_CLIENTE,  
      (SELECT COUNT(IDSWIFT)   
 FROM TBL_MEWEB_MT103 WITH(NOLOCK)   
 INNER JOIN TBL_MEWEB_MT103_LOTE WITH(NOLOCK) ON LOTE = ID_LOTE  
 WHERE 	(
		FLAGGOOGLE = 0  OR (
								FLAGGOOGLE = 1 
								AND @FLAG_HABILITA_TELAS_CCME = 'S'
							)
	)             
   AND  (EMPRESA = 'BRSA' AND STATUS_LANC = 1 OR  
     EMPRESA = 'BRSA' AND STATUS_PREBOLETO = 1 OR    
     EMPRESA = 'COTACAO' AND STATUS_LANC = 1 AND STATUS_PREBOLETO IS NULL OR   
     EMPRESA = 'COTACAO' AND STATUS_LANC = 1 AND STATUS_PREBOLETO = 1  )  
    AND BENEFICIARIO = M.BENEFICIARIO AND ORDENANTE = M.ORDENANTE AND ID_CLIENTE = M.ID_CLIENTE AND IDSWIFT <> M.IDSWIFT) AS ASSOCIACAO_ENCONTRADA   
    FROM                                                   
    #TBL_TEMP1 M        
  
  LEFT JOIN [IK_VAREJO].[DBO].[TBL_MEWEB_ASSOCIA_CLIENTES] AS A WITH(NOLOCK) ON (                   
  M.ID_ASSOCIADO = A.ID)      
  LEFT JOIN [DBO].[TBL_MEWEB_MT103_SUGEST] AS S WITH(NOLOCK) ON M.IDSWIFT = S.IDSWIFT                 
  LEFT JOIN TBL_CLIENTES AS C WITH(NOLOCK) ON C.ID_CLIENTE =    
   (CASE WHEN M.ID_CLIENTE IS NOT NULL THEN M.ID_CLIENTE                      
                  WHEN A.ID_CLIENTE IS NOT NULL THEN A.ID_CLIENTE                      
                  WHEN S.ID_CLIENTE IS NOT NULL THEN S.ID_CLIENTE                      
                  ELSE NULL                      
              END)                          
    LEFT JOIN TBL_MEWEB_MT103_CHANGE AS CA WITH(NOLOCK) ON M.IDSWIFT = CA.IDSWIFT             
    LEFT JOIN( SELECT B.ID_SWIFT, B.CDMSG, C.DATAMSG               
     FROM TBL_ME_LOG_LANC_CCMESWIFT  B WITH(NOLOCK) INNER JOIN               
    (SELECT ID_SWIFT, MAX(DATAMSG) AS DATAMSG              
    FROM TBL_ME_LOG_LANC_CCMESWIFT  WITH(NOLOCK)               
    WHERE CDMSG IN ('2000','2001')              
    GROUP BY ID_SWIFT) AS C              
    ON B.ID_SWIFT = C.ID_SWIFT              
   AND B.DATAMSG = C.DATAMSG) AS LO ON M.IDSWIFT = LO.ID_SWIFT         
   WHERE        
   ((@1CLIENTE IS NULL OR LEN(@1CLIENTE) = 0) OR                                                      
    [DBO].[MT103_FORMATA_ORDENANTE] (M.M50K_ORDERINGCUSTOMER,M.O50F_ADDITIONALINFORMATION,M.M50A_ORDERINGCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR                     
    [DBO].[MT103_FORMATA_BENEFICIARIO] (M59_BENEFICIARYCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR         
    ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) LIKE '%' + @1CLIENTE +'%' OR        
    CONVERT(VARCHAR,M.OP_N_BOLETO) LIKE @1CLIENTE +'%')             
    AND (@1LANCADOCHANGE = 'TODOS' OR (ISNULL(@1LANCADOCHANGE,'SIM') = 'SIM' AND CA.NUMERO IS NOT NULL) OR (@1LANCADOCHANGE = 'NAO' AND CA.NUMERO IS NULL))          
    AND CONVERT(DATE,DATAASSOCIA,101) BETWEEN CONVERT(DATE,@1DATAINICIAL,101) AND CONVERT(DATE,@1DATAFINAL,101)          
                
 END         
                                  
END                       
          
IF @1ACAO = 'GERAR_LANCAMENTOS'                                         
BEGIN        
                                                
   SELECT DISTINCT MT.IDSWIFT, CL.ID_CLIENTE, MT.ID_USER                                    
      , CASE WHEN RIGHT(  SUBSTRING(REPLACE(REPLACE(M32A_VDATECURRENCYINTERBANK, CHAR(13),''), CHAR(10),''),10,15), 1) =',' THEN     
   CONVERT(DECIMAL(18,2),REPLACE(SUBSTRING(REPLACE(REPLACE(M32A_VDATECURRENCYINTERBANK, CHAR(13),''), CHAR(10),''),10,15),',',''))    
  ELSE    
   CONVERT(DECIMAL(18,2),REPLACE(SUBSTRING(REPLACE(REPLACE(M32A_VDATECURRENCYINTERBANK, CHAR(13),''), CHAR(10),''),10,15),',','.'))    
END AS VALOR                                                     
      , CASE SUBSTRING(M32A_VDateCurrencyInterbank, 7, 3)            
    WHEN 'EUR' THEN 'EURO'            
    WHEN 'GBP' THEN 'STG'            
    WHEN 'AUD' THEN 'ATD'            
    WHEN 'CAD' THEN 'CAN'            
    WHEN 'JPY' THEN 'YEN'            
   ELSE SUBSTRING(M32A_VDateCurrencyInterbank, 7, 3)            
   END AS MOEDA                      
   , ISNULL(CL.CL_NOME, CL.CL_RAZAO_SOCIAL) AS NOME  
      , CL.CL_NUM_DOC, ML.EMPRESA                                                  
   , CASE WHEN ML.EMPRESA='BRSA' THEN                                                 
   (SELECT VL_CAMPO FROM TBL_VAREJO_PARAMETROS WHERE NM_CAMPO ='ID_CLIENTE_BANCO_RENDIMENTO')  
  ELSE  
   (SELECT VL_CAMPO FROM TBL_VAREJO_PARAMETROS WHERE NM_CAMPO ='ID_CLIENTE_COTACAO')  
  END AS ID_CLIENTE_EMPRESA                         
  
   , CASE WHEN ML.EMPRESA='BRSA' THEN  
     (SELECT CL_RAZAO_SOCIAL FROM TBL_CLIENTES WITH(NOLOCK) WHERE ID_CLIENTE IN (SELECT VL_CAMPO FROM TBL_VAREJO_PARAMETROS WITH(NOLOCK) WHERE NM_CAMPO ='ID_CLIENTE_BANCO_RENDIMENTO'))  
  ELSE  
   (SELECT CL_RAZAO_SOCIAL FROM TBL_CLIENTES WITH(NOLOCK) WHERE ID_CLIENTE IN (SELECT VL_CAMPO FROM TBL_VAREJO_PARAMETROS WITH(NOLOCK) WHERE NM_CAMPO ='ID_CLIENTE_COTACAO'))  
  END AS NOME_CLIENTE_EMPRESA                         
  
   , (SELECT COUNT(*) FROM TBL_ME_SUBCONTA WHERE COD_MOEDA =    
   CASE SUBSTRING(M32A_VDateCurrencyInterbank, 7, 3)            
                WHEN 'EUR' THEN 'EURO'            
                WHEN 'GBP' THEN 'STG'            
                WHEN 'AUD' THEN 'ATD'            
                WHEN 'CAD' THEN 'CAN'            
                WHEN 'JPY' THEN 'YEN'            
                ELSE SUBSTRING(M32A_VDateCurrencyInterbank, 7, 3)            
               END  AND id_cliente = CL.ID_CLIENTE AND SUB_STATUS = 'A')  AS CONTA_CLIENTE               
   , CASE WHEN MT.M59_BeneficiaryCustomer IS NULL THEN '59: N�O INFORMADO' ELSE '59:' + MT.M59_BeneficiaryCustomer END AS C59                                              
   , CASE WHEN MT.O70_RemittanceInformation IS NULL THEN '70: N�O INFORMADO' ELSE '70:' + MT.O70_RemittanceInformation END AS C70                                                     
   , CA.NUMERO AS NUMERO                                          
   , CASE WHEN (MT.ID_CLIENTE_FASE1 = (SELECT ID_CLIENTE FROM TBL_ROBOCCMESWIFT With(NOLOCK) WHERE nomRobo = 'ROBO_CCME_SWIFT')) THEN                                  
   CASE WHEN (DATEADD(day,2,CONVERT(DATE,SUBSTRING(MT.M32A_VDateCurrencyInterbank,1,6),101))  <= Convert(Char(10), GetDate(),20)) THEN                                  
    CONVERT(Char(10), GetDate(),20)                                   
   ELSE                                   
    CONVERT(DATE,SUBSTRING(MT.M32A_VDateCurrencyInterbank,1,6),101)   
   END                            
  ELSE                                  
   DATEADD(day,1,CONVERT(DATE,SUBSTRING(MT.M32A_VDateCurrencyInterbank,1,6),101))                                  
  END AS DATA_LANCAMENTO                              
   , CONVERT(DATE,SUBSTRING(MT.M32A_VDateCurrencyInterbank,1,6),101) AS VALUE_DATE                                  
   , CASE WHEN (MT.ID_CLIENTE_FASE1 = (SELECT ID_CLIENTE FROM TBL_ROBOCCMESWIFT With(NOLOCK) WHERE nomRobo = 'ROBO_CCME_SWIFT')) AND MT.id_cliente = MT.ID_CLIENTE_FASE1 THEN 1   
  ELSE 0 END AS CLIENTE_NIDENT, 
  
  MT.M20_SenderRef,

    [DBO].[MT103_FORMATA_ORDENANTE] (MT.M50K_ORDERINGCUSTOMER,MT.O50F_ADDITIONALINFORMATION,MT.M50A_ORDERINGCUSTOMER) AS ORDENANTE,
  ISNULL(
  CASE WHEN (SUBSTRING(MT.O33B_CurrencyInstructed,1,3) = 'BRL' and charindex('USD',MT.M32A_VDateCurrencyInterbank,1)<>0) THEN         
                                CONVERT(decimal(18, 2), REPLACE(SUBSTRING(dbo.FULL_TRIM(MT.M32A_VDATECURRENCYINTERBANK), 10, 30), ',', '.')) 
                                ELSE 
                                CASE WHEN RIGHT(SUBSTRING(replace(replace(dbo.FULL_TRIM(M32A_VDateCurrencyInterbank), CHAR(13),''), CHAR(10),''),10,15), 1) = ',' THEN 
                                 convert(decimal(18, 2), REPLACE(SUBSTRING(replace(replace(dbo.FULL_TRIM(M32A_VDateCurrencyInterbank), CHAR(13), ''), CHAR(10), ''), 10, 15), ',', '')) 
                                ELSE 
                                 convert(decimal(18, 2), REPLACE(SUBSTRING(replace(replace(dbo.FULL_TRIM(M32A_VDateCurrencyInterbank), CHAR(13), ''), CHAR(10), ''), 10, 15), ',', '.')) 
                                END 
                                END ,0) AS ValorRecebido,
   CL.CL_STATUS								
								              
   FROM TBL_MEWEB_MT103 MT WITH(NOLOCK)                                    
   INNER JOIN TBL_MEWEB_MT103_LOTE ML with(nolock) ON MT.id_Lote = ML.Lote               
   INNER JOIN TBL_CLIENTES CL  with(nolock) ON MT.id_cliente = CL.ID_CLIENTE                                                        
   LEFT JOIN TBL_MEWEB_MT103_CHANGE AS CA with(nolock) ON CA.idSwift = MT.idSwift    
   
   AND CONVERT(VARCHAR,LEFT(MT.M32A_VDateCurrencyInterbank, 6)) =     
       CONVERT(varchar, RIGHT(YEAR(CA.DATAVL), 2)) + REPLICATE('0' ,2-LEN(CONVERT(varchar, MONTH(CA.DATAVL)))) +     
       CONVERT(varchar, MONTH(CA.DATAVL)) + REPLICATE('0' ,2-LEN(CONVERT(varchar, DAY(CA.DATAVL)))) + CONVERT(varchar,DAY(CA.DATAVL))                                    
   AND CONVERT(FLOAT,replace(REPLACE(substring(dbo.FULL_TRIM(MT.M32A_VDateCurrencyInterbank),10,30),'.',''),',','.')) = CA.VALORME                                        
   WHERE MT.FLAGGOOGLE = 0                                                
     AND MT.LC_AUTOMATICO = 1          
     AND MT.STATUS_LANC NOT IN (0,1,3,6,8,9)                                      
    -- STATUS 0:PR�-APROVADO,1:FINALIZADO,3:RECUSADO,6:LAN�AMENTO FUTURO,8:REJEITADO,9:DEVOLVIDO
     AND MT.TIPO_LANC IN ('AMBOS','CCME')                                                    
                                                           
END                                                     
                                                    
IF @1ACAO = 'ASSOCIAR'                                                  
BEGIN                                   
 IF NOT EXISTS (SELECT CL_NUM_DOC,COUNT(CL_NUM_DOC) FROM TBL_CLIENTES   
    WHERE CL_NUM_DOC = (SELECT TOP 1 CL_NUM_DOC   
         FROM TBL_CLIENTES   
         WHERE ID_CLIENTE = @1IDCLIENTE)   
         GROUP BY CL_NUM_DOC HAVING COUNT(CL_NUM_DOC) > 1)                                    
 BEGIN                                           
  IF NOT EXISTS(SELECT TOP 1 ID from TBL_MEWEB_ASSOCIA_CLIENTES with(nolock)   
       WHERE [dbo].[FULL_TRIM](Beneficiario_Swift) = [dbo].[FULL_TRIM](@1BENEFICIARIO) AND                                            
       [dbo].[FULL_TRIM](Ordenante_Swift) = [dbo].[FULL_TRIM](@1ORDENANTE))  
   BEGIN                                                  
    INSERT INTO TBL_MEWEB_ASSOCIA_CLIENTES(Beneficiario_Swift,Ordenante_Swift,id_cliente,DataAssocia,id_user)                                                  
    VALUES(@1BENEFICIARIO,@1ORDENANTE,@1IDCLIENTE,GETDATE(),@1IDUSUARIO)                                                
   END                                                
  ELSE               
   BEGIN     
    UPDATE TBL_MEWEB_ASSOCIA_CLIENTES   
       SET Beneficiario_Swift=@1BENEFICIARIO,   
        Ordenante_Swift=@1ORDENANTE,   
        id_cliente=@1IDCLIENTE,                                                
        DataAssocia = GETDATE(),   
        id_user=@1IDUSUARIO                                                
    WHERE [dbo].[FULL_TRIM](Beneficiario_Swift) = [dbo].[FULL_TRIM](@1BENEFICIARIO) AND                                                
       [dbo].[FULL_TRIM](Ordenante_Swift) = [dbo].[FULL_TRIM](@1ORDENANTE)                                                
   END                                    
 END          
END                
                                 
IF @1ACAO = 'DESASSOCIAR'                                           
 BEGIN                                                      
  DELETE FROM TBL_MEWEB_ASSOCIA_CLIENTES WHERE id = @1IDASSOCIACAO                                       
 END                                                    
              
IF @1ACAO = 'LANCAR'                                                    
BEGIN 

DECLARE @1STATUS_PREBOLETO INT = NULL     
DECLARE @1TIPO_LANC NCHAR(20) = NULL    
DECLARE @FLAGGOOGLE BIT = NULL     
DECLARE @1M32A VARCHAR(24) = NULL

SELECT TOP 1 @1M32A = M32A_VDATECURRENCYINTERBANK, @FLAGGOOGLE = FlagGoogle   
        FROM TBL_MEWEB_MT103 WITH(NOLOCK)   
        WHERE IDSWIFT = @1IDSWIFT   
        AND ID_CLIENTE IS NOT NULL   
        AND (STATUS_LANC IS NULL OR STATUS_LANC = 2 OR STATUS_LANC = 3)   
 
      
IF @1M32A IS NOT NULL      
BEGIN      
	DECLARE @1SUBCONTA INT  
	DECLARE @1PREBOLETOCOMPRAAUTOMATICO CHAR  
	DECLARE @1OPERASOMENTEBANCO VARCHAR(1)      
  
	SELECT TOP 1   
	@1OPERASOMENTEBANCO = C.cl_OperaSomenteBanco,   
	@1PREBOLETOCOMPRAAUTOMATICO = C.PreBoletoCompraAutomatico,   
	@1SUBCONTA = SC.id_sub_conta  
	FROM TBL_CLIENTES AS C WITH(NOLOCK)      
	LEFT JOIN TBL_ME_SUBCONTA AS SC  WITH(NOLOCK)       
	ON C.ID_CLIENTE = SC.ID_CLIENTE   
	AND SC.SUB_STATUS <> 'I'   
	AND SC.cod_moeda = (CASE SUBSTRING(@1M32A,7,3)        
		WHEN 'EUR' THEN 'EURO'             
		WHEN 'GBP' THEN 'STG'            
		WHEN 'AUD' THEN 'ATD'            
		WHEN 'CAD' THEN 'CAN'            
		WHEN 'JPY' THEN 'YEN'          
		ELSE SUBSTRING(@1M32A,7,3)         
	END)       
	WHERE C.ID_CLIENTE = @1IDCLIENTE      
    
	IF @1EMPRESA = 'COTACAO'      
	BEGIN      
		IF @1IDCLIENTE = @1IDCLIENTE_NAO_IDENTIFICADO      
		BEGIN      
			SET @1STATUS_PREBOLETO = 0    
			SET @1TIPO_LANC = 'AMBOS'      
		END      
		ELSE      
		BEGIN      
			IF @1SUBCONTA IS NOT NULL      
			BEGIN      
				SET @1STATUS_PREBOLETO = NULL    
				SET @1TIPO_LANC = 'CCME'      
			END      
			ELSE      
			BEGIN      
				SET @1STATUS_PREBOLETO = 0     
				SET @1TIPO_LANC = 'AMBOS'     
			END      
		END      
	END      
	ELSE      
	BEGIN      
		IF @1SUBCONTA IS NOT NULL      
		BEGIN      
			SET @1STATUS_PREBOLETO = NULL      
			SET @1TIPO_LANC = 'CCME'     
		END      
		ELSE      
		BEGIN      
			SET @1STATUS_PREBOLETO = 0      
			SET @1TIPO_LANC = 'BOLETO'     
		END      
	END     
	
	IF @FLAGGOOGLE = 1
	BEGIN
		SET @1STATUS_PREBOLETO = 0      
		SET @1TIPO_LANC = 'BOLETO'
	END 
   
   UPDATE [IK_VAREJO].[DBO].[TBL_MEWEB_MT103]   
   SET STATUS_LANC = 0,   
    ID_CLIENTE = @1IDCLIENTE,  
    TIPO_LANC = @1TIPO_LANC,    
    STATUS_PREBOLETO = @1STATUS_PREBOLETO,   
    DATA_LANCAMENTO = CASE WHEN DATA_LANCAMENTO IS NULL THEN GETDATE() ELSE DATA_LANCAMENTO END,   
    LC_AUTOMATICO = 1             
   WHERE IDSWIFT = @1IDSWIFT    
   AND (STATUS_LANC IS NULL OR STATUS_LANC = 2 OR STATUS_LANC = 3)   
  
  IF @1TIPO_LANC = 'CCME' OR @1TIPO_LANC = 'AMBOS'  
  BEGIN  
   EXEC SPBCCME_GRAVAR_LOG_CCMESWIFT  
   @id_swift = @1IDSWIFT,  
   @CdMsg =  '2000',  
   @DsMsgLog = @1MENSAGEMLOGLANCAMENTO,  
   @id_user = @1IDUSUARIO,  
   @OrMoeda = NULL,  
   @OrValor = NULL,  
   @TpLog = 'A',  
   @ID_Lanc = NULL,  
   @OP_N_BOLETO = NULL,  
   @OP_N_BOLETO_EMPRESA = NULL,  
   @OP_N_BOLETO_SISTEMA = NULL,  
   @OrigemLog = 'LC',  
   @ur_username = @1UR_USERNAME    
  END  
  ELSE  
  BEGIN  
   EXEC SPBCCME_GRAVAR_LOG_CCMESWIFT  
   @id_swift = @1IDSWIFT,  
   @CdMsg =  '2000',  
   @DsMsgLog = @1MENSAGEMLOGLANCAMENTO,  
   @id_user = @1IDUSUARIO,  
   @OrMoeda = NULL,  
   @OrValor = NULL,  
   @TpLog = 'A',  
   @ID_Lanc = NULL,  
   @OP_N_BOLETO = NULL,  
   @OP_N_BOLETO_EMPRESA = NULL,  
   @OP_N_BOLETO_SISTEMA = NULL,  
   @OrigemLog = 'BO',  
   @ur_username = @1UR_USERNAME    
  END   
                                         
 END      
      
 SELECT @@ROWCOUNT      
END         
        
IF @1ACAO = 'HISTORICO'                                                  
BEGIN                                                  
 SELECT CASE WHEN L.UR_USERNAME IS NOT NULL THEN L.UR_USERNAME  
  WHEN LO.EMPRESA = 'COTACAO' THEN ISNULL(UDB.UR_USERNAME, UIK.UR_USERNAME)   
  WHEN LO.EMPRESA = 'BRSA' THEN ISNULL(UIK.UR_USERNAME,  UDB.UR_USERNAME)  
  ELSE UIK.UR_USERNAME END AS UR_USERNAME,  
  CDMSG,DSMSGLOG,DATAMSG, L.ID_USER, LO.EMPRESA  
 FROM [IK_VAREJO].[dbo].[TBL_ME_LOG_LANC_CCMESWIFT] AS L WITH(NOLOCK)  
  INNER JOIN [IK_VAREJO].[dbo].[TBL_MEWEB_MT103] AS MT WITH(NOLOCK) ON MT.IDSWIFT = L.ID_SWIFT              
   LEFT JOIN [IK_VAREJO].[dbo].[TBL_MEWEB_MT103_LOTE] AS LO WITH(NOLOCK) ON LO.Lote = MT.ID_LOTE  
   LEFT JOIN TBL_USERS AS UIK WITH(NOLOCK) ON UIK.id_user = L.id_user                                            
   LEFT JOIN DBVAREJO.DBO.TBL_USERS AS UDB WITH(NOLOCK) ON UDB.id_user = L.id_user                                          
   WHERE ID_SWIFT = @1IDSWIFT                                                  
   ORDER BY L.DATAMSG DESC                                            
END         
        
IF @1ACAO = 'GERAR_PRE_BOLETO'                                                  
BEGIN                                                  
   SELECT  MT.IDSWIFT, CL.ID_CLIENTE, MT.ID_USER  
   , CASE WHEN RIGHT(  SUBSTRING(replace(replace(M32A_VDateCurrencyInterbank, CHAR(13),''), CHAR(10),''),10,15), 1) =',' THEN     
    CONVERT(decimal(18,2),REPLACE(SUBSTRING(replace(replace(M32A_VDateCurrencyInterbank, CHAR(13),''), CHAR(10),''),10,15),',',''))    
   ELSE    
    CONVERT(decimal(18,2),REPLACE(SUBSTRING(replace(replace(M32A_VDateCurrencyInterbank, CHAR(13),''), CHAR(10),''),10,15),',','.'))    
  END  AS VALOR           
      , CONVERT(decimal(18,2),([IK_VAREJO].[dbo].[CALCULA_MOEDA](SUBSTRING(M32A_VDateCurrencyInterbank,7,3),LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(SUBSTRING(M32A_VDateCurrencyInterbank,10,15),CHAR(13),''),CHAR(10),''),',','.')))))) AS VALOR_USD  
      , CONVERT(decimal(18,2),  
   CASE WHEN (SUBSTRING(MT.O33B_CurrencyInstructed,1,3) = 'BRL' and charindex('USD',MT.M32A_VDateCurrencyInterbank,1)<>0) THEN        
    CASE WHEN LEN(O33B_CurrencyInstructed)>0 THEN    
     CASE WHEN RIGHT(dbo.FULL_TRIM(O33B_CurrencyInstructed),1)=',' THEN    
       dbo.FULL_TRIM(REPLACE(SUBSTRING(O33B_CurrencyInstructed,4,LEN(O33B_CurrencyInstructed)),',','.'))    
       ELSE    
       dbo.FULL_TRIM(REPLACE(SUBSTRING(O33B_CurrencyInstructed,4,LEN(O33B_CurrencyInstructed)),',','.'))    
       END     
    ELSE     
     CASE WHEN LEN(O72_SENDERTORECEIVERINF)> 0 THEN    
      dbo.FULL_TRIM(REPLACE(RTRIM(LTRIM(SUBSTRING(REPLACE(O72_SENDERTORECEIVERINF,'/ACC/PLEASE PAY',''),0,CHARINDEX('BRL',REPLACE(O72_SENDERTORECEIVERINF,'/ACC/PLEASE PAY',''))) )),',',''))    
     ELSE 'ERRO' END     
    END     
   END) AS VALOR_MN    
      , CASE WHEN (SUBSTRING(MT.O33B_CurrencyInstructed,1,3) = 'BRL' and charindex('USD',MT.M32A_VDateCurrencyInterbank,1)<>0) THEN        
    CONVERT(decimal(18,2),REPLACE(SUBSTRING(dbo.FULL_TRIM(MT.M32A_VDATECURRENCYINTERBANK),10,30),',','.'))  
    ELSE     
    CASE WHEN RIGHT(SUBSTRING(replace(replace(dbo.FULL_TRIM(M32A_VDateCurrencyInterbank), CHAR(13),''), CHAR(10),''),10,15), 1) =',' THEN     
     convert(decimal(18,2),REPLACE(SUBSTRING(replace(replace(dbo.FULL_TRIM(M32A_VDateCurrencyInterbank), CHAR(13),''), CHAR(10),''),10,15),',',''))    
    ELSE    
     convert(decimal(18,2),REPLACE(SUBSTRING(replace(replace(dbo.FULL_TRIM(M32A_VDateCurrencyInterbank), CHAR(13),''), CHAR(10),''),10,15),',','.'))    
    END     
    END AS VALOR_ME           
      , CASE WHEN (SUBSTRING(MT.O33B_CurrencyInstructed,1,3) = 'BRL' and charindex('USD',MT.M32A_VDateCurrencyInterbank,1)<>0) THEN 
    CONVERT(DECIMAL(18,8),REPLACE(dbo.FULL_TRIM(ISNULL(O36_ExchangeRate,0)),',','.'))    
    ELSE 0 END AS TAXA        
   , CASE SUBSTRING(M32A_VDateCurrencyInterbank, 7, 3)            
    WHEN 'EUR' THEN 'EURO'            
    WHEN 'GBP' THEN 'STG'            
    WHEN 'AUD' THEN 'ATD'            
    WHEN 'CAD' THEN 'CAN'            
    WHEN 'JPY' THEN 'YEN'            
  ELSE SUBSTRING(M32A_VDateCurrencyInterbank, 7, 3)            
     END AS MOEDA         
   , ISNULL(CL.cl_nome, CL.cl_razao_social) AS NOME         
      , RTRIM(LTRIM(CL.CL_NUM_DOC)) AS CL_NUM_DOC   
      , RTRIM(LTRIM(CL.CL_PASSAPORTE)) AS CL_PASSAPORTE  
   , ML.EMPRESA         
   , CASE WHEN ML.EMPRESA='BRSA' THEN          
   (select VL_CAMPO from TBL_VAREJO_PARAMETROS with(nolock) where NM_CAMPO ='ID_CLIENTE_BANCO_RENDIMENTO')                              
  ELSE                                                  
   (select VL_CAMPO from TBL_VAREJO_PARAMETROS with(nolock) where NM_CAMPO ='ID_CLIENTE_COTACAO')                                                
  END AS ID_CLIENTE_EMPRESA                                         
      , (SELECT COUNT(*) FROM TBL_ME_SUBCONTA with(nolock)   
   WHERE COD_MOEDA =  CASE SUBSTRING(M32A_VDateCurrencyInterbank, 7, 3)            
        WHEN 'EUR' THEN 'EURO'            
        WHEN 'GBP' THEN 'STG'            
        WHEN 'AUD' THEN 'ATD'            
        WHEN 'CAD' THEN 'CAN'            
        WHEN 'JPY' THEN 'YEN'            
       ELSE SUBSTRING(M32A_VDateCurrencyInterbank, 7, 3)      
       END    
   AND id_cliente = CL.ID_CLIENTE   
   AND SUB_STATUS = 'A') AS CONTA_CLIENTE               
   , CASE WHEN MT.M59_BeneficiaryCustomer IS NULL THEN '59: N�O INFORMADO' ELSE '59:' + MT.M59_BeneficiaryCustomer END AS C59           
   , CASE WHEN MT.O70_RemittanceInformation IS NULL THEN '70: N�O INFORMADO' ELSE '70:' + MT.O70_RemittanceInformation END AS C70                 
   , CA.NUMERO AS NUMERO                         
      , CASE WHEN (MT.ID_CLIENTE_FASE1 = (SELECT ID_CLIENTE FROM TBL_ROBOCCMESWIFT with(nolock) WHERE nomRobo = 'ROBO_CCME_SWIFT')) THEN                                  
   CASE WHEN (DATEADD(day,2,CONVERT(DATE,SUBSTRING(MT.M32A_VDateCurrencyInterbank,1,6),101))  <= Convert(Char(10), GetDate(),20)) THEN        
     CONVERT(Char(10), GetDate(),20)                                   
     ELSE      
     CONVERT(DATE,SUBSTRING(MT.M32A_VDateCurrencyInterbank,1,6),101)   
     END                                   
   ELSE                                  
   DATEADD(day,1,CONVERT(DATE,SUBSTRING(MT.M32A_VDateCurrencyInterbank,1,6),101))                                  
      END AS DATA_LANCAMENTO                                  
  , CONVERT(DATE,SUBSTRING(MT.M32A_VDateCurrencyInterbank,1,6),101) AS VALUE_DATE                                  
  , CASE WHEN (MT.ID_CLIENTE_FASE1 = (SELECT ID_CLIENTE FROM TBL_ROBOCCMESWIFT with(nolock) WHERE nomRobo = 'ROBO_CCME_SWIFT')) THEN 1 ELSE 0 END AS CLIENTE_NIDENT   
        
  , ISNULL(CL.cl_OperaSomenteBanco,'S') AS cl_OperaSomenteBanco        
  , CL.CL_STATUS        
        
  , ISNULL(CL.PreBoletoCompraAutomatico,'S') AS PreBoletoCompraAutomatico        
  , isnull((select TOP 1 'S' from TBL_LOGIN_INTEGRADO with(nolock) where li_idcliente = cl.id_cliente),'N') as Acessa_PortalDeCambio        
       
  , isnull((select param_status_col from TBL_COL_PARAMCLI with(nolock) where LI_DOC = CL.CL_NUM_DOC AND PARAM_STATUS_COL IN('S','A')),'N') as ACESSAPORTAL        
  , ISNULL((Select FLAG_HABILITA_CAMBIO_COTACAO  From TBL_LOGIN_INTEGRADO with(nolock) WHERE LI_DOC = CL.CL_NUM_DOC AND LI_TIPO='M' ),'N') as PORTALCOTACAO    
           
  , [DBO].[MT103_FORMATA_ORDENANTE] (MT.M50K_ORDERINGCUSTOMER,MT.O50F_ADDITIONALINFORMATION,MT.M50A_ORDERINGCUSTOMER) AS ORDENANTE        
    
  , ISNULL((select 'D'+LTRIM(RTRIM(convert(char,PARAM_DIASLIQ_COMPRAS))) + 'D'+LTRIM(RTRIM(convert(char,PARAM_DIASLIQ_COMPRASME))) from tbl_col_paramcli where li_doc = cl.cl_num_doc AND MT.FlagGoogle = 0),'D0D0') as DIASMNME        
  , MT.ID_LANC,        
    
  [DBO].[MT103_FORMATA_BANCO] (1,O52A_OrderingInstitution, O52D_OrderingInstitution, O53A_SenderCorrespondent,  M53B_SenderCorrespondent, O54A_ReceiverCorrespondent, O54D_ReceiverCorrespondent, O57A_AccountInstitution, HeaderOp) AS BANCO_ORDEM,      
  [DBO].[MT103_FORMATA_BANCO] (2,O52A_OrderingInstitution, O52D_OrderingInstitution, O53A_SenderCorrespondent,  M53B_SenderCorrespondent, O54A_ReceiverCorrespondent, O54D_ReceiverCorrespondent, O57A_AccountInstitution, HeaderOp) AS NOME_BANCO_ORDEM,     



  
  [DBO].[MT103_FORMATA_BANCO] (3,O52A_OrderingInstitution, O52D_OrderingInstitution, O53A_SenderCorrespondent,  M53B_SenderCorrespondent, O54A_ReceiverCorrespondent, O54D_ReceiverCorrespondent, O57A_AccountInstitution, HeaderOp) AS PAIS_BANCO_ORDEM,      


  (CASE WHEN CL.ID_CLIENTE =(SELECT TOP 1 ID_CLIENTE FROM TBL_ROBOCCMESWIFT With(NOLOCK) WHERE NomRobo = 'ROBO_CCME_SWIFT') THEN 'S' ELSE 'N' END) AS  'CLIENTE_NAOIDENTIFICADO',    
  CASE WHEN ML.EMPRESA = 'COTACAO' THEN    
    ( SELECT LINK_PORTAL_REDIRECT FROM TBL_EMPRESAS WHERE ID_SEFIC_EMPRESA = 1)      
  ELSE     
    ( SELECT LINK_PORTAL_REDIRECT FROM TBL_EMPRESAS WHERE ID_SEFIC_EMPRESA = 2)      
  END AS LINK,    
  CASE CL.cl_tip_doc WHEN 'CPF' THEN CL.cl_tip_doc ELSE 'CNPJ' END AS cli_tipo,    
  CL.id_corretora,  
  CL.CL_COD_VENDEDOR,  
 CASE WHEN ML.EMPRESA = 'COTACAO' THEN    
    ( SELECT ID_USER FROM DBVAREJO.DBO.TBL_USERS WHERE UR_NOME='ROBO_CCME_SWIFT')      
  ELSE     
    ( SELECT ID_USER FROM IK_VAREJO.DBO.TBL_USERS WHERE UR_NOME='ROBO_CCME_SWIFT')      
  END AS ID_USER_ROBO,    
  ( SELECT ID_USER FROM IK_VAREJO.DBO.TBL_USERS WHERE lower(ur_username)='robo.google') ID_USER_ROBO_GOOGLE ,
  CL.Flg_ProcessaGooglePortal,
  CL.flg_aceita_efet_auto_ordem,
  CL.IOF_ISENTO, 
  CL.IR_ISENTO,
  CASE @FLAG_HABILITA_TELAS_CCME WHEN 'S' THEN '1' ELSE @FLAG_HABILITA_TELAS_CCME END Flag_virada_geral
   From TBL_MEWEB_MT103 MT with(nolock)                                             
   INNER JOIN TBL_MEWEB_MT103_LOTE ML with(nolock) ON MT.id_Lote = ML.Lote               
   INNER JOIN TBL_CLIENTES CL  with(nolock) ON MT.id_cliente = CL.ID_CLIENTE     
   LEFT JOIN TBL_MEWEB_MT103_CHANGE AS CA with(nolock) ON CA.IDSWIFT = MT.IDSWIFT    
 AND CONVERT(VARCHAR,LEFT(MT.M32A_VDateCurrencyInterbank, 6)) = CONVERT(varchar, RIGHT(YEAR(CA.DATAVL), 2)) +     
 REPLICATE('0' ,2-LEN(CONVERT(varchar, MONTH(CA.DATAVL)))) +CONVERT(varchar, MONTH(CA.DATAVL)) +     
 REPLICATE('0' ,2-LEN(CONVERT(varchar, DAY(CA.DATAVL)))) + CONVERT(varchar,DAY(CA.DATAVL))                                    
 AND CONVERT(FLOAT,replace(REPLACE(substring(dbo.FULL_TRIM(MT.M32A_VDateCurrencyInterbank),10,30),'.',''),',','.')) = CA.VALORME                                        
  where MT.flagGoogle = ISNULL(@FLAG_GOOGLE,0)                       
    --AND MT.LC_AUTOMATICO = 1                                                
    AND MT.STATUS_PREBOLETO in ( 4 )       
  
	AND (MT.status_lanc is null or MT.status_lanc not in (8,9)) --8 - Rejeitado / 9 - Devolvido
  
    AND MT.TIPO_LANC IN ('AMBOS','BOLETO')   
 AND  ((ML.EMPRESA='COTACAO' AND MT.ID_LANC IS NOT NULL AND MT.OP_N_BOLETO IS NULL) OR (ML.EMPRESA='BRSA' AND MT.OP_N_BOLETO IS NULL))  
 OR (MT.IDSWIFT IN (SELECT IDSWIFT  
      FROM (  
   SELECT MT.IDSWIFT, MT.STATUS_PREBOLETO, (SELECT TOP 1 CDMSG FROM TBL_ME_LOG_LANC_CCMESWIFT WHERE ID_SWIFT= MT.IDSWIFT ORDER BY DATAMSG DESC) CDMSG  
      FROM TBL_MEWEB_MT103 MT  
        WHERE MT.FLAGGOOGLE = ISNULL(@FLAG_GOOGLE,0)                    
          AND MT.STATUS_PREBOLETO IN ( 2 )       
          AND MT.TIPO_LANC IN ('AMBOS','BOLETO') ) B  
      WHERE B.CDMSG in (-996, -997)  
      AND (ML.EMPRESA='COTACAO' AND MT.ID_LANC IS NOT NULL AND MT.OP_N_BOLETO IS NULL) OR (ML.EMPRESA='BRSA' AND MT.OP_N_BOLETO IS NULL)  
      ) )  
      --)  
  
     
END         
    
IF @1ACAO = 'ATUALIZAR_CLIENTE'    
BEGIN    
  UPDATE [IK_VAREJO].[dbo].[TBL_MEWEB_MT103] SET ID_CLIENTE = @1IDCLIENTE, STATUS_PREBOLETO = 0    
   WHERE  idSwift = @1IDSWIFT     
    AND @1IDCLIENTE <> @1IDCLIENTE_NAO_IDENTIFICADO     
    AND STATUS_PREBOLETO <> 1     
    AND STATUS_LANC = 1    
END


GO

-- Teste
-- Exec SPBCCME_MEWEB_MT103_LANCAMENTO @ACAO='HISTORICO'