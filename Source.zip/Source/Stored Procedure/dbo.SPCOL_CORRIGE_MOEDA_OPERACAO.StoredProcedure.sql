use ik_varejo
go

IF (OBJECT_ID('SPCOL_CORRIGE_MOEDA_OPERACAO') IS NOT NULL)
  DROP PROCEDURE SPCOL_CORRIGE_MOEDA_OPERACAO
GO

CREATE PROCEDURE dbo.SPCOL_CORRIGE_MOEDA_OPERACAO
AS
	
	DECLARE @pre_n_boleto integer
	DECLARE @op_n_boleto integer
	DECLARE @pre_tipo_moeda char(5)
	DECLARE @op_tipo_moeda char(5)
	DECLARE @pre_data_boleto DATETIME
	DECLARE @id_cliente int

	DECLARE CURSQL CURSOR FOR
	SELECT pre_n_boleto, pre_tipo_moeda, op_n_boleto, op_tipo_moeda, pre_data_boleto, TBL_PRE_BOLETO.id_cliente
	  FROM [dbo].[TBL_COL_PREBOLETO] WITH(NOLOCK)
	  INNER JOIN [dbo].TBL_PRE_BOLETO WITH(NOLOCK) ON [TBL_COL_PREBOLETO].pre_n_boleto = TBL_PRE_BOLETO.op_n_boleto
	 WHERE pre_tipo_moeda <> op_tipo_moeda and pre_tipo_moeda <> '0'

	OPEN CURSQL

	FETCH NEXT FROM CURSQL INTO @pre_n_boleto, @pre_tipo_moeda, @op_n_boleto, @op_tipo_moeda, @pre_data_boleto, @id_cliente

	WHILE (@@FETCH_STATUS = 0)
	BEGIN

		DECLARE @CRM_CPF_CNPJ VARCHAR(50)
        SET @CRM_CPF_CNPJ = (SELECT TOP 1 CL_NUM_DOC FROM TBL_CLIENTES WHERE ID_CLIENTE = @id_cliente)

        INSERT INTO TBL_CRM (ID_USUARIO,ID_CORRETORA,CRM_CPF_CNPJ,CRM_OCORRENCIA,CRM_PASSAPORTE,CRM_NBOLETO,ID_FILIAL)
        VALUES (NULL,0,     ISNULL (@CRM_CPF_CNPJ, 0),'"SPCOL_CORRIGE_MOEDA_OPERACAO" - TBL_PRE_BOLETO.op_tipo_moeda nao pode ser Modificada.',     NULL, @op_n_boleto, 0)

        UPDATE TBL_PRE_BOLETO set op_tipo_moeda = (SELECT TOP 1 pre_tipo_moeda FROM TBL_COL_PREBOLETO WITH(NOLOCK) 
                                                                                WHERE TBL_COL_PREBOLETO.pre_n_boleto = TBL_PRE_BOLETO.op_n_boleto)
        WHERE op_n_boleto = @op_n_boleto


		FETCH NEXT FROM CURSQL INTO @pre_n_boleto, @pre_tipo_moeda, @op_n_boleto, @op_tipo_moeda, @pre_data_boleto, @id_cliente

	END

	CLOSE CURSQL
	DEALLOCATE CURSQL

GO

-- EXEC SPCOL_CORRIGE_MOEDA_OPERACAO