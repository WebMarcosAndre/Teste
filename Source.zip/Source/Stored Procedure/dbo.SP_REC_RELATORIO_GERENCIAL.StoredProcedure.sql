use ik_varejo
go


/*
SET DATEFORMAT DMY;
EXEC SP_REC_RELATORIO_GERENCIAL @DATA_INICIAL = '01/01/2018', @DATA_FINAL = '01/02/2018'
*/
CREATE PROCEDURE dbo.SP_REC_RELATORIO_GERENCIAL
(
	@DATA_INICIAL DATETIME = NULL
	, @DATA_FINAL DATETIME = NULL
	, @ID_CORRETORA INT = NULL
	, @PRE_BOLETO_STATUS INT = NULL
)
AS
BEGIN

	SELECT
		PB.op_n_boleto
		, OWU.OP_N_ORDEM
		, PB.op_data_inclusao
		, CO.id_corretora
		, CO.co_nome AS NOME_CORRETORA
		, CL.id_cliente
		, ISNULL(CL.cl_nome, CL.cl_razao_social) AS NOME_CLIENTE
		, PB.op_tipo_operacao
		, PB.op_tipo_moeda
		, PB.op_val_moeda
		, PB.op_val_reais
		, PB.op_tx_operacao
		, PB.op_taxa_pronto_d
		, CASE WHEN PB.pre_boleto_status = 3
				THEN OWU.TAXA_CAMBIO_CANCELAMENTO
			END TAXA_CANCELAMENTO
		, CASE WHEN CONVERT(TIME, PB.op_data_inclusao) BETWEEN '09:00' AND '18:00'
				THEN 'Dentro do Hor�rio'
				ELSE 'Fora do Hor�rio'
			END AS HORARIO
		, PB.pre_boleto_status
		, ST.st_descricao
	FROM TBL_PRE_BOLETO PB WITH(NOLOCK, INDEX=IX_TBL_PRE_BOLETO_005)
	LEFT JOIN TBL_REC_ORDENS_WU OWU WITH(NOLOCK)
		ON OWU.OP_N_BOLETO = PB.op_n_boleto
	LEFT JOIN TBL_CORRETORAS CO WITH(NOLOCK)
		ON CO.id_corretora = PB.id_corretora
	LEFT JOIN TBL_CLIENTES CL WITH(NOLOCK)
		ON CL.id_cliente = PB.id_cliente
	LEFT JOIN TBL_STATUS ST WITH(NOLOCK)
		ON ST.st_status = PB.pre_boleto_status
	WHERE PB.op_data_inclusao BETWEEN @DATA_INICIAL AND @DATA_FINAL
		AND EXISTS(SELECT 0 
				FROM TBL_REC_PARAMETRO WITH(NOLOCK) 
				WHERE id_corretora = CO.id_corretora)
		AND CO.id_corretora = CASE WHEN @ID_CORRETORA IS NULL THEN CO.id_corretora ELSE @ID_CORRETORA END
		AND (
				(@PRE_BOLETO_STATUS IS NULL AND PB.pre_boleto_status IN(2, 3))
				OR PB.pre_boleto_status = @PRE_BOLETO_STATUS
			)

END
