USE [IK_Varejo] 
GO

/****** Object:  StoredProcedure [dbo].[SPBR_CALCULARVALOROPERADOCOMPLIANCEINBOUND]    Script Date: 11/13/2017 11:32:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SPBR_CALCULARVALOROPERADOCOMPLIANCEINBOUND]    
    
(    
   @ID_CLIENTE INT,    
   @ID_OPERACAO INT,    
   @TIPO CHAR(1)    
)    
    
AS    

SET NOCOUNT ON

DECLARE @SOMA MONEY    
    
IF UPPER(@TIPO) = 'A'    
BEGIN    
    
   SELECT @SOMA = SUM(ISNULL(P.OP_VAL_REAIS, 0))    
     FROM TBL_PRE_BOLETO P WITH(NOLOCK)   
    WHERE P.ID_CLIENTE = @ID_CLIENTE    
      AND APROVACAO_COMPLIANCE = 'S'    
      AND (ISNULL(PRE_BOLETO_STATUS, '0') IN ('0','1','2','4','5','6')    
      AND UPPER(AP_COMP_SEM_NIVEL) <> 'S'    
      AND P.OP_DATA_SISTEMA >= DATEADD(YEAR, -1, GETDATE())    
      AND P.ID_OPERACAO NOT IN(ISNULL(@ID_OPERACAO, 0)))    
      --AND P.OP_TIPO_ENTREGA = 'REMEXPI'
	  AND OP_N_BOLETO NOT IN(SELECT OP_N_BOLETO FROM TBL_RE_ORDEM_HISTORICO WITH(NOLOCK) WHERE CODIGOEVENTO = 3)
      AND P.OP_TIPO_OPERACAO = 'C'       
      AND NOT EXISTS (SELECT 1   
                      from tbl_re_reversao r WITH(NOLOCK)  
                      where P.op_n_boleto = r.op_n_boleto   
                      OR P.op_n_boleto = R.op_n_boleto_compra)  
      AND NOT EXISTS (SELECT 1   
                      from tbl_reversao_inbound ri WITH(NOLOCK)  
                      where P.op_n_boleto = ri.op_n_boleto   
                      OR P.op_n_boleto = ri.op_n_boleto_venda)   					   
    
END    
    
IF UPPER(@TIPO) = 'M'    
BEGIN    
    
   SELECT @SOMA = SUM(ISNULL(P.OP_VAL_REAIS, 0))    
     FROM TBL_PRE_BOLETO P WITH(NOLOCK)         
    WHERE P.ID_CLIENTE = @ID_CLIENTE    
      AND APROVACAO_COMPLIANCE = 'S'    
      AND (ISNULL(PRE_BOLETO_STATUS, '0') IN ('0','1','2','4','5','6')    
      AND UPPER(AP_COMP_SEM_NIVEL) <> 'S'    
      AND MONTH(P.OP_DATA_SISTEMA) = MONTH(GETDATE())    
      AND YEAR(P.OP_DATA_SISTEMA) = YEAR(GETDATE())    
      AND P.ID_OPERACAO NOT IN(ISNULL(@ID_OPERACAO, 0)))    
      --AND P.OP_TIPO_ENTREGA = 'REMEXPI'
      AND OP_N_BOLETO NOT IN(SELECT OP_N_BOLETO FROM TBL_RE_ORDEM_HISTORICO WITH(NOLOCK) WHERE CODIGOEVENTO = 3)
	  AND P.OP_TIPO_OPERACAO = 'C' 
      AND NOT EXISTS (SELECT 1   
                      from tbl_re_reversao r WITH(NOLOCK)  
                      where P.op_n_boleto = r.op_n_boleto   
                      OR P.op_n_boleto = R.op_n_boleto_compra)
      AND NOT EXISTS (SELECT 1   
                      from tbl_reversao_inbound ri WITH(NOLOCK)  
                      where P.op_n_boleto = ri.op_n_boleto   
                      OR P.op_n_boleto = ri.op_n_boleto_venda) 					    
END    
    
SELECT ISNULL(@SOMA, 0) AS SOMA

SET NOCOUNT OFF



GO


