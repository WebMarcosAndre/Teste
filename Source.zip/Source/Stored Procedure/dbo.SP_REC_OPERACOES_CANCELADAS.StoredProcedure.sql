Use IK_Varejo
Go

IF Object_id('SP_REC_OPERACOES_CANCELADAS') is not null
	Drop Proc SP_REC_OPERACOES_CANCELADAS
;
Go

CREATE PROCEDURE [dbo].[SP_REC_OPERACOES_CANCELADAS]
(
	  @DATA_INICIAL	 DATETIME
	, @DATA_FINAL	 DATETIME
	, @ID_CORRETORA	 INT = NULL
	, @NUM_REGISTROS INT = 0
)
AS
BEGIN
	-- 584109 - 682103 Integra��o Doc/Ted - Fase II - PPV - TW - Melhoria da performance
	SELECT
		PRB.op_n_boleto
		, OWU.op_n_ordem
		, PRB.op_val_moeda
		, PRB.op_val_reais
		, OWU.MOEDA
		, OWU.OP_DATA_STATUS
		, OWU.TAXA_CAMBIO
		, OWU.TAXA_CAMBIO_CANCELAMENTO
		, OWU.TAXA_CAMBIO AS op_taxa_banco
		, COR.co_nome AS CORRETORA
		, CASE WHEN BEN.NOME IS NOT NULL 
			THEN LTRIM(RTRIM(BEN.NOME)) +  ' ' + LTRIM(RTRIM(ISNULL(BEN.SOBRENOME, '')))
			ELSE '' END AS BENEFICIARIO
		, ISNULL(CLI.cl_nome, CLI.cl_razao_social) AS REMETENTE
		, PRB.op_data_inclusao
		, MAX(HO.DATA) AS DATA_CANCELAMENTO
		, PRB.op_tx_operacao
		, PRB.OP_TAXA_PRONTO_D
		, TXTR.Taxa as TX_TRADERATE
		, NAT.nat_codigo
		, NAT.nat_descricao
		, PRB.vlr_iof
		, PRB.op_tarifa_operacao
		, PRB.op_spread
		, OWU.valor_corretora
		, OWU.valor_brsa
		, ((OWU.taxa_cambio_cancelamento - PRB.op_taxa_pronto_d) * PRB.op_val_moeda) AS NET
		, (PRB.OP_TAXA_PRONTO_D - OWU.TaxaAbertura) * PRB.op_val_moeda AS DIF_MERCADO
	FROM TBL_PRE_BOLETO PRB WITH(NOLOCK)
	INNER JOIN TBL_REC_ORDENS_WU OWU WITH(NOLOCK)
		ON OWU.OP_N_BOLETO = PRB.op_n_boleto
	INNER JOIN TBL_CORRETORAS COR WITH(NOLOCK)
		ON COR.id_corretora = OWU.Id_Corretora
	INNER JOIN TBL_CLIENTES CLI WITH(NOLOCK)
		ON CLI.id_cliente = PRB.id_cliente
	LEFT JOIN TBL_NATUREZA NAT WITH(NOLOCK)
		ON NAT.id_natureza = PRB.op_natureza
	LEFT JOIN TBL_REC_HISTORICO_ORDEM HO WITH(NOLOCK)
		ON HO.ID_ORDEM = OWU.OP_N_ORDEM
		AND HO.ID_STATUS = 3
	LEFT JOIN TBL_RE_BENEFICIARIO BEN WITH(NOLOCK)
		ON BEN.id_re_beneficiario = PRB.ID_BENEFICIARIO
	LEFT JOIN TBL_WS_TRADERATE_FXRate TXTR WITH(NOLOCK)
		ON TXTR.FXRateId = OWU.TokenTaxa
		AND TXTR.Cod_Empresa = OWU.Id_Corretora
	WHERE OWU.OP_STATUS = 3
		AND OWU.OP_DATA_STATUS BETWEEN @DATA_INICIAL AND @DATA_FINAL
		AND OWU.Id_Corretora = ISNULL(@ID_CORRETORA, OWU.Id_Corretora)
	GROUP BY
		  PRB.op_n_boleto
		, OWU.op_n_ordem
		, PRB.op_val_moeda
		, PRB.op_val_reais
		, OWU.MOEDA
		, OWU.OP_DATA_STATUS
		, OWU.TAXA_CAMBIO
		, OWU.TAXA_CAMBIO_CANCELAMENTO
		, OWU.TAXA_CAMBIO
		, COR.co_nome
		, BEN.NOME
		, BEN.SOBRENOME
		, CLI.cl_nome
		, CLI.cl_razao_social
		, PRB.op_data_inclusao
		, PRB.op_tx_operacao
		, PRB.OP_TAXA_PRONTO_D
		, TXTR.Taxa
		, NAT.nat_codigo
		, NAT.nat_descricao
		, PRB.vlr_iof
		, PRB.op_tarifa_operacao
		, PRB.op_spread
		, OWU.valor_corretora
		, OWU.valor_brsa
		, ((OWU.taxa_cambio_cancelamento - PRB.op_taxa_pronto_d) * PRB.op_val_moeda)
		, (PRB.OP_TAXA_PRONTO_D - OWU.TaxaAbertura) * PRB.op_val_moeda
	ORDER BY
		PRB.op_n_boleto
	;
END
