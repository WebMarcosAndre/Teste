USE IK_VAREJO
CREATE PROCEDURE SPBCCME_GET_ULTIMAS_TRANSF 
(
	@id_cliente_origem INT ,
	@moeda_debito VARCHAR(10)
)
AS 
SELECT  TOP 20 
			C.id_cliente, 
			cl_razao_social = CASE WHEN C.cl_nome IS NULL THEN CONVERT(VARCHAR(10),C.id_cliente) + ' - ' + SUBSTRING(C.cl_razao_social,1,30) + '...' ELSE  CONVERT(VARCHAR(10),C.id_cliente) + ' - ' + SUBSTRING(C.cl_nome,1,30) + '...' END 
FROM 
		TBL_MEWEB_AGENDA_TRANSFERENCIA AS AT 
INNER JOIN 
		TBL_CLIENTES AS C ON AT.id_cliente_destino = C.id_cliente 
where 
		id_cliente_origem = @id_cliente_origem AND AT.moeda_debito = @moeda_debito
GROUP BY 
		C.id_cliente,C.cl_nome,cl_razao_social
ORDER BY 
		C.cl_razao_social,C.cl_nome		


		