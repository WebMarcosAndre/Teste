USE [IK_Varejo]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[SP_Rel_Limite_Credito_Cliente]    Script Date: 27/06/2019 17:17:29 ******/
/* =====================================================================================================================================
-- Author:		 Gledson Luiz - Consultoria: VINCINT
-- Create date:  25/09/2018
-- Description:	 Procedure que executa o relat�rio de Limite de cr�dito a cada cliente.
-------------------------------------------------------------------------------------------------
-- 683751.1273 - Projeto Migra��o SQL 2016 - Varejo
--					- Select com asterisco
--					- sem With(NoLock) 
-------------------------------------------------------------------------------------------------
Hist�rico de Altera��es
-----------------------------------------------------------------------------------------------------------------------------  
Date		Autor			Description      
25/09/2018	Gledson Luiz	Cria��o vers�o 0.0
08/11/2018	C�ssio Drezza	Altera��o para refinar pesquisas, performance e add. hist�rico do cr�dito
20-11-2018	C�ssio Drezza	Criada a transa��o p/ garantir a integridade dos dados do relat�rio na global ##TMP_CAD_Todos
14-12-2018  C�ssio Drezza	Limpada as informa��es a pedido da Cinthia e n�o h� mais necessidade da global e da transa��o por causa do XML
02-01-2019  C�ssio Drezza	Traduzidos os nomes dos meses
27-06-2019  C�ssio Drezza   683751.1273 - Projeto Migra��o SQL 2016 - Varejo

Usa a PROC SPBR_CalcularValoresOperados alterada com o parametro OUT opcional XML
	Exec SPBR_CalcularValoresOperados 7720	--Retorno original
	Declare @r XML=''; Exec SPBR_CalcularValoresOperados 7720, @r Out; Select @r	--Retorno em XML

--Exemplos:
	Exec SP_Rel_Limite_Credito_Cliente '2018-01-01', '2019-01-01', '"Especial"', '"A"', Null, Null, '"CPF"', '"S","N"'
-- =====================================================================================================================================*/
ALTER Proc [dbo].[SP_Rel_Limite_Credito_Cliente]
(
	@Dt_Inicio				Date		 		-- Pesquisa pelo In�cio da maior Data de opera��o Cota��o/Rendimento
 ,	@Dt_Final				Date		 		-- Pesquisa pelo Final  da maior Data de opera��o Cota��o/Rendimento
 ,	@PRM_CL_NIVEL_CREDITO	VarChar(99)	 		-- "A","B","C","D","E" e "Especial"*
 ,	@Cl_status				VarChar(18)	 		-- "A - Ativo / "I" - Inativo / "B" - Bloqueado*
 ,	@NOME					VarChar(200) = Null	-- Nome do Cliente ou parte do Nome
 ,	@NUM_DOC				Varchar(15)	 = Null	-- CPF/CNPJ ou parte do N�
 ,	@CL_TIP_DOC				VarChar(18)	 		-- "CPF" - Fisica / "CNPJ" - Jur�dica*
 ,	@cl_OperaSomenteBanco	Varchar(15)	 		-- Cliente Opera Somente Banco "S","N" -- Adicionados em 02/11/2018)*
)								-- *.Obrigat�rio estar entre aspas duplas(") Ex.: @Cl_status='"A","I"'
As
Begin
-- Par�metros da procedure
/*
Declare
		@Cl_status				VarChar(08)		= '"A"'			-- A - Ativo / I - Inativo / B - Bloqueado
	,	@CL_TIP_DOC				VarChar(18)		= '"CNPJ"'		-- CPF - Fisica / CNPJ - Jur�dica
	,	@PRM_CL_NIVEL_CREDITO	VarChar(99)		= '"Especial"'	-- A,B,C,D,E e Especial
	,	@NUM_DOC				Varchar(18)		= Null			-- CPF/CNPJ
	,	@NOME					VarChar(600)	= Null			-- Nome do Cliente
	,	@cl_OperaSomenteBanco	Varchar(15)		= '"s","n"'		-- - Cliente Opera Somente Banco S/N	-- Adicionados em 02/11/2018)
	,	@Dt_Inicio				Date			= '2018-01-01'	-- - Pesquisa pelo In�cio da maior Data de opera��o Cota��o/Rendimento
	,	@Dt_Final				Date			= '2019-01-01'	-- - Pesquisa pelo Final  da maior Data de opera��o Cota��o/Rendimento
					begin	--*/
---------------------------------------------------------------------------------------------------------------------------------------
	Set nocount ON;

	Declare
		  @ID_CLIENTE_TEMP Int = Null, @q nVarchar(4000)='', @te DateTime2 = GetDate(), @tt DateTime2 = GetDate()
	; 
	If Object_Id('TempDb..#TMP_CAD'		  )is Not Null	Drop Table #TMP_CAD 
	;
	Set @PRM_CL_NIVEL_CREDITO = Replace(  @PRM_CL_NIVEL_CREDITO,'"', Char(39) )						; 
	Set @Cl_status 			  = Replace(  @Cl_status,		    '"', Char(39) )						;
	Set @Cl_tip_doc			  = Replace(  @Cl_tip_doc,		    '"', Char(39) )						;
	Set @cl_OperaSomenteBanco = Replace(  @cl_OperaSomenteBanco,'"', Char(39) )						; 
	Set @Dt_Inicio			  = Case When @Dt_Inicio is null Then '1900-01-01' Else @Dt_Inicio End	;
	Set @Dt_Final			  = Case When @Dt_Final  is null Then GetDate()+2  Else @Dt_Final  End	;

	-- Modificado em 06/11/2018
	Set @q='Select
				ID_CLIENTE_TEMP = Cast(ID_CLIENTE as BigInt)
				, cl_status
				, Ordenante	= Case c.cl_tip_doc When ''CPF'' Then c.cl_nome Else c.cl_razao_social End 
				, cl_nivel_compliance
				, cl_nivel_credito
				, cl_tip_doc
				, cl_num_doc
				, cl_OperaSomenteBanco
				, Dt_Ult_Oper_Cotacao	 = Cast(''1900-01-01'' as DateTime )
				, Dt_Ult_Oper_Rendimento = Cast(''1900-01-01'' as DateTime )
				, Dt_Pesquisa			 = Cast(''1900-01-01'' as DateTime ) 
			From
				TBL_CLIENTES c with(nolock)
			Where
					(c.CL_STATUS			In( ' + @Cl_status			  + ' ) )
				And	(c.CL_TIP_DOC			In( ' + @CL_TIP_DOC			  + ' ) )
				And	(c.CL_NIVEL_CREDITO		In( ' + @PRM_CL_NIVEL_CREDITO + ' ) )
				And (c.cl_OperaSomenteBanco	In( ' + @cl_OperaSomenteBanco + ' ) )
		' 
		+		Case When @NUM_DOC IS NULL Then '' Else ' AND c.CL_NUM_DOC		Like ''%'+ @NUM_DOC +'%''' End
		+		Case When @NOME	   IS NULL Then '' Else ' AND(c.CL_NOME			Like ''%'+ @NOME	+'%''
														   Or c.CL_RAZAO_SOCIAL Like ''%'+ @NOME	+'%'' )' End
		+ '	Order By ID_CLIENTE '
	;
 	---Print @q
	-- Create Table #TMP_CAD (ID_CHAVE INT IDENTITY(01, 01), ID_CLIENTE_TEMP Int) -- Modificado em 06/11/2018
	Declare @Int_Index_Loop		Int, @MaxID_CLIENTE_TEMP Int
	Declare @ID_CLIENTE_ATUAL	Int
	; -- Print 'T1 Defin.	= '+Convert( VarChar(max), GetDate()-@te, 121 ); set @te=GetDate(); 
	Begin --	tran x -- Garante a integridade da sele��o dos dados do relat�rio na global #Clientes_Todos
	;
		If Object_Id('TempDb..#TMP_CAD_Todos')is Not Null	Drop Table #TMP_CAD_Todos 
		;
		Create Table #TMP_CAD_Todos (
					ID_CLIENTE_TEMP			Bigint			,
					cl_status				Char	(001)	,
					Ordenante				Varchar	(200)	,
					cl_nivel_compliance		Varchar	(008)	,
					cl_nivel_credito		Varchar	(008)	,
					cl_tip_doc				Char	(004)	,
					cl_num_doc				Char	(018)	,
					cl_OperaSomenteBanco	Varchar	(001)	,
					Dt_Ult_Oper_Cotacao		Datetime		,
					Dt_Ult_Oper_Rendimento	Datetime		,
					Dt_Pesquisa				Datetime		
			)
		;
		Insert Into #TMP_CAD_Todos
			Exec SP_ExecuteSql @q -- Cria a Table #TMP_CAD_Todos
		;
		-- Cliente Opera Somente Banco S/N	-- Adicionados em 06/11/2018) S� para Pre_Boleto_Status_Atual = 2 = Efetivado
		Update c Set Dt_Ult_Oper_Cotacao    = IsNull( ( Select Max(o.op_dt_efetivacao) 
														From  dbVarejo.dbo.TBL_OPERACOES o with(nolock) 
														Where Pre_Boleto_Status_Atual = 2 AND o.ID_CLIENTE = c.ID_CLIENTE_TEMP ), Dt_Ult_Oper_Cotacao)
				   , Dt_Ult_Oper_Rendimento = IsNull( ( Select Max(o.op_dt_efetivacao) 
														From ik_Varejo.dbo.TBL_OPERACOES o with(nolock) 
														Where Pre_Boleto_Status_Atual = 2 AND o.ID_CLIENTE = c.ID_CLIENTE_TEMP ), Dt_Ult_Oper_Rendimento)		
					-- Select *
		From #TMP_CAD_Todos c with(nolock)
		;
		Update c Set Dt_Pesquisa = Case When Dt_Ult_Oper_Cotacao>=Dt_Ult_Oper_Rendimento Then Dt_Ult_Oper_Cotacao Else Dt_Ult_Oper_Rendimento End
		From #TMP_CAD_Todos c with(nolock)
		;
		-- Select @q select * from #TMP_CAD	
		IF OBJECT_ID('TempDB..#TB_RETORNO_CLIENTE')IS NOT NULL
			DROP TABLE #TB_RETORNO_CLIENTE;
		;
		CREATE TABLE #TB_RETORNO_CLIENTE
		  (
				Id_Cliente							BigInt			default -1
			,	EXIBIR_ANALITICO					VarChar(008)	default ''
			,	cl_status							VarChar(010)	default ''
			,	Ordenante							VarChar(200)	default ''
			,	cl_nivel_compliance					VarChar(008)	default ''
			,	cl_nivel_credito					VarChar(008)	default ''
			,	cr_limite							MONEY			default -1
			,	cl_num_doc							VarChar(018)	default ''
			,	cl_tip_doc							VarChar(005)	default ''
			,	VALOR_OPERADO_CLIENTE_M				Money			default -1
			,	VALOR_OPERADO_CLIENTE_A				Money			default -1
			,	CREDITO_DISPONIVEL					Money			default -1
			,	VALOR_OP_CREDITO_SEM_NIVEL			Money			default -1
			,	Inf_Cred							VarChar(Max)	default ''
			,	cl_OperaSomenteBanco				varchar(001)	default ''
			,	VALOR_BLOQUEADO						Money			default -1
			,	Data_Ultima_Solicitacao_Credito_COT VarChar(022)	default '-'
			,	Data_Ultima_Solicitacao_Credito_REN VarChar(022)	default '-'
			,	Maior_Data_Sol_Credito				VarChar(022)	default '-'
			,	Dt_Ult_Oper_Cotacao					Datetime
			,	Dt_Ult_Oper_Rendimento				Datetime
		  )
		;
		Select ID_CHAVE = Identity(Int, 01, 01)
			 , ID_CLIENTE_TEMP, cl_status, Ordenante, cl_nivel_compliance, cl_nivel_credito, cl_tip_doc, cl_num_doc, cl_OperaSomenteBanco, Dt_Ult_Oper_Cotacao, Dt_Ult_Oper_Rendimento, Dt_Pesquisa
		Into #TMP_CAD			-- Cria a Temp j� Filtrada pelas DATAS melhorando a performance -- Select *
		From #TMP_CAD_Todos c with(nolock)
		Where
			c.Dt_Pesquisa Between @Dt_Inicio and @Dt_Final
		Order By c.Ordenante
		;
	End		--	Commit tran x
	; -- Print 'T## Tran	= '+Convert( VarChar(max), GetDate()-@te, 121 ); set @te=GetDate();
	Declare @X XML = '' -- Passado como par�metro <> NULL retorna em XML
		,	@T VarChar(max), @dc Varchar(20)='1900-01-01', @dr Varchar(20)='1900-01-01', @vn VarChar(200)='', @nvn int = 1
		,	@dtc DateTime='1900-01-01', @dtr DateTime='1900-01-01' 
	;
	Select @Int_Index_Loop = 1 , @MaxID_CLIENTE_TEMP = Max(ID_CHAVE) From #TMP_CAD
	;
	While @Int_Index_Loop <= @MaxID_CLIENTE_TEMP
	  Begin
		if @vn=(Select lTrim(rTrim(Ordenante)) From #TMP_CAD Where ID_CHAVE = @Int_Index_Loop) begin -- Diferencia nomes iguais
			Update c Set Ordenante=lTrim(rTrim(Ordenante))+'('+cast(@nvn as varchar)+')*' From #TMP_CAD c Where ID_CHAVE = @Int_Index_Loop ;
			Select @ID_CLIENTE_ATUAL = ID_CLIENTE_TEMP, @vn = lTrim(rTrim(Ordenante)), @nvn = @nvn + 1 From #TMP_CAD Where ID_CHAVE = @Int_Index_Loop ;
		  end
		else
			Select @ID_CLIENTE_ATUAL = ID_CLIENTE_TEMP, @vn=lTrim(rTrim(Ordenante)) From #TMP_CAD Where ID_CHAVE = @Int_Index_Loop
		; -- SPBR_CalcularValoresOperados_New_Status
		Execute SPBR_CalcularValoresOperados @ID_CLIENTE_ATUAL, @XML = @X Output
		;
		Insert Into #TB_RETORNO_CLIENTE
			SELECT	@ID_CLIENTE_ATUAL																								-- Id_Cliente
				,	r.c.value('EXIBIR_ANALITICO[1]',			'VarChar(0008)'	)													-- EXIBIR_ANALITICO
				,	Null -- r.c.value('CL_STATUS[1]',				'VarChar(0010)'	)- Comentado p/ usar a mesma PROC				-- cl_status
				,	Null -- r.c.value('CL_NOME[1]',					'VarChar(1000)'	)- SPBR_CalcularValoresOperados p/todos os App.	-- Ordenante
				,	Null -- r.c.value('CL_NIVEL_COMPLIANCE[1]',		'VarChar(0008)'	)												-- cl_nivel_compliance
				,	Null -- r.c.value('CL_NIVEL_CREDITO[1]',		'VarChar(0008)'	)												-- cl_nivel_credito
				,	r.c.value('CR_LIMITE[1]',					'Money'			)													-- cr_limite
				,	Null -- r.c.value('CL_NUM_DOC[1]',				'VarChar(0018)'	)												-- cl_num_doc
				,	Null -- r.c.value('CL_TIP_DOC[1]',				'VarChar(0005)'	)												-- cl_tip_doc
				,	r.c.value('VALOR_OPERADO_CLIENTE_M[1]',		'Money'			) -- Soma de Cot + Rend								-- VALOR_OPERADO_CLIENTE_M
				,	r.c.value('VALOR_OPERADO_CLIENTE_A[1]',		'Money'			) -- Soma de Cot + Rend								-- VALOR_OPERADO_CLIENTE_A
				,	r.c.value('CREDITO_DISPONIVEL[1]',			'Money'			)													-- CREDITO_DISPONIVEL
				,	r.c.value('VALOR_OP_CREDITO_SEM_NIVEL[1]',	'Money'			) -- VALOR_OP_CREDITO_SEM_NIVEL						-- VALOR_OP_CREDITO_SEM_NIVEL
				,	r.c.value('Inf_Cred[1]',					'VarChar(MAX)'	)													-- Inf_Cred
				,   Null																											-- cl_OperaSomenteBanco
				,	r.c.value('VALOR_BLOQUEADO[1]',				'Money'			) -- Soma de VALOR_BLOQUEADO Cot + Rend				-- VALOR_BLOQUEADO
				,	Data_Ultima_Solicitacao_Credito_COT		='1900-01-01'
				,	Data_Ultima_Solicitacao_Credito_REN		='1900-01-01'
				,	Maior_Data_Sol_Credito					='1900-01-01'
				,	Dt_Ult_Oper_Cotacao						= Null
				,	Dt_Ult_Oper_Rendimento					= Null
			FROM
				@X.nodes('row') As R(c)
		;		
		Select @T=Inf_Cred From #TB_RETORNO_CLIENTE t with(nolock) Where [id_cliente] = @ID_CLIENTE_ATUAL	
		;
		if CharIndex('Cr�dito COTA��O:'+Char(10)+'[Dat.Solic.]: ', @T,0) > 0 Begin -- Coloca a Data caso ela exista
			Set @dc =  Substring( @T
								, CharIndex('Cr�dito COTA��O:'+Char(10)+'[Dat.Solic.]: '
											, @T,0)+31
								, 11 ) 
			;
			Set @dtc = @dc
			;
			Update t Set Data_Ultima_Solicitacao_Credito_COT = @dc
			From #TB_RETORNO_CLIENTE t Where [id_cliente] = @ID_CLIENTE_ATUAL
		 End
		;
		if CharIndex('Cr�dito RENDIMENTO:'+Char(10)+'[Dat.Solic.]: ', @T,0) > 0 Begin -- Coloca a Data caso ela exista
			Set @dr =  Substring( @T
								, CharIndex('Cr�dito RENDIMENTO:'+Char(10)+'[Dat.Solic.]: '
											, @T,0)+34
								, 11 ) 
			;
			Set @dtr = @dr
			;
			Update t Set Data_Ultima_Solicitacao_Credito_REN = @dr
			From #TB_RETORNO_CLIENTE t with(nolock) Where [id_cliente] = @ID_CLIENTE_ATUAL
		 End
		;
		if @dtr >= @dtc --  Data Maior entre as 2 anteriores
			Update t Set Maior_Data_Sol_Credito = Case IsDate(@dr) when 1 then Convert(Varchar(11),@dr,113) else '-' end
			From #TB_RETORNO_CLIENTE t with(nolock) Where [id_cliente] = @ID_CLIENTE_ATUAL	
		else
			Update t Set Maior_Data_Sol_Credito = Case IsDate(@dc) when 1 then Convert(Varchar(11),@dc,113) else '-' end
			From #TB_RETORNO_CLIENTE t with(nolock) Where [id_cliente] = @ID_CLIENTE_ATUAL			
		;
		Select @dr='1900-01-01', @dc='1900-01-01', @dtr='1900-01-01', @dtc='1900-01-01'
		;
		Set @Int_Index_Loop = @Int_Index_Loop + 1 
	  End
	;
	Update r Set 
		  r.cl_status				= c.cl_status			
		, r.Ordenante				= c.Ordenante				
		, r.cl_nivel_compliance		= c.cl_nivel_compliance	
		, r.cl_nivel_credito		= c.cl_nivel_credito	
		, r.cl_tip_doc				= c.cl_tip_doc
		, r.cl_OperaSomenteBanco	= c.cl_OperaSomenteBanco
		, r.Maior_Data_Sol_Credito	= Replace( Replace( Replace( Replace( Replace( Replace( Replace( Replace( r.Maior_Data_Sol_Credito, '1900-01-01', '-'), '.feb.', '.fev.'), '.apr.', '.abr.'), '.may.', '.mai.'), '.aug.', '.ago.'), '.sep.', '.set.'), '.oct.', '.out.'), '.dec.', '.dez.')
		, r.Dt_Ult_Oper_Cotacao		= Case when c.Dt_Ult_Oper_Cotacao   ='1900-01-01' then NULL else c.Dt_Ult_Oper_Cotacao    End
		, r.Dt_Ult_Oper_Rendimento	= Case when c.Dt_Ult_Oper_Rendimento='1900-01-01' then NULL else c.Dt_Ult_Oper_Rendimento End
		, r.Inf_Cred				= Replace( Replace( Replace( Replace( Replace( Replace( Replace( r.Inf_Cred, '.feb.', '.fev.'), '.apr.', '.abr.'), '.may.', '.mai.'), '.aug.', '.ago.'), '.sep.', '.set.'), '.oct.', '.out.'), '.dec.', '.dez.')
		, r.cl_num_doc = Case len(rTrim(lTrim(c.cl_num_doc)))
							When 11 Then Stuff(Stuff(Stuff(      rTrim(lTrim(c.cl_num_doc)),4,0,'.'),8,0,'.'),12,0,'-')			  -- Formata o CPF
							When 14 Then Stuff(Stuff(Stuff(Stuff(rTrim(lTrim(c.cl_num_doc)),3,0,'.'),7,0,'.'),11,0,'/'),16,0,'-') -- Formata o CNPJ
							Else rTrim(lTrim(c.cl_num_doc))	--| 02834563460		  64233123000122		-- Formata CPF e CNPJ
						 End								--| 12345678901234    123456789012345678
	From #TB_RETORNO_CLIENTE r with(nolock)				 	--V 028.345.634-60 ou 64.233.123/0001-22
	Join #TMP_CAD c with(nolock) 
		On c.Id_Cliente_temp=r.Id_Cliente
	;
	SELECT Id_Cliente, EXIBIR_ANALITICO, cl_status, Ordenante, cl_nivel_compliance, cl_nivel_credito, cr_limite, cl_num_doc, cl_tip_doc, VALOR_OPERADO_CLIENTE_M, VALOR_OPERADO_CLIENTE_A, CREDITO_DISPONIVEL, VALOR_OP_CREDITO_SEM_NIVEL, Inf_Cred, cl_OperaSomenteBanco, VALOR_BLOQUEADO, Data_Ultima_Solicitacao_Credito_COT, Data_Ultima_Solicitacao_Credito_REN, Maior_Data_Sol_Credito, Dt_Ult_Oper_Cotacao, Dt_Ult_Oper_Rendimento
	FROM
		#TB_RETORNO_CLIENTE with(nolock)
	; -- Print 'T Depois	= '+Convert( VarChar(max), GetDate()-@te, 121 ); set @te=GetDate(); Print 'T Total		= '+Convert( VarChar(max), GetDate()-@tt, 121 );
End
;
Go
/*
---------------------------------------------------------------------------------
Select  "@Dt_Inicio				"=@Dt_Inicio		
	,	"@Dt_Final				"=@Dt_Final
	,	"@PRM_CL_NIVEL_CREDITO	"=@PRM_CL_NIVEL_CREDITO -- A,B,C,D,E, Especial
	,	"@Cl_status				"=@Cl_status			-- A,B,I
	,	"@NOME					"=@NOME
	,	"@NUM_DOC				"=@NUM_DOC
	,	"@CL_TIP_DOC			"=@CL_TIP_DOC			-- CNPJ, CPF 
	,	"@cl_OperaSomenteBanco	"=@cl_OperaSomenteBanco -- N,S
;--* ,
Select c.cl_nivel_credito, count(1)
from TBL_CLIENTES c with(nolock)
group by cl_nivel_credito
order by cl_nivel_credito
;
select * from #TMP_CAD
Pre_Boleto_Status_Atual = 2
*/
