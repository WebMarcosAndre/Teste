USE [IK_VAREJO]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[SPBCCME_Emitir_Comprovante_Transferencia]    Script Date: 02/07/2019 16:15:48 ******/
-- =====================================================================================================================================
-- Author:		
-- Create date: 
-- Description:	
-------------------------------------------------------------------------------------------------
-- 683751.1273 - Projeto Migra��o SQL 2016 - Varejo
--					- (No|ock) sem With
-------------------------------------------------------------------------------------------------
-- Hist�rico Altera��es
-- *********************
-- PRG_____________________________________________________________ Data_____ Autor________ Descri��o__________________________________________
-- dbo.SPBCCME_Emitir_Comprovante_Transferencia.StoredProcedure.sql 02/jul/19 C�ssio Drezza 683751.1273 - Projeto Migra��o SQL 2016 - Varejo
-- =====================================================================================================================================
ALTER PROCEDURE [dbo].[SPBCCME_Emitir_Comprovante_Transferencia] 
(
  @ID_TRANSF INT,
  @ID_CLIENTE INT
)
AS
BEGIN

	SELECT 
		A.ID_TRANSF, 
		M.MOE_DESCCCME AS MOEDA_DEBITO, 
		A.VALOR_DEBITO, 
		M2.MOE_DESCCCME AS MOEDA_TARIFA, 
		A.VALOR_TARIFA, 
		A.OBSERVACAO, 
		DATA_EFETIVACAO = CONVERT(VARCHAR(20),A.DATA_DEBITO, 103) + ' ' + CONVERT(VARCHAR(20),A.DATA_DEBITO,108),
		CASE WHEN C.CL_TIP_DOC = 'CPF' THEN C.CL_NOME ELSE C.CL_RAZAO_SOCIAL END AS CL_NOME_ORIGEM, RTRIM(LTRIM(C.CL_NUM_DOC)) AS CONTA_ORIGEM,
		CASE WHEN CD.CL_TIP_DOC = 'CPF' THEN CD.CL_NOME ELSE CD.CL_RAZAO_SOCIAL END AS CL_NOME_DESTINO, RTRIM(LTRIM(A.CONTA_DESTINO)) AS CONTA_DESTINO,
		(CAST (A.ID_HISTORICO AS VARCHAR(20)) + '::' + H.HIS_DESCRICAO) AS HIS_DESCRICAO,
		TIPOMOV = 'D�bito - Transfer�ncia entre CCME Banco Rendimento',
		REMETENTE = CASE WHEN C.CL_TIP_DOC = 'CPF' THEN C.CL_NOME + ' (Nr. Conta ' + CONVERT(varchar(15), C.id_cliente) + ')'  ELSE C.CL_RAZAO_SOCIAL + ' (Nr. Conta ' + CONVERT(varchar(15), C.id_cliente) + ')' END ,
		BENEFICIARIO = CASE WHEN CD.CL_TIP_DOC = 'CPF' THEN CD.CL_NOME + ' (Nr. Conta ' + CONVERT(varchar(15), CD.id_cliente) + ')' ELSE CD.CL_RAZAO_SOCIAL + ' (Nr. Conta ' + CONVERT(varchar(15), CD.id_cliente) + ')' END ,
		DESC_OBSERVACAO = CASE WHEN OBSERVACAO IS NOT NULL THEN 'Observa��o:' ELSE '' END
		
	FROM TBL_MEWEB_AGENDA_TRANSFERENCIA A
	INNER JOIN TBL_MOEDAS M With(NoLock) ON A.MOEDA_DEBITO = M.MOE_SIMBOLO
	INNER JOIN TBL_MOEDAS M2 With(NoLock) ON A.MOEDA_TARIFA = M2.MOE_SIMBOLO
	INNER JOIN TBL_CLIENTES C ON A.ID_CLIENTE_ORIGEM = C.ID_CLIENTE
	INNER JOIN TBL_CLIENTES CD ON A.ID_CLIENTE_DESTINO = CD.ID_CLIENTE
	INNER JOIN TBL_ME_HISTORICO H ON H.HIS_CODIGO = A.ID_HISTORICO
	WHERE A.ID_CLIENTE_ORIGEM = @ID_CLIENTE
	  AND A.ID_TRANSF = @ID_TRANSF
	;
END
;
Go

-- Teste
-- Exec SPBCCME_Emitir_Comprovante_Transferencia 1, 123
