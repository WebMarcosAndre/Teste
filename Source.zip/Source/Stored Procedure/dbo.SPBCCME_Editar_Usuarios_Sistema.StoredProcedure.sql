USE IK_VAREJO
GO

IF EXISTS(SELECT NAME FROM SYSOBJECTS WHERE NAME = 'SPBCCME_Editar_Usuarios_Sistema')
	DROP PROC DBO.SPBCCME_Editar_Usuarios_Sistema
GO



/***
	Nome: SPBCCME_Editar_Usuarios_Sistema
	Desc: 
	Autor:
	Data:
	***********************
	Hist�rico de Altera��es
	***********************
	PR								Date		Autor				Description	
	SPBCCME_Editar_Usuarios_Sistema	22/04/2019	Cidicley Rodrigues  Incluir os campos li_Data_Nascimento, li_DDI
																	
***/


CREATE PROCEDURE [dbo].[SPBCCME_Editar_Usuarios_Sistema]  
  (  
   @NUM_DOC_MASTER VARCHAR(25),  
   @LI_ID          INT  
  )  
  
AS  
  
SELECT LI_ID, LI_NOME, LI_EMAIL, LI_DOC, LI_VALIDADE,   
       LI_STATUS = (CASE LI_STATUS WHEN 'A' THEN 'Ativo' ELSE 'Inativo' END),  
       LI_EDITA_OP = (CASE LI_EDITA_OP WHEN 'S' THEN 'Sim' ELSE 'N�o' END),  
       LI_CANCELA_OP = (CASE LI_CANCELA_OP WHEN 'S' THEN 'Sim' ELSE 'N�o' END),
       LI_APROVA_OP, LI_HABILITA_INTEGRACAO,
	   LI_DATA_NASCIMENTO, LI_DDD, LI_CELULAR, LI_DDI
  FROM TBL_LOGIN_INTEGRADO WITH(NOLOCK)
 WHERE LI_DOC LIKE @NUM_DOC_MASTER + '%'  
   AND LI_ID = @LI_ID
