USE IK_VAREJO
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[SP_REL_Report_Contr_Is_IOF_V_00]    Script Date: 02/07/2019 12:26:14 ******/
-- =====================================================================================================================================
-- Author     : Gledson Luiz 	
-- Create date: 18/09/2018
-- Description: Procedure de Relat�rio para Controle de Isen��o de IOF por Cliente
-------------------------------------------------------------------------------------------------
-- 683751.1273 - Projeto Migra��o SQL 2016 - Varejo
--					- (No|ock) sem With
-------------------------------------------------------------------------------------------------
-- Hist�rico Altera��es
-- *********************
-- PRG____________________________________________________ Data_____ Autor________ Descri��o__________________________________________
-- dbo.SP_REL_Report_Contr_Is_IOF_V_00.StoredProcedure.sql 02/jul/19 C�ssio Drezza 683751.1273 - Projeto Migra��o SQL 2016 - Varejo
-- =====================================================================================================================================
ALTER PROC [dbo].[SP_REL_Report_Contr_Is_IOF_V_00]
(    
    @DATA_INICIO    Datetime        = Null
,    @DATA_FIM        DateTime        = Null
,    @NOME            VarChar(500)    = Null
,    @NUM_DOC        VarChar(015)    = Null
,    @STATUS_CLI        Char(01)        = Null
,    @STATUS_IOF        Char(01)        = Null
,    @STATUS_BAN        Char(01)        = Null
)

As
Begin
    Set NoCount On;
    
    --Declare    
    --    @DATA_INICIO    Datetime     = '2014-11-06 00:00:00.000'
    --,    @DATA_FIM        DateTime     = '2014-11-06 23:59:59.999'    
    --,    @NOME            VarChar(500) = Null    
    --,    @NUM_DOC        VarChar(015) = Null   
    --,    @STATUS_CLI        Char(01)     = Null A - Ativo / I - Inativo
    --,    @STATUS_IOF        Char(01)     = Null S - Sim / N - N�o
    --,    @STATUS_BAN        Char(01)     = 'N'  S - Sim / N - N�o
    
/**************************************************************************            
Nome        : SP_REL_Report_Contr_Is_IOF_V_00    
Desc        : Procedure de Relat�rio para Controle de Isen��o de IOF por    
            : Cliente    
Analista    :- Consultoria: VINCINT      
Data        : 18/09/2018

*****************************      
Hist�rico de Altera��es        :      
*****************************      
      
PR                        Date        Autor            Description          
SP_Report_Contr_Is_IOF 18/09/2018    Gledson Luiz    Cria��o vers�o 0.0    
SP_Report_Contr_Is_IOF 02/10/2018    Gledson Luiz    Inclus�o de campo de pesquisa e no resultado de coluna 'STATUS_BANCO' vinda da coluna
                                                     CL_OPERASOMENTEBANCO da tabela de cliente.
SP_Report_Contr_Is_IOF 02/10/2018    Gledson Luiz    Altera��o de Etiqueta S - Sim/N - N�o e A - Ativo/I - Inativo.
    
--Sample         
  --Exec dbo.SP_REL_Report_Contr_Is_IOF_V_00 '2014-11-06 00:00:00.000', '2014-11-06 23:59:59.999', Null, Null, 'A', 'S', Null
                                            
Exec dbo.SP_REL_Report_Contr_Is_IOF_V_00      Null, Null, Null, Null, 'A', 'S', 'N'

**************************************************************************/    
    
    SELECT
        CASE    
            WHEN TB_CLI.CL_TIP_DOC = 'CPF'
            THEN TB_CLI.CL_NOME
            ELSE TB_CLI.CL_RAZAO_SOCIAL
        END                    'NOME'
    ,    TB_CLI.CL_NUM_DOC   'NUM_DOC'    
    ,    CASE
            WHEN TB_CLI.IOF_ISENTO = 'N'    
            THEN 'N�o'
            ELSE 'Sim'
        END                    'STATUS_IOF'
    ,    CASE
            WHEN TB_CLI.CL_STATUS = 'A'
            THEN 'Ativo'
            ELSE 'Inativo'
        END                    'STATUS_CLI'
    ,    RTRIM(LTRIM(ISNULL(TB_APRE.AP_NOME, ''))) 'DESC_APREST'
    ,    CASE
            WHEN TB_CLI.CL_OPERASOMENTEBANCO = 'N'
            THEN 'N�o'
            ELSE 'Sim'
        END                    'STATUS_BANCO'
    FROM
        TBL_CLIENTES TB_CLI With(NoLock) LEFT JOIN TBL_APRESENTANTE TB_APRE With(NoLock) ON TB_CLI.ID_APRESENTANTE = TB_APRE.ID_AP
    WHERE
        ((@NUM_DOC  IS NOT NULL AND TB_CLI.CL_NUM_DOC = @NUM_DOC) OR (@NUM_DOC IS NULL))
    AND (((@NOME   IS NOT NULL AND TB_CLI.CL_NOME LIKE '%' + @NOME + '%') OR (@NOME IS NULL))
        Or ((@NOME   IS NOT NULL AND TB_CLI.CL_RAZAO_SOCIAL LIKE '%' + @NOME + '%') OR (@NOME IS NULL)))
    AND ((@STATUS_CLI IS NOT NULL AND TB_CLI.CL_STATUS LIKE '%' + @STATUS_CLI + '%') OR (@STATUS_CLI IS NULL))
    AND ((@STATUS_IOF IS NOT NULL AND TB_CLI.IOF_ISENTO LIKE '%' + @STATUS_IOF + '%') OR (@STATUS_IOF IS NULL))
    AND ((@STATUS_CLI IS NOT NULL AND TB_CLI.CL_STATUS LIKE '%' + @STATUS_CLI + '%') OR (@STATUS_CLI IS NULL))
    AND ((@STATUS_BAN IS NOT NULL AND TB_CLI.CL_OPERASOMENTEBANCO = @STATUS_BAN) OR (@STATUS_BAN IS NULL))
    AND ((@DATA_INICIO  IS NOT NULL     
    AND @DATA_FIM IS NOT NULL     
    AND TB_CLI.CL_DT_INCLUSAO >= @DATA_INICIO     
    AND TB_CLI.CL_DT_INCLUSAO < DATEADD(DAY, 1, @DATA_FIM))    
        OR    
        (@DATA_INICIO IS NULL AND @DATA_FIM IS NULL))
    ORDER BY
        TB_CLI.CL_NOME        , TB_CLI.CL_RAZAO_SOCIAL, TB_CLI.CL_NUM_DOC
    ,    TB_CLI.IOF_ISENTO    , TB_CLI.CL_STATUS        , TB_APRE.AP_NOME

END
;
Go

-- Teste
-- Exec dbo.SP_REL_Report_Contr_Is_IOF_V_00      Null, Null, Null, Null, 'A', 'S', 'N'
