USE [IK_VAREJO]
GO

/****** Object:  StoredProcedure [dbo].[SP_WebApiPortalCambio_Excluir_Usuario]    Script Date: 08/30/2017 15:02:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[SP_WebApiPortalCambio_Excluir_Usuario]    
    @UserID int    
AS
BEGIN
	
	DELETE 
		Tbl_WebApiPortalCambio_Usuarios	
	WHERE
		UserID = @UserID
END
	




GO


