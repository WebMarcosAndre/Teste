USE [IK_VAREJO]
GO
/****** Object:  StoredProcedure [dbo].[SPBCCME_Detalhes_Operacao]    Script Date: 11/21/2017 16:28:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
    
ALTER PROCEDURE [dbo].[SPBCCME_Detalhes_Operacao]    
   (    
   @ID_OP INT,    
   @ID_CLIENTE INT    
   )    
AS    
    
SELECT	MO.MOE_DESCCCME, 
		(CASE	WHEN M.MOV_TIPO = 'D' 
				THEN 'D�bito - Transfer�ncia entre CCME Banco Rendimento' 
				ELSE 'Cr�dito - Transfer�ncia entre CCME Banco Rendimento' END) AS MOV_TIPO, 
		M.MOV_VALOR, 
		M.MOV_TIPO_OP, 
		MOV_DATA =  CONVERT(VARCHAR(100), M.MOV_DATA,103) + ' ' + CONVERT(VARCHAR(20),M.mov_data,108),    
		M.MOV_HISTORICO, 
		h.HIS_DESCRICAO , 
		MOV_OBS = CASE	WHEN M.MOV_TIPO_OP = 'ARBITRAGEM' 
						THEN CAST (M.MOV_HISTORICO AS VARCHAR(20))+ M.MOV_OBSERVACAO + ' - ' + H.his_tipo 
						ELSE  M.MOV_OBS END, 
		PA.NM_CAMPO,MT.idSwift  ,
		Remetente = CASE	WHEN M.mov_tipo = 'D' 
							THEN  CASE	WHEN mov_tipo_op = 'TRANSF' 
										THEN '<br/><br/> Remente: Nr Conta '  + (SELECT CASE	WHEN C.cl_nome IS NULL 
																								THEN CONVERT(VARCHAR(10),C.id_cliente) + ' - ' + SUBSTRING(C.cl_razao_social,1,30) + '...' 
																								ELSE  CONVERT(VARCHAR(10),C.id_cliente) + ' - ' + SUBSTRING(C.cl_nome,1,30) + '...' END   FROM TBL_CLIENTES AS C WHERE M.mov_cliente = C.id_cliente) 
																								ELSE '' END ELSE CASE WHEN mov_tipo_op = 'TRANSF' THEN '<br/><br/> Remente: Nr Conta '  + (	SELECT CASE WHEN C.cl_nome IS NULL 
																																																		THEN CONVERT(VARCHAR(10),C.id_cliente) + ' - ' + SUBSTRING(C.cl_razao_social,1,30) + '...' 
																																																		ELSE  CONVERT(VARCHAR(10),C.id_cliente) + ' - ' + SUBSTRING(C.cl_nome,1,30) + '...' 
																																																		END   
																																															FROM	TBL_CLIENTES C
																																															INNER JOIN TBL_ME_MOVIMENTACAO MOV
																																															ON C.id_cliente = MOV.mov_cliente
																																															AND MOV.id_mov = M.ID_MOV_ORIGEM) ELSE '' END END ,
		Beneficiario = CASE WHEN mov_tipo_op = 'TRANSF' 
							THEN '<br/> Benefici�rio: Nr Conta '  + (	SELECT CASE WHEN C.cl_nome IS NULL THEN CONVERT(VARCHAR(10),C.id_cliente) + ' - ' + SUBSTRING(C.cl_razao_social,1,30) + '...' ELSE  CONVERT(VARCHAR(10),C.id_cliente) + ' - ' + SUBSTRING(C.cl_nome,1,30) + '...' END   
																		FROM	TBL_CLIENTES C
																		INNER JOIN TBL_ME_MOVIMENTACAO MOV
																		ON C.id_cliente = MOV.mov_cliente 
																		AND MOV.id_mov = M.ID_MOV_DESTINO ) ELSE '' END 
FROM TBL_ME_MOVIMENTACAO M WITH(NOLOCK)    
INNER JOIN TBL_ME_HISTORICO H WITH(NOLOCK) 
ON H.HIS_CODIGO = M.MOV_HISTORICO    
INNER JOIN TBL_MOEDAS MO WITH(NOLOCK) 
ON M.MOV_MOEDA = MO.MOE_SIMBOLO  
LEFT JOIN TBL_MEWEB_MT103 MT WITH(NOLOCK) 
ON M.ID_MOV = MT.ID_LANC  
LEFT JOIN TBL_VAREJO_PARAMETROS PA WITH(NOLOCK)
ON PA.VL_CAMPO = CONVERT(VARCHAR,M.mov_cliente)     
WHERE M.ID_MOV = @ID_OP    
AND M.MOV_CLIENTE = @ID_CLIENTE 
      
