USE IK_VAREJO 
GO 

CREATE PROCEDURE [dbo].[SP_RE_GRAVA_EMAIL_BB_AUTOMATICO](    
   @IDSistema INT,    
   @Destino VARCHAR(1000),    
   @CopiaOculta VARCHAR(500),    
   @Assunto VARCHAR(255),    
   @Corpo VARCHAR(MAX), 
   @LOTES_AGRP VARCHAR(MAX) = NULL,
   @DES_METODO	VARCHAR(50)	= NULL,     
   @DES_LOG VARCHAR(MAX),
   @NOME_EXCEL_CRED_DEB VARCHAR(500) = NULL, 
   @CORRETORA VARCHAR(500)
) AS    
    
BEGIN   

--DECLARE @IDSistema INT,    
--        @Destino VARCHAR(1000),    
--        @CopiaOculta VARCHAR(500),    
--        @Assunto VARCHAR(255),    
--        @Corpo VARCHAR(MAX), 
--        @LOTES_AGRP VARCHAR(MAX),
--        @DES_METODO	VARCHAR(50)	= NULL,     
--        @DES_LOG VARCHAR(MAX),
--        @NOME_EXCEL_CRED_DEB VARCHAR(500) = NULL, 
--        @CORRETORA VARCHAR(500)
        
--SET @IDSistema = 29 
--SET @Destino = 'palves11@globo.com'
--SET @CopiaOculta = 'samuel.oliveira@rendimento.com.br;cristiano.macedo@cotacao.com.br;rodrigo.salmazio@remessaexpressa.com.br;anderson.cancian@cotacao.com.br;leda.mendes@remessaexpressa.com.br;'
--SET @Assunto = 'Boleto de cobran�a � Remessa Expressa'
--SET @Corpo = '<html>xx<head><title>Cota&ccedil;&atilde;o - Remessa Expressa</title></head><style type=''text/css''>.fonte_preta{font-family:tahoma,sans-serif;font-size:12px;line-height:16px;color:#000000;text-align:center;}</style><body><p></p><table border=''1'' cellpadding=''1'' cellspacing=''1'' width=''900''  align=''center'' bgcolor=''#dddddd''><tr><th colspan=''5''> <b> - REMESSA EXPRESSA - </b> </th></tr><tr><th colspan=''5'' class=''fonte_preta''><b> Opera&ccedil;&otilde;es do boleto banc&aacute;rio gerado em teste</b></th></tr><tr><th class=''fonte_preta''>&nbsp;&nbsp;Tipo Opera&ccedil;&atilde;o&nbsp;&nbsp;</th><th class=''fonte_preta''>&nbsp;&nbsp;Qtde de Boletos&nbsp;&nbsp;<br /></th><th class=''fonte_preta''>&nbsp;&nbsp;Valor ME&nbsp;&nbsp;</th><th class=''fonte_preta''>&nbsp;&nbsp;Valor Total&nbsp;&nbsp;</th><th class=''fonte_preta''>&nbsp;&nbsp;OBS&nbsp;&nbsp;</th></tr><tr><td class=''fonte_preta'' style=''color: #000000;background-color:#FFFFFF;text-align:center;''>OUTBOUND</td><td class=''fonte_preta'' style=''color: #000000;background-color:#FFFFFF;text-align:center;''>3</td><td class=''fonte_preta'' style=''color: #000000;background-color:#FFFFFF;text-align:center;''>17,81</td><td class=''fonte_preta'' style=''color: #000000;background-color:#FFFFFF;text-align:center;''>93,18</td><td class=''fonte_preta'' style=''color: #000000;background-color:#FFFFFF;text-align:center;''></td></tr><tr><th colspan=''5''></th></tr><tr><td class=''fonte_preta'' style=''text-align:left;'' colspan=''3''>Total Geral:</td><td class=''fonte_preta'' style=''white-space:nowrap;text-align:center;'' style=''color: #000000;''>R$ 93,18</td><td class=''fonte_preta'' style=''white-space:nowrap;'' style=''color: #000000;''></td></tr></table><br /><br /></body></html>'
--SET @LOTES_AGRP = 3923
--SET @DES_METODO = 'Grava E-mail DBVAREJO'
--SET @DES_LOG = 'Air Brazil Turismo e Servicos Ltda -ME. Id_Email: '
--SET @CORRETORA = 'Air Brazil Turismo e Servicos Ltda -ME'

DECLARE @NOME_EXCEL VARCHAR(300)
 

  
	DECLARE @IDEmail INT, @Erro INT, @ITEM_ARRAY VARCHAR(200), @IDAnexo  INT
	DECLARE @ARRAY VARCHAR(8000), @DELIMITADOR VARCHAR(100), @S VARCHAR(8000)   
	IF NOT EXISTS(SELECT * FROM EMAIL_SERVICE..TBL_EMAIL WITH(NOLOCK) WHERE CONVERT(VARCHAR(MAX), Corpo_Email) =  @Corpo) 
	BEGIN 
	  BEGIN TRAN
		INSERT INTO TBL_Email(ID_Sistema, Destino_Email, CopiaOculta_Email, Assunto_Email, Corpo_Email, DATA_EMAIL, ENVIADO, CORRETORA, TIPO)    
		VALUES               (@IDSistema,      @Destino,      @CopiaOculta,      @Assunto,      @Corpo,  GETDATE(),     'N', @CORRETORA, 'A')    
		    
		SET @IDEmail = @@IDENTITY 
		
		
		INSERT INTO [TBL_RE_LOG_BOLETO_BANCARIO] (  DTA_LOG,  METODO_LOG,                                   DES_LOG) 
		VALUES                                   (GETDATE(), @DES_METODO, @DES_LOG + Convert(varchar(50), @IDEmail))
			
		IF (@LOTES_AGRP IS NULL) OR (@LOTES_AGRP = '0')
		BEGIN 
		  IF NOT EXISTS (SELECT ARQUIVO_ANEXO FROM TBL_ANEXO WITH(NOLOCK) WHERE ARQUIVO_ANEXO LIKE '%' + @NOME_EXCEL + '%')
		  BEGIN 
			INSERT INTO TBL_ANEXO(ID_Email,        Arquivo_Anexo, DATA_ANEXO)  
			VALUES               (@IDEmail, @NOME_EXCEL_CRED_DEB,  GETDATE())
		           
			INSERT INTO [TBL_RE_LOG_BOLETO_BANCARIO] (  DTA_LOG,   METODO_LOG,                                                                               DES_LOG)    
			VALUES                                   (GETDATE(),  @DES_METODO, 'Anexo do Id_Email DBVAREJO: ' + CONVERT(VARCHAR(50), @IDEmail) + ' - ' + @NOME_EXCEL_CRED_DEB)				
		   END 
		END 
		ELSE
		BEGIN
			
			SELECT @ARRAY =	@LOTES_AGRP
			SELECT @DELIMITADOR = '|'

			IF LEN(@ARRAY) > 0 SET @ARRAY = @ARRAY + @DELIMITADOR    

			CREATE TABLE #ARRAY(ITEM_ARRAY VARCHAR(8000))   

			WHILE LEN(@ARRAY) > 0   

			BEGIN  

			  SELECT @S = LTRIM(SUBSTRING(@ARRAY, 1, CHARINDEX(@DELIMITADOR, @ARRAY) - 1))   

			  INSERT INTO #ARRAY (ITEM_ARRAY) VALUES (@S)   

			  SELECT @ARRAY = SUBSTRING(@ARRAY, CHARINDEX(@DELIMITADOR, @ARRAY) + 1, LEN(@ARRAY))--)
			end 
			
			DECLARE INSERT_CURSOR CURSOR FOR 
			 SELECT ITEM_ARRAY
			   FROM #ARRAY
			 OPEN INSERT_CURSOR
			FETCH NEXT FROM INSERT_CURSOR INTO @ITEM_ARRAY
			
			WHILE @@FETCH_STATUS=0
			BEGIN
				--INSERI NA ANEXO
				INSERT INTO TBL_ANEXO(ID_Email, Arquivo_Anexo, DATA_ANEXO) 
				SELECT DISTINCT @IDEmail, L.NOME_ARQUIVO_PDF, GETDATE()
				  FROM TBL_RE_LOTE L WITH(NOLOCK) 
				 WHERE L.ID_LOTE = @ITEM_ARRAY
		        
				INSERT INTO [TBL_RE_LOG_BOLETO_BANCARIO] (DTA_LOG,METODO_LOG,DES_LOG) 
				SELECT DISTINCT GETDATE(),  @DES_METODO, 'Anexo do Id_Email DBVAREJO: ' + CONVERT(VARCHAR(50), @IDEmail) + ' - ' + L.NOME_ARQUIVO_PDF
				  FROM TBL_RE_LOTE L WITH(NOLOCK) 
				 WHERE L.ID_LOTE = @ITEM_ARRAY
		        
		        
				SET @NOME_EXCEL = (SELECT DISTINCT L.NOME_ARQUIVO_EXCEL FROM TBL_RE_LOTE L WITH(NOLOCK) WHERE L.ID_LOTE = @ITEM_ARRAY)
		        
				--SELECT @NOME_EXCEL AS NOME 
		        
				IF NOT EXISTS (SELECT ARQUIVO_ANEXO FROM TBL_ANEXO WITH(NOLOCK) WHERE ARQUIVO_ANEXO LIKE '%' + @NOME_EXCEL + '%')
				BEGIN 
				  INSERT INTO TBL_ANEXO(ID_Email, Arquivo_Anexo, DATA_ANEXO)  
				  SELECT DISTINCT @IDEmail,L.NOME_ARQUIVO_EXCEL, GETDATE() 
					FROM TBL_RE_LOTE L WITH(NOLOCK)  
				   WHERE L.ID_LOTE = @ITEM_ARRAY
		           
				  INSERT INTO [TBL_RE_LOG_BOLETO_BANCARIO] (DTA_LOG,METODO_LOG,DES_LOG)    
				  SELECT DISTINCT GETDATE(),  @DES_METODO, 'Anexo do Id_Email DBVAREJO: ' + CONVERT(VARCHAR(50), @IDEmail) + ' - ' + L.NOME_ARQUIVO_EXCEL
					FROM TBL_RE_LOTE L WITH(NOLOCK)  
				   WHERE L.ID_LOTE = @ITEM_ARRAY             
		          
				END 
		        
				--SELECT @ITEM_ARRAY
		        
				FETCH NEXT FROM INSERT_CURSOR INTO @ITEM_ARRAY
			END
			CLOSE INSERT_CURSOR
			DEALLOCATE INSERT_CURSOR 
		    
			
			DROP TABLE #ARRAY
	   END 
	   
	   IF @@ERROR = 0
          COMMIT TRAN       
       ELSE
         ROLLBACK
        
   END
   ELSE
   BEGIN 
      INSERT INTO [TBL_RE_LOG_BOLETO_BANCARIO] (  DTA_LOG,   METODO_LOG,                                                                               DES_LOG)    
      VALUES                                   (GETDATE(),  @DES_METODO, 'Email repetido: ' + @Corpo)
   END 
   
      SELECT isnull(@IDEmail ,0) AS 'IDEMAIL'
 
END 

