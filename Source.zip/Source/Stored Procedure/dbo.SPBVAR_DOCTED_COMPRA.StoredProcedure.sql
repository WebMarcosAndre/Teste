USE IK_VAREJO
GO

IF EXISTS(SELECT * FROM SYS.procedures WHERE name = 'SPBVAR_DOCTED_COMPRA')
	DROP PROCEDURE dbo.SPBVAR_DOCTED_COMPRA
GO

CREATE PROCEDURE [dbo].[SPBVAR_DOCTED_COMPRA]  
AS  
  
UPDATE TBL_PAGINA_USO   
SET pag_uso = 'S', data = GETDATE()  
WHERE PAGINA = 'ROBO_DOCTED'  
  
SELECT DISTINCT TOP 220    
    a.op_n_boleto,      
    a.op_paga,      
    a.id_operacao,      
    a.pre_boleto_status,      
    a.aux_datamnme,      
    a.op_tipo_operacao,      
    a.op_tipo_liq,      
    b.cl_tip_doc,      
    b.cl_nome,      
    b.cl_razao_social,      
    a.op_tipo_moeda,      
    a.op_data_boleto,      
    a.op_tipo_entrega,      
    a.op_natureza,      
    a.OP_PAISES,      
    b.cl_num_doc,      
    a.op_val_moeda,      
    a.op_tx_operacao,      
    a.op_val_reais,      
    a.op_tarifa_operacao,      
    a.op_inf_fav,      
    b.cl_endereco,      
    b.cl_cidade,      
    b.cl_estado,      
    b.cl_rg,      
    b.CL_ALIQUOTA_IR,      
    o.ID_Vinculo,      
    a.DATA_PTAX_IR,      
    a.sistema_origem,      
    o.op_dt_efetivacao,      
    o.op_inf_banco,      
    o.op_swift_code,      
    o.op_aba_iban,      
    o.op_inf_conta,      
    op_inf_motivo= NULL,      
    op_inf_obs= NULL,      
    o.n_registro_rde,      
    o.cnpj_corretor,      
    outras_especificacoes= NULL,      
    a.op_numero_ordem,      
    a.id_filial,      
    a.id_corretora,      
    a.op_data_me,      
    a.op_data_mn,      
    a.id_user_criacao,      
    a.op_grupo1,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.cl_agencia else d.bc_agencia end as cl_agencia,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.cl_conta else d.bc_conta end as cl_conta,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.cl_cod_banco else d.bc_cod_banco end as cl_cod_banco,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.CL_CNPJ_INST else d.BC_CNPJ_INST end as CL_CNPJ_INST,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.cl_tipo_conta else d.bc_tipo_conta end as cl_tipo_conta,      
    a.op_grupo2,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.cl_agencia2 else d.bc_agencia2 end as cl_agencia2,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.cl_conta2 else d.bc_conta2 end as cl_conta2,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.cl_cod_banco2 else d.bc_cod_banco2 end as cl_cod_banco2,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.CL_CNPJ_INST2 else d.BC_CNPJ_INST2 end as CL_CNPJ_INST2,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.cl_tipo_conta2 else d.bc_tipo_conta2 end as cl_tipo_conta2,      
    a.op_grupo3,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.cl_agencia3 else d.bc_agencia3 end as cl_agencia3,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.cl_conta3 else d.bc_conta3 end as cl_conta3,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.cl_cod_banco3 else d.bc_cod_banco3 end as cl_cod_banco3,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.CL_CNPJ_INST3 else d.BC_CNPJ_INST3 end as CL_CNPJ_INST3,      
    case when UPPER(LTRIM(RTRIM(b.cl_tip_doc))) <> 'CPF' THEN b.cl_tipo_conta3 else d.bc_tipo_conta3 end as cl_tipo_conta3,      
    a.op_valor1,      
    a.op_valor2,      
    a.op_valor3,      
    a.op_grp_bancarios,      
    a.id_cliente,      
    a.op_vend_comp,      
    a.op_pag_receb,      
    a.ID_EMPRESA_REMITANCE,      
    a.OP_SWIFT_CODE_R,      
    a.OP_ABA_IBAN_R,       
    b.cl_cep,      
    b.id_apresentante,      
    b.id_assessor,      
    b.cl_tel_res,      
    b.cl_tel_com,      
    CONVERT(VARCHAR(8000), o.op_inf_operacao) AS op_inf_operacao,  
    o.op_paridade,       
    a.vlr_iof,      
    a.txa_iof      
FROM TBL_PRE_BOLETO A WITH(NOLOCK)  
INNER JOIN TBL_CLIENTES B WITH(NOLOCK)  
 ON A.ID_CLIENTE = B.ID_CLIENTE  
LEFT JOIN TBL_OPERACOES O WITH(NOLOCK)  
 ON A.op_n_boleto  = O.op_n_boleto  
LEFT JOIN TBL_CLI_BANCO_COMERCIO d WITH(NOLOCK)  
 ON a.id_cliente = d.id_cliente  
WHERE A.OP_TIPO_LIQ IN ('DOC', 'TED')  
 AND A.OP_TIPO_OPERACAO = 'C'  
 AND A.SISTEMA_ORIGEM IN ('PC', 'SF')  
 AND A.OP_PAGA = 'N'  
 AND A.PRE_BOLETO_STATUS IN (2, 6)  
 AND ISNULL(A.op_aprova_rde_rof, '') IN ('S', '')  
 AND a.OP_DATA_MN < = CONVERT(VARCHAR(10),GETDATE(),111)  
 AND a.op_data_inclusao > '2014-04-17'