USE [IK_Varejo]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[SP_REMEXPR_CONSULTA_BOLETOS_BANCARIOS]    Script Date: 05/07/2019 09:46:23 ******/
-- =====================================================================================================================================
-- Author:		
-- Create date: 
-- Description:	
-------------------------------------------------------------------------------------------------
-- 683751.1273 - Projeto Migra��o SQL 2016 - Varejo
--					- Select com asterisco
--					- (No|ock) sem With
-------------------------------------------------------------------------------------------------
-- Hist�rico Altera��es
-- *********************
-- PRG__________________________________________________________ Data_____ Autor________ Descri��o__________________________________________
-- dbo.SP_REMEXPR_CONSULTA_BOLETOS_BANCARIOS.StoredProcedure.sql 05/jul/19 C�ssio Drezza 683751.1273 - Projeto Migra��o SQL 2016 - Varejo
-- =====================================================================================================================================
ALTER PROCEDURE [dbo].[SP_REMEXPR_CONSULTA_BOLETOS_BANCARIOS] (
        @DATA_INICIAL VARCHAR(10), 
        @DATA_FINAL VARCHAR(10), 
        @PageNumber VARCHAR(10) = NULL,
        @WHERE VARCHAR(MAX) = ' ',  
        @WHERE1 VARCHAR(MAX) = ''
)

AS 
BEGIN

SET NOCOUNT ON; 

DECLARE @QUERY VARCHAR(MAX) = ''
DECLARE @RowspPage AS VARCHAR(10)
    SET @RowspPage = '50'

--DECLARE @DATA_INICIAL VARCHAR(10) 
--DECLARE @DATA_FINAL VARCHAR(10) 
--DECLARE @PageNumber VARCHAR(10) 
--DECLARE @WHERE VARCHAR(MAX) = ''  
--DECLARE @WHERE1 VARCHAR(MAX) = ''--WHERE pl.nossonumero =6252125



--  SET @PageNumber = 2
--  SET @DATA_INICIAL = '03/01/2017'
--  SET @DATA_FINAL = '03/01/2017'

DECLARE @INTEGRADO INT 
    SET @INTEGRADO = (SELECT CHARINDEX('BB.INTEGRADO',@WHERE))



IF @WHERE1 <> '' 
BEGIN 

  SET @QUERY = @QUERY + 'SELECT ISNULL(PL.NOSSONUMERO,0) AS NOSSONUMERO, ISNULL(PL.NOSSONUMERODV,0) AS NOSSONUMERODV, ISNULL(PL.BARRA,0) AS CODIGO_BARRA ' + 
                             ',PL.REF , PL.VALORCOBRADO ' + 
                         'INTO #TEMP3 ' + 
                         'FROM [VAREJO_LWO].[PLAT_BOLETOS].[DBO].[BLTTBLOGS] PL With(NoLock) ' + @WHERE1 + ';'           

END 


SET @QUERY =  @QUERY +  'SELECT NUMBER, TOT, OP_N_BOLETO, OP_DATA_BOLETO, CO_NOME, FI_NOME, VALOR_ORDEM, VALOR_PAGO, DT_PGMT, INTEGRADO, MOTIVO, ID_EMPRESA_REMITANCE, CODIGOEVENTO, APROVACAO_CONTRAPARTIDA, TICKET, ROWSPAG  ' + -- *
               'INTO #TEMP ' + 
               'FROM (SELECT ROW_NUMBER() OVER(ORDER BY PB.OP_N_BOLETO) AS NUMBER , ' + 
                             'COUNT(''0'') OVER() AS TOT ,' + 
                             'PB.OP_N_BOLETO AS OP_N_BOLETO,' + 
                             'PB.OP_DATA_BOLETO AS OP_DATA_BOLETO,' +                
                             'CO.CO_NOME AS CO_NOME,' + 
                             'FI.FI_NOME AS FI_NOME,' + 
                             'ISNULL(PB.OP_VAL_REAIS,0) + ISNULL(PB.VLR_IOF,0) + ISNULL(PB.OP_TARIFA_OPERACAO,0) AS VALOR_ORDEM,' + 
                             'ISNULL(BB.VALOR_PAGO,0) AS VALOR_PAGO,' + 
                             'BB.DT_PAGAMENTO AS DT_PGMT,' + 
                             'CASE WHEN ISNULL(BB.INTEGRADO,0) = 1 THEN ''Sim'' ELSE ''N�o'' END AS INTEGRADO,' + 
                             'BB.MOTIVO AS MOTIVO,' + 
                             'PB.ID_EMPRESA_REMITANCE AS ID_EMPRESA_REMITANCE,' + 
                             'CODIGOEVENTO = (SELECT TOP 1 CODIGOEVENTO ' + 
                                               'FROM TBL_RE_ORDEM_HISTORICO With(NoLock) ' + 
                                               'WHERE OP_N_BOLETO = PB.OP_N_BOLETO AND ATIVO = 1 ORDER BY DATAMOVIMENTO DESC),' + 
                             'PB.APROVACAO_CONTRAPARTIDA,' +     
                             'BB.TICKET AS TICKET,' +                              
                             '''ROWSPAG'' = ''' + @RowspPage + ''' ' 
                       IF @WHERE1 <> ''
                       BEGIN
                         SET @QUERY = @QUERY + ', T3.NOSSONUMERO, t3.NOSSONUMERODV, t3.CODIGO_BARRA, t3.REF, t3.VALORCOBRADO ' --',T3.*'
                       END    
                       SET @QUERY = @QUERY + 'FROM TBL_BB_BOLETO_BANCARIO BB With(NoLock) ' + 
                      'INNER JOIN TBL_PRE_BOLETO PB With(NoLock) ON BB.OP_N_BOLETO = PB.OP_N_BOLETO ' + 
                      'INNER JOIN TBL_CORRETORAS CO With(NoLock) ON CO.ID_CORRETORA = PB.ID_CORRETORA ' +   
                       'LEFT JOIN TBL_FILIAIS FI With(NoLock) ON FI.ID_FILIAL = PB.ID_FILIAL ' 
                       
                       IF @WHERE1 <> ''
                       BEGIN
                         SET @QUERY = @QUERY + 'INNER JOIN #TEMP3 T3 With(NoLock) ON T3.REF = BB.TICKET AND T3.VALORCOBRADO =  ISNULL(PB.OP_VAL_REAIS,0) + ISNULL(PB.VLR_IOF,0) + ISNULL(PB.OP_TARIFA_OPERACAO,0)'
                       END 
                       
          SET @QUERY = @QUERY + 'WHERE PB.PRE_BOLETO_STATUS <> 3 ' 
                      
                      IF (((@WHERE  = '') OR (@INTEGRADO > 0)) AND @WHERE1 = '')
                      BEGIN
                        SET @QUERY = @QUERY + 'AND PB.OP_DATA_BOLETO BETWEEN CONVERT(DATETIME,''' +  CONVERT(VARCHAR(20),@DATA_INICIAL) + ''',103) AND CONVERT(DATETIME,''' + CONVERT(VARCHAR(20), @DATA_FINAL) + ''',103) '   
                      END 
                      
           SET @QUERY = @QUERY + @WHERE + ' ) AS TBL ' 
         -- SE FILTRO LISTA DE BOLETOS USADO
       --        OR PB.OP_N_BOLETO = ISNULL(@BOLETO, PB.OP_N_BOLETO)                                                         
      
IF ((@PageNumber <> 9999999) AND (((@WHERE  = '') OR (@INTEGRADO > 0)) AND @WHERE1 = ''))
BEGIN 
   SET @QUERY = @QUERY +  '  WHERE NUMBER BETWEEN ((' + @PageNumber + '- 1) * ' + @RowspPage + '+ 1) AND (' + @PageNumber + ' * ' +  @RowspPage + ') '
END                        


SET @QUERY = @QUERY + ';SELECT * ' + 
                         'INTO #TEMP2 ' + 
                         'FROM (SELECT T.NUMBER, t.TOT, t.OP_N_BOLETO, t.OP_DATA_BOLETO, t.CO_NOME, t.FI_NOME, t.VALOR_ORDEM, t.VALOR_PAGO, t.DT_PGMT, t.INTEGRADO, t.MOTIVO, t.ID_EMPRESA_REMITANCE, t.CODIGOEVENTO, t.APROVACAO_CONTRAPARTIDA, t.TICKET, t.RO
WSPAG, ISNULL(O.PCORDERNO, '''') AS ORDEM ' +    --    T.*      
                                 'FROM #TEMP T With(NoLock) ' + 
                                 'LEFT JOIN DBVAREJO.DBO.TBL_RE_RIA_ACK_ORDERIMPORT O With(NoLock) ON O.SCORDERNO = T.OP_N_BOLETO ' +
                             ' ) AS TBL2 ' 
                            
IF @WHERE1 = ''
BEGIN
SET @QUERY = @QUERY + ';SELECT ISNULL(PL.NOSSONUMERO,0) AS NOSSONUMERO, ISNULL(PL.NOSSONUMERODV,0) AS NOSSONUMERODV, ISNULL(PL.BARRA,0) AS CODIGO_BARRA ' + 
                             ', PL.REF, PL.VALORCOBRADO ' + 
                         'INTO #TEMP3 ' + 
                         'FROM [VAREJO_LWO].[PLAT_BOLETOS].[DBO].[BLTTBLOGS] PL With(NoLock) '                                  

                      IF (((@WHERE  = '') OR (@INTEGRADO > 0)) AND @WHERE1 = '')
                      BEGIN
                        SET @QUERY = @QUERY + 'WHERE PL.DATA BETWEEN CONVERT(DATETIME,''' +  CONVERT(VARCHAR(20),@DATA_INICIAL) + ''',105) AND CONVERT(DATETIME,''' + CONVERT(VARCHAR(20), @DATA_FINAL) + ''',105) + 1 '   
                      END
                      ELSE
                      BEGIN
                        SET @QUERY = @QUERY +  @WHERE1
                      END  

SET @QUERY = @QUERY + ';SELECT * ' + 
                         'INTO #TEMP4 ' + 
                         'FROM ( SELECT T2.NUMBER, t2.TOT, t2.OP_N_BOLETO, t2.OP_DATA_BOLETO, t2.CO_NOME, t2.FI_NOME, t2.VALOR_ORDEM, t2.VALOR_PAGO, t2.DT_PGMT, t2.INTEGRADO, t2.MOTIVO, t2.ID_EMPRESA_REMITANCE, t2.CODIGOEVENTO, t2.APROVACAO_CONTRAPARTIDA,
 t2.TICKET, t2.ROWSPAG, t2.ORDEM, T3.NOSSONUMERO, t3.NOSSONUMERODV, t3.CODIGO_BARRA, t3.REF, t3.VALORCOBRADO ' +  --  T2.*, T3.*         
                                 'FROM #TEMP2 T2 With(NoLock) ' + 
                                 'LEFT JOIN #TEMP3 T3 With(NoLock) ON T3.REF = T2.TICKET AND T3.VALORCOBRADO =  T2.VALOR_ORDEM) AS TBL3 ' 
                               
END


SET @QUERY = @QUERY + ';SELECT NUMBER ' + 
                             ',TOT ' + 
                             ',OP_N_BOLETO ' + 
                             ',OP_DATA_BOLETO ' + 
                             ',CO_NOME ' + 
                             ',FI_NOME ' + 
                             ',VALOR_ORDEM ' + 
                             ',VALOR_PAGO ' + 
                             ',DT_PGMT ' + 
                             ',TICKET ' + 
                             ',NOSSONUMERO ' + 
                             ',NOSSONUMERODV ' + 
                             ',CODIGO_BARRA    ' + 
                             ',INTEGRADO ' + 
                             ',MOTIVO ' + 
                             ',ID_EMPRESA_REMITANCE ' + 
                             ',ORDEM ' + 
                             ',CODIGOEVENTO ' + 
                             ',APROVACAO_CONTRAPARTIDA '+
                             ',ROWSPAG ' 
                      IF @WHERE1 = ''
                      BEGIN 
                       SET @QUERY = @QUERY + 'FROM #TEMP4 T With(NoLock) ' 
                      END 
                      ELSE                        
                      BEGIN
                        SET @QUERY = @QUERY + 'FROM #TEMP2 T With(NoLock) ' 
                      END
                      
                      SET @QUERY = @QUERY + 'ORDER BY OP_N_BOLETO, OP_DATA_BOLETO,CO_NOME;    ' + 
                              'DROP TABLE #TEMP;' +                 
                              'DROP TABLE #TEMP2;' +                 
                              'DROP TABLE #TEMP3;' 
                      IF @WHERE1 = ''
                      BEGIN         
                        SET @QUERY = @QUERY + 'DROP TABLE #TEMP4' 
                      END
 EXEC (@QUERY)                       
 print @query
END          
;
Go

-- Teste
-- Exec SP_REMEXPR_CONSULTA_BOLETOS_BANCARIOS @data_Inicial='20190101', @data_final='20190101', @integrado=1, @boletos='123234'

