USE [IK_Varejo]
GO

/****** Object:  StoredProcedure [dbo].[SPBVAR_REGRA_LIMITE_ESPECIE_INBOUND]    Script Date: 11/14/2017 15:00:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[SPBVAR_REGRA_LIMITE_ESPECIE_INBOUND] (                          
@ID_CORRETORA  VARCHAR(15) = NULL,                
@ID_USER       INT = NULL                    
                      
) AS                          
                      
DECLARE @LIMITEESPECIE_UTIL_INBOUND DECIMAL(18, 2)                                                             
--, @SUMLIMITEESPECIE   DECIMAL(18, 2)                   
--, @DIASEMANA          VARCHAR(13)                   
--, @RETORNO VARCHAR(15)                  
, @TOTDIAUTIL DECIMAL(18,2)                  
--, @MESSAGE  VARCHAR(30)                  
--, @PERCENDIAS DECIMAL(18,0)                  
--, @PERCENFIN  DECIMAL(18,0)  
, @FLAG_LIMITE INT              
             
                
SET NOCOUNT ON              
                  
SELECT @LIMITEESPECIE_UTIL_INBOUND = ISNULL(LIMITEESPECIE_UTIL_INBOUND,0),@FLAG_LIMITE = ISNULL(FLAG_LIMITE,0)   
  FROM IK_VAREJO..TBL_CORRETORAS WITH(NOLOCK) WHERE ID_CORRETORA = @ID_CORRETORA                  

                
SELECT @TOTDIAUTIL = CAST(ISNULL(SUM(ISNULL(A.OP_VAL_REAIS,0) - ISNULL(VLR_IOF, 0)),0) AS DECIMAL(12,2))
  FROM IK_VAREJO..TBL_PRE_BOLETO A WITH(NOLOCK)                  
 WHERE A.OP_TIPO_ENTREGA = 'REMEXPI'                  
   AND A.OP_TIPO_OPERACAO = 'C'                  
   AND A.SISTEMA_ORIGEM = 'RE'                  
   AND A.OP_TIPO_LIQ = 'ESPECIE'                  
   AND A.ID_CORRETORA = @ID_CORRETORA                           
   AND CAST(A.OP_DATA_BOLETO AS DATE)= CAST(GETDATE() AS DATE)
   AND A.pre_boleto_status <> 3              
   
  
/*SELECT @SUMLIMITEESPECIE = CAST(ISNULL(SUM(ISNULL(A.OP_VAL_REAIS,0) - ISNULL(VLR_IOF, 0)),0) AS DECIMAL(12,2)),@DIASEMANA = CASE WHEN dbo.[FDIA_SEMANA_EXT](A.OP_DATA_BOLETO) ='S�BADO' THEN 'FINALDESEMANA' WHEN dbo.[FDIA_SEMANA_EXT](A.OP_DATA_BOLETO) ='DOMINGO' THEN 'FINALDESEMANA' ELSE 'DIAUTIL' END         
  FROM DBVAREJO..TBL_PRE_BOLETO A WITH(NOLOCK)
 WHERE A.OP_TIPO_ENTREGA = 'REMEXPI'                  
   AND A.OP_TIPO_OPERACAO = 'C'                  
   AND A.SISTEMA_ORIGEM = 'RE'                  
   AND A.OP_TIPO_LIQ = 'ESPECIE'                  
   AND CAST(OP_DATA_BOLETO AS DATE)= CAST(GETDATE() AS DATE)              
   AND A.ID_CORRETORA =  + CAST(@ID_CORRETORA AS VARCHAR(10))  
   AND A.pre_boleto_status <> 3                              
 GROUP BY A.OP_VAL_REAIS,OP_DATA_BOLETO                  
                            
   IF @SUMLIMITEESPECIE > @LIMITEESPECIE_UTIL_INBOUND           
                     
     SET @MESSAGE = 'LIMITE DE ESP�CIE ATINGIDO'               
                     
     ELSE                  
                     
     SET @MESSAGE = NULL                  
                   
   IF @MESSAGE IS NOT NULL                         
     BEGIN                   
     SELECT @FLAG_LIMITE AS FLAG_LIMITE,ISNULL(@TOTDIAUTIL,0) TOTDIAUTIL,@MESSAGE [MESSAGE],ISNULL(@LIMITEESPECIE_UTIL_INBOUND,0) LIMITEESPECIE_UTIL_INBOUND, ISNULL(@SUMLIMITEESPECIE, 0) SUMLIMITEESPECIE_INBOUND
                                                        
   END                   
                
   IF @MESSAGE IS NULL                  
     BEGIN */                  
     SELECT @FLAG_LIMITE AS FLAG_LIMITE,ISNULL(@TOTDIAUTIL,0) TOTDIAUTIL,
	 --@MESSAGE [MESSAGE],
	 ISNULL(@LIMITEESPECIE_UTIL_INBOUND,0) LIMITEESPECIE_UTIL_INBOUND
	 --ISNULL(@SUMLIMITEESPECIE, 0) SUMLIMITEESPECIE_INBOUND 
   --END               
                 
 SET NOCOUNT OFF 





GO


