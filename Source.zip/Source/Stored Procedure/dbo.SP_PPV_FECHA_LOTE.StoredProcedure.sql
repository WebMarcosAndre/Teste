use ik_varejo
go

/*
Nome:  SP_PPV_FECHA_LOTE
Desc:  Efetua o fechamento do lote de opera��es de uma corretora(Bot�o Fechar Lote da tela em Manuten��o\Rotina Fechamento de Lote)
Autor: Regina Yuriko Utiyama
Data:  06/09/2018
************************
Hist�rico de Altera��es
************************

Exemplo:
EXEC SP_PPV_FECHA_LOTE @DT_INICIO_BACEN    = '2017-1-2', @DT_FIM_BACEN      = '2018-9-6', @usuario = 'Teste' , @ID_CORRETORA    = '166' 
EXEC SP_PPV_FECHA_LOTE @DT_INICIO_BACEN    = '2017-1-2', @DT_FIM_BACEN      = '2018-9-12', @usuario = 'ReginaYurikoUtiyama' , @ID_CORRETORA    = '166' , @MOEDA    = 'EURO' 
EXEC SP_PPV_FECHA_LOTE @DT_INICIO_BACEN    = '2017-1-2', @DT_FIM_BACEN      = '2018-9-12', @usuario = 'ReginaYurikoUtiyama' , @ID_CORRETORA    = '166' , @MOEDA    = 'USD' 
EXEC SP_PPV_FECHA_LOTE @DT_INICIO_BACEN    = '2017-1-2', @DT_FIM_BACEN      = '2018-9-13', @usuario = 'ReginaYurikoUtiyama' , @ID_CORRETORA    = '166' , @MOEDA    = 'EURO' 
*/
CREATE PROCEDURE [dbo].[SP_PPV_FECHA_LOTE]  
(  
   @ID_CORRETORA INT = NULL  
 , @DT_INICIO_BACEN DATETIME = NULL  
 , @DT_FIM_BACEN DATETIME = NULL  
 , @USUARIO VARCHAR(60) 
 , @MOEDA VARCHAR(4)=NULL
)  
AS  
BEGIN  
 SET NOCOUNT ON  
  
 -- BUSCA O VALOR CRIADO  
 DECLARE @NUM_LOTE INT  
 DECLARE @RESULTADO INT  
  
 --CHAMANDO A PROC BASE  
 CREATE TABLE #TEMPTABLE (  
  [EMPRESA] VARCHAR(150)  
  ,[PARCEIRO] VARCHAR(150)  
  ,[SUBCONTA] VARCHAR(50)  
  ,[REF_PAGTO] VARCHAR(500)  
  ,[BOLETO BRSA] INT  
  ,[BOLETO EMP] INT  
  ,[BOLETO CHANGE] INT  
  ,[DATA BOLETO] DATETIME  
  ,[DATA BACEN] DATETIME  
  ,[VLR PAGO] MONEY  
  --,[VLR_COBRADO] MONEY  
  ,[VLR PRINCIPAL] MONEY  
  ,[VLR TARIFA] MONEY  
  ,[VLR_IOF] MONEY  
  ,[VLR REPASSE] MONEY  
  ,[VLR REPASSE ME] MONEY  
  ,[VAL ME] MONEY  
  ,[MOEDA] VARCHAR(4)  
  ,[SPREAD BRSA] MONEY  
  ,[TX PRONTO] MONEY  
  ,[TX OPERACAO] MONEY  
  ,[%_SPREAD] MONEY  
  ,[status] INT  
  ,[lote] INT  
  ,Valor_BRSA MONEY  
  ,DATA_PAGAMENTO_BR DATETIME  
  ,NUM_BOLETO_CHANGE INT  
  ,DATA_FECHAMENTO DATETIME
 )  
   
 INSERT INTO #TEMPTABLE (  
  [EMPRESA]  
  ,[PARCEIRO]  
  ,[SUBCONTA]  
  ,[REF_PAGTO]  
  ,[BOLETO BRSA]  
  ,[BOLETO EMP]  
  ,[BOLETO CHANGE]  
  ,[DATA BOLETO]  
  ,[DATA BACEN]  
  ,[VLR PAGO]  
  ,[VLR PRINCIPAL]  
  ,[VLR TARIFA]  
  ,[VLR_IOF]  
  ,[VLR REPASSE]  
  ,[VLR REPASSE ME]  
  ,[VAL ME]  
  ,MOEDA  
  ,[SPREAD BRSA]  
  ,[TX PRONTO]  
  ,[TX OPERACAO]  
  ,[%_SPREAD]  
  ,[status]  
  ,LOTE  
  ,Valor_BRSA  
  ,DATA_PAGAMENTO_BR  
  ,NUM_BOLETO_CHANGE  
  ,DATA_FECHAMENTO
 )  
 EXEC SP_PPV_CONSULTA_ROTINA_FECHAMENTO_LOTE 
   @ID_CORRETORA = @ID_CORRETORA  
  ,@DT_INICIO_BACEN = @DT_INICIO_BACEN  
  ,@DT_FIM_BACEN = @DT_FIM_BACEN  
  ,@TIPO = 0  
  ,@PRE_BOLETO_STATUS = 2  
  ,@MOEDA=@MOEDA
  ,@LOTE=NULL  
   
 -- NO FECHAMENTO DE LOTE - OBRIGATORIAMENTE DEVE SER POR EMPRESA / PARCEIRO / MOEDA  
 -- SE ENCONTRAR MAIS DE 1 REGISTRO - SIGNIFICA QUE EST� TENTANDO FECHAR LOTE   
 -- PARA 1 OU MAIS EMPRESAS E/OU PARCEIROS E/OU MOEDA DE 1 S� VEZ  
 IF NOT ((SELECT COUNT(DISTINCT EMPRESA) FROM #TEMPTABLE) = 1
   /*AND (SELECT COUNT(DISTINCT PARCEIRO) FROM #TEMPTABLE) = 1 [387202 - COMENTADO]*/  
   AND (SELECT COUNT(DISTINCT MOEDA) FROM #TEMPTABLE) = 1)  
 BEGIN  
  --PRINT 'ERRO - TENTATIVA DE FECHAR LOTE PARA MAIS DE 1 EMPRESA E/OU PARCEIRO E/OU MOEDA'  
  PRINT 'ERRO - TENTATIVA DE FECHAR LOTE PARA MAIS DE 1 EMPRESA'  
  SET @RESULTADO = 0  
  SELECT 0 AS RESULTADO, @NUM_LOTE NUM_LOTE 
  RETURN (0)  
  --SELECT @RESULTADO AS RESULTADO  
 END  
  
 --INICIANDO A TRANSACAO   
 BEGIN TRAN TRAN_1  
  
 -- CRIANDO NOVO LOTE   
 INSERT INTO TBL_REC_LOTE_FECHAMENTO (USUARIO, DATA_CRIACAO)  
 VALUES (@USUARIO, GETDATE())  
  
 IF @@ERROR > 0  
 BEGIN  
  SET @NUM_LOTE = 0  
  SELECT isnull(@NUM_LOTE, 0) AS retorno  
  ROLLBACK TRANSACTION TRAN_1  
 END  
  
 SELECT @NUM_LOTE = MAX(ID_LOTE)  
 FROM TBL_REC_LOTE_FECHAMENTO WITH (NOLOCK)  
  
 --inserindo os itens do lote  
 INSERT INTO TBL_REC_LOTE_FECHAMENTO_ORDEM (  
  ID_LOTE  
  ,EMPRESA  
  ,PARCEIRO  
  ,OP_N_BOLETO  
  ,BOLETO_EMP  
  ,DATA_BOLETO  
  ,DATA_BACEN  
  ,VLR_PAGO  
  ,VLR_PRINCIPAL  
  ,VLR_TARIFA  
  ,VLR_REPASSE  
  ,VLR_REPASSE_ME  
  ,VAL_ME  
  ,MOEDA  
  ,SPREAD_BRSA  
  ,TX_PRONTO  
  ,TX_OPERACAO  
 )  
 SELECT @NUM_LOTE  
  ,EMPRESA  
  ,PARCEIRO  
  ,[BOLETO BRSA]  
  ,[BOLETO EMP]  
  ,[DATA BOLETO]  
  ,[DATA BACEN]  
  ,[VLR PAGO]  
  ,[VLR PRINCIPAL]  
  ,[VLR TARIFA]  
  ,[VLR REPASSE]  
  ,[VLR REPASSE ME]  
  ,[VAL ME]  
  ,MOEDA  
  ,[SPREAD BRSA]  
  ,[TX PRONTO]  
  ,[TX OPERACAO]  
 FROM #TEMPTABLE  
  
 IF @@ERROR > 0  
 BEGIN  
  SET @NUM_LOTE = 0  
  SELECT isnull(@NUM_LOTE, 0) AS retorno  
  ROLLBACK TRANSACTION TRAN_1  
 END  
  
 SET @RESULTADO = 1  
  
 COMMIT TRAN TRAN_1  
  
 /*  
 rotina para enviar o email  
 */  
 DECLARE   
  @nomeEmpresa VARCHAR(1000)  
  , @nomeParceiro VARCHAR(1000)  
  , @VALOR1 VARCHAR(1000)  
  , @VALOR2 VARCHAR(1000)  
  , @VALOR3 VARCHAR(1000)  
  , @VALOR4 VARCHAR(1000)  
  , @VALOR5 VARCHAR(1000)  
  , @VALOR6 VARCHAR(1000)  
  , @listaemail VARCHAR(1000)  
  , @assuntoemail VARCHAR(1000)  
  , @corpoemail VARCHAR(5000)  
  
 SET @nomeEmpresa = (SELECT TOP 1 EMPRESA FROM #TEMPTABLE)  
 SET @nomeParceiro = (SELECT TOP 1 PARCEIRO FROM #TEMPTABLE)  
 SET @VALOR1 = (SELECT sum([VLR PRINCIPAL]) FROM #TEMPTABLE)  
 SET @VALOR2 = (SELECT sum([VLR TARIFA]) FROM #TEMPTABLE)  
 SET @VALOR3 = (SELECT sum([VLR REPASSE]) FROM #TEMPTABLE)  
 SET @VALOR4 = (SELECT sum([VLR REPASSE ME]) FROM #TEMPTABLE)  
 SET @VALOR5 = (SELECT sum([VAL ME]) FROM #TEMPTABLE)  
 SET @VALOR6 = (SELECT TOP 1 [MOEDA] FROM #TEMPTABLE)  
   
 SET @listaemail = (SELECT vl_campo FROM TBL_REC_PARAMETRO WHERE nm_campo = 'EMAIL_FECHAMENTO_LOTE')  
 SET @assuntoemail = 'Fechamento Lote DD/MM (NomeEmpresa / NomeParceiro)'  
 SET @corpoemail = '<div><p>Prezados,</p><p>Segue abaixo os detalhes do fechamento do lote: VALOR7 realizado hoje GETDATE()</p><div><table border="0" cellpadding="3" cellspacing="0" style="border:solid 1px #CCCCCC; background-color:#EEEEEE;" width="400"><
tbody><tr><td class="fonte_azul"><span style="color:#6699cc;">Total Principal em R$:</span></td><td><strong><span class="box" id="soma_principal" style="TEXT-ALIGN: right; WIDTH: 100px">VALOR1</span></strong></td></tr><tr><td class="fonte_azul"><span styl
e="color:#6699cc;">Total Tarifa BRSA em R$:</span></td><td><strong><span style="text-align: right;">VALOR2</span></strong></td></tr><tr> <td class="fonte_azul"><span style="color:#6699cc;">Total Comiss&atilde;o Parceiro R$ (se parceiro no BR):</span></td>
<td><strong><span style="text-align: right;">VALOR3</span></strong></td></tr><tr><td class="fonte_azul"><span style="color:#6699cc;">Total Comiss&atilde;o Parceiro VALOR6 (se parceiro Exterior):</span></td><td><strong><span style="text-align: right;">VALO
R4</span></strong></td></tr><tr><td class="fonte_azul"><span style="color:#6699cc;">Total Principal VALOR6 (Swift):</span></td><td><strong><span style="text-align: right;">VALOR5</span></strong></td></tr></tbody></table><p>&nbsp;</p></div></div><p>&nbsp;<
/p>'  
 SET @assuntoemail = replace(@assuntoemail, 'DD/MM', substring('0' + CAST(day(getdate()) AS VARCHAR(2)), 1, 2) + '/' + substring('0' + CAST(month(getdate()) AS VARCHAR(2)), 1, 2))  
 SET @assuntoemail = replace(@assuntoemail, 'NomeEmpresa', @nomeEmpresa)  
 SET @assuntoemail = replace(@assuntoemail, 'NomeParceiro', @nomeParceiro)  
 SET @corpoemail = replace(@corpoemail, 'GETDATE()', CAST(day(getdate()) AS VARCHAR(2)) + '/' + CAST(month(getdate()) AS VARCHAR(2)) + '/' + CAST(YEAR(getdate()) AS VARCHAR(4)))  
 SET @corpoemail = replace(@corpoemail, 'VALOR1', isnull(@VALOR1, ''))  
 SET @corpoemail = replace(@corpoemail, 'VALOR2', isnull(@VALOR2, ''))  
 SET @corpoemail = replace(@corpoemail, 'VALOR3', isnull(@VALOR3, ''))  
 SET @corpoemail = replace(@corpoemail, 'VALOR4', isnull(@VALOR4, ''))  
 SET @corpoemail = replace(@corpoemail, 'VALOR5', isnull(@VALOR5, ''))  
 SET @corpoemail = replace(@corpoemail, 'VALOR6', isnull(@VALOR6, ''))  
 SET @corpoemail = replace(@corpoemail, 'VALOR7', isnull(@NUM_LOTE, ''))    

  
 INSERT INTO EMAIL_SERVICE.dbo.TBL_EMAIL (  
  id_sistema  
  ,destino_email  
  ,assunto_email  
  ,corpo_email  
  ,data_email  
  ,tentativas_email  
 )  
 VALUES (  
  4  
  ,@listaemail  
  ,@assuntoemail  
  ,@corpoemail  
  ,getdate()  
  ,0  
 )  
  
 --print @corpoemail  
 /*  
 fim da rotina do email  
 */  
 DROP TABLE #TEMPTABLE  
  
 SELECT @RESULTADO AS RESULTADO,@NUM_LOTE AS NUM_LOTE
END  