USE [IK_VAREJO] 
GO

CREATE PROCEDURE  SP_WebApi_PortalCambio_getCotacoes
    @Spread float
	
AS
BEGIN

SELECT 
	moe_nome Moe_NomeResumido
	,CAST((b.Tx_Compra * (@Spread /100+1)) AS NUMERIC (15,4)) Vl_Compra
	,CAST((b.Tx_Venda  * (@Spread /100+1)) AS NUMERIC (15,4)) Vl_Venda
FROM  
	TBL_MOEDAS A
JOIN
	varejo..tmoedas B
ON B.Cod_moeda COLLATE Latin1_General_CI_AS = A.moe_simbolo 
WHERE moe_cambio_online = 'S'

END


