use ik_varejo
go

IF EXISTS(SELECT 0 FROM SYS.procedures WHERE name = 'SPIns_LogErroHttp')
	DROP PROCEDURE dbo.SPIns_LogErroHttp
GO

CREATE PROCEDURE dbo.SPIns_LogErroHttp
(
	@Aplicacao VARCHAR(40)
	, @Codigo VARCHAR(10)
	, @Numero INT
	, @Descricao VARCHAR(250)
	, @Arquivo VARCHAR(250)
	, @NumeroLinha SMALLINT
	, @Url VARCHAR(250)
	, @UrlAnterior VARCHAR(2000)
	, @DadosGet VARCHAR(2000)
	, @DadosPost VARCHAR(5000)
	, @DadosSessao VARCHAR(2000)
	, @IpCliente VARCHAR(40)
	, @Verificado BIT = 0
)
AS
BEGIN
	SET NOCOUNT ON
	
	INSERT INTO LogErroHttp (
		Aplicacao
		, Codigo
		, Numero
		, Descricao
		, Arquivo
		, NumeroLinha
		, Url
		, UrlAnterior
		, DadosGet
		, DadosPost
		, DadosSessao
		, IpCliente
		, DataInclusao
		, Verificado
	)
	VALUES(
		@Aplicacao
		, @Codigo
		, @Numero
		, @Descricao
		, @Arquivo
		, @NumeroLinha
		, @Url
		, @UrlAnterior
		, @DadosGet
		, @DadosPost
		, @DadosSessao
		, @IpCliente
		, GETDATE()
		, @Verificado
	)
	
	SET NOCOUNT OFF
	
	SELECT @@IDENTITY AS LogErroHttpId
END
GO


