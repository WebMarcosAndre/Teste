﻿using Microsoft.EntityFrameworkCore;
using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Infra.Data.Context
{
    public partial class DBVarejoContext : DbContext
    {

        public DBVarejoContext()
        {

        }

        public DBVarejoContext(DbContextOptions<DBVarejoContext> options) : base(options)
        {

        }

        public virtual DbSet<TBL_REGRAS_TARIFAS> TBL_REGRAS_TARIFAS { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //IConfigurationRoot configuration = new ConfigurationBuilder().Build();
                //optionsBuilder.UseSqlServer("Server=REND-SRVDSQL-01; Database=IK_VAREJO; Trusted_Connection=True; MultipleActiveResultSets=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        }
    }
}
