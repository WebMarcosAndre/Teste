﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Entities.Elmah_Error;
using System.Linq;

namespace RND.CBP.Infra.Data.Context
{
    public partial class DbFeriadoContext : DbContext
    {
        public DbFeriadoContext()
        {

        }

        public DbFeriadoContext(DbContextOptions<DbFeriadoContext> options) : base(options)
        {

        }

        public virtual DbSet<Feriado> Tbl_Feriado { get; set; }
        public virtual DbSet<Tbl_FeriadoParametro> Tbl_FeriadoParametro { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //IConfigurationRoot configuration = new ConfigurationBuilder().Build();
                //optionsBuilder.UseSqlServer("Server=REND-SRVDSQL-01; Database=IK_VAREJO; Trusted_Connection=True; MultipleActiveResultSets=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Feriado>(entity =>
            {
                entity.HasKey(e => e.Feriado_id);
                entity.Property(e => e.Feriado_id).HasColumnName("Feriado_id");

                entity.Property(e => e.Dia)
                    .HasColumnName("Dia");

                entity.Property(e => e.Mes)
                    .HasColumnName("Mes");
                    
                entity.Property(e => e.Descricao)
                    .HasColumnName("Descricao")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.TipoFeriado_id)
                    .HasColumnName("TipoFeriado_id");

                entity.Property(e => e.CreatedBy)
                   .HasColumnName("CreatedBy");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("CreatedOn")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateBy)
                    .HasColumnName("LastUpdateBy");

                entity.Property(e => e.LastUpdateOn)
                    .HasColumnName("LastUpdateOn")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Ativo)
                    .HasColumnName("Ativo");

                entity.Property(e => e.Ano)
                    .HasColumnName("Ano");
            });

            modelBuilder.Entity<Tbl_FeriadoParametro>(entity =>
            {
                entity.HasKey(e => e.FeriadoParametro_id);
                entity.Property(e => e.FeriadoParametro_id).HasColumnName("FeriadoParametro_id");

                entity.Property(e => e.Feriado_id)
                    .HasColumnName("Feriado_id");

                entity.Property(e => e.Praca_id)
                    .HasColumnName("Praca_id");

                entity.Property(e => e.Sistema_id)
                    .HasColumnName("Sistema_id");

                entity.Property(e => e.TipoOperacao_id)
                    .HasColumnName("TipoOperacao_id");

                entity.Property(e => e.Moeda_id)
                    .HasColumnName("Moeda_id");

                entity.Property(e => e.CreatedBy)
                    .HasColumnName("CreatedBy");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("CreatedOn");

                entity.Property(e => e.LastUpdateBy)
                    .HasColumnName("LastUpdateBy");

                entity.Property(e => e.LastUpdateOn)
                    .HasColumnName("LastUpdateOn");

                entity.Property(e => e.Ativo)
                    .HasColumnName("Ativo");
            });

        }
    }
}
