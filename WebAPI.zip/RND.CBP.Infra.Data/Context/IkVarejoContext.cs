﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;
using RND.CBP.Domain.Entities;

namespace RND.CBP.Infra.Data.Context
{
    public partial class IkVarejoContext : DbContext
    {
        public IkVarejoContext()
        {

        }

        public IkVarejoContext(DbContextOptions<IkVarejoContext> options) : base(options)
        {

        }

        public virtual DbSet<TblClientes> TBL_CLIENTES { get; set; }

        public virtual DbSet<TblUsers> TBL_USERS { get; set; }

        public virtual DbSet<TBL_COL_SPREAD_DIA> TBL_COL_SPREAD_DIA { get; set; }
        public virtual DbSet<TBL_COL_PARAM_PRODUTOS> TBL_COL_PARAM_PRODUTOS { get; set; }
        public virtual DbSet<TBL_TARIFAS_PADRAO> TBL_TARIFAS_PADRAO { get; set; }
        public virtual DbSet<TBL_REGRAS_TARIFAS_CLI> TBL_REGRAS_TARIFAS_CLI { get; set; }
        public virtual DbSet<TBL_REGRAS_TARIFAS> TBL_REGRAS_TARIFAS { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //IConfigurationRoot configuration = new ConfigurationBuilder().Build();
                //optionsBuilder.UseSqlServer("Server=REND-SRVDSQL-01; Database=IK_VAREJO; Trusted_Connection=True; MultipleActiveResultSets=true");
            }
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TblClientes>(entity =>
            {
                entity.Property(e => e.IdCliente).HasColumnName("id_cliente");

                entity.Property(e => e.ClAgencia)
                    .HasColumnName("cl_agencia")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClAgencia2)
                    .HasColumnName("cl_agencia2")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClAgencia3)
                    .HasColumnName("cl_agencia3")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClAgenciaExt)
                    .HasColumnName("cl_agencia_ext")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClAgenciaExt2)
                    .HasColumnName("cl_agencia_ext2")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClAgenciaExt3)
                    .HasColumnName("cl_agencia_ext3")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClAliquotaIr)
                    .HasColumnName("CL_ALIQUOTA_IR")
                    .HasColumnType("decimal(10, 6)");

                entity.Property(e => e.ClBairro)
                    .HasColumnName("cl_bairro")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClBairroCor)
                    .HasColumnName("cl_bairro_cor")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClBanco)
                    .HasColumnName("cl_banco")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClBanco2)
                    .HasColumnName("cl_banco2")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClBanco3)
                    .HasColumnName("cl_banco3")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClBancoExt)
                    .HasColumnName("cl_banco_ext")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClBancoExt2)
                    .HasColumnName("cl_banco_ext2")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClBancoExt3)
                    .HasColumnName("cl_banco_ext3")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClBic1)
                    .HasColumnName("CL_BIC1")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.ClBreveRelato)
                    .HasColumnName("CL_BREVE_RELATO")
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.ClCadVenc)
                    .HasColumnName("cl_cad_venc")
                    .HasColumnType("char(1)");

                entity.Property(e => e.ClCcmeTarifaPadrao)
                    .HasColumnName("cl_ccme_tarifa_padrao")
                    .HasColumnType("char(1)");

                entity.Property(e => e.ClCelular)
                    .HasColumnName("cl_celular")
                    .HasColumnType("char(16)");

                entity.Property(e => e.ClCep)
                    .HasColumnName("cl_cep")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ClCepCor)
                    .HasColumnName("cl_cep_cor")
                    .HasMaxLength(8)
                    .IsUnicode(false);

                entity.Property(e => e.ClCepEx)
                    .HasColumnName("CL_CEP_EX")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ClCidade)
                    .HasColumnName("cl_cidade")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClCidadeCor)
                    .HasColumnName("cl_cidade_cor")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClCnpjInst)
                    .HasColumnName("CL_CNPJ_INST")
                    .HasMaxLength(14)
                    .IsUnicode(false);

                entity.Property(e => e.ClCnpjInst2)
                    .HasColumnName("CL_CNPJ_INST2")
                    .HasMaxLength(14)
                    .IsUnicode(false);

                entity.Property(e => e.ClCnpjInst3)
                    .HasColumnName("CL_CNPJ_INST3")
                    .HasMaxLength(14)
                    .IsUnicode(false);

                entity.Property(e => e.ClCodBanco)
                    .HasColumnName("cl_cod_banco")
                    .HasColumnType("char(20)");

                entity.Property(e => e.ClCodBanco2)
                    .HasColumnName("cl_cod_banco2")
                    .HasColumnType("char(4)");

                entity.Property(e => e.ClCodBanco3)
                    .HasColumnName("cl_cod_banco3")
                    .HasColumnType("char(4)");

                entity.Property(e => e.ClCodBancoExt)
                    .HasColumnName("cl_cod_banco_ext")
                    .HasColumnType("char(4)");

                entity.Property(e => e.ClCodBancoExt2)
                    .HasColumnName("cl_cod_banco_ext2")
                    .HasColumnType("char(4)");

                entity.Property(e => e.ClCodBancoExt3)
                    .HasColumnName("cl_cod_banco_ext3")
                    .HasColumnType("char(4)");

                entity.Property(e => e.ClCodPagador)
                    .HasColumnName("CL_COD_PAGADOR")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.ClCodVendedor)
                    .HasColumnName("CL_COD_VENDEDOR")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.ClComoConheceu)
                    .HasColumnName("CL_COMO_CONHECEU")
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.ClComplemento)
                    .HasColumnName("cl_complemento")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClComplementoCor)
                    .HasColumnName("cl_complemento_cor")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClConta)
                    .HasColumnName("cl_conta")
                    .HasColumnType("char(20)");

                entity.Property(e => e.ClConta2)
                    .HasColumnName("cl_conta2")
                    .HasColumnType("char(20)");

                entity.Property(e => e.ClConta3)
                    .HasColumnName("cl_conta3")
                    .HasColumnType("char(20)");

                entity.Property(e => e.ClContaExt)
                    .HasColumnName("cl_conta_ext")
                    .HasColumnType("char(20)");

                entity.Property(e => e.ClContaExt2)
                    .HasColumnName("cl_conta_ext2")
                    .HasColumnType("char(20)");

                entity.Property(e => e.ClContaExt3)
                    .HasColumnName("cl_conta_ext3")
                    .HasColumnType("char(20)");

                entity.Property(e => e.ClContato)
                    .HasColumnName("CL_CONTATO")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClDataAbertura)
                    .HasColumnName("cl_data_abertura")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClDataAbertura2)
                    .HasColumnName("cl_data_abertura2")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClDataAbertura3)
                    .HasColumnName("cl_data_abertura3")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClDataAberturaExt)
                    .HasColumnName("cl_data_abertura_ext")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClDataAberturaExt2)
                    .HasColumnName("cl_data_abertura_ext2")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClDataAberturaExt3)
                    .HasColumnName("cl_data_abertura_ext3")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClDataFollowUp)
                    .HasColumnName("CL_DATA_FOLLOW_UP")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClDataPorteEmpresa)
                    .HasColumnName("CL_DATA_PORTE_EMPRESA")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClDtAlteracao)
                    .HasColumnName("cl_dt_alteracao")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClDtInclusao)
                    .HasColumnName("cl_dt_inclusao")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ClDtLimiteNivelComp)
                    .HasColumnName("CL_DT_LIMITE_NIVEL_COMP")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClDtLimiteNivelCred)
                    .HasColumnName("CL_DT_LIMITE_NIVEL_CRED")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClDtNasc)
                    .HasColumnName("cl_dt_nasc")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClDtPassaporte)
                    .HasColumnName("cl_dt_passaporte")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClDtSucessao)
                    .HasColumnName("cl_dt_sucessao")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClEmVinculada)
                    .HasColumnName("CL_EM_VINCULADA")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClEmail)
                    .HasColumnName("cl_email")
                    .HasMaxLength(140)
                    .IsUnicode(false);

                entity.Property(e => e.ClEmpresaSucede)
                    .HasColumnName("cl_empresa_sucede")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClEndereco)
                    .HasColumnName("cl_endereco")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClEnderecoCor)
                    .HasColumnName("cl_endereco_cor")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClEstado)
                    .HasColumnName("cl_estado")
                    .HasColumnType("char(2)");

                entity.Property(e => e.ClEstadoCivil)
                    .HasColumnName("cl_estado_civil")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ClEstadoCor)
                    .HasColumnName("cl_estado_cor")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.ClEstadoEx)
                    .HasColumnName("CL_ESTADO_EX")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ClFaturamento)
                    .HasColumnName("cl_faturamento")
                    .HasColumnType("decimal(18, 0)");

                entity.Property(e => e.ClFiliais)
                    .HasColumnName("cl_filiais")
                    .HasColumnType("text");

                entity.Property(e => e.ClFlagContame)
                    .HasColumnName("CL_FLAG_CONTAME")
                    .HasColumnType("char(1)");

                entity.Property(e => e.ClIban)
                    .HasColumnName("CL_IBAN")
                    .HasMaxLength(600)
                    .IsUnicode(false);

                entity.Property(e => e.ClIdentidade)
                    .HasColumnName("cl_Identidade")
                    .HasMaxLength(50);

                entity.Property(e => e.ClImpExp)
                    .HasColumnName("cl_imp_exp")
                    .HasColumnType("char(1)");

                entity.Property(e => e.ClInfOperador)
                    .HasColumnName("cl_inf_operador")
                    .HasColumnType("text");

                entity.Property(e => e.ClInscEstadual)
                    .HasColumnName("cl_insc_estadual")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ClInscMunicipal)
                    .HasColumnName("cl_insc_municipal")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ClLocalNasc)
                    .HasColumnName("cl_local_nasc")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClNacionalidade)
                    .HasColumnName("cl_nacionalidade")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClNif)
                    .HasColumnName("cl_nif")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.ClNivelCompliance)
                    .HasColumnName("CL_NIVEL_COMPLIANCE")
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('1')");

                entity.Property(e => e.ClNivelCredito)
                    .HasColumnName("CL_NIVEL_CREDITO")
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('A')");

                entity.Property(e => e.ClNome)
                    .HasColumnName("cl_nome")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ClNomeFantasia)
                    .HasColumnName("cl_nome_fantasia")
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.ClNomeGrupo)
                    .HasColumnName("cl_nome_grupo")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClNumDoc)
                    .HasColumnName("cl_num_doc")
                    .HasColumnType("char(18)");

                entity.Property(e => e.ClNumEmpregados).HasColumnName("cl_num_empregados");

                entity.Property(e => e.ClObs)
                    .HasColumnName("cl_obs")
                    .HasColumnType("text");

                entity.Property(e => e.ClOpDirBackup)
                    .HasColumnName("cl_op_dir_backup")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClOpDirEntrada)
                    .HasColumnName("cl_op_dir_entrada")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClOpDirSaida)
                    .HasColumnName("cl_op_dir_saida")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClOpEnviaAuto)
                    .HasColumnName("cl_op_envia_auto")
                    .HasColumnType("char(1)")
                    .HasDefaultValueSql("('N')");

                entity.Property(e => e.ClOpHabilitaTipoCharge)
                    .HasColumnName("CL_OP_HABILITA_TIPO_CHARGE")
                    .HasColumnType("char(1)");

                entity.Property(e => e.ClOpModoEnvio)
                    .HasColumnName("cl_op_modo_envio")
                    .HasColumnType("char(1)")
                    .HasDefaultValueSql("('W')");

                entity.Property(e => e.ClOpNecessitaAprov)
                    .HasColumnName("cl_op_necessita_aprov")
                    .HasColumnType("char(1)")
                    .HasDefaultValueSql("('N')");

                entity.Property(e => e.ClOperaSomenteBanco)
                    .HasColumnName("cl_OperaSomenteBanco")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('N')");

                entity.Property(e => e.ClOrgaoExp)
                    .HasColumnName("cl_orgao_exp")
                    .HasColumnType("char(16)");

                entity.Property(e => e.ClPais)
                    .HasColumnName("cl_pais")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClPaisCor)
                    .HasColumnName("cl_pais_cor")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClPassaporte)
                    .HasColumnName("CL_PASSAPORTE")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ClPorteEmpresa)
                    .HasColumnName("CL_PORTE_EMPRESA")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ClProfissao)
                    .HasColumnName("cl_profissao")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClRamoAtiv)
                    .HasColumnName("cl_ramo_ativ")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClRazaoSocial)
                    .HasColumnName("cl_razao_social")
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.ClResidente)
                    .HasColumnName("cl_residente")
                    .HasColumnType("char(1)");

                entity.Property(e => e.ClRg)
                    .HasColumnName("cl_rg")
                    .HasColumnType("char(18)");

                entity.Property(e => e.ClSistemaOrigem)
                    .HasColumnName("CL_SISTEMA_ORIGEM")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.ClSobrenome)
                    .HasColumnName("cl_sobrenome")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClStatus)
                    .HasColumnName("cl_status")
                    .HasColumnType("char(1)");

                entity.Property(e => e.ClStatusCadastro)
                    .HasColumnName("CL_STATUS_CADASTRO")
                    .HasColumnType("char(1)");

                entity.Property(e => e.ClTarifa)
                    .HasColumnName("cl_tarifa")
                    .HasColumnType("char(5)");

                entity.Property(e => e.ClTarifavol)
                    .HasColumnName("cl_tarifavol")
                    .HasColumnType("char(1)");

                entity.Property(e => e.ClTelCom)
                    .HasColumnName("cl_tel_com")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ClTelRes)
                    .HasColumnName("cl_tel_res")
                    .HasMaxLength(23)
                    .IsUnicode(false);

                entity.Property(e => e.ClTipDoc)
                    .HasColumnName("cl_tip_doc")
                    .HasColumnType("char(4)");

                entity.Property(e => e.ClTipo)
                    .HasColumnName("CL_TIPO")
                    .HasColumnType("char(3)")
                    .HasDefaultValueSql("('BAN')");

                entity.Property(e => e.ClTipoConta)
                    .HasColumnName("cl_tipo_conta")
                    .HasColumnType("char(2)");

                entity.Property(e => e.ClTipoConta2)
                    .HasColumnName("cl_tipo_conta2")
                    .HasColumnType("char(2)");

                entity.Property(e => e.ClTipoConta3)
                    .HasColumnName("cl_tipo_conta3")
                    .HasColumnType("char(2)");

                entity.Property(e => e.ClTipoContaExt)
                    .HasColumnName("cl_tipo_conta_ext")
                    .HasColumnType("char(2)");

                entity.Property(e => e.ClTipoContaExt2)
                    .HasColumnName("cl_tipo_conta_ext2")
                    .HasColumnType("char(2)");

                entity.Property(e => e.ClTipoContaExt3)
                    .HasColumnName("cl_tipo_conta_ext3")
                    .HasColumnType("char(2)");

                entity.Property(e => e.ClTipoEndCorresp)
                    .HasColumnName("CL_TIPO_END_CORRESP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.ClTpoIdentidade)
                    .HasColumnName("cl_Tpo_Identidade")
                    .HasColumnType("char(10)");

                entity.Property(e => e.CodPaisNacionalidade).HasColumnName("COD_PAIS_NACIONALIDADE");

                entity.Property(e => e.CodigoTitular)
                    .HasColumnName("codigo_titular")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CompAno).HasColumnName("comp_ano");

                entity.Property(e => e.CompMes).HasColumnName("comp_mes");

                entity.Property(e => e.ContaContabil)
                    .HasColumnName("conta_contabil")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CrLimite).HasColumnName("cr_limite");

                entity.Property(e => e.DataAceitaEfetAutoOrdem)
                    .HasColumnName("data_aceita_efet_auto_ordem")
                    .HasColumnType("datetime");

                entity.Property(e => e.DocBens)
                    .HasColumnName("doc_bens")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocCadastro)
                    .HasColumnName("doc_cadastro")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocCadastroSocios)
                    .HasColumnName("doc_cadastro_socios")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocCartaoAss)
                    .HasColumnName("doc_cartao_ass")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocContratoSocial)
                    .HasColumnName("doc_contrato_social")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocCopiaCnpj)
                    .HasColumnName("doc_copia_cnpj")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocCpf)
                    .HasColumnName("doc_cpf")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocEscrituras)
                    .HasColumnName("doc_escrituras")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocFichaCadastro)
                    .HasColumnName("doc_ficha_cadastro")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocHolerite)
                    .HasColumnName("doc_holerite")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocIr)
                    .HasColumnName("doc_ir")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocLuz)
                    .HasColumnName("doc_luz")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocProcuracao)
                    .HasColumnName("doc_procuracao")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocRecebido)
                    .HasColumnName("doc_recebido")
                    .HasColumnType("datetime");

                entity.Property(e => e.DocRg)
                    .HasColumnName("doc_rg")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocUltBalanco)
                    .HasColumnName("doc_ult_balanco")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocVencimento)
                    .HasColumnName("doc_vencimento")
                    .HasColumnType("datetime");

                entity.Property(e => e.EmVinculada).HasColumnName("EM_VINCULADA");

                entity.Property(e => e.FlagNomeAlterado).HasColumnName("Flag_Nome_Alterado");

                entity.Property(e => e.FlgAceitaEfetAutoOrdem)
                    .HasColumnName("flg_aceita_efet_auto_ordem")
                    .HasColumnType("char(1)");

                entity.Property(e => e.FlgAssinaDigitalmente)
                    .HasColumnName("Flg_Assina_Digitalmente")
                    .HasColumnType("char(1)")
                    .HasDefaultValueSql("('N')");

                entity.Property(e => e.FlgProcessaGooglePortal)
                    .HasColumnName("flg_ProcessaGooglePortal")
                    .HasColumnType("char(1)")
                    .HasDefaultValueSql("('S')");

                entity.Property(e => e.FlgValorDiferenciado)
                    .HasColumnName("flg_valor_diferenciado")
                    .HasColumnType("char(1)")
                    .HasDefaultValueSql("('N')");

                entity.Property(e => e.IdApresentante).HasColumnName("id_apresentante");

                entity.Property(e => e.IdAssessor).HasColumnName("id_assessor");

                entity.Property(e => e.IdCorretora).HasColumnName("id_corretora");

                entity.Property(e => e.IdReIndicacao).HasColumnName("id_re_indicacao");

                entity.Property(e => e.IofIsento)
                    .HasColumnName("IOF_Isento")
                    .HasColumnType("char(1)")
                    .HasDefaultValueSql("('N')");

                entity.Property(e => e.IrIsento)
                    .HasColumnName("IR_Isento")
                    .HasColumnType("char(1)");

                entity.Property(e => e.IrSaida)
                    .HasColumnName("IR_SAIDA")
                    .HasColumnType("char(1)");

                entity.Property(e => e.NomeMae)
                    .HasColumnName("nome_mae")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.NomePai)
                    .HasColumnName("nome_pai")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PreBoletoCompraAutomatico)
                    .IsRequired()
                    .HasColumnType("char(1)")
                    .HasDefaultValueSql("('S')");
            });

            modelBuilder.Entity<TblUsers>(entity =>
            {
                entity.HasKey(e => e.IdUser);

                entity.ToTable("TBL_USERS");

                entity.HasIndex(e => e.UrNome)
                    .HasName("IDX_TBL_USERS_001");

                entity.HasIndex(e => e.UrUsername)
                    .HasName("_dta_index_TBL_USERS_5_1538104520__K9");

                entity.HasIndex(e => new { e.IdUser, e.UrUsername })
                    .HasName("_dta_index_TBL_USERS_5_1538104520__K1_9");

                entity.Property(e => e.IdUser).HasColumnName("id_user");

                entity.Property(e => e.AprovaRecebimento).HasColumnName("Aprova_Recebimento");

                entity.Property(e => e.AprovadorDadosBancariosSwift).HasColumnType("char(1)");

                entity.Property(e => e.AprovadorHorarioCorte).HasColumnType("char(1)");

                entity.Property(e => e.AprovadorSwiftCcme)
                    .HasColumnName("AprovadorSwiftCCME")
                    .HasColumnType("char(1)");

                entity.Property(e => e.ConsultaEopera).HasColumnName("ConsultaEOpera");

                entity.Property(e => e.EditaOrdem).HasColumnName("edita_ordem");

                entity.Property(e => e.IdCorretora).HasColumnName("id_corretora");

                entity.Property(e => e.IdFilial).HasColumnName("ID_FILIAL");

                entity.Property(e => e.LimiteAprovaDocumentacao)
                    .HasColumnName("Limite_Aprova_Documentacao")
                    .HasColumnType("numeric(15, 2)");

                entity.Property(e => e.LimiteDiario)
                    .HasColumnName("limiteDiario")
                    .HasColumnType("decimal(18, 0)")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.LimiteTipoBoletoBancario).HasColumnName("LimiteTipoBoleto_Bancario");

                entity.Property(e => e.LimiteTipoCC).HasColumnName("LimiteTipoC_C");

                entity.Property(e => e.LimiteTipoDocTed).HasColumnName("LimiteTipoDoc_Ted");

                entity.Property(e => e.LimiteTipoMoedaEstrangeira).HasColumnName("LimiteTipoMoeda_Estrangeira");

                entity.Property(e => e.Limiteordem).HasColumnName("limiteordem");

                entity.Property(e => e.LimiteordemInbound).HasColumnName("LIMITEORDEM_INBOUND");

                entity.Property(e => e.LimiteordemMensal).HasColumnName("limiteordem_mensal");

                entity.Property(e => e.OperaApenasPendenteDeRecebimento).HasColumnName("operaApenasPendenteDeRecebimento");

                entity.Property(e => e.OperaCcme)
                    .HasColumnName("OperaCCME")
                    .HasColumnType("char(1)");

                entity.Property(e => e.OperaRemessaExpressa)
                    .HasColumnName("operaRemessaExpressa")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.Operaremessaexpressainbound).HasColumnName("OPERAREMESSAEXPRESSAINBOUND");

                entity.Property(e => e.OperasemconsRfb).HasColumnName("operasemconsRFB");

                entity.Property(e => e.PermiteExcluirLancamento).HasColumnType("char(1)");

                entity.Property(e => e.SCcmeUrNivel)
                    .HasColumnName("s_ccme_ur_nivel")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.SCcmeUrTipo)
                    .HasColumnName("s_ccme_ur_tipo")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.TipoBoletoBancario).HasColumnName("Tipo_BoletoBancario");

                entity.Property(e => e.TipoCC).HasColumnName("Tipo_C_C");

                entity.Property(e => e.TipoCartao).HasColumnName("Tipo_Cartao");

                entity.Property(e => e.TipoCheque).HasColumnName("Tipo_Cheque");

                entity.Property(e => e.TipoDocTed).HasColumnName("Tipo_Doc_Ted");

                entity.Property(e => e.TipoEspecie).HasColumnName("Tipo_Especie");

                entity.Property(e => e.TipoMoedaestrangeira)
                    .HasColumnName("tipo_moedaestrangeira")
                    .HasDefaultValueSql("(1)");

                entity.Property(e => e.UrAprovaprocuracao).HasColumnName("ur_aprovaprocuracao");

                entity.Property(e => e.UrConsulta)
                    .HasColumnName("UR_CONSULTA")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.UrCpf)
                    .HasColumnName("ur_cpf")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.UrDtAlteracao)
                    .HasColumnName("ur_dt_alteracao")
                    .HasColumnType("datetime");

                entity.Property(e => e.UrDtInclusao)
                    .HasColumnName("ur_dt_inclusao")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UrEmail)
                    .HasColumnName("ur_email")
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.UrErros)
                    .HasColumnName("ur_erros")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.UrGaCod).HasColumnName("ur_ga_cod");

                entity.Property(e => e.UrNivel)
                    .HasColumnName("ur_nivel")
                    .HasColumnType("char(1)");

                entity.Property(e => e.UrNome)
                    .HasColumnName("ur_nome")
                    .HasMaxLength(64)
                    .IsUnicode(false);

                entity.Property(e => e.UrObs)
                    .HasColumnName("ur_obs")
                    .HasColumnType("text");

                entity.Property(e => e.UrOpValReaisMax)
                    .HasColumnName("UR_OP_VAL_REAIS_MAX")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.UrRg)
                    .HasColumnName("ur_rg")
                    .HasColumnType("char(12)");

                entity.Property(e => e.UrSenha)
                    .HasColumnName("ur_senha")
                    .HasMaxLength(32)
                    .IsUnicode(false);

                entity.Property(e => e.UrSpread)
                    .HasColumnName("ur_spread")
                    .HasColumnType("decimal(10, 2)");

                entity.Property(e => e.UrStatus)
                    .HasColumnName("ur_status")
                    .HasColumnType("char(1)");

                entity.Property(e => e.UrTelefone)
                    .HasColumnName("ur_telefone")
                    .HasMaxLength(16)
                    .IsUnicode(false);

                entity.Property(e => e.UrTipo)
                    .HasColumnName("ur_tipo")
                    .HasColumnType("char(1)");

                entity.Property(e => e.UrUsername)
                    .HasColumnName("ur_username")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UrVolume)
                    .HasColumnName("ur_volume")
                    .HasColumnType("decimal(10, 2)");
            });

            modelBuilder.Entity<TBL_COL_SPREAD_DIA>(entity =>
            {
                entity.HasKey(e => e.SPD_SPREAD_ID);

                entity.ToTable("TBL_COL_SPREAD_DIA");               

                entity.Property(e => e.SPD_VALIDADE_INICIO).HasColumnName("SPD_VALIDADE_INICIO");

                entity.Property(e => e.SPD_VALIDADE_FIM).HasColumnName("SPD_VALIDADE_FIM");

                entity.Property(e => e.SPD_CLIENTE_ESPECIFICO).HasColumnName("SPD_CLIENTE_ESPECIFICO");

                entity.Property(e => e.SPD_GRUPO_ESPECIFICO).HasColumnName("SPD_GRUPO_ESPECIFICO");

                entity.Property(e => e.SPD_GRUPO_ESPECIFICO).HasColumnName("SPD_GRUPO_ESPECIFICO");

                entity.Property(e => e.SPD_TX_SPREAD).HasColumnName("SPD_TX_SPREAD");

                entity.Property(e => e.SPD_MOEDA).HasColumnName("SPD_MOEDA");

                entity.Property(e => e.SPD_STATUS).HasColumnName("SPD_STATUS");

                entity.Property(e => e.SPD_IDUSER_LOG).HasColumnName("SPD_IDUSER_LOG");

                entity.Property(e => e.SPD_VALOR_DE).HasColumnName("SPD_VALOR_DE");

                entity.Property(e => e.SPD_VALOR_ATE).HasColumnName("SPD_VALOR_ATE");

                entity.Property(e => e.SPD_TIPO_OP).HasColumnName("SPD_TIPO_OP");

                entity.Property(e => e.SPD_TIPO_ENTREGA).HasColumnName("SPD_TIPO_ENTREGA");

                entity.Property(e => e.SPD_TIPO_CLIENTE_COL).HasColumnName("SPD_TIPO_CLIENTE_COL");

                entity.Property(e => e.SPD_APLICA_VAREJO).HasColumnName("SPD_APLICA_VAREJO");

                entity.Property(e => e.SPD_MARGEM_OPER_AMAIOR).HasColumnName("SPD_MARGEM_OPER_AMAIOR");

                entity.Property(e => e.SPD_MARGEM_OPER_AMENOR).HasColumnName("SPD_MARGEM_OPER_AMENOR");

            });
        }
    }
}
