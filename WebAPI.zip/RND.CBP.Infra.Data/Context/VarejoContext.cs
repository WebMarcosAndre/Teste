﻿using Microsoft.EntityFrameworkCore;
using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using static RND.CBP.Domain.Entities.TMoeda;

namespace RND.CBP.Infra.Data.Context
{
    public partial class VarejoContext : DbContext
    {

        public VarejoContext()
        {

        }

        public VarejoContext(DbContextOptions<VarejoContext> options) : base(options)
        {

        }

        public virtual DbSet<TMoeda> TMoedas { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //IConfigurationRoot configuration = new ConfigurationBuilder().Build();
                //optionsBuilder.UseSqlServer("Server=REND-SRVDSQL-01; Database=IK_VAREJO; Trusted_Connection=True; MultipleActiveResultSets=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TMoeda>(entity =>
            {
                entity.HasKey(e => e.Cod_moeda);
                entity.Property(e => e.Cod_moeda).HasColumnName("Cod_moeda");

                entity.Property(e => e.Tx_Banco).HasColumnName("Tx_Banco");

                entity.Property(e => e.Tx_Cotacao).HasColumnName("Tx_Cotacao");

                entity.Property(e => e.Custo).HasColumnName("Custo");

                entity.Property(e => e.Tx_cotacaoC).HasColumnName("Tx_cotacaoC");

                entity.Property(e => e.HoraCot).HasColumnName("HoraCot");

                entity.Property(e => e.Paridade).HasColumnName("Paridade");

                entity.Property(e => e.rowguid).HasColumnName("rowguid");

                entity.Property(e => e.ordem).HasColumnName("ordem");

                entity.Property(e => e.Tx_Compra).HasColumnName("Tx_Compra");

                entity.Property(e => e.Tx_Venda).HasColumnName("Tx_Venda");

                entity.Property(e => e.clas_paridade).HasColumnName("clas_paridade");

                entity.Property(e => e.Codigo_Moeda).HasColumnName("Codigo_Moeda");

                entity.Property(e => e.mes_letra).HasColumnName("mes_letra");
            });
        }
    }
}
