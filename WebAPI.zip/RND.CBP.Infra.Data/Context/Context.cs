﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Entities.Elmah_Error;
using System.Linq;

namespace RND.CBP.Infra.Data.Context
{
    public class SqlContext : DbContext
    {
        public SqlContext()
        {
        }

        public SqlContext(DbContextOptions<SqlContext> options) : base(options)
        {
        }
        public virtual DbSet<BancoRemessa> BancoRemessa { get; set; }
        public virtual DbSet<Dominio> Dominio { get; set; }
        public virtual DbSet<Empresa> Empresa { get; set; }
        public virtual DbSet<EmpresaGrupo> EmpresaGrupo { get; set; }
        public virtual DbSet<Moeda> Moeda { get; set; }
        public virtual DbSet<Pais> Pais { get; set; }
        public virtual DbSet<ParametroRemessa> ParametroRemessa { get; set; }
        public virtual DbSet<ParametroRemessaLog> ParametroRemessaLog { get; set; }
        public virtual DbSet<Remessa> Remessa { get; set; }
        public virtual DbSet<Sistema> Sistema { get; set; }
        public virtual DbSet<StatusRemessa> StatusRemessa { get; set; }
        public virtual DbSet<StatusSistema> StatusSistema { get; set; }
        public virtual DbSet<Tarifa> Tarifa { get; set; }
        public virtual DbSet<TarifaDetalhe> TarifaDetalhe { get; set; }
        public virtual DbSet<TarifaDetalheLog> TarifaDetalheLog { get; set; }
        public virtual DbSet<TipoAplicacao> TipoAplicacao { get; set; }
        public virtual DbSet<TipoPeriodo> TipoPeriodo { get; set; }
        public virtual DbSet<ELMAH_Error> Elmah_Error { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder().Build();
                optionsBuilder.UseSqlServer("Server=REND-SRVDSQL-05; Database=CBP; Trusted_Connection=True; MultipleActiveResultSets=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BancoRemessa>(entity =>
            {
                entity.Property(e => e.CodigoStatus)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.CodigoSwift)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CodigoSwiftReduzido)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false);

                entity.Property(e => e.CodigoTipoTarifa)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Dominio>(entity =>
            {
                entity.Property(e => e.Descricao)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MetodoChamada)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Request).IsUnicode(false);

                entity.Property(e => e.Uri)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Verbo)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MetodoRetorno)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Request).IsUnicode(false);

                entity.Property(e => e.UriRetorno)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Intervalo);

                entity.Property(e => e.OrdemExecucao);

                entity.Property(e => e.TokenChamada)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.TokenRetorno)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Empresa>(entity =>
            {
                entity.Property(e => e.CodigoEmpresa)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.CodigoStatus)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.NomeEmpresa)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ValorMaximoRemessa).HasColumnType("numeric(15, 4)");

                entity.Property(e => e.ValorMinimoRemessa).HasColumnType("numeric(15, 4)");
            });

            modelBuilder.Entity<EmpresaGrupo>(entity =>
            {
                entity.ToTable("EmpresaGrupo", "dbo");

                entity.Property(e => e.CodigoStatusEmpresaGrupo)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.NomeEmpresaGrupo)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.NomeResumido)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NumeroCnpj)
                    .IsRequired()
                    .HasMaxLength(17)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Moeda>(entity =>
            {
                entity.ToTable("Moeda", "dbo");

                entity.Property(e => e.CodigoMoeda)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.NomeMoeda)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Simbolo)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Tipo)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.HasOne(d => d.Pais)
                    .WithMany(p => p.Moeda)
                    .HasForeignKey(d => d.PaisIdPadrao)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_moeda_pais");
            });

            modelBuilder.Entity<Pais>(entity =>
            {
                entity.Property(e => e.CodigoPais)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.CodigoStatus)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.NomeAbreviado)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NomePais)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ParametroRemessa>(entity =>
            {
                entity.ToTable("ParametroRemessa", "dbo");

                entity.Property(e => e.CodigoTipoRemessa)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.HoraFimPeriodo).HasColumnType("time(1)");

                entity.Property(e => e.HoraInicioPeriodo).HasColumnType("time(1)");

                entity.Property(e => e.TipoPessoa)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.ValorLimiteOperacao).HasColumnType("numeric(15, 2)");

                entity.Property(e => e.ValorLimitePeriodo).HasColumnType("numeric(15, 2)");

                entity.Property(e => e.ValorOverSpread).HasColumnType("numeric(10, 2)");

                entity.HasOne(d => d.EmpresaGrupo)
                    .WithMany(p => p.ParametroRemessa)
                    .HasForeignKey(d => d.EmpresaGrupoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Parametro__Empre__5BE2A6F2");

                entity.HasOne(d => d.Sistema)
                    .WithMany(p => p.ParametroRemessa)
                    .HasForeignKey(d => d.SistemaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ParametroRemessa_Sistema");

                entity.HasOne(d => d.TipoPeriodo)
                    .WithMany(p => p.ParametroRemessa)
                    .HasForeignKey(d => d.TipoPeriodoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ParametroRemessa_TipoPeriodo");
            });

            modelBuilder.Entity<ParametroRemessaLog>(entity =>
            {
                entity.ToTable("ParametroRemessaLog", "dbo");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CodigoTipoRemessa)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.DataAlteracao).HasColumnType("datetime");

                entity.Property(e => e.HoraFimPeriodo).HasColumnType("time(1)");

                entity.Property(e => e.HoraInicioPeriodo).HasColumnType("time(1)");

                entity.Property(e => e.TipoPessoa)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.ValorLimiteOperacao).HasColumnType("numeric(15, 2)");

                entity.Property(e => e.ValorLimitePeriodo).HasColumnType("numeric(15, 2)");

                entity.Property(e => e.ValorOverSpread).HasColumnType("numeric(10, 2)");
            });

            modelBuilder.Entity<Remessa>(entity =>
            {
                entity.Property(e => e.CodigoContrato);

                entity.Property(e => e.CodigoMoeda)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CodigoSistemaOrigem)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.CodigoStatusEnvio)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.DataRemessa).HasColumnType("datetime");

                entity.Property(e => e.IdCliente);

                entity.Property(e => e.IdStatusRemessa)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.IdTfPin)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.IdUsuario);

                entity.Property(e => e.OpNboleto).HasColumnName("OpNBoleto");

                entity.Property(e => e.ValorRemessaME)
                    .HasColumnName("ValorRemessaME")
                    .HasColumnType("numeric(20, 4)");

                entity.Property(e => e.ValorRemessaMN)
                    .HasColumnName("ValorRemessaMN")
                    .HasColumnType("numeric(20, 4)");

                entity.Property(e => e.ValorTaxaCambio).HasColumnType("numeric(10, 4)");

                entity.HasOne(d => d.IdStatusRemessaNavigation)
                    .WithMany(p => p.Remessa)
                    .HasForeignKey(d => d.IdStatusRemessa)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Remessa__CodigoS__108B795B");
            });

            modelBuilder.Entity<Sistema>(entity =>
            {
                entity.ToTable("Sistema", "dbo");

                entity.Property(e => e.NomeSistema)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UrlSistema)
                    .IsRequired()
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.HasOne(d => d.StatusSistema)
                    .WithMany(p => p.Sistema)
                    .HasForeignKey(d => d.StatusSistemaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Sistema__StatusS__59063A47");
            });

            modelBuilder.Entity<StatusRemessa>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.NomeStatusRemessa)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StatusSistema>(entity =>
            {
                entity.ToTable("StatusSistema", "dbo");

                entity.Property(e => e.CodigoStatusSistema)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.NomeStatusSistema)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Tarifa>(entity =>
            {
                entity.Property(e => e.CodigoStatus)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.TipoRemessa)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.HasOne(d => d.EmpresaGrupo)
                    .WithMany(p => p.Tarifa)
                    .HasForeignKey(d => d.EmpresaGrupoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_tarifa_empresagrupo");

                entity.HasOne(d => d.Empresa)
                    .WithMany(p => p.Tarifa)
                    .HasForeignKey(d => d.EmpresaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Tarifa__IdEmpres__25869641");

                entity.HasOne(d => d.TipoAplicacao)
                    .WithMany(p => p.Tarifa)
                    .HasForeignKey(d => d.TipoAplicacaoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Tarifa__IdTipoAp__267ABA7A");
            });

            modelBuilder.Entity<TarifaDetalhe>(entity =>
            {
                entity.Property(e => e.CodigoStatus)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CodigoTipoTarifa)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.CodMoedaRemessa)
                   .IsRequired()
                   .HasMaxLength(3)
                   .IsUnicode(false);

                entity.Property(e => e.ValorTarifa).HasColumnType("numeric(12, 4)");

                entity.Property(e => e.ValorMinimoRemessa).HasColumnType("numeric(15, 4)");

                entity.Property(e => e.ValorMaximoRemessa).HasColumnType("numeric(15, 4)");

                entity.Property(e => e.ValorCustoTarifa).HasColumnType("numeric(12, 4)");

                entity.HasOne(d => d.Moeda)
                    .WithMany(p => p.TarifaDetalhe)
                    .HasForeignKey(d => d.MoedaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_tarifadetalhe_moeda");

                entity.HasOne(d => d.Sistema)
                    .WithMany(p => p.TarifaDetalhe)
                    .HasForeignKey(d => d.SistemaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_tarifadetalhe_sistemaid");

                entity.HasOne(d => d.Tarifa)
                    .WithMany(p => p.TarifaDetalhe)
                    .HasForeignKey(d => d.TarifaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TarifaDetalhe_Tarifa");

                entity.Property(e => e.TipoPessoa).HasColumnName("TipoPessoa");
            });

            modelBuilder.Entity<TarifaDetalheLog>(entity =>
            {
                entity.ToTable("TarifaDetalheLog", "dbo");

                entity.Property(e => e.CodMoedaRemessa)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CodigoStatus)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.CodigoTipoTarifa)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.DataAlteracao).HasColumnType("datetime");

                entity.Property(e => e.TipoPessoa)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.ValorCustoTarifa).HasColumnType("numeric(12, 4)");

                entity.Property(e => e.ValorMaximoRemessa).HasColumnType("numeric(15, 4)");

                entity.Property(e => e.ValorMinimoRemessa).HasColumnType("numeric(15, 4)");

                entity.Property(e => e.ValorTarifa).HasColumnType("numeric(12, 4)");
            });

            modelBuilder.Entity<TipoAplicacao>(entity =>
            {
                entity.Property(e => e.CodigoStatus)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.CodigoTipoAplicacao)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.NomeTipoAplicacao)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TipoPeriodo>(entity =>
            {
                entity.ToTable("TipoPeriodo", "dbo");

                entity.Property(e => e.CodigoStatus)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.NomeTipoPeriodo)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });
        }

        public void DetachLocal<T>(T t, int entryId) where T : BaseEntity
        {
            var local = this.Set<T>().Local.FirstOrDefault(entry => entry.Id == entryId);

            if (local != null)
            {
                this.Entry(local).State = EntityState.Detached;
            }
            this.Entry(t).State = EntityState.Modified;
        }
    }
}