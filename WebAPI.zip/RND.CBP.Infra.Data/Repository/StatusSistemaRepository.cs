﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Infra.Data.Context;

namespace RND.CBP.Infra.Data.Repository
{
    public class StatusSistemaRepository : BaseRepository<StatusSistema, int>, IStatusSistemaRepository
    {
        protected readonly SqlContext _sqlContext;

        public StatusSistemaRepository(SqlContext sqlContext) : base(sqlContext)
        {
            _sqlContext = sqlContext;
        }
    }
}