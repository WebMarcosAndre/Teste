﻿using Dapper;
using Microsoft.Extensions.Configuration;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Infra.Data.Context;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace RND.CBP.Infra.Data.Repository
{
    public class RemessaRepository : BaseRepository<Remessa, int>, IRemessaRepository
    {
        protected readonly SqlContext _context;
        protected readonly IkVarejoContext _ikVarejoContext;
        protected readonly VarejoContext _varejoContext;
        protected readonly IConfiguration _configuration;
        protected readonly DBVarejoContext _dbVarejoContext;

        public RemessaRepository(SqlContext context, IkVarejoContext ikVarejoContext,DBVarejoContext dbVarejoContext,
            IConfiguration configuration)
        {
            _context = context;
            _ikVarejoContext = ikVarejoContext;
            _configuration = configuration;
            _dbVarejoContext = dbVarejoContext;
        }

        public List<TblClientes> BuscarTodosClientesIkVarejo()
        {
            return (from t1 in _ikVarejoContext.TBL_CLIENTES
                    select new TblClientes
                    {
                        IdCliente = t1.IdCliente,
                        ClNome = t1.ClNome,
                        ClTipDoc = t1.ClTipDoc,
                        ClRazaoSocial = t1.ClRazaoSocial,
                        ClStatus = t1.ClStatus
                    }).ToList();
        }

        public List<TblClientes> BuscarNomesClientesIkVarejo()
        {
            return (from t1 in _ikVarejoContext.TBL_CLIENTES
                    select new TblClientes
                    {
                        ClNome = t1.ClNome
                    }).ToList();
        }

        public IEnumerable<object> FiltarRemessa(bool primeiraConsulta, string dataDe, string dataAte, char? codigoStatusRemessa, string pesquisarPor, string txtPesquisarPor, string tipoPessoa, string statusCliente)
        {
            var dataInicial = DateTime.Now.AddDays(-1);
            var dataFinal = DateTime.Now;

            switch (dataInicial.Day)
            {
                case (int)DayOfWeek.Sunday:
                    dataInicial.AddDays(-2);
                    break;
                case (int)DayOfWeek.Saturday:
                    dataInicial.AddDays(-1);
                    break;
            }
            var remessas = (from t1 in _context.Remessa
                            where dataInicial <= t1.DataRemessa && t1.DataRemessa <= dataFinal
                            select new
                            {
                                DataRemessa = t1.DataRemessa.Date,
                                t1.CodigoContrato,
                                t1.IdCliente,
                                t1.CodigoSistemaOrigem,
                                t1.CodigoMoeda,
                                t1.ValorTaxaCambio,
                                t1.ValorRemessaME,
                                t1.ValorRemessaMN,
                                t1.CodigoStatusEnvio,
                                t1.IdUsuario,
                                t1.IdStatusRemessa
                            }).ToList();

            var varejos = BuscarTodosClientesIkVarejo();

            var statusRemessas = (from t1 in _context.StatusRemessa
                                  select new
                                  {
                                      t1.Id,
                                      t1.NomeStatusRemessa
                                  }).ToList();

            var users = (from t1 in _ikVarejoContext.TBL_USERS
                         select new
                         {
                             t1.IdUser,
                             t1.UrNome,
                         }).ToList();

            try
            {
                if (primeiraConsulta)
                {


                    var listaJoin = from remessa in remessas
                                    join varejo in varejos on remessa.IdCliente equals varejo.IdCliente
                                    select new
                                    {
                                        DataRemessa = remessa.DataRemessa.Date,
                                        remessa.CodigoContrato,
                                        clNome = varejo.ClNome,
                                        razaosocial = varejo.ClRazaoSocial,
                                        remessa.CodigoSistemaOrigem,
                                        remessa.CodigoMoeda,
                                        remessa.ValorTaxaCambio,
                                        remessa.ValorRemessaME,
                                        remessa.ValorRemessaMN,
                                        remessa.CodigoStatusEnvio,
                                        remessa.IdStatusRemessa,
                                        remessa.IdUsuario
                                    } into intermediate
                                    join status in statusRemessas on intermediate.IdStatusRemessa equals status.Id
                                    select new
                                    {
                                        DataRemessa = intermediate.DataRemessa.Date,
                                        intermediate.CodigoContrato,
                                        clNome = (intermediate.clNome ?? intermediate.razaosocial),
                                        clRazaoSocial = intermediate.razaosocial,
                                        intermediate.CodigoSistemaOrigem,
                                        intermediate.CodigoMoeda,
                                        intermediate.ValorTaxaCambio,
                                        intermediate.ValorRemessaME,
                                        intermediate.ValorRemessaMN,
                                        intermediate.CodigoStatusEnvio,
                                        intermediate.IdStatusRemessa,
                                        intermediate.IdUsuario,
                                        status.NomeStatusRemessa
                                    } into intermediate2
                                    join lstUser in users on intermediate2.IdUsuario equals lstUser.IdUser
                                    select new
                                    {
                                        DataRemessa = intermediate2.DataRemessa.Date,
                                        intermediate2.CodigoContrato,
                                        clNome = (intermediate2.clNome ?? intermediate2.clRazaoSocial),
                                        intermediate2.CodigoSistemaOrigem,
                                        intermediate2.CodigoMoeda,
                                        intermediate2.ValorTaxaCambio,
                                        intermediate2.ValorRemessaME,
                                        intermediate2.ValorRemessaMN,
                                        intermediate2.CodigoStatusEnvio,
                                        intermediate2.IdStatusRemessa,
                                        lstUser.UrNome,
                                        intermediate2.NomeStatusRemessa
                                    };

                    return listaJoin;
                }

                else
                {
                    DateTime dateAte = Convert.ToDateTime(dataAte);
                    DateTime dataAteParam = dateAte.Date.Add(dataFinal.TimeOfDay);
                    DateTime dataDeParam = Convert.ToDateTime(dataDe);

                    remessas = (from t1 in _context.Remessa
                                where dataDeParam <= t1.DataRemessa && t1.DataRemessa <= dataAteParam
                                select new
                                {
                                    DataRemessa = t1.DataRemessa.Date,
                                    t1.CodigoContrato,
                                    t1.IdCliente,
                                    t1.CodigoSistemaOrigem,
                                    t1.CodigoMoeda,
                                    t1.ValorTaxaCambio,
                                    t1.ValorRemessaME,
                                    t1.ValorRemessaMN,
                                    t1.CodigoStatusEnvio,
                                    t1.IdUsuario,
                                    t1.IdStatusRemessa
                                }).ToList();

                    // filtro de status da Remessa
                    if (codigoStatusRemessa != null)
                    {
                        remessas = remessas.Where(d => d.IdStatusRemessa == codigoStatusRemessa).ToList();
                    }

                    // caso 1 - Nome razao social escolhido 2 txtpesquisarpor preenchido e 3 tipo pessoa fisico
                    if (pesquisarPor == "nome" && (!string.IsNullOrEmpty(txtPesquisarPor)) && (tipoPessoa == "cpf"))
                    {
                        varejos = varejos.Where(d => ((!string.IsNullOrEmpty(d.ClTipDoc) && (d.ClTipDoc.Trim() == "CPF")) &&
                                               ((!string.IsNullOrEmpty(d.ClNome)) && d.ClNome.Contains(txtPesquisarPor)))).ToList();
                    }

                    // caso 2 - Nome razao social escolhido 2 txtpesquisarpor preenchido e 3 tipo pessoa juridico
                    if (pesquisarPor == "nome" && (!string.IsNullOrEmpty(txtPesquisarPor)) && (tipoPessoa == "cnpj"))
                    {
                        varejos = varejos.Where(d => ((!string.IsNullOrEmpty(d.ClTipDoc) && (d.ClTipDoc.Trim() == "CNPJ")) &&
                                               ((!string.IsNullOrEmpty(d.ClRazaoSocial)) && d.ClRazaoSocial.Contains(txtPesquisarPor)))).ToList();
                    }

                    // caso 3 - Nome razao social escolhido 2 txtpesquisarpor preenchido e 3 tipo pessoa todos
                    if (pesquisarPor == "nome" && (!string.IsNullOrEmpty(txtPesquisarPor)) && (tipoPessoa == "todos"))
                    {
                        varejos = varejos.Where(d => ((!string.IsNullOrEmpty(d.ClNome) && d.ClNome.Contains(txtPesquisarPor)) ||
                                                     ((!string.IsNullOrEmpty(d.ClRazaoSocial)) && d.ClRazaoSocial.Contains(txtPesquisarPor)))).ToList();
                    }

                    // caso 4 - Nome razao social escolhido 2 txtPesquisarpor nulo e 3 tipo pessoa fisico
                    if (pesquisarPor == "nome" && (string.IsNullOrEmpty(txtPesquisarPor)) && (tipoPessoa == "cpf"))
                    {
                        varejos = varejos.Where(d => ((!string.IsNullOrEmpty(d.ClTipDoc)) && (d.ClTipDoc.Trim() == "CPF"))).ToList();
                    }

                    // caso 5 - Nome razao social escolhido 2 txtPesquisarpor nulo e 3 tipo pessoa juridico
                    if (pesquisarPor == "nome" && (string.IsNullOrEmpty(txtPesquisarPor)) && (tipoPessoa == "cnpj"))
                    {
                        varejos = varejos.Where(d => ((!string.IsNullOrEmpty(d.ClTipDoc)) && (d.ClTipDoc == "CNPJ"))).ToList();
                    }

                    // caso 6 - Documento escolhido 2 txtPesquisar preenchido e 3 tipo pessoa juridico
                    if (pesquisarPor == "documento" && (!string.IsNullOrEmpty(txtPesquisarPor)) && (tipoPessoa == "cnpj"))
                    {
                        varejos = varejos.Where(d => (((!string.IsNullOrEmpty(d.ClRazaoSocial)) && (d.ClRazaoSocial.Contains(txtPesquisarPor))) &&
                                                     ((!string.IsNullOrEmpty(d.ClTipDoc)) && (d.ClTipDoc == "CNPJ")))).ToList();
                    }

                    // caso 7 - Documento escolhido 2 txtPesquisar preenchido e 3 tipo pessoa fisico
                    if (pesquisarPor == "documento" && (!string.IsNullOrEmpty(txtPesquisarPor)) && (tipoPessoa == "cpf"))
                    {
                        varejos = varejos.Where(d => (((!string.IsNullOrEmpty(d.ClTipDoc)) && (d.ClTipDoc.Trim() == "CPF")) &&
                                                     ((!string.IsNullOrEmpty(d.ClNome)) && (d.ClNome.Contains(txtPesquisarPor))))).ToList();
                    }

                    // caso 8 - Documento escolhido 2 txtPesquisar nulo e 3 tipo pessoa juridico

                    if (pesquisarPor == "documento" && (string.IsNullOrEmpty(txtPesquisarPor)) && (tipoPessoa == "cnpj"))
                    {
                        varejos = varejos.Where(d => ((!string.IsNullOrEmpty(d.ClTipDoc)) && (d.ClTipDoc == "CNPJ"))).ToList();
                    }

                    // caso 9 - Documento escolhido 2 txtPesquisar nulo e 3 tipo pessoa fisico
                    if (pesquisarPor == "documento" && (string.IsNullOrEmpty(txtPesquisarPor)) && (tipoPessoa == "cpf"))
                    {
                        varejos = varejos.Where(d => ((!string.IsNullOrEmpty(d.ClTipDoc)) && (d.ClTipDoc.Trim() == "CPF"))).ToList();
                    }

                    // filtro de statusCliente
                    if (!string.IsNullOrEmpty(statusCliente) && statusCliente != "Todos")
                    {
                        varejos = varejos.Where(d => (((!string.IsNullOrEmpty(d.ClStatus)) && (d.ClStatus.Equals(statusCliente))))).ToList();
                    }

                    var listaJoin = from remessa in remessas
                                    join varejo in varejos on remessa.IdCliente equals varejo.IdCliente
                                    select new
                                    {
                                        DataRemessa = remessa.DataRemessa.Date,
                                        remessa.CodigoContrato,
                                        clNome = varejo.ClNome,
                                        razaosocial = varejo.ClRazaoSocial,
                                        remessa.CodigoSistemaOrigem,
                                        remessa.CodigoMoeda,
                                        remessa.ValorTaxaCambio,
                                        remessa.ValorRemessaME,
                                        remessa.ValorRemessaMN,
                                        remessa.CodigoStatusEnvio,
                                        remessa.IdStatusRemessa,
                                        remessa.IdUsuario
                                    } into intermediate
                                    join status in statusRemessas on intermediate.IdStatusRemessa equals status.Id
                                    select new
                                    {
                                        DataRemessa = intermediate.DataRemessa.Date,
                                        intermediate.CodigoContrato,
                                        clNome = (intermediate.clNome ?? intermediate.razaosocial),
                                        clRazaoSocial = intermediate.razaosocial,
                                        intermediate.CodigoSistemaOrigem,
                                        intermediate.CodigoMoeda,
                                        intermediate.ValorTaxaCambio,
                                        intermediate.ValorRemessaME,
                                        intermediate.ValorRemessaMN,
                                        intermediate.CodigoStatusEnvio,
                                        intermediate.IdStatusRemessa,
                                        intermediate.IdUsuario,
                                        status.NomeStatusRemessa
                                    } into intermediate2
                                    join lstUser in users on intermediate2.IdUsuario equals lstUser.IdUser
                                    select new
                                    {
                                        DataRemessa = intermediate2.DataRemessa.Date,
                                        intermediate2.CodigoContrato,
                                        clNome = (intermediate2.clNome ?? intermediate2.clRazaoSocial),
                                        intermediate2.CodigoSistemaOrigem,
                                        intermediate2.CodigoMoeda,
                                        intermediate2.ValorTaxaCambio,
                                        intermediate2.ValorRemessaME,
                                        intermediate2.ValorRemessaMN,
                                        intermediate2.CodigoStatusEnvio,
                                        intermediate2.IdStatusRemessa,
                                        lstUser.UrNome,
                                        intermediate2.NomeStatusRemessa
                                    };

                    return listaJoin;
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IEnumerable<object> GetSearchValue(string search)
        {
            search = search.ToLower();

            var varejos = (from t1 in _ikVarejoContext.TBL_CLIENTES
                           where t1.ClNome.ToLower().Contains(search)
                           select new
                           {
                               t1.IdCliente,
                               t1.ClNome
                           }).ToList();


            List<TblClientes> allSearch = varejos.Where(x => x.ClNome != null && x.ClNome.ToLower().Contains(search)).Select(x => new TblClientes
            {
                IdCliente = x.IdCliente,
                ClNome = x.ClNome
            }).Take(20).ToList();

            return allSearch;
        }

        public List<TblClientes> BuscarClienteId(int clientId)
        {
            return (from c in _ikVarejoContext.TBL_CLIENTES
                    select new TblClientes
                    {
                        IdCliente = c.IdCliente,
                        ClNome = c.ClNome,
                        ClTipDoc = c.ClTipDoc,
                        ClRazaoSocial = c.ClRazaoSocial,
                        ClStatus = c.ClStatus,
                        ClTarifa = c.ClTarifa,
                    }).Where(x => x.IdCliente == clientId).ToList();
        }
        public IQueryable<TBL_COL_PARAM_PRODUTOS> BuscarParametroProduto()
        {
            using (SqlConnection conexao = new SqlConnection(_configuration.GetConnectionString("Varejo")))
            {
                return conexao.Query<TBL_COL_PARAM_PRODUTOS>(
                      $@"Select * from TBL_COL_PARAM_PRODUTOS").AsQueryable();
            }
        }
       
        public List<TBL_TARIFAS_PADRAO> BuscarTarifa(int idCliente, string tipoOp, string formaEntrega, string clTarifa, decimal valor)
        {
            return (from t in _ikVarejoContext.TBL_TARIFAS_PADRAO
                    select new TBL_TARIFAS_PADRAO
                    {
                        id_tp = t.id_tp,
                        id_user = t.id_user,
                        tp_indice = t.tp_indice,
                        tp_tipo = t.tp_tipo,
                        tp_operacao = t.tp_operacao,
                        tp_val_minimo = t.tp_val_minimo,
                        tp_val_maximo = t.tp_val_maximo,
                        tp_moeda = t.tp_moeda,
                        tp_val_tarifa = t.tp_val_tarifa,
                        tp_obs = t.tp_obs,
                        tp_dt_inclusao = t.tp_dt_inclusao,
                        tp_dt_alteracao = t.tp_dt_alteracao,
                    }).Where(x => x.tp_operacao == tipoOp && x.tp_tipo == formaEntrega
                    && x.tp_indice == clTarifa && x.tp_val_minimo <= valor 
                    && x.tp_val_maximo >= valor).ToList();
        }
        public List<TBL_REGRAS_TARIFAS_CLI> BuscarRegrasTarifa(int idCliente, string tipoOp, string formaEntrega, string clTarifa, decimal valor)
        {
            return (from t in _ikVarejoContext.TBL_REGRAS_TARIFAS_CLI
                    select new TBL_REGRAS_TARIFAS_CLI
                    {
                        id_rc = t.id_rc,
                        id_user = t.id_user,
                        id_cliente = t.id_cliente,
                        rc_tipo = t.rc_tipo,
                        rc_operacao = t.rc_operacao,
                        rc_val_minimo = t.rc_val_minimo,
                        rc_val_maximo = t.rc_val_maximo,
                        rc_moeda = t.rc_moeda,
                        rc_val_tarifa = t.rc_val_tarifa,
                        rc_obs = t.rc_obs,
                        rc_dt_inclusao = t.rc_dt_inclusao,
                        rc_dt_alteracao = t.rc_dt_alteracao
                    }).Where(x => x.id_cliente == idCliente && x.rc_operacao == tipoOp
                    && x.rc_tipo == formaEntrega && x.rc_val_minimo <= valor
                    && x.rc_val_maximo >= valor).ToList();
        }
        public List<TBL_REGRAS_TARIFAS> BuscarTarifaRendimento(string tipoOp, string tipoEntrega, decimal valorTarifa)
        {
            return (from t in _ikVarejoContext.TBL_REGRAS_TARIFAS
                    select new TBL_REGRAS_TARIFAS
                    {
                        id_rt = t.id_rt,
                        id_user = t.id_user,
                        rt_tipo = t.rt_tipo,
                        rt_operacao = t.rt_operacao,
                        rt_val_minimo = t.rt_val_minimo, 
                        rt_val_maximo = t.rt_val_maximo,
                        rt_moeda = t.rt_moeda,
                        rt_val_tarifa = t.rt_val_tarifa,
                        rt_dt_inclusao = t.rt_dt_inclusao,
                        rt_obs = t.rt_obs
                    }).Where(x =>  x.rt_operacao == tipoOp
                    && x.rt_tipo == tipoEntrega && x.rt_val_minimo <= valorTarifa
                    && x.rt_val_maximo >= valorTarifa).ToList();
        }
        public List<TBL_REGRAS_TARIFAS> BuscarTarifaCotacao(string tipoOp, string tipoEntrega, decimal valorTarifa)
        {
            return (from t in _dbVarejoContext.TBL_REGRAS_TARIFAS
                    select new TBL_REGRAS_TARIFAS
                    {
                        id_rt = t.id_rt,
                        id_user = t.id_user,
                        rt_tipo = t.rt_tipo,
                        rt_operacao = t.rt_operacao,
                        rt_val_minimo = t.rt_val_minimo,
                        rt_val_maximo = t.rt_val_maximo,
                        rt_moeda = t.rt_moeda,
                        rt_val_tarifa = t.rt_val_tarifa,
                        rt_dt_inclusao = t.rt_dt_inclusao,
                        rt_obs = t.rt_obs
                    }).Where(x => x.rt_operacao == tipoOp
                    && x.rt_tipo == tipoEntrega && x.rt_val_minimo <= valorTarifa
                    && x.rt_val_maximo >= valorTarifa).ToList();
        }
    }
}

