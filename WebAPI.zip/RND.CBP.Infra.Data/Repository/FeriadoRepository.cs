﻿using System.Collections.Generic;
using System.Linq;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Enum;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Infra.Data.Context;

namespace RND.CBP.Infra.Data.Repository
{
    public class FeriadoRepository : BaseRepository<Feriado, int>, IFeriadoRepository
    {
        protected readonly SqlContext _context;
        protected readonly DbFeriadoContext _dbFeriadoContext;

        public FeriadoRepository(SqlContext context, DbFeriadoContext dbFeriadoContext)
        {
            _context = context;
            _dbFeriadoContext = dbFeriadoContext;
        }

        public List<Feriado> BuscarFeriado(int dia, int mes, int ano)
        {
            var lista = (from tab in _dbFeriadoContext.Tbl_Feriado
                         join tc in _dbFeriadoContext.Tbl_FeriadoParametro on tab.Feriado_id equals tc.Feriado_id
                         where (
                         tab.Dia == dia 
                         && tab.Mes == mes 
                         && tab.Ano == ano 
                         && tc.Sistema_id == 2    
                         && tab.TipoFeriado_id != (int)EnumTipoFeriado.Internacional
                         )
                         select new Feriado
                         {
                             Feriado_id = tab.Feriado_id,
                             Dia = tab.Dia,
                             Mes = tab.Mes,
                             Descricao = tab.Descricao,
                             TipoFeriado_id = tab.TipoFeriado_id,
                             CreatedBy = tab.CreatedBy,
                             CreatedOn = tab.CreatedOn,
                             LastUpdateBy = tab.LastUpdateBy,
                             LastUpdateOn = tab.LastUpdateOn,
                             Ativo = tab.Ativo,
                             Ano = tab.Ano
                         }).ToList();

            return lista;
        }
    }
}
