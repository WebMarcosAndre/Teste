﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Infra.Data.Context;
using System.Collections.Generic;
using System.Linq;

namespace RND.CBP.Infra.Data.Repository
{
    public class BancoRemessaRepository : BaseRepository<BancoRemessa, int>, IBancoRemessaRepository
    {
        protected readonly SqlContext _sqlContext;

        public BancoRemessaRepository(SqlContext sqlContext) : base(sqlContext)
        {
            _sqlContext = sqlContext;
        }
    }
}
