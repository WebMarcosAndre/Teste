﻿using RND.CBP.Domain.Entities.Elmah_Error;
using RND.CBP.Domain.Interfaces;
using RND.CBP.Infra.Data;
using RND.CBP.Infra.Data.Context;
using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Infra.Data.Repository
{
    public class ELMAH_ErrorRepository : BaseRepository<ELMAH_Error, int>, IELMAH_ErrorRepository
    {

        protected readonly SqlContext _context;

        #region Construtor

        public ELMAH_ErrorRepository(SqlContext context) : base(context)
        {
            _context = context;
        }

        #endregion
    }
}
