﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Infra.Data.Context;

namespace RND.CBP.Infra.Data.Repository
{
    public class PaisRepository : BaseRepository<Pais, int>, IPaisRepository
    {
        protected readonly SqlContext _sqlContext;

        public PaisRepository(SqlContext sqlContext) : base(sqlContext)
        {
            _sqlContext = sqlContext;
        }
    }
}
