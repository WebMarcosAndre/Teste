﻿using RND.CBP.Domain.Entities;
using RND.CBP.Infra.Data.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using RND.CBP.Domain.Interfaces;
using Dapper;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace RND.CBP.Infra.Data.Repository
{
    public class CotacaoRepository : BaseRepository<Cotacao, int>, ICotacaoRepository
    {
        protected readonly SqlContext _sqlContext;
        protected readonly IkVarejoContext _ikVarejoContext;
        protected readonly VarejoContext _varejoContext;
        protected readonly IConfiguration _configuration;

        public CotacaoRepository(SqlContext sqlContext, IkVarejoContext ikVarejoContext, VarejoContext varejoContext, 
            IConfiguration configuration)
        {
            _sqlContext = sqlContext;
            _ikVarejoContext = ikVarejoContext;
            _varejoContext = varejoContext;
            _configuration = configuration;
        }

        public int RecuperaIdCliente(string numdoc)
        {

            int idCliente = _ikVarejoContext.TBL_CLIENTES.Where(x => x.ClNumDoc == numdoc).
                 Select(u => u.IdCliente).FirstOrDefault();

            return idCliente;
        }

        public List<TBL_COL_SPREAD_DIA> ListarSpreadPorCliente(int idCliente, string status, string siglaMoeda, DateTime data, string tipoOperacao)
        {

            var lista = (from tab in _ikVarejoContext.TBL_COL_SPREAD_DIA
                         join tc in _ikVarejoContext.TBL_CLIENTES on tab.SPD_CLIENTE_ESPECIFICO equals tc.IdCliente
                         where (tab.SPD_STATUS == status && tc.IdCliente == idCliente && tab.SPD_MOEDA.Contains(siglaMoeda)
                         && tab.SPD_VALIDADE_INICIO.Value.Date == data.Date)
                         select new TBL_COL_SPREAD_DIA
                         {
                             SPD_SPREAD_ID = tab.SPD_SPREAD_ID,
                             SPD_VALIDADE_INICIO = tab.SPD_VALIDADE_INICIO,
                             SPD_VALIDADE_FIM = tab.SPD_VALIDADE_FIM,
                             SPD_CLIENTE_ESPECIFICO = tab.SPD_CLIENTE_ESPECIFICO,
                             SPD_TX_SPREAD = tab.SPD_TX_SPREAD,
                             SPD_MOEDA = tab.SPD_MOEDA,
                             SPD_STATUS = tab.SPD_STATUS,
                             SPD_IDUSER_LOG = tab.SPD_IDUSER_LOG,
                             SPD_VALOR_DE = tab.SPD_VALOR_DE,
                             SPD_VALOR_ATE = tab.SPD_VALOR_ATE,
                             SPD_TIPO_OP = tipoOperacao,
                             SPD_TIPO_ENTREGA = tab.SPD_TIPO_ENTREGA,
                             SPD_TIPO_CLIENTE_COL = tab.SPD_TIPO_CLIENTE_COL,
                             SPD_APLICA_VAREJO = tab.SPD_APLICA_VAREJO,
                             SPD_MARGEM_OPER_AMAIOR = tab.SPD_MARGEM_OPER_AMAIOR,
                             SPD_MARGEM_OPER_AMENOR = tab.SPD_MARGEM_OPER_AMENOR
                         }).ToList();
            return lista;
        }

        public List<TMoeda> BuscaCotacaoMoeda(string SiglaMoeda)
        {
            var cotacao = _varejoContext.TMoedas.Where(x => x.Cod_moeda.Contains(SiglaMoeda)).ToList();

            return cotacao;
        }

        public List<TBL_COL_SPREAD_DIA> ListarSpreadPadrao(string SiglaMoeda, DateTime data, string SpdStatus, decimal Valor, string tipoOperacao)
        {
            var spreadPadrao = _ikVarejoContext.TBL_COL_SPREAD_DIA.Where(
                x => x.SPD_STATUS == SpdStatus &&
                x.SPD_MOEDA == SiglaMoeda   &&                
                x.SPD_CLIENTE_ESPECIFICO == null &&
                x.SPD_GRUPO_ESPECIFICO == "006" &&
                x.SPD_TIPO_OP == tipoOperacao &&
                x.SPD_VALOR_DE <= Valor &&
                x.SPD_VALOR_ATE >= Valor
                ).ToList();

            return spreadPadrao;
        }

        public string VerificaSpreadGrupo(int idCliente)
        {
            using (SqlConnection conexao = new SqlConnection(_configuration.GetConnectionString("Varejo")))
            {
                return conexao.ExecuteScalar<string>(
                      $@"DECLARE @ID_CLIENTE INT = '{idCliente}'
                       DECLARE @SPD_GRUPO_ESPECIFICO VARCHAR(10) = ''
                        BEGIN
                        SELECT TOP 1 @SPD_GRUPO_ESPECIFICO = GRP.GRSPD_COD_GRUPO         
                        FROM TBL_COL_PARAMCLI  A           
                        JOIN TBL_COL_GRUPO_SPREAD GRP ON (A.PARAM_GRUPO_SPREAD = GRP.GRSPD_COD_GRUPO)          
                        JOIN TBL_LOGIN_INTEGRADO LI ON (LI.LI_DOC = A.LI_DOC) AND LI.li_tipo = 'M'      
                        JOIN TBL_CLIENTES CLI ON (LI.LI_IDCLIENTE = CLI.ID_CLIENTE)          
                        WHERE CLI.ID_CLIENTE = @ID_CLIENTE 
                        END
                        SELECT @SPD_GRUPO_ESPECIFICO").ToString();
            }
        }
        public List<TBL_COL_SPREAD_DIA> ListarSpreadPorGrupo(string SiglaMoeda, DateTime data, string SpdStatus, decimal Valor, string spdGrupo,string tipoOperacao)
        {
            var spreadGrupo = _ikVarejoContext.TBL_COL_SPREAD_DIA.Where(
                x => x.SPD_STATUS == SpdStatus &&
                x.SPD_MOEDA == SiglaMoeda &&
                x.SPD_GRUPO_ESPECIFICO == spdGrupo &&
                x.SPD_VALOR_DE <= Valor && x.SPD_VALOR_ATE >= Valor &&
                x.SPD_VALIDADE_INICIO.Value.Date <= data.Date &&
                x.SPD_CLIENTE_ESPECIFICO == null &&
                x.SPD_GRUPO_ESPECIFICO == spdGrupo &&
                x.SPD_TIPO_OP == tipoOperacao
                ).ToList();

            return spreadGrupo;
        }
        public List<Tbl_Moedas> BuscaDesvioTipo(string SiglaMoeda)
        {
            using (SqlConnection conexao = new SqlConnection(_configuration.GetConnectionString("Varejo")))
            {
                return conexao.Query<Tbl_Moedas>(
                      $@"DECLARE @SiglaMoeda Varchar(4) = '{SiglaMoeda}'                       
                        select moe_tipo, moe_desvio from TBL_MOEDAS where moe_simbolo = @SiglaMoeda").ToList();
            }
        }

        public List<string> BuscaCodigoMoedas()
        {
            var listaCodMoedas = _varejoContext.TMoedas.Select(x=>x.Cod_moeda).ToList();

            return listaCodMoedas;
        }
    }
}