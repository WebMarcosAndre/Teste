﻿using Microsoft.EntityFrameworkCore;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Infra.Data.Context;
using System.Collections.Generic;
using System.Linq;

namespace RND.CBP.Infra.Data.Repository
{
    public class TarifaRepository : BaseRepository<Tarifa, int>, ITarifaRepository
    {
        protected readonly SqlContext _sqlContext;

        public TarifaRepository(SqlContext sqlContext) : base(sqlContext)
        {
            _sqlContext = sqlContext;
        }        
    }
}
