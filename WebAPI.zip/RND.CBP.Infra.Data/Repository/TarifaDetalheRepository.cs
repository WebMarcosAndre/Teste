﻿using Microsoft.EntityFrameworkCore;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Infra.Data.Context;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RND.CBP.Infra.Data.Repository
{
    public class TarifaDetalheRepository : BaseRepository<TarifaDetalhe, int>, ITarifaDetalheRepository
    {
        protected readonly SqlContext _sqlContext;

        public TarifaDetalheRepository(SqlContext sqlContext) : base(sqlContext)
        {
            _sqlContext = sqlContext;
        }

        public void Cadastrar(int usuarioId, Tarifa tarifa, List<TarifaDetalhe> tarifaDetalhes)
        {
            using (var transaction = _sqlContext.Database.BeginTransaction())
            {
                try
                {
                    if (tarifa.Id == 0)
                    {
                        _sqlContext.Tarifa.Add(tarifa);
                        _sqlContext.SaveChanges();

                        var tarifaSaved = _sqlContext.Tarifa.LastOrDefault(x => x.EmpresaId == tarifa.EmpresaId && x.TipoAplicacaoId == tarifa.TipoAplicacaoId);

                        foreach (var tarifaDetalhe in tarifaDetalhes)
                        {
                            tarifaDetalhe.Tarifa = tarifaSaved;
                            tarifaDetalhe.TarifaId = tarifaSaved.Id;

                            _sqlContext.TarifaDetalhe.Add(tarifaDetalhe);

                            _sqlContext.SaveChanges();

                            var tarifaDetalheGet = _sqlContext.TarifaDetalhe.LastOrDefault(x => x.TarifaId == tarifaSaved.Id);

                            InserirLog(usuarioId, tarifaDetalheGet);
                        }

                        _sqlContext.SaveChanges();
                    }
                    else
                    {
                        _sqlContext.Entry(tarifa).State = EntityState.Modified;
                        _sqlContext.SaveChanges();

                        foreach (var tarifaDetalhe in tarifaDetalhes)
                        {
                            if (tarifaDetalhe.Id == 0)
                            {
                                tarifaDetalhe.Tarifa = tarifa;
                                tarifaDetalhe.TarifaId = tarifa.Id;

                                _sqlContext.TarifaDetalhe.Add(tarifaDetalhe);

                                _sqlContext.SaveChanges();

                                var tarifaDetalheGet = _sqlContext.TarifaDetalhe.LastOrDefault(x => x.TarifaId == tarifa.Id);

                                InserirLog(usuarioId, tarifaDetalheGet);
                            }
                            else
                            {
                                _sqlContext.Entry(tarifaDetalhe).State = EntityState.Modified;

                                _sqlContext.SaveChanges();

                                InserirLog(usuarioId, tarifaDetalhe);
                            }
                        }

                        _sqlContext.SaveChanges();
                    }

                    transaction.Commit();
                }
                catch (System.Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
        public void Atualizar(int usuarioId, Tarifa tarifa, List<TarifaDetalhe> tarifaDetalhes)
        {
            using (var transaction = _sqlContext.Database.BeginTransaction())
            {
                try
                {
                    _sqlContext.Entry(tarifa).State = EntityState.Modified;
                    _sqlContext.SaveChanges();

                    foreach (var tarifaDetalhe in tarifaDetalhes)
                    {
                        if (tarifaDetalhe.Id == 0)
                        {
                            _sqlContext.TarifaDetalhe.Add(tarifaDetalhe);

                            _sqlContext.SaveChanges();

                            var tarifaDetalheGet = _sqlContext.TarifaDetalhe.LastOrDefault(x => x.TarifaId == tarifa.Id);

                            InserirLog(usuarioId, tarifaDetalheGet);
                        }
                        else
                        {
                            _sqlContext.DetachLocal<TarifaDetalhe>(tarifaDetalhe, tarifaDetalhe.Id);

                            _sqlContext.SaveChanges();

                            InserirLog(usuarioId, tarifaDetalhe);
                        }
                    }

                    _sqlContext.SaveChanges();

                    transaction.Commit();
                }
                catch (System.Exception ex)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        public void Deletar(Tarifa tarifa, List<TarifaDetalhe> listaTarifaDetalhe)
        {            
            foreach (var tarifaDet in listaTarifaDetalhe)
            {
                _sqlContext.TarifaDetalhe.Remove(tarifaDet);

                _sqlContext.SaveChanges();
            }

            _sqlContext.Tarifa.Remove(tarifa);

            _sqlContext.SaveChanges();
        }

        public void InserirLog(int usuarioId, TarifaDetalhe tarifaDetalhe)
        {
            var tarifaDetalheLog = new TarifaDetalheLog()
            {
                TarifaDetalheId = tarifaDetalhe.Id,
                TarifaId = tarifaDetalhe.TarifaId,
                CodigoTipoTarifa = tarifaDetalhe.CodigoTipoTarifa,
                ValorTarifa = tarifaDetalhe.ValorTarifa,
                CodigoStatus = tarifaDetalhe.CodigoStatus,
                ValorMinimoRemessa = tarifaDetalhe.ValorMinimoRemessa,
                ValorMaximoRemessa = tarifaDetalhe.ValorMaximoRemessa,
                ValorCustoTarifa = tarifaDetalhe.ValorCustoTarifa,
                PaisId = tarifaDetalhe.PaisId,
                CodMoedaRemessa = tarifaDetalhe.CodMoedaRemessa,
                MoedaId = tarifaDetalhe.MoedaId,
                SistemaId = tarifaDetalhe.SistemaId,
                TipoPessoa = tarifaDetalhe.TipoPessoa,
                UsuarioId = usuarioId,
                DataAlteracao = DateTime.Now
            };

            _sqlContext.TarifaDetalheLog.Add(tarifaDetalheLog);

            _sqlContext.SaveChanges();
        }
    }
}
