﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using Microsoft.Extensions.Configuration;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces;
using RND.CBP.Infra.Data.Context;

namespace RND.CBP.Infra.Data.Repository
{
    public class MoedaCambioOnlineRepository : IMoedaCambioOnlineRepository
    {
        protected readonly SqlContext _sqlContext;
        protected readonly IkVarejoContext _ikVarejoContext;
        protected readonly VarejoContext _varejoContext;
        protected readonly IConfiguration _configuration;

        public MoedaCambioOnlineRepository(SqlContext sqlContext, IkVarejoContext ikVarejoContext, VarejoContext varejoContext, 
            IConfiguration configuration)
        {
            _sqlContext = sqlContext;
            _ikVarejoContext = ikVarejoContext;
            _varejoContext = varejoContext;
            _configuration = configuration;
        }            

     
        public List<Tbl_Moedas> List(string moe_swift)
        {
            using (SqlConnection conexao = new SqlConnection(_configuration.GetConnectionString("Varejo")))
            {
                return conexao.Query<Tbl_Moedas>(
                      $@"DECLARE @SiglaMoeda Varchar(4) = '{moe_swift}'                       
                        SELECT moe_tipo, moe_desvio, LTRIM(RTRIM(moe_simbolo)) moe_simbolo, LTRIM(RTRIM(moe_swift)) moe_swift 
                        FROM TBL_MOEDAS (NOLOCK) WHERE moe_swift = @SiglaMoeda").ToList();
            }
        }

    }
}