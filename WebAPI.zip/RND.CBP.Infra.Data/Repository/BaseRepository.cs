﻿using Microsoft.EntityFrameworkCore;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Infra.Data.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace RND.CBP.Infra.Data.Repository
{
    public class BaseRepository<TEntidade, TId> : IBaseRepository<TEntidade, TId>
        where TEntidade : BaseEntity
        where TId : struct
    {
        private SqlContext _context;

        public BaseRepository(SqlContext _context)
        {
            this._context = _context;
        }

        public BaseRepository()
        {
        }

        public TEntidade GetBy(Func<TEntidade, bool> where, params Expression<Func<TEntidade, object>>[] includeProperties)
        {
            return List(includeProperties).LastOrDefault(where);
        }

        public TEntidade GetById(TId id, params Expression<Func<TEntidade, object>>[] includeProperties)
        {
            if (includeProperties.Any())
            {
                return List(includeProperties).LastOrDefault(x => x.Id.ToString() == id.ToString());
            }

            return _context.Set<TEntidade>().Find(id);
        }

        public IQueryable<TEntidade> List(params Expression<Func<TEntidade, object>>[] includeProperties)
        {
            IQueryable<TEntidade> query = _context.Set<TEntidade>();

            if (includeProperties.Any())
            {
                return Include(_context.Set<TEntidade>(), includeProperties);
            }

            return query;
        }

        private IQueryable<TEntidade> Include(IQueryable<TEntidade> query, params Expression<Func<TEntidade, object>>[] includeProperties)
        {
            foreach (var property in includeProperties)
            {
                query = query.Include(property);
            }

            return query;
        }

        public void Insert(TEntidade entidade)
        {
            _context.Set<TEntidade>().Add(entidade);
            _context.SaveChanges();
        }

        public IQueryable<TEntidade> ListBy(Expression<Func<TEntidade, bool>> where, params Expression<Func<TEntidade, object>>[] includeProperties)
        {
            return List(includeProperties).Where(where);
        }

        public void Update(TEntidade entidade)
        {
            _context.Entry(entidade).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var t = SelectById(id);
            _context.Set<TEntidade>().Remove(t);
            _context.SaveChanges();
        }

        public List<TEntidade> SelectAll()
        {
            return _context.Set<TEntidade>().ToList();
        }

        public TEntidade SelectById(int id)
        {

            return _context.Set<TEntidade>().Where(c => c.Id == id).FirstOrDefault();

        }
    }
}