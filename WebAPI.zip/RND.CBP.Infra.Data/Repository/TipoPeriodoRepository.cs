﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Infra.Data.Context;

namespace RND.CBP.Infra.Data.Repository
{
    public class TipoPeriodoRepository : BaseRepository<TipoPeriodo, int>, ITipoPeriodoRepository
    {
        protected readonly SqlContext _sqlContext;

        public TipoPeriodoRepository(SqlContext sqlContext) : base(sqlContext)
        {
            _sqlContext = sqlContext;
        }
    }
}