﻿using System;
using Elmah;
using System.ServiceProcess;
using RND.CBP.ConsoleJob.Helpers;
using RND.CBP.ConsoleJob.DTOs;

namespace RND.CBP.ConsoleJob
{
    partial class HangFireService : ServiceBase
    {
        private IDisposable _server = null;
        private readonly HttpClientHelper _httpHelper = new HttpClientHelper();

        public HangFireService()
        {
            InitializeComponent();
        }

        public void Execute(string[] args)
        {
            Console.WriteLine("Iniciando");
            try
            {
                OnStart(args);
                Console.WriteLine("OK!");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                throw;
            }
            finally
            {
                Console.ReadLine();
                Console.WriteLine("Finalizando");
                OnStop();
                Console.WriteLine("Ok");
            }
        }

        public static void WriteElmahException(Exception ex)
        {
            var elmahCon = ErrorLog.GetDefault(null);
            elmahCon.Log(new Error(ex));
        }

        protected override void OnStart(string[] args)
        {
            IniciarBackgroundServer();
            IniciarJobsRecorrentes();
        }

        private void IniciarJobsRecorrentes()
        {
            //try
            //{
            //    var dominios = JsonConvert.DeserializeObject<List<Dominio>>(
            //        _httpHelper.ChamadaAPIGet($"{ConfigurationManager.AppSettings["urlCBP"].ToString()}/Dominio/Buscar").Result)
            //        .OrderBy(x => x.OrdemExecucao);

            //    foreach (var dominio in dominios)
            //    {
            //        RecurringJob.AddOrUpdate(() => ProcessarMetodosDominio(dominio), Cron.MinuteInterval(dominio.Intervalo), TimeZoneInfo.Local);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message.ToString());
            //    WriteElmahException(ex);
            //}
        }

        public void ProcessarMetodosDominio(Dominio dominio)
        {
            //var conteudo = JsonConvert.SerializeObject(_httpHelper.ChamadaAPIGetCustomizada(
            //            $"{dominio.Uri}{dominio.MetodoChamada}{dominio.Request}", dominio.TokenChamada)
            //            .Result.ToString());

            //var sc = new StringContent(conteudo, Encoding.UTF8, "application/json");

            //var responseCallBack = _httpHelper.ChamadaAPIPostCustomizada($"{dominio.UriRetorno}{dominio.MetodoRetorno}", dominio.TokenRetorno, sc);
        }

        protected override void OnStop()
        {
            PararBackgroundServer();
        }

        private void IniciarBackgroundServer()
        {
            try
            {
                //var globalConfiguration = GlobalConfiguration.Configuration.UseSqlServerStorage(ConfigurationManager.AppSettings["HangFireCBP"],
                //                                     new SqlServerStorageOptions { SlidingInvisibilityTimeout = TimeSpan.FromHours(1) });
                //_server = new BackgroundJobServer(new BackgroundJobServerOptions
                //{
                //    ServerName = ConfigurationManager.AppSettings["ServerName"]
                //}, globalConfiguration.Entry);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                WriteElmahException(ex);
            }
        }

        private void PararBackgroundServer()
        {
            if (_server != null)
                _server.Dispose();
        }
    }
}
