﻿using System;
using System.ServiceProcess;

namespace RND.CBP.ConsoleJob
{
    class Program
    {
        static void Main(string[] args)
        {
            if (Environment.UserInteractive)
            {
                var service = new HangFireService();
                service.Execute(args);
            }
            else
            {
                var servicesToRun = new ServiceBase[]
                {
                    new HangFireService()
                };
                ServiceBase.Run(servicesToRun);
            }
        }
    }
}
