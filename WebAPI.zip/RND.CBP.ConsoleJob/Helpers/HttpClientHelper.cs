﻿using System;
using System.Configuration;
using System.Net.Http;
using System.Threading.Tasks;

namespace RND.CBP.ConsoleJob.Helpers
{
    public class HttpClientHelper
    {
        public HttpResponseMessage ChamadaAPIPost(string url, StringContent content)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Add("Token", ConfigurationManager.AppSettings["TokenCBP"].ToString());

                var dataTask = httpClient.PostAsync(new Uri(url), content).GetAwaiter().GetResult();
                return dataTask;
            }
            catch (HttpRequestException ex)
            {
                throw ex;
            }
        }

        public HttpResponseMessage ChamadaAPIPostCustomizada(string url, string token, StringContent content)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Add("Token", token);

                var dataTask = httpClient.PostAsync(new Uri(url), content).GetAwaiter().GetResult();
                return dataTask;
            }
            catch (HttpRequestException ex)
            {
                throw ex;
            }
        }

        public async Task<String> ChamadaAPIGet(string url)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Add("Token", ConfigurationManager.AppSettings["TokenCBP"].ToString());

                Task<string> datatask = httpClient.GetStringAsync(new Uri(string.Format(url, DateTime.UtcNow.Ticks)));
                var data = await datatask;

                return data;
            }
            catch (HttpRequestException ex)
            {
                throw ex;
            }
        }

        public async Task<String> ChamadaAPIGetCustomizada(string url, string token)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Add("Token", token);

                Task<string> datatask = httpClient.GetStringAsync(new Uri(string.Format(url, DateTime.UtcNow.Ticks)));
                var data = await datatask;

                return data;
            }
            catch (HttpRequestException ex)
            {
                throw ex;
            }
        }
    }
}
