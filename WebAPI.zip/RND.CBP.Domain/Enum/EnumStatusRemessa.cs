﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace RND.CBP.Domain.Enum
{
    public enum EnumStatusRemessa
    {
        [Description("Cancel")]
        Cancel = 'C',

        [Description("Hold")]
        Hold = 'H',

        [Description("In-Progress")]
        InProcess = 'I',

        [Description("Paid")]
        Paid = 'P',

        [Description("Pending Release (optional)")]
        PendingRelease = 'R',

        [Description("Transmit")]
        Transmit = 'T',

        [Description("Web")]
        Web = 'W',

        [Description("Prestore")]
        Prestore = 'X'
    }
}
