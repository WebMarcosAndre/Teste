﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Enum
{
    public class EnumAuthorization
    {

    }
}
