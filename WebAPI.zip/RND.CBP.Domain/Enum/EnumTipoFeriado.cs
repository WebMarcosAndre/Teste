﻿
namespace RND.CBP.Domain.Enum
{
    public enum EnumTipoFeriado
    {
        Nacional = 1,
        Internacional = 2,
        Estadual = 3,
        Municipal = 4
    }
}
