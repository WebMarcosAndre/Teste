﻿using RND.CBP.Domain.Arguments.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Arguments.Remessa
{
    public class RemessaResponse : BaseResponse
    {
        #region Propriedades
        public DateTime Data { get; set; }
        public int CodigoContrato { get; set; }
        public int IdCliente { get; set; }
        public string CodigoSistemaOrigem { get; set; }
        public string CodigoMoeda { get; set; }
        public decimal ValorTaxaCambio { get; set; }
        public decimal ValorRemessaME { get; set; }
        public decimal ValorRemessaMN { get; set; }
        public char IdStatusRemessa { get; set; }
        public int IdUsuario { get; set; }
        #endregion

        #region Métodos

        public static explicit operator RemessaResponse(RND.CBP.Domain.Entities.Remessa r)
        {
            return new RemessaResponse()
            {
                Data = r.DataRemessa,
                CodigoContrato = r.CodigoContrato,
                IdCliente = r.IdCliente,
                CodigoSistemaOrigem = r.CodigoSistemaOrigem,
                CodigoMoeda = r.CodigoMoeda,
                ValorTaxaCambio = r.ValorTaxaCambio,
                ValorRemessaME = r.ValorRemessaME,
                ValorRemessaMN = r.ValorRemessaMN,
                IdStatusRemessa = r.IdStatusRemessa,
                IdUsuario = r.IdUsuario
            };
        }

        #endregion
    }
}
