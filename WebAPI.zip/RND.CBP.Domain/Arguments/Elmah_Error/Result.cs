﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Arguments.Elmah_Error
{
    public class Result<T>
    {
        public int Draw { get; set; }
        public int RecordsTotal { get; set; }
        public int RecordsFilter { get; set; }
        public List<T> data { get; set; }
    }
}
