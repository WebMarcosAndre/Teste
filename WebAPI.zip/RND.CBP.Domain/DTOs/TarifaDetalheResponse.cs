﻿using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.DTOs
{
    public class TarifaDetalheResponse
    {
        public int IdPais { get; set; }
        public string NomePais { get; set; }
        public int TarifaId { get; set; }
        public int TarifaDetalheId { get; set; }
        public string CodigoTipoTarifa { get; set; }
        public string CodigoMoeda { get; set; }
        public string CodigoMoedaTarifa { get; set; }
        public string ValorMinimo { get; set; }
        public string ValorMaximo { get; set; }
        public string CustoTarifa { get; set; }
        public string ValorTarifa { get; set; }
        public string TipoPessoa { get; set; }
    }
}
