﻿using System.Collections.Generic;

namespace RND.CBP.Domain.DTOs
{
    public class UsuarioPerfilRequest
    {
        public int IdUsuario { get; set; }

        public List<int> Perfis { get; set; }
    }
}