﻿using System.Collections.Generic;

namespace RND.CBP.Domain.DTOs
{
    public class PerfilFuncionalidadeResponse
    {
        public int IdPerfil { get; set; }
        public string NomePerfil { get; set; }

        public List<Funcionalidade> Funcionalidades { get; set; }
    }
}
