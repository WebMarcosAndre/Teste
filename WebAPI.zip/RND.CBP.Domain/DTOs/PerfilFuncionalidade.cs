﻿namespace RND.CBP.Domain.DTOs
{
    public class PerfilFuncionalidade
    {
        public int Id { get; set; }
        public int PerfilId { get; set; }
        public int FuncionalidadeId { get; set; }

        public Funcionalidade Funcionalidade { get; set; }
        public Perfil Perfil { get; set; }
    }
}