﻿using Newtonsoft.Json;
using RND.CBP.Domain.Entities;
using System.Collections.Generic;

namespace RND.CBP.Domain.DTOs
{
    public class Menu : BaseEntity
    {
        public Menu()
        {
            MenuFuncionalidade = new HashSet<MenuFuncionalidade>();
        }

        public string Nome { get; set; }
        public string CaminhoMenu { get; set; }
        public string PaginaAcesso { get; set; }

        public ICollection<MenuFuncionalidade> MenuFuncionalidade { get; set; }
    }
}
