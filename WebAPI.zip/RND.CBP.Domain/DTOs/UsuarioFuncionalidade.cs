﻿using Newtonsoft.Json;
using RND.CBP.Domain.Entities;

namespace RND.CBP.Domain.DTOs
{
    public class UsuarioFuncionalidade : BaseEntity
    {
        public int UsuarioId { get; set; }
        public int FuncionalidadeId { get; set; }

        [JsonIgnore]
        public virtual Funcionalidade Funcionalidade { get; set; }
        [JsonIgnore]
        public virtual Usuario Usuario { get; set; }
    }
}