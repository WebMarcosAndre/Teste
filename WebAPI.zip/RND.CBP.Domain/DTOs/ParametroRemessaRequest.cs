﻿using System;

namespace RND.CBP.Domain.DTOs
{
    public class ParametroRemessaRequest
    {
        public int Id { get; set; }
        public int TipoPeriodoId { get; set; }
        public string TipoPessoa { get; set; }
        public int SistemaId { get; set; }
        public int EmpresaGrupoId { get; set; }
        public string CodigoTipoRemessa { get; set; }
        public int OperacoesCliente { get; set; }
        public TimeSpan HoraInicio { get; set; }
        public TimeSpan HoraFim { get; set; }
        public string OverSpread { get; set; }
        public string LimiteOperacao { get; set; }
        public string LimitePeriodo { get; set; }
    }
}
