﻿using Microsoft.AspNetCore.Authorization;

namespace RND.CBP.Domain.DTOs.Authorization
{
    public class PaginaRequirement : IAuthorizationRequirement
    {
        public int FuncionalidadeId { get; set; }

        public PaginaRequirement(int funcionalidadeId)
        {
            FuncionalidadeId = funcionalidadeId;
        }
    }
}
