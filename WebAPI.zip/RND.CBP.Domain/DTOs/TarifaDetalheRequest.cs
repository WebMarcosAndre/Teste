﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.DTOs
{
    public class TarifaDetalheRequest
    {
        public int Id { get; set; }
        public string TipoPessoa { get; set; }
        public string CodigoTipoTarifa { get; set; }
        public string CodigoMoeda { get; set; }
        public string CodigoMoedaTarifa { get; set; }
        public int PaisId { get; set; }
        public string ValorMinimo { get; set; }
        public string ValorMaximo { get; set; }
        public string CustoTarifa { get; set; }
        public string ValorTarifa { get; set; }
    }
}
