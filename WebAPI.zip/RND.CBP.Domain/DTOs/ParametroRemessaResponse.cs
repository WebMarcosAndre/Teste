﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.DTOs
{
    public class ParametroRemessaResponse
    {
        public int Id { get; set; }
        public int SistemaId { get; set; }
        public int TipoPeriodoId { get; set; }
        public string TipoPessoa { get; set; }
        public string CodigoTipoRemessa { get; set; }
        public TimeSpan HoraInicioPeriodo { get; set; }
        public TimeSpan HoraFimPeriodo { get; set; }
        public int NumeroOperacaoCliente { get; set; }
        public string ValorOverSpread { get; set; }
        public string ValorLimitePeriodo { get; set; }
        public string ValorLimiteOperacao { get; set; }
        public int EmpresaGrupoId { get; set; }
    }
}
