﻿using System.Collections.Generic;

namespace RND.CBP.Domain.DTOs
{
    public class Sistema
    {
        public Sistema()
        {
            Funcionalidade = new HashSet<Funcionalidade>();
        }

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public string Versao { get; set; }
        public bool Ativo { get; set; }

        public ICollection<Funcionalidade> Funcionalidade { get; set; }
    }
}