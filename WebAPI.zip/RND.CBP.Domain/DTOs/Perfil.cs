﻿using RND.CBP.Domain.Entities;
using System.Collections.Generic;

namespace RND.CBP.Domain.DTOs
{
    public class Perfil : BaseEntity
    {
        public Perfil()
        {
            PerfilFuncionalidade = new HashSet<PerfilFuncionalidade>();
            UsuarioPerfil = new HashSet<UsuarioPerfil>();
        }

        public int Id { get; set; }
        public string Nome { get; set; }
        public bool Ativo { get; set; }

        public ICollection<PerfilFuncionalidade> PerfilFuncionalidade { get; set; }
        public ICollection<UsuarioPerfil> UsuarioPerfil { get; set; }
    }
}