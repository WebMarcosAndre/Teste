﻿using System.Collections.Generic;

namespace RND.CBP.Domain.DTOs
{
    public class UsuarioFuncionalidadeRequest
    {
        public int IdUsuario { get; set; }

        public string Nome { get; set; }

        public string UsuarioAD { get; set; }

        public List<int> Funcionalidades { get; set; }
    }
}