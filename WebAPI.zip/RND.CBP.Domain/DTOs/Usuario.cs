﻿using RND.CBP.Domain.Entities;
using System.Collections.Generic;

namespace RND.CBP.Domain.DTOs
{
    public class Usuario : BaseEntity
    {
        public Usuario()
        {
            Area = new HashSet<Area>();
            UsuarioFuncionalidade = new HashSet<UsuarioFuncionalidade>();
            UsuarioPerfil = new HashSet<UsuarioPerfil>();
        }

        public string UsuarioAd { get; set; }
        public string Nome { get; set; }
        public bool Ativo { get; set; }

        public virtual ICollection<Area> Area { get; set; }
        public virtual ICollection<UsuarioFuncionalidade> UsuarioFuncionalidade { get; set; }
        public virtual ICollection<UsuarioPerfil> UsuarioPerfil { get; set; }
    }
}
