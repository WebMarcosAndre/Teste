﻿namespace RND.CBP.Domain.DTOs
{
    public class Area
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public int CoordenadorId { get; set; }
        public bool Ativo { get; set; }

        public Usuario Coordenador { get; set; }
    }
}