﻿using Newtonsoft.Json;

namespace RND.CBP.Domain.DTOs
{
    public class MenuFuncionalidade
    {
        public int Id { get; set; }
        public int MenuId { get; set; }
        public int FuncionalidadeId { get; set; }

        public Funcionalidade Funcionalidade { get; set; }

        [JsonIgnore]
        public Menu Menu { get; set; }
    }
}
