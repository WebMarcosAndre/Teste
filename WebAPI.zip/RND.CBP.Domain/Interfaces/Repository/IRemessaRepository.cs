﻿using RND.CBP.Domain.Arguments.Remessa;
using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RND.CBP.Domain.Interfaces.Repository
{
    public interface IRemessaRepository : IBaseRepository<Remessa, int>
    {
        List<TblClientes> BuscarTodosClientesIkVarejo();
        List<TblClientes> BuscarNomesClientesIkVarejo();
        IEnumerable<object> FiltarRemessa(bool primeiraConsulta, string dataDe, string dataAte, char? codigoStatusRemessa, string pesquisarPor, string txtPesquisarPor, string tipoPessoa, string statusCliente);
        IEnumerable<object> GetSearchValue(string search);
        List<TblClientes> BuscarClienteId(int clientId);
        IQueryable<TBL_COL_PARAM_PRODUTOS> BuscarParametroProduto();        
        List<TBL_TARIFAS_PADRAO> BuscarTarifa(int idCliente, string tipoOp, string formaEntrega,string clTarifa, decimal valor);
        
        List<TBL_REGRAS_TARIFAS_CLI> BuscarRegrasTarifa(int idCliente, string tipoOp, string formaEntrega, string clTarifa, decimal valor);


        List<TBL_REGRAS_TARIFAS> BuscarTarifaCotacao(string tipoOp, string tipoEntrega, decimal valorTarifa);

        List<TBL_REGRAS_TARIFAS> BuscarTarifaRendimento(string tipoOp, string tipoEntrega, decimal valorTarifa);
    }
}
