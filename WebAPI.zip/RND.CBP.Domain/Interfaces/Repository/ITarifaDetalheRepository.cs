﻿using RND.CBP.Domain.DTOs;
using RND.CBP.Domain.Entities;
using System.Collections.Generic;

namespace RND.CBP.Domain.Interfaces.Repository
{
    public interface ITarifaDetalheRepository : IBaseRepository<TarifaDetalhe, int>
    {
        void Cadastrar(int usuarioId, Tarifa tarifa, List<TarifaDetalhe> tarifaDetalhes);
        void Atualizar(int usuarioId, Tarifa tarifa, List<TarifaDetalhe> tarifaDetalhes);
        void Deletar(Tarifa tarifa, List<TarifaDetalhe> tarifaDetalhes);
    }
}
