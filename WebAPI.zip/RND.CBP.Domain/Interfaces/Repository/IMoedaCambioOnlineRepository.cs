﻿
using System.Collections.Generic;
using RND.CBP.Domain.Entities;

namespace RND.CBP.Domain.Interfaces
{
    public interface IMoedaCambioOnlineRepository 
    {
        List<Tbl_Moedas> List(string SiglaMoeda);

    }
}
