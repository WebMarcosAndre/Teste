﻿using RND.CBP.Domain.Entities;
using System.Collections.Generic;

namespace RND.CBP.Domain.Interfaces.Repository
{
    public interface ISistemaRepository : IBaseRepository<Sistema, int>
    {
        
    }
}
