﻿using RND.CBP.Domain.DTOs;
using RND.CBP.Domain.Entities;
using System.Collections.Generic;

namespace RND.CBP.Domain.Interfaces.Repository
{
    public interface ITarifaRepository : IBaseRepository<Tarifa, int>
    {        
    }
}
