﻿using RND.CBP.Domain.Entities;

namespace RND.CBP.Domain.Interfaces.Repository
{
    public interface IMoedaRepository : IBaseRepository<Moeda, int>
    {
    }
}
