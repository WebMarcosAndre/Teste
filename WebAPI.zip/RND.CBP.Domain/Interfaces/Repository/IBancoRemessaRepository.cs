﻿using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RND.CBP.Domain.Interfaces.Repository
{
    public interface IBancoRemessaRepository : IBaseRepository<BancoRemessa, int>
    {

    }
}
