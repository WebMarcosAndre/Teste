﻿using RND.CBP.Domain.Entities;

namespace RND.CBP.Domain.Interfaces.Repository
{
    public interface IDominioRepository : IBaseRepository<Dominio, int>
    {
    }
}
