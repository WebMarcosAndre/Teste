﻿using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Interfaces.Repository
{
    public interface IFeriadoRepository : IBaseRepository<Feriado, int>
    {
        List<Feriado> BuscarFeriado(int dia, int mes, int ano);
    }
}
