﻿using RND.CBP.Domain.Entities;

namespace RND.CBP.Domain.Interfaces.Repository
{
    public interface IPaisRepository : IBaseRepository<Pais, int>
    {
    }
}
