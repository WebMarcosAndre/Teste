﻿using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace RND.CBP.Domain.Interfaces.Repository
{
    public interface IBaseRepository<TEntidade, TId> where TEntidade : class where TId : struct
    {
        IQueryable<TEntidade> ListBy(Expression<Func<TEntidade, bool>> where, params Expression<Func<TEntidade, object>>[] inclueProperties);
        IQueryable<TEntidade> List(params Expression<Func<TEntidade, object>>[] includeProperties);
        TEntidade GetBy(Func<TEntidade, bool> where, params Expression<Func<TEntidade, object>>[] includeProperties);
        TEntidade GetById(TId id, params Expression<Func<TEntidade, object>>[] includeProperies);
        void Update(TEntidade entidade);
        void Insert(TEntidade entidade);
        void Delete(int id);
    }
}