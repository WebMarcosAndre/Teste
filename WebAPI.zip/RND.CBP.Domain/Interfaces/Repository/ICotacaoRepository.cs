﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RND.CBP.Domain.Interfaces
{
    public interface ICotacaoRepository : IBaseRepository<Cotacao, int>
    {
        int RecuperaIdCliente(string numdoc);        
        List<TMoeda> BuscaCotacaoMoeda(string SiglaMoeda);
        
        string VerificaSpreadGrupo(int idCliente);
        
        List<Tbl_Moedas>BuscaDesvioTipo(string SiglaMoeda);
        List<string> BuscaCodigoMoedas();

        List<TBL_COL_SPREAD_DIA> ListarSpreadPorCliente(int idCliente, string status, string siglaMoeda, DateTime data, string tipoOperacao);
        List<TBL_COL_SPREAD_DIA> ListarSpreadPorGrupo(string siglaMoeda, DateTime data, string spdStatus, decimal valor, string spdGrupo, string tipoOperacao);
        List<TBL_COL_SPREAD_DIA> ListarSpreadPadrao(string siglaMoeda, DateTime data, string spdStatus, decimal valor, string tipoOperacao);
    }
}
