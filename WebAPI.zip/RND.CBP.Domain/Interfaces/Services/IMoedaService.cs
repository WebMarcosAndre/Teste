﻿using RND.CBP.Domain.Entities;
using System.Collections.Generic;

namespace RND.CBP.Domain.Interfaces.Services
{
    public interface IMoedaService
    {
        List<Moeda> ListarMoedas();

        List<string> ListarCodigoMoedas();

        Tbl_Moedas GetCambioOnlineByMoeSwift(string moe_swift);
    }
}
