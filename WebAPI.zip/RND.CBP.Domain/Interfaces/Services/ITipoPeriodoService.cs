﻿using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Interfaces.Services
{
    public interface ITipoPeriodoService
    {
        IEnumerable<TipoPeriodo> ListarTipoPeriodo();
    }
}
