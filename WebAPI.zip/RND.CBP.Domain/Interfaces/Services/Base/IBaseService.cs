﻿using FluentValidation;
using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace RND.CBP.Domain.Interfaces.Services.Base
{
    public interface IBaseService<T> where T : BaseEntity
    {
        T Post<V>(T obj) where V : AbstractValidator<T>;

        T Put<V>(T obj) where V : AbstractValidator<T>;

        void Delete(int id);

        T Get(int id);

        IList<T> Get();

        IList<T> ListBy(Expression<Func<T, bool>> where, params Expression<Func<T, object>>[] includeProperties);
    }
}
