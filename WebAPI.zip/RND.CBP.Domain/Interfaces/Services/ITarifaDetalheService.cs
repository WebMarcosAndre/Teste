﻿using RND.CBP.Domain.DTOs;
using RND.CBP.Domain.Entities;
using System.Collections.Generic;
using System.Linq;

namespace RND.CBP.Domain.Interfaces.Services
{
    public interface ITarifaDetalheService
    {
        TarifaDetalhe BuscarPorId(int id);

        void Upsert(int usuarioId, int sistemaId, int empresaGrupoId, int empresaId, string tipoRemessa, string tipoAplicacaoSelecionado, List<TarifaDetalheRequest> requests);

        void InsertPorEmpresa(int usuarioId, int sistemaId, int empresaGrupoId, int empresaId, string tipoRemessa, string tipoAplicacaoSelecionado, List<TarifaDetalheRequest> requests);

        TarifaDetalhe BuscarMenorTarifaComFiltro(string tipoPessoa, int sistemaId,decimal valorTarifa, string pais, string codigoMoedaRemessa, int clienteId, string tipoOp, string formaEntrega);

        List<TarifaDetalheResponse> BuscarPorFiltroDaPagina(int idSistema, int idEmpresaGrupo, int idEmpresa, string tipoRemessa, string codTipoAplicacao);

        void DeletarTarifa(int idTarifaDetalhe, string tipoAplicacao);
    }
}
