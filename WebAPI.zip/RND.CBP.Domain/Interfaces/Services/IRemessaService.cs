﻿using RND.CBP.Domain.Arguments.Remessa;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Services.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RND.CBP.Domain.Interfaces.Services
{
    public interface IRemessaService
    {
        List<TblClientes> BuscarTodosClientesIkVarejo();
        List<TblClientes> BuscarNomesClientesIkVarejo();
        List<object> FiltarRemessa(bool primeiraConsulta, string dataDe, string dataAte, char? codigoStatusRemessa, string pesquisarPor, string txtPesquisarPor, string tipoPessoa, string statusCliente);
        List<TblClientes> GetSearchValue(string search, List<TblClientes> listaRemessa);
    }
}
