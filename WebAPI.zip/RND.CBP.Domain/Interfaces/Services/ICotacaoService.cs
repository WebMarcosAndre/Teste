﻿using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Interfaces.Services
{
    public interface ICotacaoService
    {
        Cotacao Buscar(string tipoPessoa, string numeroDocumento, decimal Valor, string moedaSigla, DateTime dataHora);
        Cotacao BuscarSemDocumento(decimal Valor, string siglaMoeda, Tbl_Moedas moedaCambioOnline, DateTime dataHora, int Sistema);
    }
}
