﻿using RND.CBP.Domain.Entities;
using System.Collections.Generic;

namespace RND.CBP.Domain.Interfaces.Services
{
    public interface ISistemaService
    {
        IEnumerable<Sistema> ListarSistemas();

        void Excluir(int idSistema);

        ParametroRemessa BuscarDadosSistema(int id, int empresa, string remessa, string horario, string tipoPessoa);

        bool UpsertSistema(int idSistema, string nomeSistema, string urlSistema, int idStatusSistema);
        StatusSistema StatusSistema(int id);
    }
}
