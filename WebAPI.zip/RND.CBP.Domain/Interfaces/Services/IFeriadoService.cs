﻿using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Interfaces.Services
{
    public interface IFeriadoService
    {
        List<Feriado> BuscarFeriado(int dia, int mes, int ano, int sistemaId);
    }
}
