﻿using RND.CBP.Domain.DTOs;
using RND.CBP.Domain.Entities;
using System.Collections.Generic;

namespace RND.CBP.Domain.Interfaces.Services
{
    public interface IParametroRemessaService
    {
        IEnumerable<ParametroRemessa> ListarParametroRemessa();

        IEnumerable<ParametroRemessaResponse> ListarParametroRemessaPorFiltro(int idSistema, int idEmpresaGrupo, string tipoPessoa);

        IEnumerable<ParametroRemessa> BuscarParametroRemessaParaValidacao(int idSistema, int idEmpresaGrupo, int idTipoPeriodo, string codTipoRemessa, string tipoPessoa);

        bool UpsertParametroRemessa(DTOs.ParametroRemessaRequest parametroRemessa);

        void Excluir(int idParametroRemessa);
    }
}
