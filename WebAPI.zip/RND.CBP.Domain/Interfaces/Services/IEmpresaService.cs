﻿using RND.CBP.Domain.Entities;
using System.Collections.Generic;

namespace RND.CBP.Domain.Interfaces.Services
{
    public interface IEmpresaService
    {
        IEnumerable<Empresa> ListarEmpresas();
    }
}
