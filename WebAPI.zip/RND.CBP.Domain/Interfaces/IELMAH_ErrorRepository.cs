﻿using RND.CBP.Domain.Entities.Elmah_Error;
using RND.CBP.Domain.Interfaces.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Interfaces
{
    public interface IELMAH_ErrorRepository : IBaseRepository<ELMAH_Error, int>
    {
    }
}
