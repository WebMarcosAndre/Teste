﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Interfaces.Validator
{
    public interface IValidate<TRequest>
    {
        TRequest Validacao(TRequest request);
    }
}
