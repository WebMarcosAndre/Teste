﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Entities
{
    public class Feriado : BaseEntity
    {
        public Feriado()
        {

        }
     public int Feriado_id { get; set; }
     public int? Dia { get; set; }
     public int? Mes { get; set; }
     public string Descricao { get; set; }
     public int? TipoFeriado_id { get; set; }
     public int? CreatedBy { get; set; }
     public DateTime? CreatedOn { get; set; }
     public int? LastUpdateBy { get; set; }
     public DateTime? LastUpdateOn { get; set; }
     public bool? Ativo { get; set; }
     public int? Ano { get; set; }     
    }
}
