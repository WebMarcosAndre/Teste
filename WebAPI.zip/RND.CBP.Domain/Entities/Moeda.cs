﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace RND.CBP.Domain.Entities
{
    public class Moeda : BaseEntity
    {
        public Moeda()
        {
            TarifaDetalhe = new HashSet<TarifaDetalhe>();
        }

        public string CodigoMoeda { get; set; }
        public string NomeMoeda { get; set; }
        public string Simbolo { get; set; }
        public string Tipo { get; set; }
        public string Status { get; set; }
        public int PaisIdPadrao { get; set; }

        public Pais Pais { get; set; }
        [JsonIgnore]
        public ICollection<TarifaDetalhe> TarifaDetalhe { get; set; }
    }
}
