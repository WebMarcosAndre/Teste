﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Entities
{
    public class TBL_COL_SPREAD_DIA
    {
        public int SPD_SPREAD_ID { get; set; }

        public DateTime? SPD_VALIDADE_INICIO { get; set; }

        public DateTime? SPD_VALIDADE_FIM { get; set; }

        public int? SPD_CLIENTE_ESPECIFICO { get; set; }

        public string SPD_GRUPO_ESPECIFICO { get; set; }

        public decimal SPD_TX_SPREAD { get; set; }

        public string SPD_MOEDA { get; set; }

        public string SPD_STATUS { get; set; }

        public int? SPD_IDUSER_LOG { get; set; }

        public decimal? SPD_VALOR_DE { get; set; }

        public decimal? SPD_VALOR_ATE { get; set; }

        public string SPD_TIPO_OP { get; set; }

        public string SPD_TIPO_ENTREGA { get; set; }

        public string SPD_TIPO_CLIENTE_COL { get; set; }

        public decimal? SPD_APLICA_VAREJO { get; set; }

        public decimal? SPD_MARGEM_OPER_AMAIOR { get; set; }

        public decimal? SPD_MARGEM_OPER_AMENOR { get; set; }

    }
}
