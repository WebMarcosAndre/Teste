﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Entities
{
    public class TMoeda 
    {
        public TMoeda()
        {

        }
            public string Cod_moeda { get; set; }
            public double? Tx_Banco { get; set; }
            public double? Tx_Cotacao { get; set; }
            public double? Custo { get; set; }
            public double? Tx_cotacaoC { get; set; }
            public DateTime? HoraCot { get; set; }
            public double? Paridade { get; set; }
            public Guid rowguid { get; set; }
            public decimal? ordem { get; set; }
            public double? Tx_Compra { get; set; }
            public double Tx_Venda { get; set; }
            public string clas_paridade { get; set; }
            public decimal? Codigo_Moeda { get; set; }
            public string mes_letra { get; set; }

        }
    }

