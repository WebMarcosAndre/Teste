﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Entities
{
    public partial class StatusRemessa : BaseEntity
    {
        public StatusRemessa()
        {
            Remessa = new HashSet<Remessa>();
        }

        public char Id { get; set; }

        public string NomeStatusRemessa { get; set; }

        public ICollection<Remessa> Remessa { get; set; }
    }
}
