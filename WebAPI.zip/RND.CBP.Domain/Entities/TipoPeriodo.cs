﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace RND.CBP.Domain.Entities
{
    public partial class TipoPeriodo : BaseEntity
    {
        public TipoPeriodo()
        {
            ParametroRemessa = new HashSet<ParametroRemessa>();
        }

        public string NomeTipoPeriodo { get; set; }
        public string CodigoStatus { get; set; }

        [JsonIgnore]
        public ICollection<ParametroRemessa> ParametroRemessa { get; set; }
    }
}
