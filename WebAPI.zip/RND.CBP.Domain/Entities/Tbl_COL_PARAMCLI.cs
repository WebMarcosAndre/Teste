﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Entities
{
    public class Tbl_COL_PARAMCLI
    {
        public string LI_DOC { get; set; }
        public string param_status_col { get; set; }
        public string param_nivel_complice { get; set; }
        public string param_autoriza_nivel_complice { get; set; }
        public string param_proc_eletronica { get; set; }
        public string param_spread_especial { get; set; }
        public string param_grupo_spread { get; set; }
        public decimal? param_taxa_spread { get; set; }
        public decimal? param_limite_operacao { get; set; }
        public string param_operacao_compra { get; set; }
        public string param_operacao_venda { get; set; }
        public string param_msg_especifica { get; set; }
        public string PARAM_EMAIL_AUTOMATICO { get; set; }
        public int? PARAM_DIASLIQ_VENDAS { get; set; }
        public int? PARAM_DIASLIQ_VENDASME { get; set; }
        public int? PARAM_DIASLIQ_COMPRAS { get; set; }
        public int? PARAM_DIASLIQ_COMPRASME { get; set; }
        public bool? PARAM_DIASLIQ_COMPRA_MN_STATUS { get; set; }
        public bool? PARAM_DIASLIQ_COMPRA_ME_STATUS { get; set; }
        public bool? PARAM_DIASLIQ_VENDA_MN_STATUS { get; set; }
        public bool? PARAM_DIASLIQ_VENDA_ME_STATUS { get; set; }
    }

}
