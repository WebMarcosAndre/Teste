﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace RND.CBP.Domain.Entities
{
    public class TBL_REGRAS_TARIFAS_CLI
    {
        [Key]
        public int id_rc { get; set; }

        public int? id_user { get; set; }

        public int? id_cliente { get; set; }

        public string rc_tipo { get; set; }

        public string rc_operacao { get; set; }

        public decimal? rc_val_minimo { get; set; }

        public decimal? rc_val_maximo { get; set; }

        public string rc_moeda { get; set; }

        public decimal? rc_val_tarifa { get; set; }

        public string rc_obs { get; set; }

        public DateTime? rc_dt_inclusao { get; set; }

        public DateTime? rc_dt_alteracao { get; set; }

    }
}