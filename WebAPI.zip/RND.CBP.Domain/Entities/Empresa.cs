﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace RND.CBP.Domain.Entities
{
    public partial class Empresa : BaseEntity
    {
        public Empresa()
        {
            Tarifa = new HashSet<Tarifa>();
        }
        
        public string CodigoEmpresa { get; set; }
        public string NomeEmpresa { get; set; }
        public string CodigoStatus { get; set; }
        public decimal ValorMinimoRemessa { get; set; }
        public decimal ValorMaximoRemessa { get; set; }

        [JsonIgnore]
        public ICollection<Tarifa> Tarifa { get; set; }
    }
}
