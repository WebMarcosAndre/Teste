﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace RND.CBP.Domain.Entities
{
    public partial class Tarifa : BaseEntity
    {
        public Tarifa()
        {
            TarifaDetalhe = new HashSet<TarifaDetalhe>();
        }

        public int EmpresaId { get; set; }
        public int TipoAplicacaoId { get; set; }
        public string CodigoStatus { get; set; }
        public int EmpresaGrupoId { get; set; }
        public string TipoRemessa { get; set; }

        public Empresa Empresa { get; set; }
        public EmpresaGrupo EmpresaGrupo { get; set; }
        public TipoAplicacao TipoAplicacao { get; set; }

        [JsonIgnore]
        public ICollection<TarifaDetalhe> TarifaDetalhe { get; set; }
    }
}