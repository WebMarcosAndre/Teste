﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace RND.CBP.Domain.Entities
{
    public class TBL_REGRAS_TARIFAS
    {
        [Key]
        public int id_rt { get; set; }
        public int? id_user { get; set; }
        public string rt_tipo { get; set; }
        public string rt_operacao { get; set; }
        public decimal? rt_val_minimo { get; set; }
        public decimal? rt_val_maximo { get; set; }
        public string rt_moeda { get; set; }
        public decimal? rt_val_tarifa { get; set; }
        public DateTime? rt_dt_inclusao { get; set; }
        public string rt_obs { get; set; }
    }
}
