﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace RND.CBP.Domain.Entities
{
    public partial class Pais : BaseEntity
    {
        public Pais()
        {
            Moeda = new HashSet<Moeda>();
        }

        public string NomePais { get; set; }
        public string NomeAbreviado { get; set; }
        public string CodigoPais { get; set; }
        public string CodigoStatus { get; set; }

        [JsonIgnore]

        public ICollection<Moeda> Moeda { get; set; }
    }
}
