﻿using System;

namespace RND.CBP.Domain.Entities
{
    public partial class Remessa : BaseEntity
    {
        public int CodigoContrato { get; set; }
        public string IdTfPin { get; set; }
        public int OpNboleto { get; set; }
        public int IdCliente { get; set; }
        public string CodigoSistemaOrigem { get; set; }
        public string CodigoMoeda { get; set; }
        public DateTime DataRemessa { get; set; }
        public decimal ValorTaxaCambio { get; set; }
        public decimal ValorRemessaME { get; set; }
        public decimal ValorRemessaMN { get; set; }
        public char IdStatusRemessa { get; set; }
        public char CodigoStatusEnvio { get; set; }
        public int IdUsuario { get; set; }

        public StatusRemessa IdStatusRemessaNavigation { get; set; }
    }
}
