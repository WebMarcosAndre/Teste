﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace RND.CBP.Domain.Entities
{
    public partial class Sistema : BaseEntity
    {
        public Sistema()
        {
            ParametroRemessa = new HashSet<ParametroRemessa>();
            TarifaDetalhe = new HashSet<TarifaDetalhe>();
        }

        public string NomeSistema { get; set; }
        public string UrlSistema { get; set; }
        public int StatusSistemaId { get; set; }

        public StatusSistema StatusSistema { get; set; }

        [JsonIgnore]
        public ICollection<ParametroRemessa> ParametroRemessa { get; set; }
        [JsonIgnore]
        public ICollection<TarifaDetalhe> TarifaDetalhe { get; set; }


    }
}
