﻿using Newtonsoft.Json;
using System;

namespace RND.CBP.Domain.Entities
{
    public partial class ParametroRemessa : BaseEntity
    {
        public int SistemaId { get; set; }
        public int TipoPeriodoId { get; set; }
        public string CodigoTipoRemessa { get; set; }
        public TimeSpan HoraInicioPeriodo { get; set; }
        public TimeSpan HoraFimPeriodo { get; set; }
        public decimal? ValorOverSpread { get; set; }
        public int NumeroOperacaoCliente { get; set; }
        public decimal? ValorLimitePeriodo { get; set; }
        public decimal? ValorLimiteOperacao { get; set; }
        public int EmpresaGrupoId { get; set; }
        public string TipoPessoa { get; set; }

        public EmpresaGrupo EmpresaGrupo { get; set; }

        public Sistema Sistema { get; set; }

        public TipoPeriodo TipoPeriodo { get; set; }
    }
}
