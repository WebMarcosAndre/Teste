﻿using System;

namespace RND.CBP.Domain.Entities
{
    public class TarifaDetalheLog
    {
        public int Id { get; set; }
        public int TarifaDetalheId { get; set; }
        public int TarifaId { get; set; }
        public string CodigoTipoTarifa { get; set; }
        public decimal ValorTarifa { get; set; }
        public string CodigoStatus { get; set; }
        public decimal ValorMinimoRemessa { get; set; }
        public decimal ValorMaximoRemessa { get; set; }
        public decimal ValorCustoTarifa { get; set; }
        public int PaisId { get; set; }
        public string CodMoedaRemessa { get; set; }
        public int MoedaId { get; set; }
        public int SistemaId { get; set; }
        public string TipoPessoa { get; set; }
        public int UsuarioId { get; set; }
        public DateTime DataAlteracao { get; set; }
    }
}
