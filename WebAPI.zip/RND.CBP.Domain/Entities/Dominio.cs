﻿namespace RND.CBP.Domain.Entities
{
    public partial class Dominio : BaseEntity
    {
        public string MetodoChamada { get; set; }
        public string Descricao { get; set; }
        public int IdSistema { get; set; }
        public string Uri { get; set; }
        public string Verbo { get; set; }
        public string Request { get; set; }
        public string MetodoRetorno { get; set; }
        public string UriRetorno { get; set; }
        public int Intervalo { get; set; }
        public int OrdemExecucao { get; set; }
        public string TokenChamada { get; set; }
        public string TokenRetorno { get; set; }
    }
}
