﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace RND.CBP.Domain.Entities
{
    public partial class TblUsers

    {
        public TblUsers()
        {

        }

        [Key]
        public int IdUser { get; set; }
        public string UrTipo { get; set; }
        public int? IdCorretora { get; set; }
        public string UrNome { get; set; }
        public string UrRg { get; set; }
        public string UrCpf { get; set; }
        public string UrTelefone { get; set; }
        public string UrEmail { get; set; }
        public string UrUsername { get; set; }
        public string UrSenha { get; set; }
        public string UrNivel { get; set; }
        public string UrStatus { get; set; }
        public int? UrErros { get; set; }
        public decimal? UrSpread { get; set; }
        public decimal? UrVolume { get; set; }
        public string UrObs { get; set; }
        public DateTime? UrDtAlteracao { get; set; }
        public DateTime? UrDtInclusao { get; set; }
        public int? IdFilial { get; set; }
        public string UrConsulta { get; set; }
        public decimal? UrOpValReaisMax { get; set; }
        public decimal? LimiteDiario { get; set; }
        public bool? OperaRemessaExpressa { get; set; }
        public decimal? LimiteordemMensal { get; set; }
        public bool? OperaApenasPendenteDeRecebimento { get; set; }
        public decimal? Limiteordem { get; set; }
        public bool? TipoEspecie { get; set; }
        public bool? TipoCheque { get; set; }
        public bool? TipoCC { get; set; }
        public bool? TipoDocTed { get; set; }
        public bool? TipoBoletoBancario { get; set; }
        public decimal? LimiteTipoEspecie { get; set; }
        public decimal? LimiteTipoCheque { get; set; }
        public decimal? LimiteTipoCC { get; set; }
        public decimal? LimiteTipoDocTed { get; set; }
        public decimal? LimiteTipoBoletoBancario { get; set; }
        public bool? ConsultaEopera { get; set; }
        public bool? OperasemconsRfb { get; set; }
        public bool? TipoMoedaestrangeira { get; set; }
        public decimal? LimiteTipoMoedaEstrangeira { get; set; }
        public bool? EditaOrdem { get; set; }
        public string OperaCcme { get; set; }
        public string SCcmeUrTipo { get; set; }
        public string SCcmeUrNivel { get; set; }
        public bool? PermissaoCadUsuariosInternos { get; set; }
        public bool? PermissaoCadUsuariosExternos { get; set; }
        public bool? PermissaoCadCorretoras { get; set; }
        public bool? PermissaoCadFiliais { get; set; }
        public bool? PermissaoConfigLimites { get; set; }
        public decimal? LimiteTipoCartao { get; set; }
        public bool? TipoCartao { get; set; }
        public bool? AprovaRecebimento { get; set; }
        public decimal? LimiteAprovaDocumentacao { get; set; }
        public int? UrGaCod { get; set; }
        public string AprovadorDadosBancariosSwift { get; set; }
        public string AprovadorHorarioCorte { get; set; }
        public string AprovadorSwiftCcme { get; set; }
        public string PermiteExcluirLancamento { get; set; }
        public bool? PermiteBloquearBeneficiario { get; set; }
        public bool Operaremessaexpressainbound { get; set; }
        public decimal? LimiteordemInbound { get; set; }
        public bool? UrAprovaprocuracao { get; set; }
    }
}
