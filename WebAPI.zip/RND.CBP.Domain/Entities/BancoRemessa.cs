﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace RND.CBP.Domain.Entities
{
    public partial class BancoRemessa : BaseEntity
    {
        public BancoRemessa()
        {
        }

        public string NomeBancoRemessa { get; set; }
        public string CodigoSwift { get; set; }
        public string CodigoSwiftReduzido { get; set; }
        public string CodigoTipoTarifa { get; set; }
        public string CodigoStatus { get; set; }
    }
}
