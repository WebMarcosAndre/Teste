﻿using System.ComponentModel.DataAnnotations.Schema;

namespace RND.CBP.Domain.Entities
{
    public partial class TarifaDetalhe : BaseEntity
    {
        public int TarifaId { get; set; }
        public string CodigoTipoTarifa { get; set; }
        public string CodMoedaRemessa { get; set; }
        public decimal ValorTarifa { get; set; }
        public string CodigoStatus { get; set; }
        public decimal ValorMinimoRemessa { get; set; }
        public decimal ValorMaximoRemessa { get; set; }
        public decimal ValorCustoTarifa { get; set; }

        [NotMapped]
        public decimal ValorCustoTarifaDolar { get; set; }

        public int PaisId { get; set; }
        public int MoedaId { get; set; }
        public int SistemaId { get; set; }

        public string TipoPessoa { get; set; }

        public Moeda Moeda { get; set; }

        public Sistema Sistema { get; set; }

        public Pais Pais { get; set; }
                
        public Tarifa Tarifa { get; set; }
    }
}