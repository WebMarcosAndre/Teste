﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace RND.CBP.Domain.Entities
{
    public partial class TipoAplicacao : BaseEntity
    {
        public TipoAplicacao()
        {
            Tarifa = new HashSet<Tarifa>();
        }

        public string CodigoTipoAplicacao { get; set; }
        public string NomeTipoAplicacao { get; set; }
        public string CodigoStatus { get; set; }

        [JsonIgnore]
        public ICollection<Tarifa> Tarifa { get; set; }
    }
}