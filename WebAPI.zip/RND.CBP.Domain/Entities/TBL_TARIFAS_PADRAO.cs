﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace RND.CBP.Domain.Entities
{
    public class TBL_TARIFAS_PADRAO
    {
        [Key]
        public int id_tp { get; set; }

        public int? id_user { get; set; }

        public string tp_indice { get; set; }

        public string tp_tipo { get; set; }

        public string tp_operacao { get; set; }

        public decimal? tp_val_minimo { get; set; }

        public decimal? tp_val_maximo { get; set; }

        public string tp_moeda { get; set; }

        public decimal? tp_val_tarifa { get; set; }

        public string tp_obs { get; set; }

        public DateTime? tp_dt_inclusao { get; set; }

        public DateTime? tp_dt_alteracao { get; set; }

    }
}

