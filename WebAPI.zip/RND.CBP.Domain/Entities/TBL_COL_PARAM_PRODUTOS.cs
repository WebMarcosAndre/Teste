﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace RND.CBP.Domain.Entities
{
    public class TBL_COL_PARAM_PRODUTOS
    {  
        [Key]
            public int? TEMPOEXPIRACAOTAXA { get; set; }
            public int? TEMPO_PREENCHIMENTO { get; set; }
            public decimal? VALORLIMITE_OPER { get; set; }
            public decimal? VALOR_APROVACAO_AUTO { get; set; }
            public int? DIASLIQ_COMPRAS { get; set; }
            public int? DIASLIQ_VENDAS { get; set; }
            public string HORARIO_CORTE { get; set; }
            public string ID_CORRETORA { get; set; }
            public int? ID_FILIAL { get; set; }
            public decimal? ADIC_SPREAD_DTLIQ { get; set; }
            public string LINK_PROCURACAO { get; set; }
            public int? DIASLIQ_COMPRASME { get; set; }
            public int? DIASLIQ_VENDASME { get; set; }
            public int? ID_ASSESSOR { get; set; }
            public string FLG_HABILITAR_OPERACAO { get; set; }
            public string TARIFA_PADRAO { get; set; }
            public string TEMPO_EXPIRACAO_TAXA_CORRETORA { get; set; }
            public string TEMPO_EXPIRACAO_TAXA_AGENCIA { get; set; }
            public string TEMPO_EXPIRACAO_TAXA_INTERCAMBIO { get; set; }
            public string TEMPO_EXPIRACAO_TAXA_PJ { get; set; }
            public string TEMPO_EXPIRACAO_TAXA_PF { get; set; }
            public string TEMPO_EXPIRACAO_TAXA_EMBAIXADA { get; set; }
            public string TEMPO_EXPIRACAO_TAXA_DIPLOMATA { get; set; }
            public string TEMPO_EXPIRACAO_TAXA_ORGANISMOS { get; set; }
            public string HORARIO_CORTE_VENDA { get; set; }
            public string HORARIO_CORTE_COMPRA { get; set; }
            public string HORARIO_CORTE_GOOGLE { get; set; }
            public string HORARIO_CORTE_VENDA_TERMO { get; set; }
            public string HORARIO_CORTE_COMPRA_TERMO { get; set; }
            public bool? FLAG_DIAS_UTEIS { get; set; }
            public string HORARIO_DIAS_UTEIS_DE { get; set; }
            public string HORARIO_DIAS_UTEIS_ATE { get; set; }
            public bool? FLAG_SABADOS { get; set; }
            public string HORARIO_SABADOS_DE { get; set; }
            public string HORARIO_SABADOS_ATE { get; set; }
            public bool? FLAG_DOMINGOS { get; set; }
            public string HORARIO_DOMINGOS_DE { get; set; }
            public string HORARIO_DOMINGOS_ATE { get; set; }
            public bool? FLAG_FERIADOS { get; set; }
            public string HORARIO_FERIADOS_DE { get; set; }
            public string HORARIO_FERIADOS_ATE { get; set; }
            public decimal? VL_MINIMO_ARBITRAGEM_USD { get; set; }
            public string TIPO_DESCONTO_GOOGLE { get; set; }
            public decimal? DESCONTO_GOOGLE_AUTOMATICO { get; set; }
            public decimal? DESCONTO_GOOGLE_MANUAL { get; set; }

        }

    }
