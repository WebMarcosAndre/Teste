﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Entities
{
    public class Cotacao : BaseEntity
    {
        public string NomeMoeda { get; set; }
        public decimal? ValorCompra { get; set; }
        public decimal? ValorVenda { get; set; }
        public string IofInformativo { get; set; }
        public decimal IofValor { get; set; }
        public decimal TarifaReal { get; set; }
        public decimal ValorFinal { get; set; }
    }
}
