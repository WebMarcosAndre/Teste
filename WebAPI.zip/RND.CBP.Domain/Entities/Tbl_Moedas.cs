﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Entities
{
    public class Tbl_Moedas
    {
        public string moe_tipo { get; set; }
        public double moe_desvio { get; set; }
        public string moe_simbolo { get; set; }
        public string moe_swift { get; set; }
    }
}
