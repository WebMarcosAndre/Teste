﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace RND.CBP.Domain.Entities
{
    public partial class EmpresaGrupo : BaseEntity
    {
        public EmpresaGrupo()
        {
            ParametroRemessa = new HashSet<ParametroRemessa>();
            Tarifa = new HashSet<Tarifa>();
        }

        public string NomeEmpresaGrupo { get; set; }
        public string NomeResumido { get; set; }
        public string NumeroCnpj { get; set; }
        public string CodigoStatusEmpresaGrupo { get; set; }

        [JsonIgnore]
        public ICollection<ParametroRemessa> ParametroRemessa { get; set; }
        [JsonIgnore]
        public ICollection<Tarifa> Tarifa { get; set; }
    }
}
