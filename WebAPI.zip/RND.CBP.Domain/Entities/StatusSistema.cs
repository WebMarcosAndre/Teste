﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace RND.CBP.Domain.Entities
{
    public partial class StatusSistema : BaseEntity
    {
        public StatusSistema()
        {
            Sistema = new HashSet<Sistema>();
        }

        public string NomeStatusSistema { get; set; }
        public string CodigoStatusSistema { get; set; }

        [JsonIgnore]
        public ICollection<Sistema> Sistema { get; set; }
    }
}
