﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Entities
{
    public class Tbl_FeriadoParametro
    {
        public Tbl_FeriadoParametro()
        {

        }
        public int FeriadoParametro_id { get; set; }

        public int? Feriado_id { get; set; }

        public int? Praca_id { get; set; }

        public int? Sistema_id { get; set; }

        public int? TipoOperacao_id { get; set; }

        public int? Moeda_id { get; set; }

        public int? CreatedBy { get; set; }

        public DateTime? CreatedOn { get; set; }

        public int? LastUpdateBy { get; set; }

        public DateTime? LastUpdateOn { get; set; }

        public bool? Ativo { get; set; }

    }
}
