﻿using System.Collections.Generic;

using Newtonsoft.Json;
using RestSharp;

namespace RND.CBP.CrossCutting
{
    public class HttpMethods
    {
        private  string _baseUrl;


        public HttpMethods(string baseUrl)
        {

            _baseUrl = baseUrl;
        }

        public IRestResponse Get(string uri, Dictionary<string, string> parametros = null)
        {
            var client = new RestClient(_baseUrl);
            var request = new RestRequest(uri, Method.GET);

            if (parametros != null)
            {
                foreach (var parametro in parametros)
                {
                    request.AddParameter(parametro.Value, parametro.Key);
                }
            }

            return client.Execute(request);
        }

        public IRestResponse Post(string uri, Dictionary<string, string> parametros = null, string token = null)
        {
            var client = new RestClient(_baseUrl);
            var request = new RestRequest(uri, Method.POST);

            if (parametros != null)
            {
                foreach (var parametro in parametros)
                {
                    request.AddParameter(parametro.Key, parametro.Value);
                }
            }

            return client.Execute(request);
        }

        public IRestResponse Post<T>(string uri, T obj, string token)
        {
            var client = new RestClient(_baseUrl);
            var request = new RestRequest(uri, Method.POST);

            if (!string.IsNullOrEmpty(token))
            {
                request.AddParameter("Token", token, ParameterType.HttpHeader);
                request.AddParameter("application/json", JsonConvert.SerializeObject(obj), ParameterType.RequestBody);
                request.RequestFormat = DataFormat.Json;
            }

            return client.Execute(request);
        }

        public IRestResponse Get<T>(string uri, T obj, string token)
        {
            var client = new RestClient(_baseUrl);
            var request = new RestRequest(uri, Method.GET);

            if (!string.IsNullOrEmpty(token))
            {
                request.AddParameter("Token", token, ParameterType.HttpHeader);
                request.AddParameter("application/json", JsonConvert.SerializeObject(obj), ParameterType.RequestBody);
                request.RequestFormat = DataFormat.Json;
            }

            return client.Execute(request);
        }
    }
}
