﻿using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace RND.CBP.CrossCutting
{
    public class CriptografiaAES
    {
        public static string CriptografarUnicode(string texto, string chave)
        {
            byte[] criptografado;

            using (AesManaged aes = new AesManaged())
            {
                ICryptoTransform cripto = aes.CreateEncryptor(Encoding.UTF8.GetBytes(chave), Encoding.UTF8.GetBytes("1234567890123456"));

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, cripto, CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(cs))
                            sw.Write(texto);

                        criptografado = ms.ToArray();
                    }
                }
            }

            return Encoding.Unicode.GetString(criptografado);
        }

        public static string CriptografarBigEndianUnicode(string texto, string chave)
        {
            byte[] criptografado;

            using (AesManaged aes = new AesManaged())
            {
                ICryptoTransform cripto = aes.CreateEncryptor(Encoding.UTF8.GetBytes(chave), Encoding.UTF8.GetBytes("1234567890123456"));

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, cripto, CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(cs))
                            sw.Write(texto);

                        criptografado = ms.ToArray();
                    }
                }
            }

            return Encoding.BigEndianUnicode.GetString(criptografado);
        }
    }
}
