﻿using FluentValidation;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Services.Base;
using RND.CBP.Infra.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace RND.CBP.Service.Base
{
    public class BaseService<T> : IBaseService<T> where T : BaseEntity
    {

        private BaseRepository<T, int> repository = new BaseRepository<T, int>();

        public T Post<V>(T obj) where V : AbstractValidator<T>
        {
            Validate(obj, Activator.CreateInstance<V>());

            repository.Insert(obj);
            return obj;
        }

        public T Put<V>(T obj) where V : AbstractValidator<T>
        {
            Validate(obj, Activator.CreateInstance<V>());

            repository.Update(obj);
            return obj;
        }

        public void Delete(int id)
        {
            if (id == 0)
                throw new ArgumentException("Id não pode ser zero");

            repository.Delete(id);
        }


        public T Get(int id)
        {
            if (id == 0)
                throw new ArgumentException("Id não pode ser zero");

            return repository.SelectById(id);
        }

        private void Validate(T obj, AbstractValidator<T> validator)
        {
            if (obj == null)
                throw new Exception("Registros não detectados!");

            validator.ValidateAndThrow(obj);
        }

        public IList<T> Get()
        {
            return repository.SelectAll();
        }

        public IList<T> List(params Expression<Func<T, object>>[] includeProperties)
        {
            return repository.List(includeProperties).ToList();
        }

        public IList<T> ListBy(Expression<Func<T, bool>> where, params Expression<Func<T, object>>[] includeProperties)
        {
            return repository.ListBy(where, includeProperties).ToList();
        }

    }
}
