﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;
using RND.CBP.Domain.DTOs;
using RND.CBP.Domain.DTOs.Authorization;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RND.CBP.Service.Validators
{
    public class AcessoHandler : AuthorizationHandler<PaginaRequirement>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private ISession _session => _httpContextAccessor.HttpContext.Session;

        public AcessoHandler(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, PaginaRequirement requirement)
        {
            var isLogged = _session.GetString("isLogged");

            var redirectContext = context.Resource as AuthorizationFilterContext;
            var descriptor = redirectContext?.ActionDescriptor as ControllerActionDescriptor;

            if (!string.IsNullOrEmpty(isLogged) && isLogged.Equals("true") && !string.IsNullOrEmpty(_session.GetString("PermissionUser")))
            {
                var funcionalidadesUsuario = JsonConvert.DeserializeObject<List<UsuarioFuncionalidade>>(_session.GetString("PermissionUser"));

                foreach (var item in funcionalidadesUsuario)
                {
                    if (item.FuncionalidadeId == requirement.FuncionalidadeId)
                    {
                        if (descriptor != null && descriptor.ControllerName == "Tarifa") //TODO: Fazer para todas as controllers
                        {
                            redirectContext.Result = new RedirectToActionResult("Acesso", descriptor.ControllerName, null);
                            break;
                        }

                        context.Succeed(requirement);
                        break;
                    }
                }

                if (!context.HasSucceeded)
                {
                    if (descriptor != null && descriptor.ControllerName == "Tarifa") //TODO: Fazer para todas as controllers
                    {
                        redirectContext.Result = new RedirectToActionResult("Acesso", descriptor.ControllerName, null);
                    }
                    else
                        redirectContext.Result = new RedirectToActionResult("AccessDenied", "Home", null);

                    context.Succeed(requirement);
                }
            }
            else if (isLogged == null || string.IsNullOrEmpty(isLogged) || isLogged.Equals("false"))
            {
                redirectContext.Result = new RedirectToActionResult("Index", "Login", null);
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }
    }
}
