﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace RND.CBP.Service.Helper
{
    public static class Helper
    {
        public static string QuebrarHorario(DateTime horario)
        {
            string hora = horario.Hour.ToString();
            hora = hora + ":" + horario.Minute.ToString();
            return hora;
        }

        public static string DiaDaSemana(DateTime dt)
        {
            string dia = dt.DayOfWeek.ToString();
            switch (dia)
            {
                case "Saturday":
                    dia = "fds";
                    break;
                case "Sunday":
                    dia = "fds";
                    break;
                default:
                    dia = "util";
                    break;
            }
            return dia;
        }

        public static bool HoraInicioValida(TimeSpan newHoraInicio, TimeSpan horaInicio, TimeSpan horaFim)
        {
            if (newHoraInicio >= horaInicio && newHoraInicio <= horaFim)
                return false;

            return true;
        }

        public static bool HoraFimValida(TimeSpan newHoraFim, TimeSpan horaInicio, TimeSpan horaFim)
        {
            if (newHoraFim >= horaInicio && newHoraFim <= horaFim)
                return false;

            return true;
        }

        public static int Dia(DateTime data)
        {
            int dia = Convert.ToInt32(data.Day);

            return dia;
        }

        public static int Mes(DateTime data)
        {
            int mes = Convert.ToInt32(data.Month);

            return mes;
        }

        public static int Ano(DateTime data)
        {
            int ano = Convert.ToInt32(data.Year);

            return ano;
        }

        //public static decimal CalculoValorFinal(decimal Iof, decimal Valor, decimal Tarifa, decimal CotacaoVenda, decimal Spread)
        //{
        //    decimal valorFinal = 0;
        //    decimal spreadReais = 0;
        //    valorFinal = Valor * CotacaoVenda;

        //    if (Spread > 0)
        //        spreadReais = (valorFinal * Spread) / 100;
        //    valorFinal = valorFinal + spreadReais;
        //    Iof = Iof + 1;
        //    valorFinal = valorFinal * Iof;

        //    valorFinal = valorFinal + Tarifa;

        //    return valorFinal;
        //}
        public static decimal CalculoValorFinalTaxaBanco(decimal Iof, decimal Valor, decimal Tarifa, decimal TxBancoVenda)
        {
            decimal valorFinal = 0;
            valorFinal = Valor * TxBancoVenda;
            Iof = Iof + 1;
            valorFinal = valorFinal * Iof;
            valorFinal = valorFinal + Tarifa;
            return valorFinal;
        }

        public static double? ParidadeTipoBTxVenda(double txVenda, double? paridade)
        {
            double? valorB = 0;
            valorB = (txVenda * paridade);

            return valorB;
        }
        public static double? ParidadeTipoBTxCompra(double? txCompra, double? paridade)
        {
            double? valorB = 0;
            valorB = (txCompra * paridade);

            return valorB;
        }
        public static double? ParidadeTipoATxVenda(double txVenda, double? paridade)
        {
            double? valorA = 0;
            valorA = (txVenda / paridade);

            return valorA;
        }
        public static double? ParidadeTipoATxCompra(double? txCompra, double? paridade)
        {
            double? valorA = 0;
            valorA = (txCompra / paridade);

            return valorA;
        }
        public static double? TxBancoVenda(double? txVenda, double? moeDesvio)
        {
            double? valor = 0;
            valor = txVenda + (moeDesvio * txVenda / 100);
         
            return valor;
        }
        public static double? TxBancoCompra(double? txCompra, double? moeDesvio)
        {
            double? valor = 0;
            valor = txCompra - (moeDesvio * txCompra / 100);

            return valor;
        }

        public static string RemoveAccents(this string text)
        {
            StringBuilder sbReturn = new StringBuilder();
            var arrayText = text.Normalize(NormalizationForm.FormD).ToCharArray();
            foreach (char letter in arrayText)
            {
                if (CharUnicodeInfo.GetUnicodeCategory(letter) != UnicodeCategory.NonSpacingMark)
                    sbReturn.Append(letter);
            }
            return sbReturn.ToString();
        }
    }
}
