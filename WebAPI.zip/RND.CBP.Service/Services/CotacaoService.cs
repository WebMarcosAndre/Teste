﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Service.Base;

namespace RND.CBP.Service.Services
{
    public class CotacaoService : BaseService<Cotacao>, ICotacaoService
    {

        private readonly ICotacaoRepository _cotacaoRepository;
        private readonly IFeriadoRepository _feriadoRepository;
        private readonly IParametroRemessaRepository _parametroRepository;
        private readonly ITarifaDetalheRepository _tarifaDetalheRepository;
        private readonly IPaisRepository _paisRepository;
        private readonly IMoedaRepository _moedaRepository;
        private readonly IMoedaService _moedaService;

        public CotacaoService(ICotacaoRepository cotacaoRepository, IFeriadoRepository feriadoRepository,
            IParametroRemessaRepository parametroRepository, ITarifaDetalheRepository tarifaDetalheRepository,
            IPaisRepository paisRepository, IMoedaRepository moedaRepository, IMoedaService moedaService)
        {
            _cotacaoRepository = cotacaoRepository;
            _feriadoRepository = feriadoRepository;
            _parametroRepository = parametroRepository;
            _tarifaDetalheRepository = tarifaDetalheRepository;
            _paisRepository = paisRepository;
            _moedaRepository = moedaRepository;
            _moedaService = moedaService;
        }

        public Cotacao Buscar(string tipoPessoa, string numeroDocumento, decimal Valor, string siglaMoeda, DateTime dataHora)
        {
            #region var
            var cot = new Cotacao();
            var moeda = new List<Moeda>();
            var parametro = new List<ParametroRemessa>();
            var tarifa = new List<TarifaDetalhe>();
            decimal cotacaoVenda = 0;
            var pais = new List<Pais>();
            decimal tarifas = 0;
            decimal spread = 0;
            decimal spreadOver = 0;
            double? paridade = 0;
            double? txProntoVenda = 0;
            double? txProntoCompra = 0;
            double? txBancoVenda = 0;
            decimal Iof = Decimal.Parse("0,0038");
            var moedaCambio = new List<Tbl_Moedas>();
            List<TBL_COL_SPREAD_DIA> spreadEspecifico = new List<TBL_COL_SPREAD_DIA>();
            string spreadGrupo = "";
            DateTime hora = dataHora.Date < DateTime.Today.Date ? DateTime.Now : dataHora;
            Tbl_Moedas moedaCambioOnline = new Tbl_Moedas();
            moedaCambioOnline = _moedaService.GetCambioOnlineByMoeSwift(siglaMoeda);
            string moeSimbolo = moedaCambioOnline.moe_simbolo;
            #endregion
            #region Helper
            string diaSemana = Helper.Helper.DiaDaSemana(hora);
            int dia = Helper.Helper.Dia(hora);
            int mes = Helper.Helper.Mes(hora);
            int ano = Helper.Helper.Ano(hora);
            #endregion

            if (string.IsNullOrEmpty(numeroDocumento))
            {
                cot = BuscarSemDocumento(Valor, siglaMoeda, moedaCambioOnline, hora, 4);
            }
            else
            {
                #region Chamada sem Login Site Cotação 
                #region pegarSpread
                int id_cliente = _cotacaoRepository.RecuperaIdCliente(numeroDocumento);

                spreadEspecifico = _cotacaoRepository.ListarSpreadPorCliente(id_cliente, "A", moeSimbolo, hora, "V");
                if (spreadEspecifico.Count == 0)
                    spreadEspecifico = _cotacaoRepository.ListarSpreadPorCliente(id_cliente, "A", moeSimbolo, hora, "A");

                if (spreadEspecifico.Count > 0)
                {
                    foreach (var x in spreadEspecifico)
                    {
                        spread = x.SPD_TX_SPREAD;
                    }
                }
                else
                {
                    spreadGrupo = _cotacaoRepository.VerificaSpreadGrupo(id_cliente);

                    spreadEspecifico = _cotacaoRepository.ListarSpreadPorGrupo(moeSimbolo, hora, "A", Valor, spreadGrupo, "V");
                    if (spreadEspecifico.Count == 0)
                        spreadEspecifico = _cotacaoRepository.ListarSpreadPorGrupo(moeSimbolo, hora, "A", Valor, spreadGrupo, "A");

                    if (spreadEspecifico.Count > 0)
                    {
                        foreach (var x in spreadEspecifico)
                        {
                            spread = x.SPD_TX_SPREAD;
                        }
                    }
                    else
                    {

                    }
                }
                if (spread <= 0)
                {
                    spreadEspecifico = _cotacaoRepository.ListarSpreadPadrao(moeSimbolo, hora, "A", Valor, "V");
                    if (spreadEspecifico.Count == 0)
                        spreadEspecifico = _cotacaoRepository.ListarSpreadPadrao(moeSimbolo, hora, "A", Valor, "A");

                    foreach (var x in spreadEspecifico)
                    {
                        spread = x.SPD_TX_SPREAD;
                    }
                }

                #endregion
                #region Feriado
                var feriado = _feriadoRepository.BuscarFeriado(dia, mes, ano);
                if (feriado.Count() > 0)
                {
                    parametro = _parametroRepository.List().Where(x => x.TipoPeriodoId == 2
                    && x.CodigoTipoRemessa == "E" && x.SistemaId == 4).ToList();
                }
                else if (!string.IsNullOrEmpty(diaSemana) && diaSemana == "fds")
                {
                    parametro = _parametroRepository.List().Where(x => x.TipoPeriodoId == 1
                    && x.CodigoTipoRemessa == "E" && x.SistemaId == 4).ToList();
                }
                else
                {
                    parametro = _parametroRepository.List().Where(x => x.HoraInicioPeriodo <= dataHora.TimeOfDay
                    && x.HoraFimPeriodo >= dataHora.TimeOfDay && x.TipoPeriodoId != 1 && x.TipoPeriodoId != 2
                    && x.CodigoTipoRemessa == "E" && x.SistemaId == 4).ToList();
                }
                #endregion
                #region Buscar Cotacao


                var valorMoeda = _cotacaoRepository.BuscaCotacaoMoeda(moeSimbolo);
                foreach (var item in valorMoeda)
                {
                    cotacaoVenda = (decimal)item.Tx_Venda;
                }
                #endregion
                #region Buscar Tarifa
                moeda = _moedaRepository.List().Where(x => x.CodigoMoeda == siglaMoeda).ToList();
                foreach (var item in moeda)
                {
                    pais = _paisRepository.List().Where(x => x.Id == item.PaisIdPadrao).ToList();
                    foreach (var p in pais)
                    {
                        tarifa = _tarifaDetalheRepository.List().Where(x => x.CodMoedaRemessa == siglaMoeda &&
                        x.CodigoStatus == "A" && x.PaisId == p.Id && x.SistemaId == 4).ToList();
                    }
                }
                foreach (var x in parametro)
                {
                    spreadOver = (decimal)x.ValorOverSpread;
                }
                spreadOver = spreadOver + spread;

                foreach (var item in tarifa)
                {
                    var cotVenda = _cotacaoRepository.BuscaCotacaoMoeda("USD");
                    foreach (var x in cotVenda)
                    {
                        cotacaoVenda = (decimal)x.Tx_Venda;
                    }
                    tarifas = item.ValorCustoTarifa * cotacaoVenda;

                }

                #endregion
                #region preparação calculo
               double prontoVendaDolar = _cotacaoRepository.BuscaCotacaoMoeda("USD").FirstOrDefault().Tx_Venda;
                foreach (var x in valorMoeda)
                {
                    if (moedaCambioOnline.moe_tipo == "B")
                    {
                        paridade = x.Paridade;
                        txProntoVenda = Helper.Helper.ParidadeTipoBTxVenda(x.Tx_Venda, paridade);
                        txProntoCompra = Helper.Helper.ParidadeTipoBTxCompra(x.Tx_Compra, paridade);
                    }
                    else if (moedaCambioOnline.moe_tipo == "A")
                    {
                        paridade = x.Paridade;
                        txProntoVenda = Helper.Helper.ParidadeTipoATxVenda(prontoVendaDolar, paridade);
                        txProntoCompra = Helper.Helper.ParidadeTipoATxCompra(x.Tx_Compra, paridade);

                    }
                    else
                    {
                        paridade = x.Paridade;
                        txProntoVenda = Helper.Helper.ParidadeTipoBTxVenda(prontoVendaDolar, paridade);
                        txProntoCompra = Helper.Helper.ParidadeTipoBTxCompra(x.Tx_Compra, paridade);
                    }
                }

                //Taxa Banco Venda
                txBancoVenda = Helper.Helper.TxBancoVenda(txProntoVenda, moedaCambioOnline.moe_desvio);
                //txBancoVenda = txBancoVenda * (((double?)spreadOver / 100) + 1);

                //var valorfinal = Helper.Helper.CalculoValorFinalTaxaBanco(Iof, Valor, tarifas, (decimal)txBancoVenda);
                //#region Preencher Objeto
                //cot.NomeMoeda = siglaMoeda;
                //cot.IofInformativo = "0.38%";
                //cot.IofValor = (Valor * (decimal)txBancoVenda) * Iof;
                //cot.TarifaReal = tarifas;
                //cot.ValorCompra = (decimal)txProntoCompra;
                //cot.ValorVenda = (decimal)txBancoVenda;
                //cot.ValorFinal = valorfinal;

                
                decimal valorVenda = (decimal)txBancoVenda * (spreadOver / 100 + 1);
                decimal valorQtdMoeda = valorVenda * Valor;
                decimal valorIof = valorQtdMoeda * Iof;
                decimal valorFinal = valorQtdMoeda + valorIof + tarifas;
                #endregion
                #region Preencher Objeto                

                cot.NomeMoeda = siglaMoeda;
                cot.IofInformativo = "0.38%";
                cot.IofValor = Math.Round(valorIof, 2, MidpointRounding.AwayFromZero);
                cot.TarifaReal = tarifas;
                cot.ValorCompra = 0;
                cot.ValorVenda = Math.Round(valorVenda, 6, MidpointRounding.AwayFromZero);

                cot.ValorFinal = valorFinal;
                #endregion

                #endregion

            }

            return cot;
        }

        public Cotacao BuscarSemDocumento(decimal Valor, string siglaMoeda, Tbl_Moedas moedaCambioOnline, DateTime dataHora, int Sistema)
        {
            #region Var
            var cot = new Cotacao();
            var parametro = new List<ParametroRemessa>();
            var tarifa = new List<TarifaDetalhe>();
            var moeda = new List<Moeda>();
            var pais = new List<Pais>();
            decimal spreadOver = 0;
            decimal Iof = Decimal.Parse("0.0038", NumberStyles.Any, new CultureInfo("en-US"));
            decimal tarifas = 0;
            decimal cotacaoVenda = 0;
            decimal cotacaoCompra = 0;
            decimal prontoVenda = 0;
            double prontoVendaDolar = 0;
            #endregion
            #region Helper
            string diaSemana = Helper.Helper.DiaDaSemana(dataHora);
            int dia = Helper.Helper.Dia(dataHora);
            int mes = Helper.Helper.Mes(dataHora);
            int ano = Helper.Helper.Ano(dataHora);
            #endregion
            #region feriado
            var feriado = _feriadoRepository.BuscarFeriado(dia, mes, ano);
            if (feriado.Count() > 0)
            {
                parametro = _parametroRepository.List().Where(x => x.TipoPeriodoId == 2
                && x.CodigoTipoRemessa == "E" && x.SistemaId == Sistema).ToList();
            }
            else if (!string.IsNullOrEmpty(diaSemana) && diaSemana == "fds")
            {
                parametro = _parametroRepository.List().Where(x => x.TipoPeriodoId == 1
                && x.CodigoTipoRemessa == "E" && x.SistemaId == Sistema).ToList();
            }
            else
            {
                parametro = _parametroRepository.List().Where(x => x.HoraInicioPeriodo <= dataHora.TimeOfDay
                && x.HoraFimPeriodo >= dataHora.TimeOfDay && x.TipoPeriodoId != 1 && x.TipoPeriodoId != 2
                && x.CodigoTipoRemessa == "E" && x.SistemaId == Sistema).ToList();
            }

            #endregion
            #region BuscarCotacao

            prontoVendaDolar = _cotacaoRepository.BuscaCotacaoMoeda("USD").FirstOrDefault().Tx_Venda;
            var valorMoeda = _cotacaoRepository.BuscaCotacaoMoeda(moedaCambioOnline.moe_simbolo);
            foreach (var item in valorMoeda)
            {
                cotacaoVenda = (decimal)item.Tx_Venda;
                cotacaoCompra = (decimal)item.Tx_Compra;

                prontoVenda = (decimal)(moedaCambioOnline.moe_tipo == "A"
                    ? Helper.Helper.ParidadeTipoATxVenda(prontoVendaDolar, item.Paridade)
                     : Helper.Helper.ParidadeTipoBTxVenda(prontoVendaDolar, item.Paridade));
            }
            #endregion
            #region BuscarTarifa
            moeda = _moedaRepository.List().Where(x => x.CodigoMoeda == siglaMoeda).ToList();
            foreach (var item in moeda)
            {
                pais = _paisRepository.List().Where(x => x.Id == item.PaisIdPadrao).ToList();
                foreach (var p in pais)
                {
                    tarifa = _tarifaDetalheRepository.List().Where(x => x.CodMoedaRemessa == siglaMoeda &&
                    x.CodigoStatus == "A" && x.PaisId == p.Id && x.SistemaId == 4
                    && x.ValorMinimoRemessa <= Valor && x.ValorMaximoRemessa >= Valor).ToList();
                }
            }

            var spreadPadrao = _cotacaoRepository.ListarSpreadPadrao(moedaCambioOnline.moe_simbolo, dataHora, "A", Valor, "V");
            if (spreadPadrao.Count == 0)
                spreadPadrao = _cotacaoRepository.ListarSpreadPadrao(moedaCambioOnline.moe_simbolo, dataHora, "A", Valor, "A");
            foreach (var item in spreadPadrao)
            {
                spreadOver = item.SPD_TX_SPREAD;

                foreach (var x in parametro)
                {
                    spreadOver = spreadOver + (decimal)(x.ValorOverSpread);
                }

            }
            foreach (var item in tarifa)
            {
                var cotVenda = _cotacaoRepository.BuscaCotacaoMoeda("USD");
                foreach (var x in cotVenda)
                {
                    cotacaoVenda = (decimal)x.Tx_Venda;
                }
                tarifas = item.ValorTarifa * cotacaoVenda;

            }



            decimal txBancoVenda = prontoVenda + ((decimal)moedaCambioOnline.moe_desvio * prontoVenda / 100);
            decimal valorVenda = txBancoVenda * (spreadOver / 100 + 1);
            decimal valorQtdMoeda = valorVenda * Valor;
            decimal valorIof = valorQtdMoeda * Iof;
            decimal valorFinal = valorQtdMoeda + valorIof + tarifas;
            #endregion
            #region Preencher Objeto                

            cot.NomeMoeda = siglaMoeda;
            cot.IofInformativo = "0.38%";
            cot.IofValor = Math.Round(valorIof, 2, MidpointRounding.AwayFromZero);
            cot.TarifaReal = tarifas;
            cot.ValorCompra = cotacaoCompra;
            cot.ValorVenda =  Math.Round(valorVenda, 6, MidpointRounding.AwayFromZero);

            cot.ValorFinal = valorFinal;
            #endregion


            return cot;
        }



        public string DeParaNomeResumido(string SiglaMoeda)
        {
            string nomeResumido = "";
            if (SiglaMoeda == "USD")
                nomeResumido = "Dolar Americano";
            if (SiglaMoeda == "EUR")
                nomeResumido = "EURO";
            if (SiglaMoeda == "GBP")
                nomeResumido = "LIBRA ESTERLINA";


            return nomeResumido;
        }
    }
}
