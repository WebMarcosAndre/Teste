﻿using Newtonsoft.Json;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Service.Base;
using System.Collections.Generic;
using System.Linq;

namespace RND.CBP.Service.Services
{
    public class BancoRemessaService : BaseService<BancoRemessa>, IBancoRemessaService
    {
        private readonly IBancoRemessaRepository _bancoRemessaRepository;

        public BancoRemessaService(IBancoRemessaRepository bancoRemessaRepository)
        {
            _bancoRemessaRepository = bancoRemessaRepository;
        }
    }
}
