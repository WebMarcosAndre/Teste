﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Service.Base;
using System.Collections.Generic;

namespace RND.CBP.Service.Services
{
    public class EmpresaGrupoService : BaseService<EmpresaGrupo>, IEmpresaGrupoService
    {
        private readonly IEmpresaGrupoRepository _empresaGrupoRepository;

        public EmpresaGrupoService(IEmpresaGrupoRepository empresaGrupoRepository)
        {
            _empresaGrupoRepository = empresaGrupoRepository;
        }
        public IEnumerable<EmpresaGrupo> ListarEmpresaGrupo()
        {
            return _empresaGrupoRepository.List();
        }
    }
}
