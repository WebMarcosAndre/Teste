﻿using RND.CBP.Domain.DTOs;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Service.Base;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;

namespace RND.CBP.Service.Services
{
    public class TarifaDetalheService : BaseService<TarifaDetalhe>, ITarifaDetalheService
    {
        private readonly ITarifaDetalheRepository _tarifaDetalheRepository;
        private readonly IPaisRepository _paisRepository;
        private readonly ITipoAplicacaoRepository _tipoAplicacaoRepository;
        private readonly IEmpresaRepository _empresaRepository;
        private readonly ITarifaRepository _tarifaRepository;
        private readonly IMoedaRepository _moedaRepository;
        private readonly ISistemaRepository _sistemaRepository;
        private readonly IParametroRemessaRepository _parametroRemessaRepository;
        private readonly ICotacaoRepository _cotacaoRepository;
        private readonly IEmpresaGrupoRepository _empresaGrupoRepository;
        private readonly IRemessaRepository _remessaRepository;
        private readonly IMoedaService _moedaService;

        public TarifaDetalheService(ITarifaDetalheRepository tarifaDetalheRepository,
                                    IPaisRepository paisRepository,
                                    ITipoAplicacaoRepository tipoAplicacaoRepository,
                                    IEmpresaRepository empresaRepository,
                                    ITarifaRepository tarifaRepository,
                                    IMoedaRepository moedaRepository,
                                    ISistemaRepository sistemaRepository,
                                    IParametroRemessaRepository parametroRemessaRepository,
                                    ICotacaoRepository cotacaoRepository,
                                    IEmpresaGrupoRepository empresaGrupoRepository,
                                    IRemessaRepository remessaRepository,
                                    IMoedaService moedaService)
        {
            _tarifaDetalheRepository = tarifaDetalheRepository;
            _paisRepository = paisRepository;
            _tipoAplicacaoRepository = tipoAplicacaoRepository;
            _empresaRepository = empresaRepository;
            _tarifaRepository = tarifaRepository;
            _moedaRepository = moedaRepository;
            _sistemaRepository = sistemaRepository;
            _parametroRemessaRepository = parametroRemessaRepository;
            _cotacaoRepository = cotacaoRepository;
            _empresaGrupoRepository = empresaGrupoRepository;
            _remessaRepository = remessaRepository;
            _moedaService = moedaService;
        }

        public TarifaDetalhe BuscarPorId(int id)
        {
            return _tarifaDetalheRepository.GetById(id);
        }

        public void Upsert(int usuarioId, int sistemaId, int empresaGrupoId, int empresaId, string tipoRemessa, string tipoAplicacaoSelecionado, List<TarifaDetalheRequest> requests)
        {
            var tipoAplicacao = _tipoAplicacaoRepository.GetBy(x => x.CodigoTipoAplicacao == tipoAplicacaoSelecionado);
            var empresaGrupo = _empresaGrupoRepository.GetById(empresaGrupoId);
            var sistema = _sistemaRepository.GetById(sistemaId);

            if (empresaGrupo != null && sistema != null)
            {
                if (tipoAplicacao.CodigoTipoAplicacao == "U")
                {
                    UpsertPorEmpresa(usuarioId, sistema, empresaGrupo, empresaId, tipoRemessa, tipoAplicacao, requests);
                }
                else
                {
                    UpsertPorPais(usuarioId, sistema, empresaGrupo, empresaId, tipoRemessa, tipoAplicacao, requests);
                }
            }
        }

        public void InsertPorEmpresa(int usuarioId, int sistemaId, int empresaGrupoId, int empresaId, string tipoRemessa, string tipoAplicacaoSelecionado, List<TarifaDetalheRequest> requests)
        {
            var tipoAplicacao = _tipoAplicacaoRepository.GetBy(x => x.CodigoTipoAplicacao == tipoAplicacaoSelecionado);
            var empresaGrupo = _empresaGrupoRepository.GetById(empresaGrupoId);
            var sistema = _sistemaRepository.GetById(sistemaId);

            CultureInfo customCulture = (CultureInfo)Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ".";
            Thread.CurrentThread.CurrentCulture = customCulture;

            var empresa = _empresaRepository.GetById(empresaId);

            foreach (var request in requests)
            {
                var codMoeda = request.CodigoMoeda.Substring(0, 3);

                var moeda = _moedaRepository.GetBy(x => x.CodigoMoeda == request.CodigoMoedaTarifa);

                var valorTarifa = string.IsNullOrEmpty(request.ValorTarifa) ? "0.00" : request.ValorTarifa.Replace(".", string.Empty).Replace(",", ".");
                var valorMinimo = string.IsNullOrEmpty(request.ValorMinimo) ? "0.00" : request.ValorMinimo.Replace(".", string.Empty).Replace(",", ".");
                var valorMaximo = string.IsNullOrEmpty(request.ValorMaximo) ? "0.00" : request.ValorMaximo.Replace(".", string.Empty).Replace(",", ".");
                var custoTarifa = string.IsNullOrEmpty(request.CustoTarifa) ? "0.00" : request.CustoTarifa.Replace(".", string.Empty).Replace(",", ".");

                var tarifa = new Tarifa()
                {
                    TipoAplicacao = tipoAplicacao,
                    Empresa = empresa,
                    EmpresaId = empresa.Id,
                    TipoAplicacaoId = tipoAplicacao.Id,
                    CodigoStatus = "A",
                    EmpresaGrupo = empresaGrupo,
                    TipoRemessa = tipoRemessa
                };

                var paises = _paisRepository.List();
                var tarifaDetalhes = new List<TarifaDetalhe>();

                foreach (var pais in paises)
                {
                    var tarifaDetalhe = new TarifaDetalhe()
                    {
                        Pais = pais,
                        PaisId = pais.Id,
                        CodigoTipoTarifa = request.CodigoTipoTarifa,
                        TipoPessoa = request.TipoPessoa,
                        Moeda = moeda,
                        MoedaId = moeda.Id,
                        CodMoedaRemessa = codMoeda,
                        ValorTarifa = Convert.ToDecimal(valorTarifa),
                        CodigoStatus = "A",
                        ValorMinimoRemessa = Convert.ToDecimal(valorMinimo),
                        ValorMaximoRemessa = Convert.ToDecimal(valorMaximo),
                        ValorCustoTarifa = Convert.ToDecimal(custoTarifa),
                        Sistema = sistema,
                        SistemaId = sistema.Id
                    };

                    tarifaDetalhes.Add(tarifaDetalhe);
                }

                _tarifaDetalheRepository.Cadastrar(usuarioId, tarifa, tarifaDetalhes);

            }
        }

        public void UpsertPorEmpresa(int usuarioId, Domain.Entities.Sistema sistema, EmpresaGrupo empresaGrupo, int empresaId, string tipoRemessa, TipoAplicacao tipoAplicacao, List<TarifaDetalheRequest> requests)
        {
            CultureInfo customCulture = (CultureInfo)Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ".";
            Thread.CurrentThread.CurrentCulture = customCulture;

            var empresa = _empresaRepository.GetById(empresaId);

            foreach (var request in requests)
            {
                var codMoeda = request.CodigoMoeda.Substring(0, 3);

                var moeda = _moedaRepository.GetBy(x => x.CodigoMoeda == request.CodigoMoedaTarifa);

                var valorTarifa = string.IsNullOrEmpty(request.ValorTarifa) ? "0.00" : request.ValorTarifa.Replace(".", string.Empty).Replace(",", ".");
                var valorMinimo = string.IsNullOrEmpty(request.ValorMinimo) ? "0.00" : request.ValorMinimo.Replace(".", string.Empty).Replace(",", ".");
                var valorMaximo = string.IsNullOrEmpty(request.ValorMaximo) ? "0.00" : request.ValorMaximo.Replace(".", string.Empty).Replace(",", ".");
                var custoTarifa = string.IsNullOrEmpty(request.CustoTarifa) ? "0.00" : request.CustoTarifa.Replace(".", string.Empty).Replace(",", ".");

                if (request.Id == 0)
                {
                    var tarifaExistente = _tarifaRepository.GetBy(
                                        x => x.EmpresaId == empresa.Id
                                        && x.EmpresaGrupoId == empresaGrupo.Id
                                        && x.TipoRemessa == tipoRemessa
                                        && x.TarifaDetalhe.Where(
                                                y => y.SistemaId == sistema.Id
                                                ).Count() > 0
                                        , x => x.TarifaDetalhe);

                    var lista = new List<TarifaDetalhe>();

                    if (tarifaExistente != null)
                    {
                        lista = tarifaExistente.TarifaDetalhe.ToList();

                        _tarifaDetalheRepository.Deletar(tarifaExistente, lista);
                    }

                    var tarifa = new Tarifa()
                    {
                        TipoAplicacao = tipoAplicacao,
                        Empresa = empresa,
                        EmpresaId = empresa.Id,
                        TipoAplicacaoId = tipoAplicacao.Id,
                        CodigoStatus = "A",
                        EmpresaGrupo = empresaGrupo,
                        TipoRemessa = tipoRemessa
                    };

                    var paises = _paisRepository.List();
                    var tarifaDetalhes = new List<TarifaDetalhe>();

                    foreach (var pais in paises)
                    {
                        var tarifaDetalhe = new TarifaDetalhe()
                        {
                            Pais = pais,
                            PaisId = pais.Id,
                            CodigoTipoTarifa = request.CodigoTipoTarifa,
                            TipoPessoa = request.TipoPessoa,
                            Moeda = moeda,
                            MoedaId = moeda.Id,
                            CodMoedaRemessa = codMoeda,
                            ValorTarifa = Convert.ToDecimal(valorTarifa),
                            CodigoStatus = "A",
                            ValorMinimoRemessa = Convert.ToDecimal(valorMinimo),
                            ValorMaximoRemessa = Convert.ToDecimal(valorMaximo),
                            ValorCustoTarifa = Convert.ToDecimal(custoTarifa),
                            Sistema = sistema,
                            SistemaId = sistema.Id
                        };

                        tarifaDetalhes.Add(tarifaDetalhe);
                    }

                    _tarifaDetalheRepository.Cadastrar(usuarioId, tarifa, tarifaDetalhes);
                }
                else
                {
                    var tarifaDetalhes2 = new List<TarifaDetalhe>();

                    var tarifaDetalhe = _tarifaDetalheRepository.GetById(request.Id);
                    var tarifaDetalhes = _tarifaDetalheRepository.ListBy(x => x.TarifaId == tarifaDetalhe.TarifaId);
                    var tarifa = _tarifaRepository.GetBy(x => x.Id == tarifaDetalhe.TarifaId);

                    var paises = _paisRepository.List();

                    foreach (var pais in paises)
                    {
                        //var paises = _paisRepository.GetBy(y => y.Id == item.PaisId);
                        var item = tarifaDetalhes.Where(y => y.PaisId == pais.Id).FirstOrDefault();
                        var x = new TarifaDetalhe();

                        if (item != null)
                        {
                            x = new TarifaDetalhe
                            {
                                CodigoStatus = item.CodigoStatus,
                                Pais = pais,
                                Id = item.Id,
                                CodigoTipoTarifa = request.CodigoTipoTarifa,
                                Moeda = moeda,
                                MoedaId = moeda.Id,
                                CodMoedaRemessa = codMoeda,
                                PaisId = pais.Id,
                                Sistema = sistema,
                                SistemaId = sistema.Id,
                                TarifaId = item.TarifaId,
                                Tarifa = tarifa,
                                TipoPessoa = request.TipoPessoa,
                                ValorCustoTarifa = decimal.Parse(custoTarifa),
                                ValorMaximoRemessa = decimal.Parse(valorMaximo),
                                ValorMinimoRemessa = decimal.Parse(valorMinimo),
                                ValorTarifa = decimal.Parse(valorTarifa)
                            };
                        }
                        else
                        {
                            x = new TarifaDetalhe()
                            {
                                Pais = pais,
                                PaisId = pais.Id,
                                CodigoTipoTarifa = request.CodigoTipoTarifa,
                                TipoPessoa = request.TipoPessoa,
                                Moeda = moeda,
                                MoedaId = moeda.Id,
                                CodMoedaRemessa = codMoeda,
                                ValorTarifa = Convert.ToDecimal(valorTarifa),
                                CodigoStatus = "A",
                                ValorMinimoRemessa = Convert.ToDecimal(valorMinimo),
                                ValorMaximoRemessa = Convert.ToDecimal(valorMaximo),
                                ValorCustoTarifa = Convert.ToDecimal(custoTarifa),
                                Sistema = sistema,
                                SistemaId = sistema.Id,
                                TarifaId = tarifa.Id,
                                Tarifa = tarifa,
                            };
                        }

                        tarifaDetalhes2.Add(x);
                    }


                    //foreach (var item in tarifaDetalhes)
                    //{

                    //}

                    tarifa.TipoAplicacao = tipoAplicacao;
                    tarifa.TipoAplicacaoId = tipoAplicacao.Id;
                    tarifa.TipoRemessa = tipoRemessa;

                    _tarifaDetalheRepository.Atualizar(usuarioId, tarifa, tarifaDetalhes2);
                }
            }
        }

        public void UpsertPorPais(int usuarioId, Domain.Entities.Sistema sistema, EmpresaGrupo empresaGrupo, int empresaId, string tipoRemessa, TipoAplicacao tipoAplicacao, List<TarifaDetalheRequest> requests)
        {
            CultureInfo customCulture = (CultureInfo)Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ".";
            Thread.CurrentThread.CurrentCulture = customCulture;

            var empresa = _empresaRepository.GetById(empresaId);

            var tarifa = _tarifaRepository.GetBy(
                x => x.EmpresaId == empresa.Id
                && x.EmpresaGrupoId == empresaGrupo.Id
                && x.TipoRemessa == tipoRemessa
                && x.TarifaDetalhe.Where(y => y.SistemaId == sistema.Id).Count() > 0
                , x => x.TarifaDetalhe);

            if (tarifa != null)
            {
                tarifa.TipoAplicacao = tipoAplicacao;
                tarifa.Empresa = empresa;
                tarifa.EmpresaId = empresa.Id;
                tarifa.TipoAplicacaoId = tipoAplicacao.Id;
                tarifa.CodigoStatus = "A";
                tarifa.TipoRemessa = tipoRemessa;
            }
            else
            {
                tarifa = new Tarifa()
                {
                    TipoAplicacao = tipoAplicacao,
                    Empresa = empresa,
                    EmpresaId = empresa.Id,
                    TipoAplicacaoId = tipoAplicacao.Id,
                    CodigoStatus = "A",
                    EmpresaGrupo = empresaGrupo,
                    TipoRemessa = tipoRemessa
                };
            }

            var ehAtualizacao = false;

            foreach (var request in requests)
            {
                var valorTarifa = string.IsNullOrEmpty(request.ValorTarifa) ? "0.00" : request.ValorTarifa.Replace(".", string.Empty).Replace(",", ".");
                var valorMinimo = string.IsNullOrEmpty(request.ValorMinimo) ? "0.00" : request.ValorMinimo.Replace(".", string.Empty).Replace(",", ".");
                var valorMaximo = string.IsNullOrEmpty(request.ValorMaximo) ? "0.00" : request.ValorMaximo.Replace(".", string.Empty).Replace(",", ".");
                var custoTarifa = string.IsNullOrEmpty(request.CustoTarifa) ? "0.00" : request.CustoTarifa.Replace(".", string.Empty).Replace(",", ".");

                var codMoeda = request.CodigoMoeda.Substring(0, 3);

                var tarifaDetalhes = new List<TarifaDetalhe>();
                var moeda = _moedaRepository.GetBy(x => x.CodigoMoeda == request.CodigoMoedaTarifa);

                if (request.Id == 0)
                {
                    var pais = _paisRepository.GetById(request.PaisId);

                    var tarifaDetalhe = new TarifaDetalhe()
                    {
                        Pais = pais,
                        PaisId = pais.Id,
                        Tarifa = tarifa,
                        CodigoTipoTarifa = request.CodigoTipoTarifa,
                        TipoPessoa = request.TipoPessoa,
                        Moeda = moeda,
                        MoedaId = moeda.Id,
                        CodMoedaRemessa = codMoeda,
                        ValorTarifa = Convert.ToDecimal(valorTarifa),
                        CodigoStatus = "A",
                        ValorMinimoRemessa = Convert.ToDecimal(valorMinimo),
                        ValorMaximoRemessa = Convert.ToDecimal(valorMaximo),
                        ValorCustoTarifa = Convert.ToDecimal(custoTarifa),
                        Sistema = sistema,
                        SistemaId = sistema.Id
                    };

                    tarifaDetalhes.Add(tarifaDetalhe);
                }
                else
                {
                    ehAtualizacao = true;
                    var tarifaDetalhe = _tarifaDetalheRepository.GetById(request.Id);

                    tarifaDetalhe.CodigoTipoTarifa = request.CodigoTipoTarifa;
                    tarifaDetalhe.TipoPessoa = request.TipoPessoa;
                    tarifaDetalhe.Moeda = moeda;
                    tarifaDetalhe.MoedaId = moeda.Id;
                    tarifaDetalhe.CodMoedaRemessa = codMoeda;
                    tarifaDetalhe.ValorTarifa = Convert.ToDecimal(valorTarifa);
                    tarifaDetalhe.ValorMinimoRemessa = Convert.ToDecimal(valorMinimo);
                    tarifaDetalhe.ValorMaximoRemessa = Convert.ToDecimal(valorMaximo);
                    tarifaDetalhe.ValorCustoTarifa = Convert.ToDecimal(custoTarifa);
                    tarifaDetalhe.Sistema = sistema;
                    tarifaDetalhe.SistemaId = sistema.Id;

                    tarifaDetalhes.Add(tarifaDetalhe);

                    var tarifaUpdate = _tarifaRepository.GetBy(x => x.Id == tarifaDetalhe.TarifaId);

                    tarifa.TipoAplicacao = tipoAplicacao;
                    tarifa.TipoAplicacaoId = tipoAplicacao.Id;
                    tarifa.TipoRemessa = tipoRemessa;

                    _tarifaDetalheRepository.Atualizar(usuarioId, tarifaUpdate, tarifaDetalhes);
                }

                if (!ehAtualizacao) _tarifaDetalheRepository.Cadastrar(usuarioId, tarifa, tarifaDetalhes);
            }
        }

        public TarifaDetalhe BuscarMenorTarifaComFiltro(string tipoPessoa, int sistemaId, decimal valorTarifa, string pais, string codigoMoedaRemessa, int clienteId, string tipoOp, string formaEntrega)
        {
            string tipoTarifa = "";
            decimal? tarifa = 0;
            decimal? custoTarifaPj = 0;
            var tarifaDetalhe = new TarifaDetalhe();
            if (!string.IsNullOrEmpty(pais))
            {
                pais = Helper.Helper.RemoveAccents(pais);
            }
            if (tipoPessoa == "J")
            {                
                codigoMoedaRemessa = _moedaService.GetCambioOnlineByMoeSwift(codigoMoedaRemessa).moe_simbolo;
                
                tipoTarifa = ObterTipoTarifa(clienteId);
                if (tipoTarifa != "E")
                {
                    tarifa = CalcularTarifaPorTipo(clienteId, tipoOp, formaEntrega, tipoTarifa, valorTarifa, codigoMoedaRemessa);
                    custoTarifaPj = CalcularValorCustoTarifaPJ(tipoOp, formaEntrega, valorTarifa, codigoMoedaRemessa, sistemaId);
                    tarifaDetalhe.ValorCustoTarifaDolar = (decimal)custoTarifaPj;
                    tarifa = ConverterTarifa("USD", (decimal)tarifa);
                    custoTarifaPj = ConverterTarifa("USD", (decimal)custoTarifaPj);
                    tarifaDetalhe.CodigoTipoTarifa = "J";
                    tarifaDetalhe.ValorTarifa = (decimal)tarifa;
                    tarifaDetalhe.ValorCustoTarifa = (decimal)custoTarifaPj;
                }
                else
                {
                    tarifa = CalcularTarifaEspecifica(clienteId, tipoOp, formaEntrega, tipoTarifa, valorTarifa, codigoMoedaRemessa);
                    custoTarifaPj = CalcularValorCustoTarifaPJ(tipoOp, formaEntrega, valorTarifa, codigoMoedaRemessa, sistemaId);
                    tarifaDetalhe.ValorCustoTarifaDolar = (decimal)custoTarifaPj;
                    tarifa = ConverterTarifa("USD", (decimal)tarifa);
                    custoTarifaPj = ConverterTarifa("USD", (decimal)custoTarifaPj);
                    tarifaDetalhe.CodigoTipoTarifa = "J";
                    tarifaDetalhe.ValorTarifa = (decimal)tarifa;
                    tarifaDetalhe.ValorCustoTarifa = (decimal)custoTarifaPj;
                }
            }
            else
            {
                if (string.IsNullOrEmpty(pais))
                {
                    var moedaPais = _moedaRepository.GetBy(x => x.CodigoMoeda.Contains(codigoMoedaRemessa));
                    var paisPadrao = _paisRepository.GetBy(x => x.Id == moedaPais.PaisIdPadrao);
                    pais = Helper.Helper.RemoveAccents(paisPadrao.NomePais);
                }

                var listaTarifas = _tarifaDetalheRepository.ListBy(x => x.CodMoedaRemessa == codigoMoedaRemessa
                                                           && Helper.Helper.RemoveAccents(x.Pais.NomePais).ToUpper() == pais.ToUpper()
                                                           && x.ValorMinimoRemessa <= valorTarifa
                                                           && x.ValorMaximoRemessa >= valorTarifa
                                                           && x.TipoPessoa == tipoPessoa
                                                           && x.SistemaId == sistemaId
                                                           , x => x.Tarifa
                                                           , x => x.Tarifa.Empresa
                                                           , x => x.Pais);
                if (listaTarifas.Count() > 0)
                    tarifaDetalhe = listaTarifas.OrderBy(x => x.ValorTarifa).FirstOrDefault();
                if (tarifaDetalhe != null)
                {
                    tarifaDetalhe.ValorCustoTarifaDolar = tarifaDetalhe.ValorCustoTarifa;
                    tarifaDetalhe.ValorTarifa = ConverterTarifa("USD", tarifaDetalhe.ValorTarifa);
                    tarifaDetalhe.ValorCustoTarifa = ConverterTarifa("USD", tarifaDetalhe.ValorCustoTarifa);
                }
            }
            return tarifaDetalhe;
        }

        public List<TarifaDetalheResponse> BuscarPorFiltroDaPagina(int idSistema, int idEmpresaGrupo, int idEmpresa, string tipoRemessa, string codTipoAplicacao)
        {
            var tipoAplicacao = _tipoAplicacaoRepository.GetBy(x => x.CodigoTipoAplicacao == codTipoAplicacao);

            if (tipoAplicacao.CodigoTipoAplicacao == "U") //Tarifa Única
                return BuscarPorEmpresa(idSistema, idEmpresaGrupo, idEmpresa, tipoRemessa);
            else
                return BuscarPorPais(idSistema, idEmpresaGrupo, idEmpresa, tipoRemessa);
        }

        public List<TarifaDetalheResponse> BuscarPorPais(int idSistema, int idEmpresaGrupo, int idEmpresa, string tipoRemessa)
        {
            CultureInfo customCulture = (CultureInfo)Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ".";
            Thread.CurrentThread.CurrentCulture = customCulture;

            var paises = _paisRepository.List();
            var listaTarifaDetalhePorPais = new List<TarifaDetalheResponse>();

            var tarifaDetalhes = _tarifaDetalheRepository.ListBy(
                    x => x.SistemaId == idSistema
                    && x.Tarifa.EmpresaId == idEmpresa
                    && x.Tarifa.EmpresaGrupoId == idEmpresaGrupo
                    && x.Tarifa.TipoRemessa == tipoRemessa
                    , x => x.Tarifa, x => x.Pais);

            if (tarifaDetalhes != null && tarifaDetalhes.Any())
            {
                foreach (var tarifaDetalhe in tarifaDetalhes)
                {
                    var tarifaDetalhePorPais = new TarifaDetalheResponse();
                    tarifaDetalhePorPais.IdPais = tarifaDetalhe.PaisId;
                    tarifaDetalhePorPais.NomePais = tarifaDetalhe.Pais.NomePais;

                    var moeda = _moedaRepository.GetBy(x => x.Id == tarifaDetalhe.MoedaId);

                    tarifaDetalhePorPais.TarifaId = tarifaDetalhe.TarifaId;
                    tarifaDetalhePorPais.TarifaDetalheId = tarifaDetalhe.Id;
                    tarifaDetalhePorPais.CodigoTipoTarifa = tarifaDetalhe.CodigoTipoTarifa;
                    tarifaDetalhePorPais.CodigoMoeda = tarifaDetalhe.CodMoedaRemessa;
                    tarifaDetalhePorPais.CodigoMoedaTarifa = moeda.CodigoMoeda;
                    tarifaDetalhePorPais.ValorMaximo = tarifaDetalhe.ValorMaximoRemessa.ToString("0.00");
                    tarifaDetalhePorPais.ValorMinimo = tarifaDetalhe.ValorMinimoRemessa.ToString("0.00");
                    tarifaDetalhePorPais.CustoTarifa = tarifaDetalhe.ValorCustoTarifa.ToString("0.00");
                    tarifaDetalhePorPais.ValorTarifa = tarifaDetalhe.ValorTarifa.ToString("0.00");
                    tarifaDetalhePorPais.TipoPessoa = tarifaDetalhe.TipoPessoa;

                    listaTarifaDetalhePorPais.Add(tarifaDetalhePorPais);
                }
            }
            else
            {
                foreach (var pais in paises)
                {
                    var tarifaDetalhePorPais = new TarifaDetalheResponse();
                    tarifaDetalhePorPais.IdPais = pais.Id;
                    tarifaDetalhePorPais.NomePais = pais.NomePais;

                    listaTarifaDetalhePorPais.Add(tarifaDetalhePorPais);
                }
            }

            return listaTarifaDetalhePorPais.OrderBy(x => x.TarifaId).ToList();
        }

        public List<TarifaDetalheResponse> BuscarPorEmpresa(int idSistema, int idEmpresaGrupo, int idEmpresa, string tipoRemessa)
        {
            CultureInfo customCulture = (CultureInfo)Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ".";
            Thread.CurrentThread.CurrentCulture = customCulture;

            var tarifasUnica = _tarifaRepository.ListBy(
                x => x.EmpresaId == idEmpresa
                && x.EmpresaGrupoId == idEmpresaGrupo
                && x.TipoAplicacao.CodigoTipoAplicacao == "U"
                && x.TipoRemessa == tipoRemessa
                && x.TarifaDetalhe.Where(y => y.SistemaId == idSistema).Count() > 0
                , x => x.TarifaDetalhe);

            var listaTarifaDetalheResponse = new List<TarifaDetalheResponse>();

            if (tarifasUnica != null && tarifasUnica.Any())
            {
                foreach (var tarifaUnica in tarifasUnica)
                {
                    var tarifaDetalhePorPais = new TarifaDetalheResponse();
                    tarifaDetalhePorPais.IdPais = 0;
                    tarifaDetalhePorPais.NomePais = "Todos";

                    var moeda = _moedaRepository.GetBy(x => x.Id == tarifaUnica.TarifaDetalhe.FirstOrDefault().MoedaId);
                    var teste = tarifaUnica.TarifaDetalhe.FirstOrDefault().ValorMaximoRemessa;

                    tarifaDetalhePorPais.TarifaDetalheId = tarifaUnica.TarifaDetalhe.FirstOrDefault().Id;
                    tarifaDetalhePorPais.CodigoTipoTarifa = tarifaUnica.TarifaDetalhe.FirstOrDefault().CodigoTipoTarifa;
                    tarifaDetalhePorPais.CodigoMoeda = tarifaUnica.TarifaDetalhe.FirstOrDefault().CodMoedaRemessa;
                    tarifaDetalhePorPais.CodigoMoedaTarifa = moeda.CodigoMoeda;
                    tarifaDetalhePorPais.ValorMaximo = tarifaUnica.TarifaDetalhe.FirstOrDefault().ValorMaximoRemessa.ToString("0.00");
                    tarifaDetalhePorPais.ValorMinimo = tarifaUnica.TarifaDetalhe.FirstOrDefault().ValorMinimoRemessa.ToString("0.00");
                    tarifaDetalhePorPais.CustoTarifa = tarifaUnica.TarifaDetalhe.FirstOrDefault().ValorCustoTarifa.ToString("0.00");
                    tarifaDetalhePorPais.ValorTarifa = tarifaUnica.TarifaDetalhe.FirstOrDefault().ValorTarifa.ToString("0.00");
                    tarifaDetalhePorPais.TipoPessoa = tarifaUnica.TarifaDetalhe.FirstOrDefault().TipoPessoa;

                    listaTarifaDetalheResponse.Add(tarifaDetalhePorPais);
                }
            }
            else
            {
                var tarifaDetalhePorPais = new TarifaDetalheResponse();
                tarifaDetalhePorPais.IdPais = 0;
                tarifaDetalhePorPais.NomePais = "Todos";

                listaTarifaDetalheResponse.Add(tarifaDetalhePorPais);
            }

            return listaTarifaDetalheResponse;
        }

        public void DeletarTarifa(int idTarifaDetalhe, string tipoAplicacao)
        {
            if (tipoAplicacao == "U")
            {
                var tarifaDetalheDb = _tarifaDetalheRepository.GetById(idTarifaDetalhe);

                if (tarifaDetalheDb != null)
                {
                    var tarifa = _tarifaRepository.GetById(tarifaDetalheDb.TarifaId, x => x.TarifaDetalhe);
                    var lista = new List<TarifaDetalhe>();

                    if (tarifa != null)
                    {
                        lista = tarifa.TarifaDetalhe.ToList();
                    }

                    foreach (var tarifaDetalhe in lista)
                    {
                        _tarifaDetalheRepository.Delete(tarifaDetalhe.Id);
                    }

                    _tarifaRepository.Delete(tarifa.Id);
                }
            }
            else
            {
                var tarifaDetalhe = _tarifaDetalheRepository.GetById(idTarifaDetalhe);

                if (tarifaDetalhe != null)
                    _tarifaDetalheRepository.Delete(tarifaDetalhe.Id);
            }
        }

        public decimal ConverterTarifa(string SiglaMoedaCotacao, decimal ValorTarifa)
        {
            decimal cotVenda = 0;
            var moeda = _cotacaoRepository.BuscaCotacaoMoeda(SiglaMoedaCotacao);
            foreach (var x in moeda)
            {
                cotVenda = ValorTarifa * (decimal)x.Tx_Venda;
            }
            return cotVenda;
        }

        public string ObterTipoTarifa(int clienteId)
        {
            string tipoTarifa = "";
            var clientes = _remessaRepository.BuscarClienteId(clienteId);
            foreach (var item in clientes)
            {
                tipoTarifa = item.ClTarifa;

            }
            return tipoTarifa;
        }

        public decimal? CalcularTarifaPorTipo(int idCliente, string tipoOp, string tipoEntrega, string clTarifa, decimal valorTarifa, string codigoMoedaRemessa)
        {
            decimal? tarifa = 0;
            var tarifas = _remessaRepository.BuscarTarifa(idCliente, tipoOp, tipoEntrega, clTarifa, valorTarifa);

            if (tarifas.Count() > 0)
            {

                var itemTarifa = tarifas.Where(x => x.tp_moeda.Trim() == codigoMoedaRemessa).FirstOrDefault();
                if (itemTarifa != null)
                    tarifa = itemTarifa.tp_val_tarifa;

                if (tarifa == 0)
                {
                    itemTarifa = tarifas.Where(x => x.tp_moeda.Trim() == "OUTRAS").FirstOrDefault();
                    if (itemTarifa != null)
                        tarifa = itemTarifa.tp_val_tarifa;
                }

                if (tarifa == 0)
                {
                    itemTarifa = tarifas.Where(x => x.tp_moeda.Trim() == "TODAS").FirstOrDefault();
                    if (itemTarifa != null)
                        tarifa = itemTarifa.tp_val_tarifa;
                }

                if (tarifa == 0)
                    tarifa = tarifas.FirstOrDefault().tp_val_tarifa;
            }

            if (!tarifa.HasValue)
                tarifa = 0;

            return tarifa;
        }

        public decimal? CalcularTarifaEspecifica(int idCliente, string tipoOp, string tipoEntrega, string clTarifa, decimal valorTarifa, string codigoMoedaRemessa)
        {
            decimal? tarifa = 0;
            var tarifas = _remessaRepository.BuscarRegrasTarifa(idCliente, tipoOp, tipoEntrega, clTarifa, valorTarifa);

            if (tarifas.Count() > 0)
            {

                var itemTarifa = tarifas.Where(x => x.rc_moeda.Trim() == codigoMoedaRemessa).FirstOrDefault();
                if (itemTarifa != null)
                    tarifa = itemTarifa.rc_val_tarifa;

                if (tarifa == 0)
                {
                    itemTarifa = tarifas.Where(x => x.rc_moeda.Trim() == "OUTRAS").FirstOrDefault();
                    if (itemTarifa != null)
                        tarifa = itemTarifa.rc_val_tarifa;
                }

                if (tarifa == 0)
                {
                    itemTarifa = tarifas.Where(x => x.rc_moeda.Trim() == "TODAS").FirstOrDefault();
                    if (itemTarifa != null)
                        tarifa = itemTarifa.rc_val_tarifa;
                }

                if (tarifa == 0)
                    tarifa = tarifas.FirstOrDefault().rc_val_tarifa;
            }

            if (!tarifa.HasValue)
                tarifa = 0;

            return tarifa;
        }
        public decimal? CalcularValorCustoTarifaPJ(string tipoOp, string tipoEntrega, decimal valorTarifa, string codigoMoedaRemessa, int sistemaId)
        {
            decimal? valorCustoTarifa = 0;
            List<TBL_REGRAS_TARIFAS> tarifas = new List<TBL_REGRAS_TARIFAS>();
            codigoMoedaRemessa = codigoMoedaRemessa == "USD" ? "US$" : codigoMoedaRemessa;
            if (sistemaId == 4)
            {
                tarifas = _remessaRepository.BuscarTarifaCotacao(tipoOp, tipoEntrega, valorTarifa);
            }
            else
            {
                tarifas = _remessaRepository.BuscarTarifaRendimento(tipoOp, tipoEntrega, valorTarifa);
            }

            if (tarifas.Count() > 0)
            {
                var itemTarifa = tarifas.Where(item => item.rt_moeda.Trim() == codigoMoedaRemessa).FirstOrDefault();
                if (itemTarifa != null)
                    valorCustoTarifa = itemTarifa.rt_val_tarifa;

                if (valorCustoTarifa == 0)
                {
                    itemTarifa = tarifas.Where(item => item.rt_moeda.Trim() == "OUTRAS").FirstOrDefault();
                    if (itemTarifa != null)
                        valorCustoTarifa = itemTarifa.rt_val_tarifa;
                }
                if (valorCustoTarifa == 0)
                {
                    itemTarifa = tarifas.Where(item => item.rt_moeda.Trim() == "TODAS").FirstOrDefault();
                    if (itemTarifa != null)
                        valorCustoTarifa = itemTarifa.rt_val_tarifa;
                }
                if (!valorCustoTarifa.HasValue)
                    valorCustoTarifa = 0;
            }
            return valorCustoTarifa;
        }
    }

}
