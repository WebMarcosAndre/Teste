﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Service.Base;
using System.Collections.Generic;

namespace RND.CBP.Service.Services
{
    public class TipoAplicacaoService : BaseService<TipoAplicacao>, ITipoAplicacaoService
    {
        private readonly ITipoAplicacaoRepository _tipoAplicacaoRepository;

        public TipoAplicacaoService(ITipoAplicacaoRepository tipoAplicacaoRepository)
        {
            _tipoAplicacaoRepository = tipoAplicacaoRepository;
        }

        public IEnumerable<TipoAplicacao> ListarTipoAplicacao()
        {
            return _tipoAplicacaoRepository.List();
        }
    }
}
