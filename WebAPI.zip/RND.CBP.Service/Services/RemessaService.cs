﻿using RND.CBP.Domain.Arguments.Remessa;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Infra.Data.Context;
using RND.CBP.Infra.Data.Repository;
using RND.CBP.Service.Base;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RND.CBP.Service.Services
{
    public class RemessaService : BaseService<Remessa>, IRemessaService
    {
        protected readonly SqlContext _context;
        private readonly IRemessaRepository _remessaRepository;

        public RemessaService(IRemessaRepository remessaRepository)
        {
            _remessaRepository = remessaRepository;
        }

        public List<TblClientes> BuscarTodosClientesIkVarejo()
        {
            return _remessaRepository.BuscarTodosClientesIkVarejo();
        }

        public List<TblClientes> BuscarNomesClientesIkVarejo()
        {
            return _remessaRepository.BuscarNomesClientesIkVarejo();
        }

        public List<object> FiltarRemessa(bool primeiraConsulta, string dataDe, string dataAte, char? codigoStatusRemessa, string pesquisarPor, string txtPesquisarPor, string tipoPessoa, string statusCliente)
        {
            var listaRemessa = _remessaRepository.FiltarRemessa(primeiraConsulta, dataDe, dataAte, codigoStatusRemessa, pesquisarPor, txtPesquisarPor, tipoPessoa, statusCliente);

            if (listaRemessa != null)
            {
                return listaRemessa.ToList();
            }
            else return null;
            
        }

        public List<TblClientes> GetSearchValue(string search, List<TblClientes> listaRemessa)
        {
            search = search.ToLower();

            var varejos = (from t1 in listaRemessa
                           where (t1.ClNome != null && t1.ClNome.ToLower().Contains(search))
                           select new TblClientes
                           {
                               IdCliente = t1.IdCliente,
                               ClNome = t1.ClNome
                           }).Take(20).ToList();

            return varejos;
        }
    }
}
