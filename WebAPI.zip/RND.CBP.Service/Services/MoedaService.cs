﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Service.Base;
using System.Collections.Generic;
using System.Linq;

namespace RND.CBP.Service.Services
{
    public class MoedaService : BaseService<Moeda>, IMoedaService
    {
        private readonly IMoedaRepository _moedaRepository;
        private readonly ICotacaoRepository _cotacaoRepository;
        private readonly IMoedaCambioOnlineRepository _moedaCambioOnlineRepository;

        public MoedaService(IMoedaRepository moedaRepository, ICotacaoRepository cotacaoRepository, IMoedaCambioOnlineRepository moedaCambioOnlineRepository)
        {
            _moedaRepository = moedaRepository;
            _cotacaoRepository = cotacaoRepository;
            _moedaCambioOnlineRepository = moedaCambioOnlineRepository;
        }

        public List<Moeda> ListarMoedas()
        {
            var listaMoedas = _moedaRepository.List().ToList();

            return listaMoedas;
        }

        public List<string> ListarCodigoMoedas()
        {
            //var listaMoedas = _cotacaoRepository.BuscaCodigoMoedas();
            var listaMoedas = _moedaRepository.List().Select(x=>x.CodigoMoeda).ToList();

            return listaMoedas.ToList();
        }

        public Tbl_Moedas GetCambioOnlineByMoeSwift(string moe_swift) {
            Tbl_Moedas moeda = new Tbl_Moedas();
            var moedasCambio = _moedaCambioOnlineRepository.List(moe_swift);
            foreach (var item in moedasCambio)
                moeda= item;
            return moeda;
        }
    }
}
