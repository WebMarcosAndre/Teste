﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Service.Base;
using System.Collections.Generic;
using System.Linq;

namespace RND.CBP.Service.Services
{
    public class PaisService : BaseService<Pais>, IPaisService
    {
        private readonly IPaisRepository _paisRepository;

        public PaisService(IPaisRepository paisRepository)
        {
            _paisRepository = paisRepository;
        }

        public List<Pais> ListarPaises()
        {
            var listaPaises = _paisRepository.List().ToList();

            return listaPaises;
        }
    }
}
