﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Service.Base;
using System.Collections.Generic;

namespace RND.CBP.Service.Services
{
    public class StatusSistemaService : BaseService<StatusSistema>, IStatusSistemaService
    {
        private readonly IStatusSistemaRepository _statusSistemaRepository;

        public StatusSistemaService(IStatusSistemaRepository statusSistemaRepository)
        {
            _statusSistemaRepository = statusSistemaRepository;
        }
        public IEnumerable<StatusSistema> ListarStatusSistema()
        {
            return _statusSistemaRepository.List();
        }
    }
}
