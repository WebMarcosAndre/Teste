﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Service.Base;
using System.Collections.Generic;

namespace RND.CBP.Service.Services
{
    public class TipoPeriodoService : BaseService<TipoPeriodo>, ITipoPeriodoService
    {
        private readonly ITipoPeriodoRepository _tipoPeriodoRepository;

        public TipoPeriodoService(ITipoPeriodoRepository tipoPeriodoRepository)
        {
            _tipoPeriodoRepository = tipoPeriodoRepository;
        }
        public IEnumerable<TipoPeriodo> ListarTipoPeriodo()
        {
            return _tipoPeriodoRepository.List();
        }
    }
}
