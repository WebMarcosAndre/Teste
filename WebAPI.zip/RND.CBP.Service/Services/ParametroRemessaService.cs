﻿using RND.CBP.Domain.DTOs;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Service.Base;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;

namespace RND.CBP.Service.Services
{
    public class ParametroRemessaService : BaseService<ParametroRemessa>, IParametroRemessaService
    {
        private readonly IParametroRemessaRepository _parametroRemessaRepository;
        private readonly ITipoPeriodoRepository _tipoPeriodoRepository;
        private readonly ISistemaRepository _sistemaRespository;
        private readonly IEmpresaGrupoRepository _empresaGrupoRepository;

        public ParametroRemessaService(IParametroRemessaRepository parametroRemessaRepository
                                        , ITipoPeriodoRepository tipoPeriodoRepository
                                        , ISistemaRepository sistemaRespository
                                        , IEmpresaGrupoRepository empresaGrupoRepository)
        {
            _parametroRemessaRepository = parametroRemessaRepository;
            _tipoPeriodoRepository = tipoPeriodoRepository;
            _sistemaRespository = sistemaRespository;
            _empresaGrupoRepository = empresaGrupoRepository;
        }

        public IEnumerable<ParametroRemessa> ListarParametroRemessa()
        {
            return _parametroRemessaRepository.List();
        }

        public IEnumerable<ParametroRemessaResponse> ListarParametroRemessaPorFiltro(int idSistema, int idEmpresaGrupo, string tipoPessoa)
        {
            CultureInfo customCulture = (CultureInfo)Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ".";
            Thread.CurrentThread.CurrentCulture = customCulture;

            var listaParametroRemessaResponse = new List<ParametroRemessaResponse>();

            var retornoBanco = _parametroRemessaRepository.ListBy(x => x.SistemaId == idSistema 
                                                                  && x.EmpresaGrupoId == idEmpresaGrupo
                                                                  && x.TipoPessoa == tipoPessoa);

            foreach (var item in retornoBanco)
            {
                listaParametroRemessaResponse.Add(new ParametroRemessaResponse()
                {
                    Id = item.Id,
                    SistemaId = item.SistemaId,
                    TipoPeriodoId = item.TipoPeriodoId,
                    TipoPessoa = item.TipoPessoa,
                    CodigoTipoRemessa = item.CodigoTipoRemessa,
                    HoraInicioPeriodo = item.HoraInicioPeriodo,
                    HoraFimPeriodo = item.HoraFimPeriodo,
                    NumeroOperacaoCliente = item.NumeroOperacaoCliente,
                    ValorOverSpread = item.ValorOverSpread?.ToString("0.00"),
                    ValorLimitePeriodo = item.ValorLimitePeriodo?.ToString("0.00"),
                    ValorLimiteOperacao = item.ValorLimiteOperacao?.ToString("0.00")
                });
            }

            return listaParametroRemessaResponse;
        }

        public IEnumerable<ParametroRemessa> BuscarParametroRemessaParaValidacao(int idSistema, int idEmpresaGrupo, int idTipoPeriodo, string codTipoRemessa, string tipoPessoa)
        {
            return _parametroRemessaRepository.ListBy(x => x.SistemaId == idSistema 
                                                      && x.EmpresaGrupoId == idEmpresaGrupo
                                                      && x.TipoPeriodoId == idTipoPeriodo
                                                      && x.CodigoTipoRemessa == codTipoRemessa
                                                      && x.TipoPessoa == tipoPessoa);
        }

        public void Excluir(int idParametroRemessa)
        {
            _parametroRemessaRepository.Delete(idParametroRemessa);
        }

        public bool UpsertParametroRemessa(Domain.DTOs.ParametroRemessaRequest parametroRemessa)
        {
            CultureInfo customCulture = (CultureInfo)Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ".";
            Thread.CurrentThread.CurrentCulture = customCulture;

            var overSpread = string.IsNullOrEmpty(parametroRemessa.OverSpread) ? "0.00" : parametroRemessa.OverSpread.Replace(".", string.Empty).Replace(",", ".");
            var limiteOperacao = string.IsNullOrEmpty(parametroRemessa.LimiteOperacao) ? "0.00" : parametroRemessa.LimiteOperacao.Replace(".", string.Empty).Replace(",", ".");
            var limitePeriodo = string.IsNullOrEmpty(parametroRemessa.LimitePeriodo) ? "0.00" : parametroRemessa.LimitePeriodo.Replace(".", string.Empty).Replace(",", ".");

            var tipoPeriodo = _tipoPeriodoRepository.GetById(parametroRemessa.TipoPeriodoId);

            if (parametroRemessa.Id > 0)
            {
                var parametroRemessaDados = _parametroRemessaRepository.GetById(parametroRemessa.Id);

                if (parametroRemessaDados != null)
                {
                    parametroRemessaDados.TipoPeriodo = tipoPeriodo;
                    parametroRemessaDados.TipoPessoa = parametroRemessa.TipoPessoa;
                    parametroRemessaDados.TipoPeriodoId = parametroRemessa.TipoPeriodoId;
                    parametroRemessaDados.CodigoTipoRemessa = parametroRemessa.CodigoTipoRemessa;
                    parametroRemessaDados.NumeroOperacaoCliente = parametroRemessa.OperacoesCliente;
                    parametroRemessaDados.HoraInicioPeriodo = parametroRemessa.HoraInicio;
                    parametroRemessaDados.HoraFimPeriodo = parametroRemessa.HoraFim;
                    parametroRemessaDados.ValorOverSpread = Convert.ToDecimal(overSpread);
                    parametroRemessaDados.ValorLimiteOperacao = Convert.ToDecimal(limiteOperacao);
                    parametroRemessaDados.ValorLimitePeriodo = Convert.ToDecimal(limitePeriodo);

                    _parametroRemessaRepository.Update(parametroRemessaDados);
                }
                else
                {
                    return false;
                }
            }
            else
            {
                var sistema = _sistemaRespository.GetById(parametroRemessa.SistemaId);
                var empresaGrupo = _empresaGrupoRepository.GetById(parametroRemessa.EmpresaGrupoId);

                var paramentroRemessaDados = new ParametroRemessa()
                {
                    TipoPeriodo = tipoPeriodo,
                    TipoPeriodoId = parametroRemessa.TipoPeriodoId,
                    TipoPessoa = parametroRemessa.TipoPessoa,
                    EmpresaGrupo = empresaGrupo,
                    EmpresaGrupoId = parametroRemessa.EmpresaGrupoId,
                    Sistema = sistema,
                    SistemaId = parametroRemessa.SistemaId,
                    CodigoTipoRemessa = parametroRemessa.CodigoTipoRemessa,
                    NumeroOperacaoCliente = parametroRemessa.OperacoesCliente,
                    HoraInicioPeriodo = parametroRemessa.HoraInicio,
                    HoraFimPeriodo = parametroRemessa.HoraFim,
                    ValorOverSpread = Convert.ToDecimal(overSpread),
                    ValorLimiteOperacao = Convert.ToDecimal(limiteOperacao),
                    ValorLimitePeriodo = Convert.ToDecimal(limitePeriodo)
                };

                _parametroRemessaRepository.Insert(paramentroRemessaDados);
            }

            return true;
        }
    }
}
