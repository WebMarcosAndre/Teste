﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Infra.Data.Context;
using RND.CBP.Service.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Service.Services
{
    public class FeriadoService : BaseService<Feriado>, IFeriadoService
    {
        protected readonly SqlContext _context;
        private readonly IFeriadoRepository _feriadoRepository;

        public FeriadoService(IFeriadoRepository feriadoRepository)
        {
            _feriadoRepository = feriadoRepository;
        }

        public List<Feriado> BuscarFeriado(int dia, int mes, int ano, int sistemaId)
        {
            return _feriadoRepository.BuscarFeriado(dia, mes, ano);
        }


    }
}
