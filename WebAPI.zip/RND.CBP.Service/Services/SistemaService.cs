﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Service.Base;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;

namespace RND.CBP.Service.Services
{
    public class SistemaService : BaseService<Sistema>, ISistemaService
    {
        private readonly ISistemaRepository _sistemaRepository;
        private readonly IStatusSistemaRepository _statusSistemaRepository;
        private readonly IFeriadoRepository _feriadoRepository;
        private readonly IParametroRemessaRepository _parametroRepository;

        public SistemaService(ISistemaRepository sistemaRepository, IStatusSistemaRepository statusSistemaRepository, IFeriadoRepository feriadoRepository, IParametroRemessaRepository parametroRepository)
        {
            _sistemaRepository = sistemaRepository;
            _statusSistemaRepository = statusSistemaRepository;
            _feriadoRepository = feriadoRepository;
            _parametroRepository = parametroRepository;
        }

        public IEnumerable<Sistema> ListarSistemas()
        {
            return _sistemaRepository.List();
        }
        public void Excluir(int idSistema)
        {
            _sistemaRepository.Delete(idSistema);
        }

        public ParametroRemessa BuscarDadosSistema(int id, int empresa, string remessa, string horario, string tipoPessoa)
        {
            #region Variáveis e Helper
            int tipoPeriodo = 0;
            DateTime data = Convert.ToDateTime(horario);
            string diaSemana = Helper.Helper.DiaDaSemana(data);
            int dia = Helper.Helper.Dia(data);
            int mes = Helper.Helper.Mes(data);
            int ano = Helper.Helper.Ano(data);
            var over = new List<ParametroRemessa>();
            var param = new ParametroRemessa();
            #endregion
            if (!string.IsNullOrEmpty(diaSemana) && diaSemana == "fds")
            {
                tipoPeriodo = 1;
                over = _parametroRepository.List().Where(x => x.TipoPeriodoId == tipoPeriodo
                && x.CodigoTipoRemessa == remessa && x.SistemaId == id && x.EmpresaGrupoId == empresa
                && x.TipoPessoa == tipoPessoa).ToList();
            }
            if (!string.IsNullOrEmpty(diaSemana) && diaSemana == "util")
            {
                var feriado = _feriadoRepository.BuscarFeriado(dia, mes, ano);
                if (feriado.Count() > 0)
                {
                    tipoPeriodo = 2;
                    over = _parametroRepository.List().Where(x => x.TipoPeriodoId == tipoPeriodo
                    && x.CodigoTipoRemessa == remessa && x.SistemaId == id && x.EmpresaGrupoId == empresa
                    && x.TipoPessoa == tipoPessoa).ToList();
                }
                else
                {
                    over = _parametroRepository.List().Where(x => x.HoraInicioPeriodo <= data.TimeOfDay
                    && x.HoraFimPeriodo >= data.TimeOfDay && x.TipoPeriodoId != 1 && x.TipoPeriodoId != 2
                    && x.CodigoTipoRemessa == remessa && x.SistemaId == id && x.EmpresaGrupoId == empresa
                    && x.TipoPessoa == tipoPessoa).ToList();
                }
            }
           
            foreach (var item in over)
                {
                    param.CodigoTipoRemessa = item.CodigoTipoRemessa;
                    param.EmpresaGrupo = item.EmpresaGrupo;
                    param.EmpresaGrupoId = item.EmpresaGrupoId;
                    param.HoraFimPeriodo = item.HoraFimPeriodo;
                    param.HoraInicioPeriodo = item.HoraInicioPeriodo;
                    param.Id = item.Id;
                    param.NumeroOperacaoCliente = item.NumeroOperacaoCliente;
                    param.Sistema = item.Sistema;
                    param.SistemaId = item.SistemaId;
                    param.TipoPeriodo = item.TipoPeriodo;
                    param.TipoPeriodoId = item.TipoPeriodoId;
                    param.ValorLimiteOperacao = item.ValorLimiteOperacao;
                    param.ValorLimitePeriodo = item.ValorLimitePeriodo;
                    param.ValorOverSpread = item.ValorOverSpread;                    
                }
            
            return param;               
        }

        public bool UpsertSistema(int idSistema, string nomeSistema, string urlSistema, int idStatusSistema)
        {
            if (idSistema > 0)
            {
                var sistema = _sistemaRepository.GetById(idSistema);
                var statusSistema = _statusSistemaRepository.GetById(idStatusSistema);

                if (sistema != null)
                {
                    sistema.NomeSistema = nomeSistema;
                    sistema.UrlSistema = urlSistema;
                    sistema.StatusSistemaId = statusSistema.Id;
                    sistema.StatusSistema = statusSistema;

                    _sistemaRepository.Update(sistema);
                }
                else
                {
                    return false;
                }
            }
            else
            {
                var statusSistema = _statusSistemaRepository.GetById(idStatusSistema);

                var sistema = new Sistema()
                {
                    NomeSistema = nomeSistema,
                    UrlSistema = urlSistema,
                    StatusSistemaId = statusSistema.Id,
                    StatusSistema = statusSistema
                };

                _sistemaRepository.Insert(sistema);
            }

            return true;
        }

        public StatusSistema StatusSistema(int id)
        {
            var sistema = new List<Sistema>();
            var statusSistema = new StatusSistema();
            var status = new List<StatusSistema>();           
            sistema = _sistemaRepository.List().Where(x => x.Id == id).ToList();
            foreach(var item in sistema)
            {
                status =  _statusSistemaRepository.List().Where(x => x.Id == item.StatusSistemaId).ToList();
                foreach(var st in status)
                {
                    statusSistema.Id = st.Id;
                    statusSistema.NomeStatusSistema = st.NomeStatusSistema;
                    statusSistema.Sistema = st.Sistema;
                    statusSistema.CodigoStatusSistema = st.CodigoStatusSistema;                   
                }
            }

            return statusSistema;
        }
    }
}
