﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Domain.Interfaces.Services;
using RND.CBP.Service.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RND.CBP.Service.Services
{
    public class DominioService : BaseService<Dominio>, IDominioService
    {
        private readonly IDominioRepository _dominioRepository;

        public DominioService(IDominioRepository dominioRepository)
        {
            _dominioRepository = dominioRepository;
        }

        public List<Dominio> ListarDominios()
        {
            return _dominioRepository.List().ToList();
        }
    }
}
