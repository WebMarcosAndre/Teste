﻿using Microsoft.Extensions.Configuration;
using RND.CBP.Domain.Arguments.Elmah_Error;
using RND.CBP.Domain.Interfaces;
using RND.CBP.Domain.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RND.CBP.Service.Services
{
    public class ElmahService  : IElmahService
    {
        private readonly IConfiguration _configuration;
        private readonly IELMAH_ErrorRepository _elmahRepository;

        public ElmahService(IConfiguration configuration, IELMAH_ErrorRepository elmahRepository)
        {
            _configuration = configuration;
            _elmahRepository = elmahRepository;
        }

        public void ResponseExceptionAsync(Exception e)
        {
            var sqlErrorLog = new ElmahCore.Sql.SqlErrorLog(_configuration["ConnectionStrings:CBP"]).ToString();
        }

        public IEnumerable<ELMAH_ErrorRequest> ListarTodos()
        {
            try
            {
                var parceiro = _elmahRepository.List();

                if (parceiro == null) return null;
                var retorno = parceiro.Select(i => (ELMAH_ErrorResponse)i).ToList();
                return retorno.Select(i => (ELMAH_ErrorRequest)i).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Result<ELMAH_ErrorRequest> ObterLog(DateTime dataDe, DateTime dataAte, int start = 0, int itensPorPagina = 10, int draw = 0)
        {
            try
            {
                var records = _elmahRepository.ListBy(x => x.TimeUtc.Date >= dataDe && x.TimeUtc.Date <= dataAte).Count();
                if (itensPorPagina == -1)
                {
                    itensPorPagina = records;
                }
                var parceiro = _elmahRepository.ListBy(x => x.TimeUtc.Date >= dataDe && x.TimeUtc.Date <= dataAte)
                                               .Skip(start).Take(itensPorPagina);

                var retorno = parceiro.Select(i => (ELMAH_ErrorResponse)i).ToList();
                var paginationResult = new Result<ELMAH_ErrorRequest>
                {
                    Draw = draw,
                    data = retorno.Select(i => (ELMAH_ErrorRequest)i).ToList(),
                    RecordsFilter = records,
                    RecordsTotal = records
                };
                return paginationResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ELMAH_ErrorRequest ObterPor(int id)
        {
            try
            {
                var parceiro = _elmahRepository.GetById(id);
                if (parceiro == null) return null;
                var retorno = (ELMAH_ErrorResponse)parceiro;
                return (ELMAH_ErrorRequest)retorno;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
