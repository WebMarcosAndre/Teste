﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Data;
//using System.Data.SqlClient;
//using BancoRendimento.Uteis;
//using Interf_CC_TES;
//using System.Collections;
//using System.IO;
//using Microsoft.ApplicationBlocks.Data;
//using System.Net;
//using R_ContrapartidaCC.EmailService;
//using System.Web.Script.Serialization;

//namespace R_CCMESwift
//{
//    public class ProcessarContraPartidaCC
//    {
//        public int intId_LogPai = 0;
//        public Parametro oParametro = new Parametro();
//        public Parametro oDBParametro = new Parametro();
//        public LogCCMESwift oLogContraPartida = new LogCCMESwift();
//        private string strConexao = clsFerramentas.Decodificar(System.Configuration.ConfigurationManager.AppSettings.Get("ConnectionString"));
//        private string strSistema = System.Configuration.ConfigurationManager.AppSettings.Get("NomeSistema");
//        private string wsEmailService = System.Configuration.ConfigurationManager.AppSettings.Get("URL_WSEmail");

//        LogContaCorrente aux_oLogContaCorrente = new LogContaCorrente();
//        // Historico
//        Hashtable Historico = new Hashtable();

//        //Hashtable RetornoMovimentacao = new Hashtable();
//        DataTable dtDados = new DataTable("dtTeste");
//        DataView dvDados = new DataView();


//        public ProcessarContraPartidaCC()
//        {
//            //Consulta Parametro 
//            oDBParametro = oParametro.ConsultarParametro();
//        }


//        public void IniciarContraPartidaCC()
//        {
//            try
//            {
//                //Grava Log 
//                oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                oLogContraPartida.DesLog = "Inicio :";
//                oLogContraPartida.TpoLog = "I";
//                intId_LogPai = oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);

//                if (!AutorizarProcessamento())
//                {
//                    oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);
//                    return;
//                }

//                ProcessarContraPartida();

//                //Envio diário de report com boletos de liquidacao em C/C que não tiveram a contrapartida aprovada.
//                ProcessarEnvioEmailDiario();

//                //Grava Log 
//                oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                oLogContraPartida.DesLog = "Fim :";
//                oLogContraPartida.TpoLog = "I";
//                oLogContraPartida.IdLogPai = intId_LogPai;
//                oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);


//                // pagina uso 
//                intId_LogPai = 0;
//            }
//            catch (Exception e)
//            {
//                //Grava log em arquivo texto 
//                GravarArquivoLog(e.Message.ToString() + " - " + e.StackTrace);

//                //Grava Log 
//                oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                oLogContraPartida.DesLog = e.Message.ToString() + " - " + e.StackTrace;
//                oLogContraPartida.TpoLog = "E";
//                intId_LogPai = oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);
//            }
//            intId_LogPai = 0;
//        }

//        private void ProcessarEnvioEmailDiario()
//        {
//            string sHoraPrimeiro = "";
//            string sFlagPrimeiro = "";
//            string sHoraSegundo = "";
//            string sFlagSegundo = "";
//            string sHoraAgora = DateTime.Now.Hour.ToString();

//            Parametro objParametro = new Parametro();
//            Parametro objDBParametro = new Parametro();

//            objDBParametro = objParametro.ConsultarParametro();

//            try
//            {
//                if (oDBParametro.Email != "")
//                {
//                    DataSet dsParametros = ConsultParametrosTBL_ROBOCONTRAPARTIDACC();

//                    if (dsParametros != null)
//                    {
//                        if (dsParametros.Tables[0].Rows.Count >= 1)
//                        {
//                            DataRow drwParametros = dsParametros.Tables[0].Rows[0];

//                            sFlagPrimeiro = drwParametros["FlagPrimeiroEnvio"].ToString().Trim();
//                            sHoraPrimeiro = drwParametros["HoraPrimeiroEnvio"].ToString().Trim().Substring(0, 2);
//                            sFlagSegundo = drwParametros["FlagSegundoEnvio"].ToString().Trim();
//                            sHoraSegundo = drwParametros["HoraSegundoEnvio"].ToString().Trim().Substring(0, 2);
//                        }
//                    }

//                    // Primeiro envio.
//                    if (sHoraPrimeiro == sHoraAgora)
//                    {
//                        if (sFlagPrimeiro != "S")
//                        {
//                            var infoEmail = new InfoEmail
//                            {
//                                IdSistema = "2",
//                                IdEmpresa = "1",
//                                Codigo = "38",
//                                ListaEmailPara = objDBParametro.Email,
//                                ListaEmailCc = "",
//                                Assunto = "Robô de Contrapartida - Boletos Pendentes" + sHoraPrimeiro + "hrs.",
//                                ListaArquivos = null,
//                                ListaParametrosCorpo = new List<EmailService.Parametro>()
//                            };

//                            //cria objeto com lista de boletos pendentes, serializa e inclui nos parametros enviados para o webservice
//                            var listaDescricao = new List<Descricao>();
//                            DataSet dsBoletosPendentes = ConsultarBoletosPendentes();

//                            if (dsBoletosPendentes != null)
//                            {
//                                if (dsBoletosPendentes.Tables[0].Rows.Count >= 1)
//                                {
//                                    infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "temBoletos", Valor = "true" });

//                                    // Se tiver boletos pendentes com erro de processamento, monta o e-mail.
//                                    for (int i = 0; i <= dsBoletosPendentes.Tables[0].Rows.Count - 1; i++)
//                                    {
//                                        DataRow drwBoletosPendentes = dsBoletosPendentes.Tables[0].Rows[i];

//                                        listaDescricao.Add(new Descricao
//                                        {
//                                            Agencia = drwBoletosPendentes["Agencia"].ToString(),
//                                            DataMovto = drwBoletosPendentes["DataMovto"].ToString(),
//                                            Desc_Retorno = drwBoletosPendentes["Desc_Retorno"].ToString(),
//                                            Documento = drwBoletosPendentes["Documento"].ToString(),
//                                            NroConta = drwBoletosPendentes["NroConta"].ToString(),
//                                            OP_Data_MN = drwBoletosPendentes["OP_Data_MN"].ToString(),
//                                            Valor = drwBoletosPendentes["Valor"].ToString()
//                                        });
//                                    }
//                                }
//                                else
//                                {
//                                    infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "temBoletos", Valor = "false" });
//                                }

//                            }

//                            var serializer = new JavaScriptSerializer();
//                            string lista = serializer.Serialize(listaDescricao);
//                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "ListaDescricao", Valor = lista });

//                            string dados = serializer.Serialize(infoEmail);

//                            var rest = new RestClient(wsEmailService);
//                            string resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));

//                            objDBParametro.TBL_ROBOCONTRAPARTIDACC_Alterar(objDBParametro, "S", "N");
//                        }
//                    }

//                    // Segundo envio.
//                    if (sHoraSegundo == sHoraAgora)
//                    {
//                        if (sFlagSegundo != "S")
//                        {
//                            var infoEmail = new InfoEmail
//                            {
//                                IdSistema = "2",
//                                IdEmpresa = "1",
//                                Codigo = "38",
//                                ListaEmailPara = objDBParametro.Email,
//                                ListaEmailCc = "",
//                                Assunto = "Robô de Contrapartida - Boletos Pendentes" + sHoraSegundo + "hrs.",
//                                ListaArquivos = null,
//                                ListaParametrosCorpo = new List<EmailService.Parametro>()
//                            };

//                            //cria objeto com lista de boletos pendentes, serializa e inclui nos parametros enviados para o webservice
//                            var listaDescricao = new List<Descricao>();
//                            DataSet dsBoletosPendentes = ConsultarBoletosPendentes();

//                            if (dsBoletosPendentes != null)
//                            {
//                                if (dsBoletosPendentes.Tables[0].Rows.Count >= 1)
//                                {
//                                    infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "temBoletos", Valor = "true" });

//                                    // Se tiver boletos pendentes com erro de processamento, monta o e-mail.
//                                    for (int i = 0; i <= dsBoletosPendentes.Tables[0].Rows.Count - 1; i++)
//                                    {
//                                        DataRow drwBoletosPendentes = dsBoletosPendentes.Tables[0].Rows[i];

//                                        listaDescricao.Add(new Descricao
//                                        {
//                                            Agencia = drwBoletosPendentes["Agencia"].ToString(),
//                                            DataMovto = drwBoletosPendentes["DataMovto"].ToString(),
//                                            Desc_Retorno = drwBoletosPendentes["Desc_Retorno"].ToString(),
//                                            Documento = drwBoletosPendentes["Documento"].ToString(),
//                                            NroConta = drwBoletosPendentes["NroConta"].ToString(),
//                                            OP_Data_MN = drwBoletosPendentes["OP_Data_MN"].ToString(),
//                                            Valor = drwBoletosPendentes["Valor"].ToString()
//                                        });
//                                    }
//                                }
//                                else
//                                {
//                                    infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "temBoletos", Valor = "false" });
//                                }

//                            }

//                            var serializer = new JavaScriptSerializer();
//                            string lista = serializer.Serialize(listaDescricao);
//                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "ListaDescricao", Valor = lista });

//                            string dados = serializer.Serialize(infoEmail);

//                            var rest = new RestClient(wsEmailService);
//                            string resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));

//                            objDBParametro.TBL_ROBOCONTRAPARTIDACC_Alterar(objDBParametro, "N", "S");
//                        }
//                    }
//                }
//            }
//            catch (Exception e)
//            {
//                GravarArquivoLog("Método : ProcessarEnvioEmailDiario - Error : " + e.Message.ToString() + " - " + e.StackTrace);
//            }
//        }

//        private DataSet ConsultarBoletosPendentes()
//        {
//            DataSet dsPendentes = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBR_VERIFICA_BOLETOS_PENDENTES");

//            return dsPendentes;
//        }

//        private DataSet ConsultParametrosTBL_ROBOCONTRAPARTIDACC()
//        {
//            SqlParameter[] strParametros = new SqlParameter[2];

//            strParametros[0] = new SqlParameter("@Nom_Robo", SqlDbType.VarChar, 30);
//            strParametros[0].Value = "ROBO_APROVA_CONTRAPARTIDACC";

//            strParametros[1] = new SqlParameter("@TipoConsulta", SqlDbType.VarChar, 1);
//            strParametros[1].Value = "1";

//            DataSet dsParametros = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBVAR_RoboContraPartida_Consultar", strParametros);

//            return dsParametros;
//        }

//        //METODO PARA CONSULTA DOS PARAMETROS PARA EXECUTAR O ROBO
//        public string ConsultarParametrosTBL_EMPRESAS(string campo)
//        {
//            SqlParameter[] strParametros = new SqlParameter[2];

//            strParametros[0] = new SqlParameter("@PARAMETRO", SqlDbType.VarChar, 200);
//            strParametros[0].Value = campo;

//            strParametros[1] = new SqlParameter("@IDEMPRESA", SqlDbType.Int);
//            strParametros[1].Value = 2;

//            DataSet dsParametros = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBR_BuscarParamEmpresaValue", strParametros);

//            return dsParametros.Tables[0].Rows[0][0].ToString();
//        }

//        public void ProcessarContraPartida()
//        {
//            try
//            {
//                //Grava Log 
//                oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                oLogContraPartida.IdLogPai = intId_LogPai;
//                oLogContraPartida.DesLog = "Inicio :";
//                oLogContraPartida.TpoLog = "I";
//                oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);

//                // Consulta ContraPartida

//                // Incluir nova rotina para Credito em Conta Corrente - Eduardo 31/10/2011
//                DataSet dstObterCreditaContraPartida = ObterCreditaContraPartida();
//                //*************************************************************************

//                DataSet dstContraPartida = ConsultarContraPartida();
//                LogContaCorrente oLogContaCorrente = new LogContaCorrente();
//                LogContaCorrente oDBLogContaCorrente = new LogContaCorrente();

//                //POPULA AS VARIAVEIS COM AS INFORMAÇÕES OBTIDAS NA CONSULTA
//                string sNumDocCotacao = ConsultarParametrosTBL_EMPRESAS("CNPJ");//System.Configuration.ConfigurationManager.AppSettings.Get("CnpjCotacao").ToString();
//                string sAgenciaCotacao = ConsultarParametrosTBL_EMPRESAS("CodAgencia_cc");//System.Configuration.ConfigurationManager.AppSettings.Get("NumeroAgenciaCotacao").ToString();
//                string sContaCotacao = ConsultarParametrosTBL_EMPRESAS("CodConta_cc");//System.Configuration.ConfigurationManager.AppSettings.Get("NumeroContaCotacao").ToString();

//                Email oEmail = new Email();
//                // Incluir nova rotina para Credito em Conta Corrente - Eduardo 31/10/2011
//                if (dstObterCreditaContraPartida != null)
//                {
//                    if (dstObterCreditaContraPartida.Tables[0].Rows.Count >= 1)
//                    {
//                        int intRetorno = 0;
//                        bool blnEstornar = false;
//                        string tpo_operacao = string.Empty;
//                        string SisOrigem = System.Configuration.ConfigurationManager.AppSettings.Get("SisOrigem");
//                        decimal PrazoBloq = decimal.Parse(System.Configuration.ConfigurationManager.AppSettings.Get("PrazoBloq"));
//                        decimal totalBoleto = 0;
//                        bool blnLiberaDebitoCC = false;


//                        string dta_Movimento = DateTime.Now.ToString("dd/MM/yyyy");

//                        AlimentarHistorico();

//                        try
//                        {
//                            for (int intCiclo = 0; intCiclo <= dstObterCreditaContraPartida.Tables[0].Rows.Count - 1; intCiclo++)
//                            {
//                                DataRow drwContraPartida = dstObterCreditaContraPartida.Tables[0].Rows[intCiclo];

//                                tpo_operacao = drwContraPartida["op_tipo_operacao"].ToString().Trim();
//                                blnEstornar = false;
//                                intRetorno = 0;
//                                totalBoleto = 0;
//                                RetornoMovimentacaoLimpar();

//                                #region COMPRA

//                                //TIPO OPERAÇAO COMPRA 
//                                if (tpo_operacao == "C")
//                                {
//                                    if (drwContraPartida["NroConta"].ToString() != "")  // Consistir dados como numero de conta.
//                                    {
//                                        oLogContaCorrente.flg_RecolheIR = drwContraPartida["Op_rec_ir"].ToString();
//                                        oLogContaCorrente.tpo_Cliente = drwContraPartida["cl_tip_doc"].ToString().Trim();
//                                        oLogContaCorrente.vlr_IR = decimal.Parse(drwContraPartida["vlr_ir"].ToString());
//                                        oLogContaCorrente.vlr_Reais = decimal.Parse(drwContraPartida["op_val_reais"].ToString());
//                                        oLogContaCorrente.vlr_IOF = decimal.Parse(drwContraPartida["vlr_iof"].ToString());
//                                        oLogContaCorrente.vlr_TarifaOP = decimal.Parse(drwContraPartida["op_tarifa_operacao"].ToString());
//                                        oLogContaCorrente.Op_N_Boleto = int.Parse(drwContraPartida["op_n_boleto"].ToString());
//                                        oLogContaCorrente.Id_Operacao = int.Parse(drwContraPartida["Id_Operacao"].ToString());
//                                        oLogContaCorrente.Id_Corretora = int.Parse(drwContraPartida["id_corretora"].ToString());
//                                        oLogContaCorrente.Cl_Passaporte = drwContraPartida["Cl_Passaporte"].ToString().Trim();
//                                        oLogContaCorrente.Cl_Num_Doc = drwContraPartida["Cl_Num_Doc"].ToString().Trim();
//                                        oLogContaCorrente.Op_Tipo_Operacao = tpo_operacao;
//                                        oLogContaCorrente.SisOrigem = SisOrigem;
//                                        oLogContaCorrente.PrazoBloq = PrazoBloq;
//                                        oLogContaCorrente.NroConta = drwContraPartida["NroConta"].ToString().Trim();
//                                        oLogContaCorrente.Documento = int.Parse(drwContraPartida["op_n_boleto"].ToString());
//                                        oLogContaCorrente.DataMovto = dta_Movimento;
//                                        oLogContaCorrente.Coligada = oDBParametro.Coligada;
//                                        oLogContaCorrente.CodUsuario = oDBParametro.IdUser;
//                                        oLogContaCorrente.CodAgenciaDes = oDBParametro.CodAgenciaDes;
//                                        oLogContaCorrente.CodAgenciaCli = oDBParametro.CodAgenciaCli;
//                                        oLogContaCorrente.Agencia = oDBParametro.Agencia;
//                                        oLogContaCorrente.DescRetorno = "Enviado para a Conta Corrente.";
//                                        oLogContaCorrente.FlgSucesso = 1;
//                                        oLogContraPartida.DesParametro = "|Boleto:" + oLogContaCorrente.Op_N_Boleto.ToString() + "|NumeroConta:" + oLogContaCorrente.NroConta.ToString() + "|R$_IR:" + oLogContaCorrente.vlr_IR.ToString() + "|R$_Reais:" + oLogContaCorrente.vlr_Reais.ToString() + "|R$ IOF:" + oLogContaCorrente.vlr_IOF.ToString() + "|R$_TarifaOP:" + oLogContaCorrente.vlr_TarifaOP.ToString();
//                                        oLogContaCorrente.Historico = RetornaHistorico(tpo_operacao + "_" + oLogContaCorrente.tpo_Cliente + "_vlr_Reais");
//                                        oLogContaCorrente.Valor = oLogContaCorrente.vlr_Reais;
//                                        oLogContaCorrente.vlr_total = 0;

//                                        //CALCULA O TOTAL DO BOLETO
//                                        totalBoleto = decimal.Parse(oLogContaCorrente.vlr_Reais.ToString()) - decimal.Parse(oLogContaCorrente.vlr_IOF.ToString()) - decimal.Parse(oLogContaCorrente.vlr_TarifaOP.ToString());

//                                        //CRIA OBJETO AUXILIAR PARA TRATAR OS DADOS DA COTACAO
//                                        LogContaCorrente oLogContaCorrente_Aux = new LogContaCorrente();

//                                        //POPULA O NOVO OBJETO COM AS INFORMAÇÕES DO OBJETO ORIGINAL
//                                        oLogContaCorrente_Aux.flg_RecolheIR = oLogContaCorrente.flg_RecolheIR;
//                                        oLogContaCorrente_Aux.tpo_Cliente = oLogContaCorrente.tpo_Cliente;
//                                        oLogContaCorrente_Aux.vlr_IR = 0;
//                                        oLogContaCorrente_Aux.vlr_Reais = 0;
//                                        oLogContaCorrente_Aux.vlr_IOF = 0;
//                                        oLogContaCorrente_Aux.vlr_TarifaOP = 0;
//                                        oLogContaCorrente_Aux.Op_N_Boleto = oLogContaCorrente.Op_N_Boleto;
//                                        oLogContaCorrente_Aux.Id_Operacao = oLogContaCorrente.Id_Operacao;
//                                        oLogContaCorrente_Aux.Id_Corretora = oLogContaCorrente.Id_Corretora;
//                                        oLogContaCorrente_Aux.Cl_Passaporte = oLogContaCorrente.Cl_Passaporte;
//                                        oLogContaCorrente_Aux.Op_Tipo_Operacao = oLogContaCorrente.Op_Tipo_Operacao;
//                                        oLogContaCorrente_Aux.SisOrigem = oLogContaCorrente.SisOrigem;
//                                        oLogContaCorrente_Aux.PrazoBloq = oLogContaCorrente.PrazoBloq;
//                                        oLogContaCorrente_Aux.Documento = oLogContaCorrente.Documento;
//                                        oLogContaCorrente_Aux.DataMovto = oLogContaCorrente.DataMovto;
//                                        oLogContaCorrente_Aux.CodUsuario = oLogContaCorrente.CodUsuario;
//                                        oLogContaCorrente_Aux.CodAgenciaDes = oLogContaCorrente.CodAgenciaDes;
//                                        oLogContaCorrente_Aux.Agencia = oLogContaCorrente.Agencia;
//                                        oLogContaCorrente_Aux.DescRetorno = "| Boleto:" + oLogContaCorrente_Aux.Op_N_Boleto.ToString() + " |DÉBITO COTACAO | R$_TOTAL:" + totalBoleto;
//                                        oLogContaCorrente_Aux.FlgSucesso = oLogContaCorrente.FlgSucesso;
//                                        oLogContaCorrente_Aux.vlr_total = totalBoleto;
//                                        oLogContaCorrente_Aux.sDocumentoAjustado = clsFerramentas.Right("0000000" + oLogContaCorrente_Aux.Documento.ToString(), 7);

//                                        // Consiste dados da conta corrente do cliente.
//                                        string sCodBanco = "";
//                                        string sAgenciaCliente = "";
//                                        string sContaCliente = "";
//                                        oLogContaCorrente.auxDescRetorno = "";

//                                        oLogContaCorrente.sDocumentoAjustado = clsFerramentas.Right("0000000" + oLogContaCorrente.Documento.ToString(), 7);
//                                        oLogContaCorrente.sHistoricoAjustado = clsFerramentas.Right("00000" + oLogContaCorrente.Historico, 5);

//                                        DataSet dsDadosBancariosCliente = GetDadosBancariosCliente(oLogContaCorrente.Cl_Num_Doc, oLogContaCorrente.Op_N_Boleto, "1");

//                                        if (dsDadosBancariosCliente != null)
//                                        {
//                                            if (dsDadosBancariosCliente.Tables[0].Rows.Count >= 1)
//                                            {
//                                                DataRow drwDadosBancariosCliente = dsDadosBancariosCliente.Tables[0].Rows[0];

//                                                sCodBanco = drwDadosBancariosCliente["CodBanco"].ToString().Trim();
//                                                sAgenciaCliente = drwDadosBancariosCliente["Agencia"].ToString().Trim();
//                                                sContaCliente = drwDadosBancariosCliente["NroConta"].ToString().Trim();

//                                                // Atualiza o objecto com os dados de Agencia/Conta corretos.
//                                                oLogContaCorrente.Agencia = sAgenciaCliente;
//                                                oLogContaCorrente.NroConta = sContaCliente;
//                                            }
//                                        }
//                                        // Monta os dados no log.
//                                        oLogContaCorrente.auxDescRetorno = "CodBanco: " + sCodBanco + ", Agencia: " + sAgenciaCliente + ", Conta: " + sContaCliente;
//                                        // Verifica dados conta corrente. Caso exista alguma divergência, set estorno = true
//                                        if (sAgenciaCliente == "" || sContaCliente == "" || sCodBanco == "")
//                                        {
//                                            intRetorno = -97;
//                                            blnEstornar = true;
//                                        }
//                                        else
//                                        {
//                                            if (sCodBanco != "633")
//                                            {
//                                                // Conta não pertence ao Banco Rendimento.
//                                                intRetorno = -96;
//                                                blnEstornar = true;
//                                            }
//                                            else
//                                            {

//                                                if (sAgenciaCliente != "00019" && sAgenciaCliente != "00030" && sAgenciaCliente != "00020")
//                                                {
//                                                    // Agência não pertence ao Banco Rendimento.
//                                                    intRetorno = -95;
//                                                    blnEstornar = true;
//                                                }
//                                            }
//                                        }

//                                        #region COTACAO

//                                        // Processar - Movimentar CC - Compra 

//                                        // Alteração Alexandre / Igor 
//                                        // Verificar se é cotacao - se for cotacao - precisa debitar a conta
//                                        // se nao tiver saldo - nao credita a conta do cliente
//                                        // se tiver saldo - debita cotação e credita cliente

//                                        if (strSistema == "COTACAO")
//                                        {
//                                            //ALTERA AS PROPRIEDADES DO OBJETO COLOCANDO AS INFORMAÇÕES DA COTAÇÃO
//                                            oLogContaCorrente_Aux.Cl_Num_Doc = sNumDocCotacao; //CNPJ COTACAO
//                                            oLogContaCorrente_Aux.CodAgenciaCli = sAgenciaCotacao; //NRO AGENCIA COTACAO
//                                            oLogContaCorrente_Aux.NroConta = sContaCotacao; //NRO CONTA COTACAO
//                                            oLogContaCorrente_Aux.Historico = RetornaHistorico("CD_DEB_VALORTOTAL");
//                                            oLogContaCorrente_Aux.sHistoricoAjustado = clsFerramentas.Right("00000" + oLogContaCorrente_Aux.Historico, 5);
//                                            oLogContaCorrente_Aux.Valor = totalBoleto; //VALOR TOTAL A SER LANCADO(IR, IOF, TARIFA, VALOR DA TRANSACAO)

//                                            // Valida se a COTACAO possui saldo suficiente.
//                                            try
//                                            {
//                                                blnLiberaDebitoCC = VerificaSaldoContaCorrente(oLogContaCorrente_Aux.Agencia, oLogContaCorrente_Aux.NroConta, totalBoleto);
//                                            }
//                                            catch (Exception e)
//                                            {
//                                                GravarArquivoLog("Método : VerificaSaldoContaCorrente - Error : " + e.Message.ToString() + " - " + e.StackTrace);
//                                            }

//                                            // Se tiver saldo, realiza o debito na cotacao
//                                            if (blnLiberaDebitoCC)
//                                            {
//                                                // processa o debito na cotacao
//                                                intRetorno = ProcessarMovimentarContaCorrente(oLogContaCorrente_Aux);
//                                            }
//                                            else
//                                            {
//                                                intRetorno = -98; // Manda o numero de erro referente a saldo insuficiente.
//                                            }

//                                            //cria registro no DataTable auxiliar utilizado na rotina de estorno
//                                            RetornoMovimentacao(intRetorno, "vlr_total");

//                                            // Verifica se gerou erro no momento do debito
//                                            if (intRetorno != 0)
//                                            {
//                                                oLogContaCorrente_Aux.FlgSucesso = 0;
//                                                ProcessarEstornar(oLogContaCorrente_Aux, "COTACAO");
//                                                blnEstornar = true;
//                                            }
//                                            // terminou a cotacao
//                                        }

//                                        #endregion

//                                        if (blnEstornar == false)
//                                        {
//                                            // Processar - Movimentar CC
//                                            intRetorno = ProcessarMovimentarContaCorrente(oLogContaCorrente);
//                                            if (intRetorno != 0)
//                                            {
//                                                blnEstornar = true;
//                                            }

//                                            RetornoMovimentacao(intRetorno, "vlr_Reais");

//                                            #region TARIFA

//                                            // Calcula Tarifa
//                                            // Movimentação de Tarifa Operação 
//                                            if (oLogContaCorrente.vlr_TarifaOP > 0 && blnEstornar == false)
//                                            {
//                                                //Historico                   = RetornaHistorico(tpo_operacao + "_" + oLogContaCorrente.tpo_Cliente + "_vlr_TarifaOP");
//                                                oLogContaCorrente.Historico = RetornaHistorico(tpo_operacao + "_" + oLogContaCorrente.tpo_Cliente + "_vlr_TarifaOP");
//                                                oLogContaCorrente.Valor = oLogContaCorrente.vlr_TarifaOP;
//                                                oLogContaCorrente.sDocumentoAjustado = clsFerramentas.Right("0000000" + oLogContaCorrente.Documento.ToString(), 7);
//                                                oLogContaCorrente.sHistoricoAjustado = clsFerramentas.Right("00000" + oLogContaCorrente.Historico, 5);
//                                                intRetorno = ProcessarMovimentarContaCorrente(oLogContaCorrente);

//                                                if (intRetorno != 0)
//                                                {
//                                                    blnEstornar = true;
//                                                }

//                                                RetornoMovimentacao(intRetorno, "vlr_TarifaOP");
//                                            }

//                                            #endregion

//                                            #region IOF

//                                            // Movimentação de IOF
//                                            if (oLogContaCorrente.vlr_IOF > 0 && blnEstornar == false)
//                                            {
//                                                oLogContaCorrente.Historico = RetornaHistorico(tpo_operacao + "_" + oLogContaCorrente.tpo_Cliente + "_vlr_IOF");
//                                                oLogContaCorrente.Valor = oLogContaCorrente.vlr_IOF;
//                                                oLogContaCorrente.sDocumentoAjustado = clsFerramentas.Right("0000000" + oLogContaCorrente.Documento.ToString(), 7);
//                                                oLogContaCorrente.sHistoricoAjustado = clsFerramentas.Right("00000" + oLogContaCorrente.Historico, 5);
//                                                intRetorno = ProcessarMovimentarContaCorrente(oLogContaCorrente);

//                                                if (intRetorno != 0)
//                                                {
//                                                    blnEstornar = true;
//                                                }

//                                                RetornoMovimentacao(intRetorno, "vlr_IOF");
//                                            }

//                                            #endregion

//                                            //Estorno Verifica se precisa estornar
//                                            if (blnEstornar == true)
//                                            {
//                                                oLogContaCorrente.FlgSucesso = 0;
//                                                ProcessarEstornar(oLogContaCorrente, "RENDIMENTO");

//                                                if (strSistema == "COTACAO")
//                                                {
//                                                    //ESTORNA COTACAO
//                                                    oLogContaCorrente_Aux.FlgSucesso = 0;
//                                                    oLogContaCorrente_Aux.Historico = RetornaHistorico("CD_ESTD_VALORTOTAL");
//                                                    oLogContraPartida.DesParametro = "| Boleto:" + oLogContaCorrente_Aux.Op_N_Boleto.ToString() + " |DÉBITO COTACAO | R$_TOTAL:" + totalBoleto;
//                                                    ProcessarEstornar(oLogContaCorrente_Aux, "COTACAO");
//                                                }
//                                            }
//                                            else
//                                            {
//                                                AprovarContraPartida(oLogContaCorrente, true);

//                                                //Gravando no log do Robo 
//                                                oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                                                oLogContraPartida.IdLogPai = intId_LogPai;
//                                                oLogContraPartida.DesLog = "Transferido com sucesso Cliente!";
//                                                oLogContraPartida.TpoLog = "I";
//                                                oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);

//                                                if (strSistema == "COTACAO")
//                                                {
//                                                    //log da parte cotacao
//                                                    oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                                                    oLogContraPartida.IdLogPai = intId_LogPai;
//                                                    oLogContraPartida.DesLog = "Transferido com sucesso Cotacao!";
//                                                    oLogContraPartida.DesParametro = "| Boleto:" + oLogContaCorrente_Aux.Op_N_Boleto.ToString() + " |DÉBITO COTACAO | R$_TOTAL:" + totalBoleto;
//                                                    oLogContraPartida.TpoLog = "I";
//                                                    oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);
//                                                }
//                                            }
//                                        }

//                                    }

//                                }

//                                #endregion
//                            }

//                        }
//                        catch (Exception err)
//                        {
//                            //gravar log em arquivo texto 
//                            GravarArquivoLog(err.Message.ToString() + " - " + err.StackTrace);

//                            oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                            oLogContraPartida.IdLogPai = intId_LogPai;
//                            oLogContraPartida.DesLog = err.Message.ToString() + " - " + err.StackTrace;
//                            oLogContraPartida.TpoLog = "E";
//                            oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);
//                        }
//                    }
//                }
//                //***************************************************************************************
//                if (dstContraPartida != null)
//                {
//                    if (dstContraPartida.Tables[0].Rows.Count >= 1)
//                    {

//                        int intRetorno = 0;
//                        int intRetornoCotacao = 0;
//                        bool blnEstornar = false;
//                        string tpo_operacao = string.Empty;
//                        string SisOrigem = System.Configuration.ConfigurationManager.AppSettings.Get("SisOrigem");
//                        decimal PrazoBloq = decimal.Parse(System.Configuration.ConfigurationManager.AppSettings.Get("PrazoBloq"));
//                        decimal totalBoleto = 0;
//                        bool blnLiberaDebitoCC = false;


//                        string dta_Movimento = DateTime.Now.ToString("dd/MM/yyyy");

//                        AlimentarHistorico();

//                        try
//                        {
//                            for (int intCiclo = 0; intCiclo <= dstContraPartida.Tables[0].Rows.Count - 1; intCiclo++)
//                            {
//                                DataRow drwContraPartida = dstContraPartida.Tables[0].Rows[intCiclo];

//                                tpo_operacao = drwContraPartida["op_tipo_operacao"].ToString().Trim();
//                                blnEstornar = false;
//                                intRetorno = 0;
//                                intRetornoCotacao = 0;
//                                totalBoleto = 0;
//                                RetornoMovimentacaoLimpar();

//                                #region VENDA

//                                if (tpo_operacao == "V")
//                                {
//                                    if (drwContraPartida["NroConta"].ToString() != "")  // Consistir dados como numero de conta.
//                                    {
//                                        #region DEBITO CONTA CLIENTE

//                                        oLogContaCorrente.flg_RecolheIR = drwContraPartida["Op_rec_ir"].ToString();
//                                        oLogContaCorrente.tpo_Cliente = drwContraPartida["cl_tip_doc"].ToString().Trim();
//                                        oLogContaCorrente.vlr_IR = decimal.Parse(drwContraPartida["vlr_ir"].ToString());
//                                        oLogContaCorrente.vlr_Reais = decimal.Parse(drwContraPartida["op_val_reais"].ToString());
//                                        oLogContaCorrente.vlr_IOF = decimal.Parse(drwContraPartida["vlr_iof"].ToString());
//                                        oLogContaCorrente.vlr_TarifaOP = decimal.Parse(drwContraPartida["op_tarifa_operacao"].ToString());
//                                        oLogContaCorrente.Op_N_Boleto = int.Parse(drwContraPartida["op_n_boleto"].ToString());
//                                        oLogContaCorrente.Id_Operacao = int.Parse(drwContraPartida["Id_Operacao"].ToString());
//                                        oLogContaCorrente.Id_Corretora = int.Parse(drwContraPartida["id_corretora"].ToString());
//                                        oLogContaCorrente.Cl_Passaporte = drwContraPartida["Cl_Passaporte"].ToString().Trim();
//                                        oLogContaCorrente.Cl_Num_Doc = drwContraPartida["Cl_Num_Doc"].ToString().Trim();
//                                        oLogContaCorrente.Op_Tipo_Operacao = tpo_operacao;
//                                        oLogContaCorrente.SisOrigem = SisOrigem;
//                                        oLogContaCorrente.PrazoBloq = PrazoBloq;
//                                        oLogContaCorrente.NroConta = drwContraPartida["NroConta"].ToString().Trim();
//                                        oLogContaCorrente.Documento = int.Parse(drwContraPartida["op_n_boleto"].ToString());
//                                        oLogContaCorrente.DataMovto = dta_Movimento;
//                                        oLogContaCorrente.Coligada = oDBParametro.Coligada;
//                                        oLogContaCorrente.CodUsuario = oDBParametro.IdUser;
//                                        oLogContaCorrente.CodAgenciaDes = oDBParametro.CodAgenciaDes;
//                                        oLogContaCorrente.CodAgenciaCli = oDBParametro.CodAgenciaCli;
//                                        oLogContaCorrente.Agencia = oDBParametro.Agencia;
//                                        oLogContaCorrente.DescRetorno = "Enviado para a Conta Corrente!";
//                                        oLogContaCorrente.FlgSucesso = 1;
//                                        oLogContraPartida.DesParametro = "|Boleto:" + oLogContaCorrente.Op_N_Boleto.ToString() + "|NumeroConta:" + oLogContaCorrente.NroConta.ToString() + "|R$_IR:" + oLogContaCorrente.vlr_IR.ToString() + "|R$_Reais:" + oLogContaCorrente.vlr_Reais.ToString() + "|R$ IOF:" + oLogContaCorrente.vlr_IOF.ToString() + "|R$_TarifaOP:" + oLogContaCorrente.vlr_TarifaOP.ToString();
//                                        oLogContaCorrente.Historico = RetornaHistorico(tpo_operacao + "_" + oLogContaCorrente.tpo_Cliente + "_vlr_Reais");
//                                        oLogContaCorrente.Valor = oLogContaCorrente.vlr_Reais;
//                                        oLogContaCorrente.vlr_total = 0;

//                                        //CALCULA O TOTAL DO BOLETO
//                                        totalBoleto = decimal.Parse(oLogContaCorrente.vlr_IR.ToString()) + decimal.Parse(oLogContaCorrente.vlr_Reais.ToString()) + decimal.Parse(oLogContaCorrente.vlr_IOF.ToString()) + decimal.Parse(oLogContaCorrente.vlr_TarifaOP.ToString());

//                                        //CRIA OBJETO AUXILIAR PARA TRATAR OS DADOS DA COTACAO
//                                        LogContaCorrente oLogContaCorrente_Aux = new LogContaCorrente();

//                                        //POPULA O NOVO OBJETO COM AS INFORMAÇÕES DO OBJETO ORIGINAL
//                                        oLogContaCorrente_Aux.flg_RecolheIR = oLogContaCorrente.flg_RecolheIR;
//                                        oLogContaCorrente_Aux.tpo_Cliente = oLogContaCorrente.tpo_Cliente;
//                                        oLogContaCorrente_Aux.vlr_IR = 0;
//                                        oLogContaCorrente_Aux.vlr_Reais = 0;
//                                        oLogContaCorrente_Aux.vlr_IOF = 0;
//                                        oLogContaCorrente_Aux.vlr_TarifaOP = 0;
//                                        oLogContaCorrente_Aux.Op_N_Boleto = oLogContaCorrente.Op_N_Boleto;
//                                        oLogContaCorrente_Aux.Id_Operacao = oLogContaCorrente.Id_Operacao;
//                                        oLogContaCorrente_Aux.Id_Corretora = oLogContaCorrente.Id_Corretora;
//                                        oLogContaCorrente_Aux.Cl_Passaporte = oLogContaCorrente.Cl_Passaporte;
//                                        oLogContaCorrente_Aux.Op_Tipo_Operacao = oLogContaCorrente.Op_Tipo_Operacao;
//                                        oLogContaCorrente_Aux.SisOrigem = oLogContaCorrente.SisOrigem;
//                                        oLogContaCorrente_Aux.PrazoBloq = oLogContaCorrente.PrazoBloq;
//                                        oLogContaCorrente_Aux.Documento = oLogContaCorrente.Documento;
//                                        oLogContaCorrente_Aux.DataMovto = oLogContaCorrente.DataMovto;
//                                        oLogContaCorrente_Aux.CodUsuario = oLogContaCorrente.CodUsuario;
//                                        oLogContaCorrente_Aux.CodAgenciaDes = oLogContaCorrente.CodAgenciaDes;
//                                        oLogContaCorrente_Aux.Agencia = oLogContaCorrente.Agencia;
//                                        oLogContaCorrente_Aux.DescRetorno = "| Boleto:" + oLogContaCorrente_Aux.Op_N_Boleto.ToString() + " |CRÉDITO COTACAO | R$_TOTAL:" + totalBoleto;
//                                        oLogContaCorrente_Aux.FlgSucesso = oLogContaCorrente.FlgSucesso;
//                                        oLogContaCorrente_Aux.vlr_total = totalBoleto;
//                                        oLogContaCorrente_Aux.sDocumentoAjustado = clsFerramentas.Right("0000000" + oLogContaCorrente_Aux.Documento.ToString(), 7);

//                                        // Consiste dados da conta corrente do cliente.
//                                        string sCodBanco = "";
//                                        string sAgenciaCliente = "";
//                                        string sContaCliente = "";
//                                        oLogContaCorrente.auxDescRetorno = "";

//                                        oLogContaCorrente.sDocumentoAjustado = clsFerramentas.Right("0000000" + oLogContaCorrente.Documento.ToString(), 7);
//                                        oLogContaCorrente.sHistoricoAjustado = clsFerramentas.Right("00000" + oLogContaCorrente.Historico, 5);

//                                        DataSet dsDadosBancariosCliente = GetDadosBancariosCliente(oLogContaCorrente.Cl_Num_Doc, oLogContaCorrente.Op_N_Boleto, "1");

//                                        if (dsDadosBancariosCliente != null)
//                                        {
//                                            if (dsDadosBancariosCliente.Tables[0].Rows.Count >= 1)
//                                            {
//                                                DataRow drwDadosBancariosCliente = dsDadosBancariosCliente.Tables[0].Rows[0];

//                                                sCodBanco = drwDadosBancariosCliente["CodBanco"].ToString().Trim();
//                                                sAgenciaCliente = drwDadosBancariosCliente["Agencia"].ToString().Trim();
//                                                sContaCliente = drwDadosBancariosCliente["NroConta"].ToString().Trim();

//                                                // Atualiza o objecto com os dados de Agencia/Conta corretos.
//                                                oLogContaCorrente.Agencia = sAgenciaCliente;
//                                                oLogContaCorrente.NroConta = sContaCliente;
//                                            }
//                                        }

//                                        // Monta os dados no log.
//                                        oLogContaCorrente.auxDescRetorno = "CodBanco: " + sCodBanco + ", Agencia: " + sAgenciaCliente + ", Conta: " + sContaCliente;

//                                        if (sAgenciaCliente == "" || sContaCliente == "" || sCodBanco == "")
//                                        {
//                                            intRetorno = -97;
//                                            blnEstornar = true;
//                                        }
//                                        else
//                                        {
//                                            if (sCodBanco != "633")
//                                            {
//                                                // Conta não pertence ao Banco Rendimento.
//                                                intRetorno = -96;
//                                                blnEstornar = true;
//                                            }
//                                            else
//                                            {
//                                                if (sAgenciaCliente != "00019" && sAgenciaCliente != "00030" && sAgenciaCliente != "00020")
//                                                {
//                                                    // Agência não pertence ao Banco Rendimento.
//                                                    intRetorno = -95;
//                                                    blnEstornar = true;
//                                                }
//                                            }
//                                        }

//                                        if (!blnEstornar)
//                                        {
//                                            // Valida se o cliente possui saldo suficiente.
//                                            try
//                                            {
//                                                blnLiberaDebitoCC = VerificaSaldoContaCorrente(sAgenciaCliente, sContaCliente, totalBoleto);
//                                            }
//                                            catch (Exception e)
//                                            {
//                                                GravarArquivoLog("Método : VerificaSaldoContaCorrente - Error : " + e.Message.ToString() + " - " + e.StackTrace);
//                                            }

//                                            if (blnLiberaDebitoCC)
//                                            {
//                                                intRetorno = ProcessarMovimentarContaCorrente(oLogContaCorrente);
//                                            }
//                                            else
//                                            {
//                                                intRetorno = -98; // Manda o numero de erro referente a saldo insuficiente.
//                                            }

//                                            if (intRetorno != 0)
//                                            {
//                                                blnEstornar = true;
//                                            }
//                                        }

//                                        RetornoMovimentacao(intRetorno, "vlr_Reais");

//                                        #region TARIFA

//                                        // Movimentação de Tarifa Operação 
//                                        if (oLogContaCorrente.vlr_TarifaOP > 0 && blnEstornar == false)
//                                        {
//                                            oLogContaCorrente.Historico = RetornaHistorico(tpo_operacao + "_" + oLogContaCorrente.tpo_Cliente + "_vlr_TarifaOP");
//                                            oLogContaCorrente.Valor = oLogContaCorrente.vlr_TarifaOP;
//                                            oLogContaCorrente.sDocumentoAjustado = clsFerramentas.Right("0000000" + oLogContaCorrente.Documento.ToString(), 7);
//                                            oLogContaCorrente.sHistoricoAjustado = clsFerramentas.Right("00000" + oLogContaCorrente.Historico, 5);
//                                            intRetorno = ProcessarMovimentarContaCorrente(oLogContaCorrente);

//                                            if (intRetorno != 0)
//                                            {
//                                                blnEstornar = true;
//                                            }

//                                            RetornoMovimentacao(intRetorno, "vlr_TarifaOP");
//                                        }

//                                        #endregion

//                                        #region IOF

//                                        // Movimentação de IOF
//                                        if (oLogContaCorrente.vlr_IOF > 0 && blnEstornar == false)
//                                        {
//                                            oLogContaCorrente.Historico = RetornaHistorico(tpo_operacao + "_" + oLogContaCorrente.tpo_Cliente + "_vlr_IOF");
//                                            oLogContaCorrente.Valor = oLogContaCorrente.vlr_IOF;
//                                            oLogContaCorrente.sDocumentoAjustado = clsFerramentas.Right("0000000" + oLogContaCorrente.Documento.ToString(), 7);
//                                            oLogContaCorrente.sHistoricoAjustado = clsFerramentas.Right("00000" + oLogContaCorrente.Historico, 5);
//                                            intRetorno = ProcessarMovimentarContaCorrente(oLogContaCorrente);

//                                            if (intRetorno != 0)
//                                            {
//                                                blnEstornar = true;
//                                            }

//                                            RetornoMovimentacao(intRetorno, "vlr_IOF");
//                                        }

//                                        #endregion

//                                        #region IR

//                                        // Movimentação de IR
//                                        if (oLogContaCorrente.flg_RecolheIR == "B")
//                                        {
//                                            if (oLogContaCorrente.vlr_IR > 0 && blnEstornar == false)
//                                            {
//                                                oLogContaCorrente.Historico = RetornaHistorico(tpo_operacao + "_" + oLogContaCorrente.tpo_Cliente + "_vlr_IR");
//                                                oLogContaCorrente.Valor = oLogContaCorrente.vlr_IR;
//                                                oLogContaCorrente.sDocumentoAjustado = clsFerramentas.Right("0000000" + oLogContaCorrente.Documento.ToString(), 7);
//                                                oLogContaCorrente.sHistoricoAjustado = clsFerramentas.Right("00000" + oLogContaCorrente.Historico, 5);
//                                                intRetorno = ProcessarMovimentarContaCorrente(oLogContaCorrente);

//                                                if (intRetorno != 0)
//                                                {
//                                                    blnEstornar = true;
//                                                }

//                                                RetornoMovimentacao(intRetorno, "vlr_IR");
//                                            }
//                                        }

//                                        #endregion

//                                        #endregion

//                                        #region CREDITO EM CONTA COTACAO

//                                        if (blnEstornar == false)
//                                        {
//                                            if (strSistema == "COTACAO")
//                                            {
//                                                //ALTERA AS PROPRIEDADES DO OBJETO COLOCANDO AS INFORMAÇÕES DA COTAÇÃO
//                                                oLogContaCorrente_Aux.Cl_Num_Doc = sNumDocCotacao; //CNPJ COTACAO
//                                                oLogContaCorrente_Aux.CodAgenciaCli = sAgenciaCotacao; //NRO AGENCIA COTACAO
//                                                oLogContaCorrente_Aux.NroConta = sContaCotacao; //NRO CONTA COTACAO
//                                                oLogContaCorrente_Aux.Historico = RetornaHistorico("CC_CRED_VALORTOTAL");//IDENTIFICACAO HISTORICO LANCAMENTO COTACAO
//                                                oLogContaCorrente_Aux.sHistoricoAjustado = clsFerramentas.Right("00000" + oLogContaCorrente_Aux.Historico, 5);
//                                                oLogContaCorrente_Aux.Valor = totalBoleto; //VALOR TOTAL A SER LANCADO(IR, IOF, TARIFA, VALOR DA TRANSACAO)

//                                                //PROCESSA MOVIMENTO
//                                                intRetornoCotacao = ProcessarMovimentarContaCorrente(oLogContaCorrente_Aux);

//                                                if (intRetornoCotacao != 0)
//                                                {
//                                                    blnEstornar = true;
//                                                }
//                                            }
//                                        }

//                                        #endregion

//                                        //Estorno Verifica se precisa estornar
//                                        if (blnEstornar == true)
//                                        {
//                                            oLogContaCorrente.FlgSucesso = 0;
//                                            ProcessarEstornar(oLogContaCorrente, "RENDIMENTO");
//                                        }
//                                        else
//                                        {
//                                            AprovarContraPartida(oLogContaCorrente, false);

//                                            oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                                            oLogContraPartida.IdLogPai = intId_LogPai;
//                                            oLogContraPartida.DesLog = "Transferido com sucesso Cliente!";
//                                            oLogContraPartida.TpoLog = "I";
//                                            oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);

//                                            if (strSistema == "COTACAO")
//                                            {
//                                                oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                                                oLogContraPartida.IdLogPai = intId_LogPai;
//                                                oLogContraPartida.DesLog = "Transferido com sucesso Cotacao!";
//                                                oLogContraPartida.DesParametro = "| Boleto:" + oLogContaCorrente_Aux.Op_N_Boleto.ToString() + " |CRÉDITO COTACAO | R$_TOTAL:" + totalBoleto;
//                                                oLogContraPartida.DesParametro = "|Op_N_Boleto:" + oLogContaCorrente_Aux.Op_N_Boleto.ToString() + "|NroConta:" + oLogContaCorrente_Aux.NroConta.ToString() + "|vlr_Total:" + oLogContaCorrente_Aux.vlr_total;
//                                                oLogContraPartida.TpoLog = "I";
//                                                oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);
//                                            }
//                                        }


//                                    }
//                                    else
//                                    {
//                                        oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                                        oLogContraPartida.IdLogPai = intId_LogPai;
//                                        oLogContraPartida.DesLog = "Não há número de conta cadastrada!";
//                                        oLogContraPartida.TpoLog = "A";
//                                        oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);
//                                    }

//                                }

//                                #endregion
//                            }

//                        }
//                        catch (Exception err)
//                        {
//                            GravarArquivoLog(err.Message.ToString() + " - " + err.StackTrace);

//                            oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                            oLogContraPartida.IdLogPai = intId_LogPai;
//                            oLogContraPartida.DesLog = err.Message.ToString() + " - " + err.StackTrace;
//                            oLogContraPartida.TpoLog = "E";
//                            oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);
//                        }

//                    }
//                    else
//                    {
//                        //Grava Log  if (dstContraPartida.Tables[0].Rows.Count >= 1)
//                        oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                        oLogContraPartida.IdLogPai = intId_LogPai;
//                        oLogContraPartida.DesParametro = "";
//                        oLogContraPartida.DesLog = "Não há dados para o Robô processar!";
//                        oLogContraPartida.TpoLog = "I";
//                        oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);
//                    }
//                }
//                else
//                {
//                    //Grava Log  if (dstContraPartida != null)
//                    oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                    oLogContraPartida.IdLogPai = intId_LogPai;
//                    oLogContraPartida.DesParametro = "";
//                    oLogContraPartida.DesLog = "Não há dados para processar!";
//                    oLogContraPartida.TpoLog = "I";
//                    oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);
//                }

//                //Grava Log 
//                oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                oLogContraPartida.IdLogPai = intId_LogPai;
//                oLogContraPartida.DesLog = "Fim :";
//                oLogContraPartida.DesParametro = "";
//                oLogContraPartida.TpoLog = "I";
//                oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);
//            }
//            catch (Exception e)
//            {
//                //grava log em arquivo texto 
//                GravarArquivoLog(e.Message.ToString() + " - " + e.StackTrace);

//                //Grava Log 
//                oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                oLogContraPartida.IdLogPai = intId_LogPai;
//                oLogContraPartida.DesLog = e.Message.ToString() + " - " + e.StackTrace;
//                oLogContraPartida.TpoLog = "E";
//                oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);
//            }
//        }

//        private DataSet GetDadosBancariosCliente(string sCPFCNPJ, int? iNBoleto, string sGrupoBancario)
//        {
//            SqlParameter[] strParametros = new SqlParameter[3];

//            strParametros[0] = new SqlParameter("@CPF_CNPJ", SqlDbType.NVarChar, 15);
//            strParametros[0].Value = sCPFCNPJ;

//            strParametros[1] = new SqlParameter("@NBoleto", SqlDbType.Int);
//            strParametros[1].Value = iNBoleto;

//            strParametros[2] = new SqlParameter("@GrpBancario", SqlDbType.NVarChar, 1);
//            strParametros[2].Value = sGrupoBancario;

//            DataSet dsDadosBancarios = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "GetDadosBancariosClienteBRSA", strParametros);

//            return dsDadosBancarios;
//        }

//        public int ProcessarMovimentarContaCorrente(LogContaCorrente oRetorno)
//        {
//            int intRetorno = 0;
//            try
//            {
//                oRetorno.IncluirLogContaCorrente(oRetorno);
//                intRetorno = MovimentarContaCorrente(oRetorno.Coligada, oRetorno.Agencia, oRetorno.CodAgenciaCli, oRetorno.CodAgenciaDes, oRetorno.NroConta, oRetorno.DataMovto.ToString(), oRetorno.sDocumentoAjustado, oRetorno.sHistoricoAjustado, decimal.Parse(oRetorno.Valor.ToString()), oRetorno.SisOrigem, oDBParametro.IdUser.ToString(), decimal.Parse(oRetorno.PrazoBloq.ToString()));

//            }
//            catch (Exception e)
//            {
//                intRetorno = -99;
//                GravarArquivoLog("Método : ProcessarMovimentarContaCorrente - Error : " + e.Message.ToString() + " - " + e.StackTrace);
//            }

//            return intRetorno;
//        }

//        public bool VerificaSaldoContaCorrente(string sAgencia, string sNroConta, decimal dValor)
//        {
//            decimal? fsaldo = 0;

//            fsaldo = ConsultarSaldoContaCorrente(sAgencia, sNroConta);

//            if (fsaldo >= dValor)
//            {
//                return true;
//            }
//            else
//            {
//                return false;
//            }
//        }

//        public int ProcessarEstornar(LogContaCorrente oRetorno, string strEmpresa)
//        {
//            DataSet dstAuxiliar;
//            int intRetorno = 0;
//            string strHistoricoErro = string.Empty;
//            Email oEmail = new Email();

//            oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//            oLogContraPartida.IdLogPai = intId_LogPai;

//            //CASO A PRIMEIRA VALIDAÇÃO DE SALDO APRESENTE PROBLEMAS NÃO EFETUA O ESTORNO.
//            if (dvDados.Table != null)
//            {

//                for (int i = 0; (i <= dvDados.Table.Rows.Count - 1); i++)
//                {
//                    intRetorno = 0;

//                    //##############ALTERAÇÃO##################
//                    //ALTERADO POR: FLÁVIO LOPES
//                    //ALTERAÇÃO: O CAMPO HISTORICO E HISTORICOAJUSTADO SERÁ PREENCHIDO COM O CÓDICO DE ESTORNO CORRETO.
//                    //AS ALTERAÇÕES VÃO AFETAR OS ESTORNOS PARA LANÇAMENTOS NA CONTA CLIENTE (CÓDIGO JÁ EXISTENTE), OS ESTORNOS PARA A PARTE COTAÇÃO JÁ ESTÃO AJUSTADOS.
//                    //PARA A OPÇÃO VLR_REAIS SERÁ PRECISO VERIFICAR QUAL O TIPO DE OPERAÇÃO (C - COMPRA, V - VENDA)
//                    //OS HISTORICOS DE ESTORNO DE TARIFA, IOF E IR SÃO OS MESMOS PARA AMBOS OS TIPOS DE LANÇAMENTOS (COMPRA, VENDA, PF E PJ)

//                    switch (dtDados.Rows[i]["descricao"].ToString())
//                    {
//                        case "vlr_Reais":
//                            oRetorno.Valor = oRetorno.vlr_Reais;
//                            if (oRetorno.Op_Tipo_Operacao == "C")
//                            {
//                                oRetorno.Historico = RetornaHistorico("EST_C_VLR_REAIS");
//                            }
//                            else
//                            {
//                                oRetorno.Historico = RetornaHistorico("EST_V_VLR_REAIS");
//                            }
//                            oRetorno.sHistoricoAjustado = clsFerramentas.Right("00000" + oRetorno.Historico, 5);
//                            break;

//                        case "vlr_TarifaOP":
//                            oRetorno.Valor = oRetorno.vlr_TarifaOP;
//                            oRetorno.Historico = RetornaHistorico("EST_VLR_TARIFAOP");
//                            oRetorno.sHistoricoAjustado = clsFerramentas.Right("00000" + oRetorno.Historico, 5);
//                            break;

//                        case "vlr_IOF":
//                            oRetorno.Valor = oRetorno.vlr_IOF;
//                            oRetorno.Historico = RetornaHistorico("EST_VLR_IOF");
//                            oRetorno.sHistoricoAjustado = clsFerramentas.Right("00000" + oRetorno.Historico, 5);
//                            break;

//                        case "vlr_IR":
//                            oRetorno.Valor = oRetorno.vlr_IR;
//                            oRetorno.Historico = RetornaHistorico("EST_VLR_IR");
//                            oRetorno.sHistoricoAjustado = clsFerramentas.Right("00000" + oRetorno.Historico, 5);
//                            break;
//                        case "vlr_total":
//                            oRetorno.Valor = oRetorno.vlr_total;
//                            break;
//                    }

//                    // Grava log que deu erro ao mandar para a tesouraria
//                    //if (int.Parse(enuRetorno.Key.ToString()) < 0)
//                    if (int.Parse(dtDados.Rows[i]["codigo"].ToString()) < 0)
//                    {
//                        dstAuxiliar = SelecionarErros_ContaCorrente(int.Parse(dtDados.Rows[i]["codigo"].ToString()) * (-1));
//                        oRetorno.DescRetorno = "Erro não identificado !" + dtDados.Rows[i]["codigo"].ToString();

//                        int iErro = int.Parse(dtDados.Rows[i]["codigo"].ToString());

//                        switch (iErro)
//                        {
//                            case -98:
//                                oRetorno.DescRetorno = "Erro " + dtDados.Rows[i]["codigo"].ToString() + ". Saldo insuficiente na conta corrente. " + oRetorno.auxDescRetorno;
//                                break;

//                            case -97:
//                                oRetorno.DescRetorno = "Erro " + dtDados.Rows[i]["codigo"].ToString() + ". Dados inconsistentes. " + oRetorno.auxDescRetorno;
//                                break;

//                            case -96:
//                                oRetorno.DescRetorno = "Erro " + dtDados.Rows[i]["codigo"].ToString() + ". Conta não pertence ao Banco Rendimento. " + oRetorno.auxDescRetorno;
//                                break;

//                            case -95:
//                                oRetorno.DescRetorno = "Erro " + dtDados.Rows[i]["codigo"].ToString() + ". Agência não pertence ao Banco Rendimento. " + oRetorno.auxDescRetorno;
//                                break;
//                        }

//                        if (dstAuxiliar.Tables[0].Rows.Count >= 1)
//                        {
//                            DataRow drwAuxiliar = dstAuxiliar.Tables[0].Rows[0];
//                            oRetorno.DescRetorno = drwAuxiliar["Desc_erro"].ToString();
//                            strHistoricoErro = oRetorno.DescRetorno;
//                        }
//                    }

//                    // Estornando 
//                    if (int.Parse(dtDados.Rows[i]["codigo"].ToString()) == 0)
//                    {
//                        oRetorno.DescRetorno = "Movimentação estornada devido a erros em outros lançamentos!";

//                        // Estornando os que não deram erros
//                        if (dtDados.Rows[i]["descricao"].ToString() != "vlr_IR")
//                        {
//                            /*########################################################################################################################
//                             AJUSTE DE LANÇAMENTOS DE ESTORNO
//                             PARA LANÇAMENTOS NA COTAÇÃO DEVERÁ FAZER APENAS O ESTORNO DO VLR_TOTAL, PARA O CLIENTE A FORMA DE ESTORNO SE MANTEM
//                            ########################################################################################################################*/
//                            if (oRetorno.Valor > 0)
//                            {
//                                if (dtDados.Rows[i]["descricao"].ToString() != "vlr_total")
//                                {
//                                    intRetorno = Estornar(oDBParametro.Coligada, oDBParametro.Agencia, oDBParametro.CodAgenciaCli, oDBParametro.CodAgenciaDes, oRetorno.NroConta, oRetorno.DataMovto.ToString(), oRetorno.sDocumentoAjustado, oRetorno.sHistoricoAjustado, decimal.Parse(oRetorno.Valor.ToString()), oRetorno.SisOrigem, oDBParametro.IdUser.ToString(), decimal.Parse(oRetorno.PrazoBloq.ToString()));
//                                }
//                                else
//                                {
//                                    string historicoAjustado = clsFerramentas.Right("00000" + oRetorno.Historico, 5);
//                                    string sContaCotacao = System.Configuration.ConfigurationManager.AppSettings.Get("NumeroContaCotacao").ToString();
//                                    string sNumDocCotacao = System.Configuration.ConfigurationManager.AppSettings.Get("CnpjCotacao").ToString();
//                                    string sAgenciaCotacao = System.Configuration.ConfigurationManager.AppSettings.Get("NumeroAgenciaCotacao").ToString();
//                                    string sColigadaCotacao = "001";
//                                    string sCodAgenciaDes = "00019";
//                                    string sCodAgenciaCli = "00019";

//                                    intRetorno = Estornar(sColigadaCotacao, sAgenciaCotacao, sCodAgenciaCli, sCodAgenciaDes, sContaCotacao, oRetorno.DataMovto.ToString(), oRetorno.sDocumentoAjustado, historicoAjustado, decimal.Parse(oRetorno.Valor.ToString()), oRetorno.SisOrigem, oDBParametro.IdUser.ToString(), decimal.Parse(oRetorno.PrazoBloq.ToString()));
//                                }
//                            }
//                            else
//                            {
//                                intRetorno = 0;
//                            }
//                        }
//                        else
//                        {
//                            var infoEmail = new InfoEmail
//                            {
//                                IdSistema = "2",
//                                IdEmpresa = "1",
//                                Codigo = "39",
//                                ListaEmailPara = oDBParametro.Email,
//                                ListaEmailCc = "",
//                                Assunto = "Robô de ContraPartida!",
//                                ListaArquivos = null,
//                                ListaParametrosCorpo = new List<EmailService.Parametro>()
//                            };

//                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "DesParametro", Valor = oLogContraPartida.DesParametro });

//                            var serializer = new JavaScriptSerializer();
//                            string dados = serializer.Serialize(infoEmail);

//                            var rest = new RestClient(wsEmailService);
//                            string resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));
//                        }

//                        if (intRetorno != 0)
//                        {
//                            //Grava log em arquivo texto 
//                            GravarArquivoLog("Erro ao Estornar");

//                            //Gravando no log do Robo 
//                            oLogContraPartida.DesLog = "Erro ao estornar!";
//                            oLogContraPartida.TpoLog = "E";
//                            oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);

//                            var infoEmail = new InfoEmail
//                            {
//                                IdSistema = "2",
//                                IdEmpresa = "1",
//                                Codigo = "40",
//                                ListaEmailPara = oDBParametro.Email,
//                                ListaEmailCc = "",
//                                Assunto = "Robô de ContraPartida - Erro ao Estornar!",
//                                ListaArquivos = null,
//                                ListaParametrosCorpo = new List<EmailService.Parametro>()
//                            };

//                            var serializer = new JavaScriptSerializer();
//                            string dados = serializer.Serialize(infoEmail);

//                            var rest = new RestClient(wsEmailService);
//                            string resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));
//                        }
//                    }

//                    // Encaminhar e-mail
//                    dstAuxiliar = oRetorno.ConsultarLogContaCorrente(oRetorno);

//                    if (dstAuxiliar.Tables[0].Rows.Count <= 0)
//                    {
//                        if (int.Parse(dtDados.Rows[i]["codigo"].ToString()) == -98)
//                        {
//                            // Erro ao debitar da Conta Corrente. Sem saldo.
//                            strHistoricoErro = "Saldo insuficiente na conta corrente.";
//                        }

//                        var infoEmail = new InfoEmail
//                        {
//                            IdSistema = "2",
//                            IdEmpresa = "1",
//                            Codigo = "41",
//                            ListaEmailPara = oDBParametro.Email,
//                            ListaEmailCc = "",
//                            Assunto = "Robô de ContraPartida - Débito em conta corrente não realizado.",
//                            ListaArquivos = null,
//                            ListaParametrosCorpo = new List<EmailService.Parametro>()
//                        };

//                        infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "DesParametro", Valor = oLogContraPartida.DesParametro });
//                        infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "strHistoricoErro", Valor = strHistoricoErro });

//                        var serializer = new JavaScriptSerializer();
//                        string dados = serializer.Serialize(infoEmail);

//                        var rest = new RestClient(wsEmailService);
//                        string resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));

//                        // Gravando Log da Conta Corrente
//                        oRetorno.IncluirLogContaCorrente(oRetorno);
//                    }

//                    if (((strEmpresa == "COTACAO") && (dtDados.Rows[i]["descricao"].ToString() == "vlr_total")) || ((strEmpresa == "RENDIMENTO") && (dtDados.Rows[i]["descricao"].ToString() != "vlr_total")))
//                    {
//                        //Grava log em arquivo texto 
//                        GravarArquivoLog(oRetorno.DescRetorno);

//                        //Gravando no log do Robo 
//                        oLogContraPartida.DesLog = oRetorno.DescRetorno;
//                        oLogContraPartida.TpoLog = "E";
//                        oLogContraPartida.IncluirLogContraPartida(oLogContraPartida);
//                    }

//                }
//            }

//            return intRetorno;
//        }

//        public void RetornoMovimentacaoLimpar()
//        {
//            dtDados.Columns.Clear();
//            dtDados.Clear();
//            dtDados.Columns.Add("codigo", typeof(int));
//            dtDados.Columns.Add("descricao", typeof(string));
//        }

//        public DataTable RetornoMovimentacao(int intRetorno, string descricao)
//        {
//            dtDados.Rows.Add(intRetorno, descricao);

//            dvDados.Table = dtDados;
//            dvDados.Sort = "codigo asc";

//            return dtDados = dvDados.ToTable();
//        }

//        public void AlimentarHistorico()
//        {
//            Historico.Clear();
//            Historico.Add("V_CPF_VLR_IR", System.Configuration.ConfigurationManager.AppSettings.Get("VEN_DEB_FIS_IR"));
//            Historico.Add("V_CNPJ_VLR_IR", System.Configuration.ConfigurationManager.AppSettings.Get("VEN_DEB_JUR_IR"));

//            Historico.Add("V_CPF_VLR_REAIS", System.Configuration.ConfigurationManager.AppSettings.Get("VEN_DEB_FIS_Reais"));
//            Historico.Add("V_CNPJ_VLR_REAIS", System.Configuration.ConfigurationManager.AppSettings.Get("VEN_DEB_JUR_Reais"));

//            Historico.Add("V_CPF_VLR_IOF", System.Configuration.ConfigurationManager.AppSettings.Get("VEN_DEB_FIS_IOF"));
//            Historico.Add("V_CNPJ_VLR_IOF", System.Configuration.ConfigurationManager.AppSettings.Get("VEN_DEB_JUR_IOF"));

//            Historico.Add("V_CPF_VLR_TARIFAOP", System.Configuration.ConfigurationManager.AppSettings.Get("VEN_DEB_FIS_TarifaOeracao"));
//            Historico.Add("V_CNPJ_VLR_TARIFAOP", System.Configuration.ConfigurationManager.AppSettings.Get("VEN_DEB_JUR_TarifaOeracao"));

//            Historico.Add("C_CPF_VLR_REAIS", System.Configuration.ConfigurationManager.AppSettings.Get("COM_CRE_FIS_Reais"));
//            Historico.Add("C_CNPJ_VLR_REAIS", System.Configuration.ConfigurationManager.AppSettings.Get("COM_CRE_JUR_Reais"));

//            Historico.Add("C_CPF_VLR_IOF", System.Configuration.ConfigurationManager.AppSettings.Get("COM_DEB_FIS_IOF"));
//            Historico.Add("C_CNPJ_VLR_IOF", System.Configuration.ConfigurationManager.AppSettings.Get("COM_DEB_JUR_IOF"));

//            Historico.Add("C_CPF_VLR_TARIFAOP", System.Configuration.ConfigurationManager.AppSettings.Get("COM_DEB_FIS_TarifaOeracao"));
//            Historico.Add("C_CNPJ_VLR_TARIFAOP", System.Configuration.ConfigurationManager.AppSettings.Get("COM_DEB_JUR_TarifaOeracao"));

//            Historico.Add("EST_C_VLR_REAIS", System.Configuration.ConfigurationManager.AppSettings.Get("EST_COM_CRE_Reais"));
//            Historico.Add("EST_V_VLR_REAIS", System.Configuration.ConfigurationManager.AppSettings.Get("EST_VEN_DEB_Reais"));
//            Historico.Add("EST_VLR_TARIFAOP", System.Configuration.ConfigurationManager.AppSettings.Get("EST_COM_DEB_TarifaOperacao"));
//            Historico.Add("EST_VLR_IOF", System.Configuration.ConfigurationManager.AppSettings.Get("EST_COM_DEB_IOF"));
//            Historico.Add("EST_VLR_IR", System.Configuration.ConfigurationManager.AppSettings.Get("EST_VEN_DEB_IR"));

//            if (strSistema == "COTACAO")
//            {
//                Historico.Add("CD_DEB_VALORTOTAL", System.Configuration.ConfigurationManager.AppSettings.Get("CT_COM_DEB_ValorTotal"));
//                Historico.Add("CD_ESTD_VALORTOTAL", System.Configuration.ConfigurationManager.AppSettings.Get("CT_EST_DEB_ValorTotal"));

//                Historico.Add("CC_CRED_VALORTOTAL", System.Configuration.ConfigurationManager.AppSettings.Get("CT_COM_CRE_ValorTotal"));
//                Historico.Add("CC_ESTC_VALORTOTAL", System.Configuration.ConfigurationManager.AppSettings.Get("CT_EST_CRE_ValorTotal"));
//            }

//        }

//        public int Estornar(string Coligada, string Agencia, string CodAgenciaCli, string CodAgenciaDes, string NroConta, string DataMovto, string Documento, string Historico, decimal Valor, string SisOrigem, string CodUsuario, decimal PrazoBloq)
//        {
//            int retorno = 0;
//            return retorno = MovimentarContaCorrente(Coligada, Agencia, CodAgenciaCli, CodAgenciaDes, NroConta, DataMovto, Documento, Historico, Valor, SisOrigem, CodUsuario, PrazoBloq);
//        }

//        public void GravarArquivoLog(string strMensagem)
//        {
//            string strCaminhoArquivoLog = System.Configuration.ConfigurationManager.AppSettings.Get("CaminhoArquivoLog");
//            string strNomeArquivoLog = System.Configuration.ConfigurationManager.AppSettings.Get("NomeArquivoLog");

//            StreamWriter oStreamWriter = new StreamWriter(Path.Combine(strCaminhoArquivoLog, strNomeArquivoLog), true);
//            oStreamWriter.WriteLine(DateTime.Now.Date.ToLongDateString() + " " + DateTime.Now.TimeOfDay.ToString());
//            oStreamWriter.WriteLine(strMensagem);
//            oStreamWriter.WriteLine("----------------------------------");
//            oStreamWriter.Close();
//        }

//        public bool AutorizarProcessamento()
//        {
//            bool blnRetorno = true;
//            string strMensagem = string.Empty;

//            if (oDBParametro == null)
//            {
//                // parametro não encontrado.
//                throw new Exception("Não econtrado Parametros para a execução do Robô");
//            }

//            // Verifica se o Robo está ativo
//            if (oDBParametro.FlagAtivo == "N")
//            {
//                strMensagem = strMensagem + "Robô não está ativo para processar";
//                blnRetorno = false;
//            }

//            // Verifica se eh dia util e processa 
//            if (oDBParametro.FlagSomenteDiaUtil == "S" && BancoRendimento.Uteis.Uteis.DiaUtil() == false)
//            {
//                strMensagem = strMensagem + "Robô não autorizado processar em dia não útil.";
//                blnRetorno = false;
//            }

//            int HoraI = 0;
//            int MinutoI = 0;
//            HoraI = Convert.ToInt32(oDBParametro.HrInicio.Trim().Substring(0, 2));
//            MinutoI = Convert.ToInt32(oDBParametro.HrInicio.Trim().Substring(3, 2));

//            int HoraF = 0;
//            int MinutoF = 0;
//            HoraF = Convert.ToInt32(oDBParametro.HrFim.Trim().Substring(0, 2));
//            MinutoF = Convert.ToInt32(oDBParametro.HrFim.Trim().Substring(3, 2));

//            DateTime DataInicio = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, HoraI, MinutoI, DateTime.Now.Second, DateTime.Now.Millisecond);
//            DateTime DataTermino = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, HoraF, MinutoF, DateTime.Now.Second, DateTime.Now.Millisecond);

//            // se o horairio esta dentor 
//            if (DateTime.Now < DataInicio)
//            {
//                strMensagem = strMensagem + "Robô não autorizado processar horário MENOR que o permitido.";
//                blnRetorno = false;
//            }

//            if (DateTime.Now > DataTermino)
//            {
//                strMensagem = strMensagem + "Robô não autorizado processar horário MAIOR que o permitido.";
//                blnRetorno = false;
//            }

//            if (blnRetorno == false)
//            {
//                oLogContraPartida.DesLog = strMensagem;
//                oLogContraPartida.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
//                oLogContraPartida.TpoLog = "A";
//            }

//            return blnRetorno;
//        }

//        public DataSet ObterCreditaContraPartida()
//        {
//            db_ProcessarContraPartidaCC ObterCreditaContraPartida = new db_ProcessarContraPartidaCC();
//            DataSet dstRetorno = ObterCreditaContraPartida.ObterCreditaContraPartida();
//            return dstRetorno;
//        }

//        public DataSet ConsultarContraPartida()
//        {
//            db_ProcessarContraPartidaCC odb_ProcessarContraPartidaCC = new db_ProcessarContraPartidaCC();
//            DataSet dstRetorno = odb_ProcessarContraPartidaCC.ConsultarContraPartida(oDBParametro);

//            return dstRetorno;
//        }

//        public int AprovarContraPartida(LogContaCorrente oRetorno, Boolean OpCompra)
//        {
//            db_ProcessarContraPartidaCC odb_ProcessarContraPartidaCC = new db_ProcessarContraPartidaCC();
//            return odb_ProcessarContraPartidaCC.AprovarContraPartida(oRetorno, OpCompra);
//        }

//        public string RetornaHistorico(string strKey)
//        {
//            string strcod_Retorno = string.Empty;

//            if (Historico.ContainsKey(strKey.ToUpper()) == true)
//            {
//                IDictionaryEnumerator enuHistorico = Historico.GetEnumerator();
//                while (enuHistorico.MoveNext())
//                {
//                    if (enuHistorico.Key.ToString().ToUpper() == strKey.ToUpper())
//                    {
//                        strcod_Retorno = enuHistorico.Value.ToString();
//                        return strcod_Retorno;
//                    }
//                }

//            }
//            return strcod_Retorno;
//        }

//        public int MovimentarContaCorrente(string Coligada, string Agencia, string CodAgenciaCli, string CodAgenciaDes, string NroConta, string DataMovto, string Documento, string Historico, decimal Valor, string SisOrigem, string CodUsuario, decimal PrazoBloq)
//        {
//            int retorno = 0;
//            try
//            {
//                try
//                {
//                    EB_PadraoServicesService ws_autbank = new EB_PadraoServicesService();

//                    int tentativas = 0;
//                    while (tentativas < 2)
//                    {
//                        TOIntegracaoRetornoEntradaMovto entrada = new TOIntegracaoRetornoEntradaMovto();

//                        //Futuramente o Objeto que trafega a Data movimento como String deverá ser alterado para DATA.
//                        DateTime DtMov = DateTime.Now;
//                        string mes = Convert.ToString(DtMov.Month);
//                        string dia = Convert.ToString(DtMov.Day);
//                        DataMovto = DtMov.Year + "/" + mes.PadLeft(2, '0') + "/" + dia.PadLeft(2, '0');

//                        CodAgenciaCli = Agencia;
//                        entrada = ws_autbank.entradaMovto("001", Agencia, "001", CodAgenciaCli, NroConta, DataMovto, Documento, Historico, Valor, "000", "N", "EM", "VJ", "N", "N", CodUsuario, "N", "", Convert.ToInt32(PrazoBloq.ToString()), "", "");

//                        if (entrada.codErro != 0)
//                        {
//                            retorno = 1;
//                            GravarArquivoLog("retorno: " + retorno.ToString() + " DocErro: " + entrada.codErro + " MsgErro: " + entrada.descricaoErro + "  Coligada: " + "001" + ", Agencia: " + Agencia + ", CodAgenciaCli: " + CodAgenciaCli + ", CodAgenciaDes: " + CodAgenciaDes + ", NroConta: " + NroConta + ", DataMovto: " + DataMovto + ", Documento: " + Documento + ", Historico: " + Historico + ", Valor: " + Valor.ToString() + ", SisOrigem: " + SisOrigem + ", CodUsuario: " + CodUsuario + ", PrazoBloq: " + PrazoBloq.ToString());
//                        }
//                        if (entrada.codErro != 0 && tentativas <= 2)
//                        {
//                            tentativas++;
//                        }
//                        if (entrada.codErro == 0)
//                        {
//                            tentativas = 2;
//                        }
//                    }
//                }
//                catch (Exception ex)
//                {
//                    retorno = 1;
//                    GravarArquivoLog("retorno: " + retorno.ToString() + " MsgErro: " + ex.Message + ". Coligada: " + Coligada + ", Agencia: " + Agencia + ", CodAgenciaCli: " + CodAgenciaCli + ", CodAgenciaDes: " + CodAgenciaDes + ", NroConta: " + NroConta + ", DataMovto: " + DataMovto + ", Documento: " + Documento + ", Historico: " + Historico + ", Valor: " + Valor.ToString() + ", SisOrigem: " + SisOrigem + ", CodUsuario: " + CodUsuario + ", PrazoBloq: " + PrazoBloq.ToString());
//                }
//            }
//            catch (Exception e)
//            {
//                retorno = 99;
//                GravarArquivoLog("Método : MovimentarContaCorrente - Error : " + e.Message.ToString() + " - " + e.StackTrace);
//            }

//            return (retorno * (-1));
//        }

//        public decimal? ConsultarSaldoContaCorrente(string Agencia, string NroConta)
//        {
//            decimal? retorno = 0;
//            try
//            {
//                try
//                {
//                    EB_PadraoServicesService ws_autbank = new EB_PadraoServicesService();

//                    int tentativas = 0;
//                    while (tentativas < 2)
//                    {
//                        TOIntegracaoRetornoSaldoConta saldo = new TOIntegracaoRetornoSaldoConta();

//                        saldo = ws_autbank.consultaSaldoConta("001", Agencia, NroConta);

//                        retorno = saldo.saldoDisp;

//                        if (saldo.codErro != 0)
//                        {
//                            retorno = 0;
//                            GravarArquivoLog("retorno: " + retorno.ToString() + " DocErro: " + saldo.codErro + " MsgErro: Algum dado está incorreto na consulta de saldo" + "  Coligada: " + "001" + ", Agencia: " + Agencia + ", NroConta: " + NroConta);
//                        }
//                        if (saldo.codErro != 0 && tentativas <= 2)
//                        {
//                            tentativas++;
//                        }
//                        if (saldo.codErro == 0)
//                        {
//                            tentativas = 2;
//                        }
//                    }
//                }
//                catch (Exception ex)
//                {
//                    retorno = 0;
//                    GravarArquivoLog("retorno: " + retorno.ToString() + " MsgErro: " + ex.Message + " Agencia: " + Agencia + ", NroConta: " + NroConta);
//                }
//            }
//            catch (Exception e)
//            {
//                retorno = 0;
//                GravarArquivoLog("Método : ConsultarSaldoContaCorrente - Error : " + e.Message.ToString() + " - " + e.StackTrace);
//            }

//            return retorno;
//        }

//        public DataSet SelecionarErros_ContaCorrente(int intcod_Erros)
//        {
//            db_ProcessarContraPartidaCC odb_ProcessarContraPartidaCC = new db_ProcessarContraPartidaCC();
//            return odb_ProcessarContraPartidaCC.SelecionarErros_ContaCorrente(intcod_Erros);
//        }

//        public class db_ProcessarContraPartidaCC
//        {
//            private string strConexao = clsFerramentas.Decodificar(System.Configuration.ConfigurationManager.AppSettings.Get("ConnectionString"));

//            public int AprovarContraPartida(LogContaCorrente oRetorno, Boolean opCompra)
//            {
//                SqlParameter[] strParametros = new SqlParameter[9];

//                //Condicional inserida apenas para operação de Compra. 11/11/11 - Eduardo
//                if (opCompra == true)
//                {
//                    strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 50);
//                    strParametros[0].Value = "APROVAR_OPERACAO_DE_COMPRA";
//                }
//                else
//                {
//                    strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 50);
//                    strParametros[0].Value = "APROVAR_CONTRAPARTIDA_CC";
//                }

//                strParametros[1] = new SqlParameter("@Id_Operacao", SqlDbType.Int);
//                strParametros[1].Value = oRetorno.Id_Operacao;

//                strParametros[2] = new SqlParameter("@AUX_DATAMNME", SqlDbType.VarChar, 4);
//                strParametros[2].Value = "";

//                strParametros[3] = new SqlParameter("@US_CON", SqlDbType.Int);
//                strParametros[3].Value = oRetorno.CodUsuario;

//                strParametros[4] = new SqlParameter("@Id_Corretora", SqlDbType.Int);
//                strParametros[4].Value = oRetorno.Id_Corretora;

//                strParametros[5] = new SqlParameter("@Cl_Num_Doc", SqlDbType.VarChar, 18);
//                strParametros[5].Value = oRetorno.Cl_Num_Doc;

//                strParametros[6] = new SqlParameter("@Op_Tipo_Operacao", SqlDbType.Char, 1);
//                strParametros[6].Value = oRetorno.Op_Tipo_Operacao;

//                strParametros[7] = new SqlParameter("@Op_N_Boleto", SqlDbType.Int);
//                strParametros[7].Value = oRetorno.Op_N_Boleto;

//                strParametros[8] = new SqlParameter("@Cl_Passaporte", SqlDbType.VarChar, 18);
//                strParametros[8].Value = oRetorno.Cl_Passaporte;

//                SqlDataReader drRetorno = SqlHelper.ExecuteReader(this.strConexao, CommandType.StoredProcedure, "SPBVAR_APROVACAO_CONTRAPARTIDA", strParametros);

//                Int32 intRetorno = 0;

//                //intRetorno = int.Parse(drRetorno.GetValue(0).ToString());

//                return intRetorno;
//            }

//            public DataSet ObterCreditaContraPartida()
//            {
//                DataSet dstRetorno = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SP_ProcContraPartida");

//                return dstRetorno;
//            }

//            public DataSet ConsultarContraPartida(Parametro oRetorno)
//            {
//                SqlParameter[] strParametros = new SqlParameter[3];

//                strParametros[0] = new SqlParameter("@op_tipo_liq", SqlDbType.VarChar, 20);
//                strParametros[0].Value = oRetorno.op_tipo_liq.Trim();

//                strParametros[1] = new SqlParameter("@op_grp_bancarios", SqlDbType.Int);
//                strParametros[1].Value = oRetorno.GrpBancarios;

//                strParametros[2] = new SqlParameter("@APROVACAO_CONTRAPARTIDA", SqlDbType.VarChar, 1);
//                strParametros[2].Value = "N";

//                DataSet dstRetorno = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPRVAR_ContraPartida_Consultar", strParametros);

//                return dstRetorno;
//            }

//            public DataSet SelecionarErros_ContaCorrente(int intcod_Erros)
//            {
//                SqlParameter[] strParametros = new SqlParameter[1];

//                strParametros[0] = new SqlParameter("@Cod_erro", SqlDbType.Int);
//                strParametros[0].Value = intcod_Erros;

//                DataSet dstRetorno = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPRVAR_ERROS_CONTA_CORRENTE_Selecionar", strParametros);

//                return dstRetorno;
//            }

//            public int EncaminharEmail(Email oRetorno)
//            {
//                SqlParameter[] strParametros = new SqlParameter[5];

//                strParametros[0] = new SqlParameter("@IDSistema", SqlDbType.Int);
//                strParametros[0].Value = oRetorno.IDSistema;

//                strParametros[1] = new SqlParameter("@Destino", SqlDbType.VarChar, 500);
//                strParametros[1].Value = oRetorno.Destino;

//                strParametros[2] = new SqlParameter("@CopiaOculta", SqlDbType.VarChar, 500);
//                strParametros[2].Value = oRetorno.CopiaOculta;

//                strParametros[3] = new SqlParameter("@Assunto", SqlDbType.VarChar, 255);
//                strParametros[3].Value = oRetorno.Assunto;

//                strParametros[4] = new SqlParameter("@Corpo", SqlDbType.VarChar, 4000);
//                strParametros[4].Value = oRetorno.Corpo;

//                return SqlHelper.ExecuteNonQuery(this.strConexao, CommandType.StoredProcedure, "SP_SendMail", strParametros);
//            }
//        }
//    }
//}