﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using BSICript;

namespace R_CCMESwift
{
    public class clsFerramentas
    {

        public bool DefiniColunas(string colunas, DataTable dados, string nomeDataTable)
        {
            try
            {
                DataTable dt = new DataTable(nomeDataTable);
                string[] listaColunas = colunas.Split(',');


                for (int i = 0; i <= listaColunas.Length - 1; i++)
                {
                    dt.Columns.Add(listaColunas[i].Trim(), typeof(string));
                }

                dados = dt;

                return true;
            }
            catch
            {
                return false;
            }


        }


        public bool InsereValores(string valores, DataTable dados)
        {
            try
            {
                string[] listaValores = valores.Split(',');

                dados.Rows.Add(listaValores);

                return true;
            }
            catch
            {
                return false;
            }


        }

        public static string Right(string param, int length)
        {
            string result = param.Substring(param.Length - length, length);
            return result;
        }

        public static string Decodificar(string string_cripto)
        {
            string string_decoded = null;

            try
            {

                //CriptografiaClass objCript = new CriptografiaClass();
                //object string_new = string_cripto;
                //string_decoded = objCript.Decode(ref string_new);
                string_decoded = "user id=CelulaSustentacao;password=CelulaSustentacao;initial catalog=IK_VAREJO;data source=REND-SRVDSQL-05;Connect Timeout=240;Pooling=false";
    }
            catch (Exception ex)
            {
                throw ex;
            }

            return string_decoded;

        }

    }
}
