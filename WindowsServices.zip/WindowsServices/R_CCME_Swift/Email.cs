﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace R_CCMESwift
{
    public class Email
    {
        Int32? _IDSistema = null;
        string _Destino = null;
        string _CopiaOculta = null;
        string _Assunto = null;
        string _Corpo = null;

        public Int32? IDSistema
        {
            get { return _IDSistema; }
            set { _IDSistema = value; }
        }

        public string Destino
        {
            get { return _Destino; }
            set { _Destino = value; }
        }

        public string CopiaOculta
        {
            get { return _CopiaOculta; }
            set { _CopiaOculta = value; }
        }

        public string Assunto
        {
            get { return _Assunto; }
            set { _Assunto = value; }
        }

        public string Corpo
        {
            get { return _Corpo; }
            set { _Corpo = value; }
        }



    }
}
