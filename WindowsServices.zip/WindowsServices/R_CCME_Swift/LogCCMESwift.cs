﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace R_CCMESwift
{
    public class LogCCMESwift
    {



        private Int32?      _IdLog          = null;
        private Int32?      _IdLogPai	    = null; 
        private DateTime?   _DtaLog	        = null;
        private string      _DesMetodo	    = null;
        private string      _DesParametro	= null; 
        private string      _DesLog	        = null;
        private string      _NumLog	        = null;
        private string      _TpoLog         = null;
        

        public Int32? IdLog
        {
            get { return _IdLog; }
            set { _IdLog = value; }
        }

        public Int32? IdLogPai
        {
            get { return _IdLogPai; }
            set { _IdLogPai = value; }
        }

        public DateTime? DtaLog
        {
            get { return _DtaLog; }
            set { _DtaLog = value; }
        }

        public string DesMetodo
        {
            get { return _DesMetodo; }
            set { _DesMetodo = value; }
        }

        public string DesParametro
        {
            get { return _DesParametro;}
            set { _DesParametro = value; }
        }

        public string DesLog
        {
            get { return _DesLog; }
            set { _DesLog = value; }
        }

        public string NumLog
        {
            get { return _NumLog; }
            set { _NumLog = value; }
        }

        public string TpoLog
        {
            get { return _TpoLog; }
            set { _TpoLog = value; }
        }

             

        public LogCCMESwift() 
        {
		}

        public LogCCMESwift(SqlDataReader reader)
		{
			CarregarDados(reader);
		}


		private void CarregarDados(SqlDataReader reader)
		{
            SetarCampos.RetonarValor(reader, this);
		}

        /// <summary>
        /// Grava na tabela de log
        /// </summary>
        /// <param name="oRetorno"></param>
        /// <returns></returns>
        public int IncluirLogCCMESwift(LogCCMESwift oRetorno)
        {
            db_LogCCMESwift odb_LogCCMESwift = new db_LogCCMESwift();

            return odb_LogCCMESwift.IncluirLogCCMESwift(oRetorno);
        }

        public class db_LogCCMESwift
        {
            private string strConexao = clsFerramentas.Decodificar(System.Configuration.ConfigurationManager.AppSettings.Get("ConnectionString"));

            public int IncluirLogCCMESwift(LogCCMESwift oRetorno)
            {

                SqlParameter[] strParametros = new SqlParameter[7];

                strParametros[0] = new SqlParameter("@Id_LogPai", SqlDbType.Int);
                strParametros[0].Value = oRetorno.IdLogPai;

                strParametros[1] = new SqlParameter("@Dta_Log", SqlDbType.DateTime);
                strParametros[1].Value = oRetorno.DtaLog;

                strParametros[2] = new SqlParameter("@Des_Metodo", SqlDbType.VarChar, 50);
                strParametros[2].Value = oRetorno.DesMetodo;

                strParametros[3] = new SqlParameter("@Des_Parametro", SqlDbType.VarChar, 500);
                strParametros[3].Value = oRetorno.DesParametro;

                strParametros[4] = new SqlParameter("@Des_Log", SqlDbType.VarChar, 500);
                strParametros[4].Value = oRetorno.DesLog;

                strParametros[5] = new SqlParameter("@Num_Log", SqlDbType.VarChar, 50);
                strParametros[5].Value = oRetorno.NumLog;

                strParametros[6] = new SqlParameter("@Tpo_log", SqlDbType.VarChar, 1);
                strParametros[6].Value = oRetorno.TpoLog;

                SqlDataReader drRetorno = SqlHelper.ExecuteReader(this.strConexao, CommandType.StoredProcedure, "SPRVAL_LogRoboCCMESwift_Inserir", strParametros);

                Int32 intRetorno = 0;

                if (drRetorno.Read())
                {
                    intRetorno = int.Parse(drRetorno.GetValue(0).ToString());
                }

                return intRetorno;

            }

        }

    }
}
