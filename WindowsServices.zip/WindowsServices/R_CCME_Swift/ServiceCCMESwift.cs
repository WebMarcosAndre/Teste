﻿using System;
using System.Data;
using System.ServiceProcess;
using System.Timers; // Temporizador

namespace R_CCMESwift
{
    public partial class ServiceCCMESwift : ServiceBase
    {
        private Timer _tmTemporizador;
        private int _timerStandBy = 10;
        private ProcessarArquivoSwift oProcessarArquivoSwift;

        public ServiceCCMESwift()
        {
            InitializeComponent();

            if (System.Configuration.ConfigurationManager.AppSettings["StandBy"] != null)
            {
                _timerStandBy = int.Parse(System.Configuration.ConfigurationManager.AppSettings.Get("StandBy"));
            }

            TimeSpan oTimeSpan = new TimeSpan(0, _timerStandBy, 0);

            this._tmTemporizador = new Timer();
            this._tmTemporizador.Elapsed += new ElapsedEventHandler(IniciarServico);
            this._tmTemporizador.Interval = oTimeSpan.TotalMilliseconds;
            this._tmTemporizador.Enabled = false;

            GC.KeepAlive(this._tmTemporizador);
        }

        internal void IniciarServico(object source, ElapsedEventArgs e)
        {
            //Para o serviço para execução da rotina
            this._tmTemporizador.Stop();

            try
            {
                IniciaProcessarArquivoSwift();

                PaginaUso oPaginaUso = new PaginaUso();
                DataSet DtPagina = oPaginaUso.SelecionarPaginaUso("ROBO_CCME_SWIFT");

                if (DtPagina.Tables[0].Rows[0][1].ToString() == "N")
                {
                    oPaginaUso.AtualizarPaginaUso(oProcessarArquivoSwift.oDBParametro.id_Pag, "S");

                    oProcessarArquivoSwift.IniciarCCMESwift();

                    oPaginaUso.AtualizarPaginaUso(oProcessarArquivoSwift.oDBParametro.id_Pag, "N");
                }

                AtualizaTimerConfiguravel();
            }
            catch (Exception err)
            {
                GravarLogBD(err);
            }

            this._tmTemporizador.Start();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                IniciaProcessarArquivoSwift();

                AtualizaTimerConfiguravel();

                //Grava em arquivo Texto
                oProcessarArquivoSwift.GravarArquivoLog("Serviço inicializado !");

                // Grava na tabela de log
                oProcessarArquivoSwift.oLogCCMESwift.DesLog = "Serviço inicializado ! " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
                oProcessarArquivoSwift.oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oProcessarArquivoSwift.oLogCCMESwift.TpoLog = "I";

                oProcessarArquivoSwift.oLogCCMESwift.IncluirLogCCMESwift(oProcessarArquivoSwift.oLogCCMESwift);
            }
            catch (Exception err)
            {
                GravarLogBD(err);
            }

            _tmTemporizador.Start();
        }

        protected override void OnStop()
        {
            try
            {
                PaginaUso oPaginaUso = new PaginaUso();
                oPaginaUso.AtualizarPaginaUso(oProcessarArquivoSwift.oDBParametro.id_Pag, "N");

                //Grava em arquivo Texto
                oProcessarArquivoSwift.GravarArquivoLog("Serviço parado !");

                // Grava na tabela de log
                oProcessarArquivoSwift.oLogCCMESwift.DesLog = "Serviço parado! " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + ". O Robô CCME Swift foi desligado, verifique a necessidade de liga-lo novamente!";
                oProcessarArquivoSwift.oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oProcessarArquivoSwift.oLogCCMESwift.TpoLog = "I";

                oProcessarArquivoSwift.oLogCCMESwift.IncluirLogCCMESwift(oProcessarArquivoSwift.oLogCCMESwift);
            }
            catch (Exception err)
            {
                GravarLogBD(err);
            }

            _tmTemporizador.Stop();
        }

        /// <summary>
        /// Busca sempre o último valor configuravel na base de dados, 
        /// permitindo que a próxima execução seja ajustada com o novo valor, caso o mesmo tenha sido alterado.
        /// </summary>
        private void AtualizaTimerConfiguravel()
        {
            oProcessarArquivoSwift.oParametro = oProcessarArquivoSwift.oParametro.ConsultarParametro();

            if (oProcessarArquivoSwift.oParametro != null && oProcessarArquivoSwift.oParametro.Intervalo.HasValue)
            {
                int intervaloDB = oProcessarArquivoSwift.oParametro.Intervalo.Value;

                TimeSpan oTimeSpan = new TimeSpan(0, intervaloDB, 0);
                this._tmTemporizador.Interval = oTimeSpan.TotalMilliseconds;

                oProcessarArquivoSwift.oLogCCMESwift.DesParametro = "Intervalo minutos;" + intervaloDB;
            }
        }

        /// <summary>
        /// Grava o log diretamente na base de dados, caso não seja possível o metodo para gravar em disco será chamado.
        /// </summary>
        /// <param name="err"></param>
        private void GravarLogBD(Exception err)
        {
            try
            {
                // Grava na tabela de log
                oProcessarArquivoSwift.oLogCCMESwift.DesLog = "Erro : " + err.Message.ToString() + " - " + err.StackTrace;
                oProcessarArquivoSwift.oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oProcessarArquivoSwift.oLogCCMESwift.TpoLog = "E";

                oProcessarArquivoSwift.oLogCCMESwift.IncluirLogCCMESwift(oProcessarArquivoSwift.oLogCCMESwift);
            }
            catch (Exception)
            {
                GravarLogEmDisco(err);
            }
        }

        /// <summary>
        /// Grava o log diretamente no disco, caso não seja possível, nenhuma ação é tomada posteriormente.
        /// </summary>
        /// <param name="err"></param>
        private void GravarLogEmDisco(Exception err)
        {
            try
            {
                //Gravar em arquivo de texto
                oProcessarArquivoSwift.GravarArquivoLog("Erro : " + err.Message.ToString() + " - " + err.StackTrace);
            }
            catch (Exception)
            {
                //O robô continua rodando caso não consiga gravar nenhum log
            }
        }

        private void IniciaProcessarArquivoSwift()
        {
            if (oProcessarArquivoSwift == null)
            {
                oProcessarArquivoSwift = new ProcessarArquivoSwift();
            }
        }
    }
}
