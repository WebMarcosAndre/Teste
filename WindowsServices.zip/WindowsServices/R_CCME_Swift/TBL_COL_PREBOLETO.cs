﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace R_CCMESwift.ModelosCambio
{
    public class TBL_COL_PREBOLETO : BaseModelo
    {
        public int id_operacao;
        public int id_cliente;
        public string pre_tipo_operacao;
        public string pre_tipo_entrega;
        public string pre_tipo_liq;
        public string pre_tipo_moeda;
        public decimal pre_tx_operacao;
        public decimal pre_tarifa_operacao;
        public decimal pre_val_moeda;
        public decimal pre_val_reais;
        public decimal pre_valorReceber;
        public DateTime pre_data_sistema;
        public DateTime pre_data_boleto;
        public DateTime pre_data_inclusao;
        public int pre_n_boleto = 0;
        public string pre_natureza;
        public string pre_status;
        public string pre_vend_comp;
        public string pre_pag_receb;
        public int pre_boleto_status;
        public DateTime pre_data_mn_bol;
        public DateTime pre_data_me_bol;
        public decimal pre_vlr_IOF;
        public DateTime OP_DATA_TAXA_OPERACAO;
        
        public int pre_faseAtual;
        public string pre_usuario_fase1;
        public string pre_usuario_fase2;
        public string pre_usuario_fase3;
        public string pre_usuario_fase4;
        public string pre_usuario_fase5;
        public DateTime pre_data_fase1;
        public DateTime pre_data_fase2;
        public DateTime pre_data_fase3;
        public DateTime pre_data_fase4;
        public DateTime pre_data_fase5;

        public string  op_rec_IR;        //Chamado 94422 - Inclusão de DARF - IR
        public decimal taxa_IR;
        public string op_tipo_aliquota_iR;
        public decimal Vlr_IR;
        public decimal tx_ptax_ir;
        public DateTime data_ptax_ir;
        public string retorno_darf_IR;
        public string msg_email_ir;
        public decimal valor_moeda_ir;
        public decimal valor_reais_ir;
        public string cod_darf_ir;
        public string op_inf_obs_ir;
        public int op_paises;
        public string pre_data_prevEmbarque;
        public int pre_cod_mod_imp;
        public int pre_disp_LI;
        public string DOCUMENTACAO_REJEITADA;
        public string BOLETO_ASSINADO_REJEITADO;
        public bool PRE_FASE_CONCLUIDO;

        public TBL_COL_PREBOLETO()
        {
        }
    }
}
