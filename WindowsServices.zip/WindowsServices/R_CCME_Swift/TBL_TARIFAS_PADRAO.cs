﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace R_CCMESwift.ModelosCambio
{
    public class TBL_TARIFAS_PADRAO : BaseModelo
    {


        public int id_tp;
        public int id_user;
        public string tp_indice;
        public string tp_tipo;
        public string tp_operacao;
        public decimal tp_val_minimo;
        public decimal tp_val_maximo;
        public string tp_moeda;
        public decimal tp_val_tarifa;
        public string tp_obs;
        public DateTime tp_dt_inclusao;
        public DateTime tp_dt_alteracao;


        public TBL_TARIFAS_PADRAO()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_tp";
        }
    }
}
