﻿
using R_CCMESwift;
using R_CCMESwift.ModelosCambio;
using Dapper;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using R_CCMESwift.EmailService;
using System.Collections.Generic;
using System.Web.Script.Serialization;

namespace R_CCME_Swift.EmailService
{
    public class EnviarEmail_Test
    {
        private string strConexao = "user id=CelulaSustentacao;password=CelulaSustentacao;initial catalog=IK_VAREJO;data source=REND-SRVDSQL-05;Connect Timeout=240;Pooling=false";
        //clsFerramentas.Decodificar(System.Configuration.ConfigurationManager.AppSettings.Get("ConnectionStrin"));

        private string wsEmailService = System.Configuration.ConfigurationManager.AppSettings.Get("URL_WSEmail");

        public TBL_PRE_BOLETO GetPreBoleto(int NrBoleto)
        {
            TBL_PRE_BOLETO obj = null;
            try
            {
                using (var cn = ((IDbConnection)new SqlConnection(this.strConexao)))
                {
                    obj = cn.Query<TBL_PRE_BOLETO>(
                            string.Format(@"
                                        SELECT n.* FROM TBL_PRE_BOLETO n (NOLOCK)
                                        WHERE n.op_n_boleto = @NrBoleto
                                "), new
                            {
                                NrBoleto = NrBoleto
                            }
                    ).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {

            }
            return obj;
        }

        public void IniciarTesteEnvio()
        {
            using (SqlConnection conexao = new SqlConnection(this.strConexao))
            {
                try
                {
                    conexao.Open();
                    var transacao = conexao.BeginTransaction();

                    ProcessarArquivoSwift obj = new ProcessarArquivoSwift();
                    //obj.EnviarEmailGoogleManual(transacao, GetPreBoleto(2550205), "10", "Google", "www.google.com.br", true, "CPF", "marcos.costa.ext@cotacao.com.br");
                    /*
                     2550205
                     2550444
                     2550201
                     2632352      teste homolog
                     */
                    obj.PreBoletosGoogle(2550444);
                    //EnviarEmailGoogleManual(GetPreBoleto(), "10", "Google", "wwww.google.com.br");
                }
                catch (Exception ex) {

                }
            }
        }



        private void EnviarEmailGoogleManual(TBL_PRE_BOLETO preboleto, string idSistemaEmail, string nomeCliente, string link)
        {
            string resposta = null;
            string email_para = null;
            string dados = "";


            var cultureInfo = new System.Globalization.CultureInfo("pt-br");
            /*
                        DataTable dtMAIL = Get_Email_Para(preboleto.id_cliente);
                        if (dtMAIL.Rows.Count > 0)
                            email_para = dtMAIL.Rows[0]["EMAIL_PARA"].ToString();*/
            email_para = "marcos.costa.ext@cotacao.com.br";

            var infoEmail = new InfoEmail
            {
                IdSistema = idSistemaEmail,
                IdEmpresa = preboleto.EMPRESA.ToString(),
                Codigo = "67",
                ListaEmailPara = email_para,
                ListaEmailCc = "",
                Assunto = "Aviso de Ordem de Pagamento Recebida",
                ListaArquivos = null,
                ListaParametrosCorpo = new List<R_CCMESwift.EmailService.Parametro>()
            };
            CarregarParametrosGoogle(infoEmail, preboleto, nomeCliente);

            var serializer = new JavaScriptSerializer();
            dados = serializer.Serialize(infoEmail);

            var rest = new RestClient(wsEmailService);
            resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));

            string erro = string.Empty;
            if (!resposta.Equals("Não foi possivel enviar o email"))//enviado com sucesso
            {
                erro = "Erro 1";
            }
            else
            {
                erro = "Erro 2";
            }

        }

        private void CarregarParametrosGoogle(InfoEmail info, TBL_PRE_BOLETO obj, string NomeCliente)
        {
            var serializer = new JavaScriptSerializer();

            decimal vlrReceber = (obj.op_val_reais.HasValue ? obj.op_val_reais.Value : 0) - obj.Vlr_IOF - obj.op_tarifa_operacao;

            info.ListaParametrosCorpo.Add(new R_CCMESwift.EmailService.Parametro()
            { Nome = "NomeCliente", Valor = NomeCliente });
            info.ListaParametrosCorpo.Add(new R_CCMESwift.EmailService.Parametro()
            { Nome = "Ordenante", Valor = obj.op_inf_fav });
            info.ListaParametrosCorpo.Add(new R_CCMESwift.EmailService.Parametro()
            { Nome = "NumeroContrato", Valor = obj.op_n_boleto.ToString() });
            info.ListaParametrosCorpo.Add(new R_CCMESwift.EmailService.Parametro()
            { Nome = "ValorRecebido", Valor = obj.op_val_reais.Value.ToString("N", new System.Globalization.CultureInfo("pt-br").NumberFormat) });


            info.ListaParametrosCorpo.Add(new R_CCMESwift.EmailService.Parametro()
            { Nome = "TaxaCambio", Valor = obj.op_tx_operacao.HasValue ? obj.op_tx_operacao.Value.ToString("N", new System.Globalization.CultureInfo("pt-br").NumberFormat) : "0,00" });
            info.ListaParametrosCorpo.Add(new R_CCMESwift.EmailService.Parametro()
            { Nome = "Tarifa", Valor = obj.op_tarifa_operacao.ToString("N", new System.Globalization.CultureInfo("pt-br").NumberFormat) });


            info.ListaParametrosCorpo.Add(new R_CCMESwift.EmailService.Parametro()
            { Nome = "IOF", Valor = obj.Vlr_IOF.ToString("N", new System.Globalization.CultureInfo("pt-br").NumberFormat) });
            info.ListaParametrosCorpo.Add(new R_CCMESwift.EmailService.Parametro()
            { Nome = "VET", Valor = Convert.ToString(Math.Round(vlrReceber / obj.op_val_moeda, 4, MidpointRounding.AwayFromZero)) });
            info.ListaParametrosCorpo.Add(new R_CCMESwift.EmailService.Parametro()
            { Nome = "Total", Valor = (vlrReceber - (obj.Vlr_IR.HasValue ? obj.Vlr_IR.Value : 0)).ToString("N") });


            List<R_CCMESwift.EmailService.Parametro> param = new List<R_CCMESwift.EmailService.Parametro>();
            #region Status Google
            string notificacao = string.Empty;
            param.Add(new R_CCMESwift.EmailService.Parametro() { Nome = "Nome", Valor = "Remessa recebida do exterior" });
            param.Add(new R_CCMESwift.EmailService.Parametro() { Nome = "Notificacao", Valor = string.Empty });
            param.Add(new R_CCMESwift.EmailService.Parametro() { Nome = "Data", Valor = "15/ Jun" });


            notificacao = "Para fechamento da sua operação acesse www.cambiorendimento.com.br =>Menu => Remessas Recebidas.";
            param.Add(new R_CCMESwift.EmailService.Parametro() { Nome = "Nome", Valor = "Fechamento do câmbio realizado" });
            param.Add(new R_CCMESwift.EmailService.Parametro() { Nome = "Notificacao", Valor = "Teste 2" });
            param.Add(new R_CCMESwift.EmailService.Parametro() { Nome = "Data", Valor = "15/ Jul" });

            param.Add(new R_CCMESwift.EmailService.Parametro() { Nome = "Nome", Valor = "Envio do contrato assinado" });
            param.Add(new R_CCMESwift.EmailService.Parametro() { Nome = "Notificacao", Valor = "Teste 3 asdfasdf asdf asdfasdfasd  asdfsd asfa asdf afasd asd  fd afasdfasdasdasd asd asd fasdfasdas asdfasd f" });
            param.Add(new R_CCMESwift.EmailService.Parametro() { Nome = "Data" });


            param.Add(new R_CCMESwift.EmailService.Parametro() { Nome = "Nome", Valor = "Pagamento dos valores em Reais" });
            param.Add(new R_CCMESwift.EmailService.Parametro() { Nome = "Notificacao", Valor = "*O prazo para pagamento está sujeito a possível solicitação e análise documental." });
            param.Add(new R_CCMESwift.EmailService.Parametro() { Nome = "Data" });
            #endregion

            info.ListaParametrosCorpo.Add(new R_CCMESwift.EmailService.Parametro()
            { Nome = "ListaStatusGoogle", Valor = serializer.Serialize(param) });

        }

    }

}
