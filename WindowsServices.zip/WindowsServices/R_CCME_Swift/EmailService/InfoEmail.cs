﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Script.Serialization;

namespace R_CCMESwift.EmailService
{
    public class InfoEmail
    {
        public List<Parametro> ListaParametrosCorpo;
        public string IdSistema { get; set; }
        public string IdEmpresa { get; set; }
        public string Codigo { get; set; }
        public string EmailDe { get; set; }
        public string NomeDe { get; set; }
        public string ListaEmailPara { get; set; }
        public string ListaEmailCc { get; set; }
        public string Assunto { get; set; }
        public string ListaArquivos { get; set; }
        public string EnderecoWebService { get; set; }
    }
}