﻿namespace R_CCMESwift.EmailService
{
    public class Descricao
    {
        public string Documento { get; set; }
        public string Agencia { get; set; }
        public string NroConta { get; set; }
        public string Valor { get; set; }
        public string OP_Data_MN { get; set; }
        public string DataMovto { get; set; }
        public string Desc_Retorno { get; set; }
    }
}