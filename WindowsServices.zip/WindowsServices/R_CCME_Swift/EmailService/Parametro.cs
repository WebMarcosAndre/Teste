namespace R_CCMESwift.EmailService
{
    public class Parametro
    {
        public string Nome { get; set; }
        public string Valor { get; set; }
    }
}