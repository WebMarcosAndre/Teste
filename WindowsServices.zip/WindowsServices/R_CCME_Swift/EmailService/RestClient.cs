﻿using System.IO;
using System.Net;
using System.Text;

namespace R_CCMESwift.EmailService
{
    public class RestClient
    {
        private readonly string _endereco;

        public RestClient(string endereco)
        {
            _endereco = endereco;
        }

        public string SendPost(string parametros)
        {
            if (parametros == null)
            {
                parametros = "";
            }

            var request = WebRequest.Create(_endereco);
            request.Method = "POST";

            byte[] byteArray = Encoding.UTF8.GetBytes(parametros);
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = byteArray.Length;

            var dataStream = request.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();

            var response = request.GetResponse();

            dataStream = response.GetResponseStream();
            var reader = new StreamReader(dataStream);
            string responseFromServer = reader.ReadToEnd();

            reader.Close();
            dataStream.Close();
            response.Close();

            return responseFromServer;
        }

        public string SendGet(string parametros)
        {
            HttpWebRequest request;

            if (string.IsNullOrEmpty(parametros.Trim()))
            {
                request = (HttpWebRequest)WebRequest.Create(_endereco);
            }
            else
            {
                request = (HttpWebRequest)WebRequest.Create(string.Format("{0}?{1}", _endereco, parametros));
            }

            request.Method = "GET";
            request.ContentType = "text/json; encoding='utf-8'";

            var response = request.GetResponse();

            var stream = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding("utf-8"));
            string responseFromServer = stream.ReadToEnd();

            stream.Close();
            response.Close();

            return responseFromServer;
        }
    }
}
