﻿
using R_CCMESwift.ModelosCambio;

namespace R_CCME_Swift.EmailService
{
    public class EmailGoogle
    {

        public TBL_PRE_BOLETO pre { get; }

        public string IDSistemaEmail { get; }
        public string nomeCliente { get; }
        public string link { get; }
        public string cliTipo { get; }

        public bool googleAutomatico { get; }
        public EmailGoogle(TBL_PRE_BOLETO _pre, string _IDSistemaEmail, string _nomeCliente, string _link, bool _googleAutomatico, string _cliTipo)
        {
            pre = _pre; IDSistemaEmail = _IDSistemaEmail; nomeCliente = _nomeCliente; link = _link;
            googleAutomatico = _googleAutomatico; cliTipo = _cliTipo;
        }
    }
}
