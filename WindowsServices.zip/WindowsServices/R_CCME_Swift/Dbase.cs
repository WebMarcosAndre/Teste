﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
using System.Reflection;

namespace R_CCMESwift
{
	public static class DBase
    {
        private static string mStrConnectionString;

        public static string connectionString
        {
            get
            {
                return mStrConnectionString;
            }
            set
            {
                mStrConnectionString = value;
            }
        }

        // -----------------------

        ////Criptografa string no padrão. Dll BSICript.
        //public static string Codificar(string string_origem)
        //{

        //    object msg_erro = null;
        //    object string_new = string_origem;

        //    try
        //    {
        //        CriptografiaClass objCript = new CriptografiaClass();

        //        objCript.Criptografar(ref string_new, string_origem, ref msg_erro);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return Convert.ToString(string_new);
        //}

        //// -----------------------

        //public static string Decodificar(string string_cripto)
        //{
        //    string string_decoded = null;

        //    try
        //    {
        //        CriptografiaClass objCript = new CriptografiaClass();
        //        object string_new = string_cripto;
        //        string_decoded = objCript.Decode(ref string_new);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return string_decoded;

        //}

        // -----------------------

        public static ArrayList AddParametro(string vParametro, object oValor)
        {
            vParametro = AddArroba(vParametro);
            ArrayList parameters = new ArrayList();
            parameters.Add(new SqlParameter(vParametro, oValor));
            return parameters;
        }

        // -----------------------

        private static string AddArroba(string vParametro)
        {
            if (vParametro.Substring(0, 1) != "@")
            { vParametro.Insert(0, "@"); }
            return vParametro;
        }

        public static int ExecuteNonQuery(string commandText, SqlCommand oSqlCommandParametro, SqlTransaction transaction)
        {
            return ExecuteNonQuery(connectionString, transaction, commandText, oSqlCommandParametro);    
        }

        // -----------------------

        public static int ExecuteNonQuery(string strConnectionString, SqlTransaction transaction, string commandText, SqlCommand oSqlCommandParametro)
        {
            SqlConnection oSqlConnection    = new SqlConnection();
            oSqlConnection.ConnectionString = strConnectionString;
            //SqlCommand oSqlCommand          = new SqlCommand();

            //oSqlCommand.Connection          = oSqlConnection;
            //oSqlCommand.CommandType         = CommandType.StoredProcedure;
            //oSqlCommand.CommandText         = commandText;
            //oSqlCommand.Parameters.  (oSqlCommandParametro);

            oSqlCommandParametro.Connection = oSqlConnection;
            oSqlCommandParametro.CommandType = CommandType.StoredProcedure;
            oSqlCommandParametro.CommandText = commandText;

            oSqlConnection.Open();
            return oSqlCommandParametro.ExecuteNonQuery();

        }

        // -----------------------

        public static  SqlDataReader ExecuteReader(string commandText, SqlCommand oSqlCommand, SqlTransaction transaction)
        {
            return ExecuteReader(connectionString, transaction, commandText, oSqlCommand);
        }

        // -----------------------

        private static SqlDataReader ExecuteReader(string strConnectionString, SqlTransaction transaction, string commandText, SqlCommand oSqlCommandParametro)
        {
            SqlConnection oSqlConnection    = new SqlConnection();
            oSqlConnection.ConnectionString = strConnectionString;

        
            //SqlCommand oSqlCommand          = new SqlCommand();

            if (oSqlCommandParametro != null)
            {
                oSqlCommandParametro.Connection = oSqlConnection;
                oSqlCommandParametro.CommandType = CommandType.StoredProcedure;
                oSqlCommandParametro.CommandText = commandText;
                //oSqlCommand.Parameters.Add(oSqlCommandParametro);
            }

            oSqlConnection.Open();
            SqlDataReader drRetorno = oSqlCommandParametro.ExecuteReader();
            //oSqlConnection.Close();
            return drRetorno;
        }

        // -----------------------

        public static DataSet ExecuteDataSet (string commandText, SqlCommand oSqlCommand, SqlTransaction transaction)
        {
            return ExecuteDataSet(connectionString, transaction, commandText, oSqlCommand);
        }

        // -----------------------

        private static DataSet ExecuteDataSet(string strConnectionString, SqlTransaction transaction, string commandText, SqlCommand oSqlCommandParametro)
        {
            SqlConnection oSqlConnection = new SqlConnection();
            oSqlConnection.ConnectionString = strConnectionString;
            oSqlCommandParametro.Connection = oSqlConnection;
            oSqlCommandParametro.CommandType = CommandType.StoredProcedure;
            oSqlCommandParametro.CommandText = commandText;

            SqlDataAdapter dpRetorno = new SqlDataAdapter(oSqlCommandParametro);
            DataSet dsRetorno = new DataSet();
            
            dpRetorno.Fill(dsRetorno);
            oSqlConnection.Open();
            
            return dsRetorno;
        }



    }

}



