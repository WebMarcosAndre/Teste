﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace R_CCMESwift.Modelos.ModelosCambio
{
    public class TBL_MOEDAS : BaseModelo
    {
        public int id_moedas;
        public string moe_simbolo;
        public int moe_codigo;
        public string moe_nome;
        public string moe_cambio_online;
        public string MOE_PERMITE_ME;
        public string moe_descccme;
        public string moe_tipo;
        public decimal moe_desvio;
        public int MOE_CASASDEC_COL;
        public string MOE_ORDEMLISTA_COL;
        public string moe_swift;
        public string moe_nomeresumido;

        public TBL_MOEDAS()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_moedas";
        }
    }
}
