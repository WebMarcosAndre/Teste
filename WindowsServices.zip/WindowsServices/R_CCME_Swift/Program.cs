﻿using R_CCME_Swift.EmailService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;

namespace R_CCMESwift
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {

            //#if RELEASE

            //ServiceBase[] ServicesToRun;
            //ServicesToRun = new ServiceBase[] { new ServiceCCMESwift() };
            //ServiceBase.Run(ServicesToRun);

            //#else

            //ServiceCCMESwift ser = new ServiceCCMESwift();
            //ser.Stop();
            //ser.IniciarServico(null, null);

            EnviarEmail_Test obj = new EnviarEmail_Test();
            obj.IniciarTesteEnvio();

            //#endif

        }
    }
}
