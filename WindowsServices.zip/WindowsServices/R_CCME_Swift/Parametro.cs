﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace R_CCMESwift
{
    public class Parametro
    {
        private Int32?     _IdRoboCCMESwift      = null;
        private string     _NomRobo              = null;
        private Int32?     _Idrotina             = null;
        private Int32?     _Intervalo             = null;
        private Int32?     _IdSistema            = null;
        private string     _FlagLogDetalhado     = null;
        private string     _FlagAtivo	          = null;
        private string     _FlagSomenteDiaUtil	  = null;
        private string     _SWIFT_BRSA          = null;
        private string     _SWIFT_COTACAO       = null;
        private string     _SWIFT_LEITURA       = null;
        private string     _SWIFT_LIDOS          = null;
        private string      _SWIFT_RESTRITIVA = null;
        private string      _SWIFT_RESTRITIVA_LIDOS = null;
        //private string     _OpTipoLiq           = null;
        //private Int32?     _GrpBancarios         = null;
        private Int32?     _IdUser               = null;
        //private string     _Coligada              = null;
        //private string     _Agencia               = null;
        //private string     _CodAgenciaCli         = null;
        //private string     _CodAgenciaDes         = null;
        private string     _HrInicio	          = null;
        private string     _HrFim	              = null;
        private Int32?     _UserAlt              = null;
        private DateTime?  _DtAlt                = null;
        private string     _Email                 = null;
        private int?       _Id_Pag                = null;
        private string     _FlagPrimeiroEnvio     = null;
        private string     _HoraPrimeiroEnvio     = null;
        private string     _FlagSegundoEnvio      = null;
        private string     _HoraSegundoEnvio      = null;
        private string     _ExtArquivoSaida       = null;
        private string     _ExtArquivoEntrada     = null;
        private Int32?     _His_codigo_c          = null;
        //private Int32?     _His_codigo_d          = null;
        private string     _email_Notificacao     = null;
        private string _FLAG_HABILITA_TELAS_CCME = null;

        private string strConexao = clsFerramentas.Decodificar(System.Configuration.ConfigurationManager.AppSettings.Get("ConnectionString"));

        public Int32? IdRoboCCMESwift
        {
            get { return _IdRoboCCMESwift; }
            set { _IdRoboCCMESwift = value; }
        }

        public string NomRobo
        {
            get { return _NomRobo; }
            set { _NomRobo = value; }
        }

        public Int32? Idrotina
        {
            get { return _Idrotina; }
            set { _Idrotina = value; }
        }

        public Int32? Intervalo
        {
            get { return _Intervalo; }
            set { _Intervalo = value; }
        }

        public Int32? IdSistema
        {
            get { return _IdSistema; }
            set { _IdSistema = value; }
        }

        public string FlagLogDetalhado
        {
            get { return _FlagLogDetalhado; }
            set { _FlagLogDetalhado = value; }
        }

        public string FlagAtivo
        {
            get { return _FlagAtivo; }
            set { _FlagAtivo = value; }
        }

        public string FlagSomenteDiaUtil
        {
            get { return _FlagSomenteDiaUtil; }
            set { _FlagSomenteDiaUtil = value; }
        }
        public string SWIFT_BRSA
        {
            get { return _SWIFT_BRSA; }
            set { _SWIFT_BRSA = value; }
        }
        public string SWIFT_COTACAO
        {
            get { return _SWIFT_COTACAO; }
            set { _SWIFT_COTACAO = value; }
        }
        public string SWIFT_LEITURA
        {
            get { return _SWIFT_LEITURA; }
            set { _SWIFT_LEITURA = value; }
        }
        public string SWIFT_LIDOS
        {
            get { return _SWIFT_LIDOS; }
            set { _SWIFT_LIDOS = value; }
        }
        public string SWIFT_RESTRITIVA
        {
            get { return _SWIFT_RESTRITIVA; }
            set { _SWIFT_RESTRITIVA = value; }
        }

        public string SWIFT_RESTRITIVA_LIDOS
        {
            get { return _SWIFT_RESTRITIVA_LIDOS; }
            set { _SWIFT_RESTRITIVA_LIDOS = value; }
        }

        //public string op_tipo_liq
        //{
        //    get { return _OpTipoLiq; }
        //    set { _OpTipoLiq = value; }
        //}

        //public Int32? GrpBancarios
        //{
        //    get { return _GrpBancarios; }
        //    set { _GrpBancarios = value; }
        //}

        public Int32? IdUser
        {
            get { return _IdUser; }
            set { _IdUser = value; }
        }

        //public string Coligada
        //{
        //    get { return _Coligada; }
        //    set { _Coligada = value; }
        //}

        //public string Agencia
        //{
        //    get { return _Agencia; }
        //    set { _Agencia = value; }
        //}

        //public string CodAgenciaCli
        //{
        //    get { return _CodAgenciaCli; }
        //    set { _CodAgenciaCli = value; }
        //}

        //public string CodAgenciaDes
        //{
        //    get { return _CodAgenciaDes; }
        //    set { _CodAgenciaDes = value; }
        //}
        
        public string HrInicio
        {
            get { return _HrInicio; }
            set { _HrInicio = value; }
        }

        public string HrFim
        {
            get { return _HrFim; }
            set { _HrFim = value; }
        }

        public Int32? UserAlt
        {
            get { return _UserAlt; }
            set { _UserAlt = value; }
        }

        public DateTime? DtAlt
        {
            get { return _DtAlt; }
            set { _DtAlt = value; }
        }

        public string Email
        {
            get { return _Email  ; }
            set { _Email  = value; }
        }

        public int? id_Pag
        {
            get { return _Id_Pag; }
            set { _Id_Pag = value; }
        }

        public string FlagPrimeiroEnvio
        {
            get { return _FlagPrimeiroEnvio; }
            set { _FlagPrimeiroEnvio = value; }
        }

        public string HoraPrimeiroEnvio
        {
            get { return _HoraPrimeiroEnvio; }
            set { _HoraPrimeiroEnvio = value; }
        }

        public string FlagSegundoEnvio
        {
            get { return _FlagSegundoEnvio; }
            set { _FlagSegundoEnvio = value; }
        }

        public string HoraSegundoEnvio
        {
            get { return _HoraSegundoEnvio; }
            set { _HoraSegundoEnvio = value; }
        }
        public string ExtArquivoSaida 
        {
            get { return _ExtArquivoSaida; }
            set { _ExtArquivoSaida = value; }
        }
        public string ExtArquivoEntrada
        {
            get { return _ExtArquivoEntrada; }
            set { _ExtArquivoEntrada = value; }
        }

        public Int32? His_codigo_c
        {
            get { return _His_codigo_c; }
            set { _His_codigo_c= value; }
        }
        //public Int32? His_codigo_d 
        //{
        //    get { return _His_codigo_d; }
        //    set { _His_codigo_d = value; }
        //}
        public string email_Notificacao
        {
            get { return _email_Notificacao; }
            set { _email_Notificacao = value; }
        }
        public string FLAG_HABILITA_TELAS_CCME
        {
            get { return _FLAG_HABILITA_TELAS_CCME; }
            set { _FLAG_HABILITA_TELAS_CCME = value; }
        }

        public Parametro() {
		}

		public Parametro(SqlDataReader reader)
		{
			CarregarDados(reader);
		}


        /*int IComparable<Parametro>.CompareTo(Parametro arq)
        {
            if (arq == null)
                throw new ArgumentNullException("arq");
            return this.Nbol.ToString().CompareTo(arq.Nbol.ToString());
        }*/


		private void CarregarDados(SqlDataReader reader)
		{
            SetarCampos.RetonarValor(reader, this);
		}


        public Parametro ConsultarParametro()
        {
            db_Parametro odb_Parametro = new db_Parametro();
            Parametro oParametro = new Parametro();

            oParametro = odb_Parametro.ConsultarParametro();

            return oParametro;

        }



        public class db_Parametro
        {

            private string strConexao = clsFerramentas.Decodificar(System.Configuration.ConfigurationManager.AppSettings.Get("ConnectionString"));

            public  Parametro ConsultarParametro()
            {
                Parametro oParametro = new Parametro();

                SqlParameter[] strParametros = new SqlParameter[1];

                strParametros[0] = new SqlParameter("@Nom_Robo", SqlDbType.VarChar, 30);
                strParametros[0].Value = "";

                using (SqlDataReader oSqlDataReader = SqlHelper.ExecuteReader(this.strConexao, CommandType.StoredProcedure, "SPBVAR_RoboCCMESwift_Consultar", strParametros))
                {
                    if (oSqlDataReader.Read())
                    {
                        oParametro.CarregarDados(oSqlDataReader);
                    }

                    return oParametro;

                }

            }
        
        }

    }
}
