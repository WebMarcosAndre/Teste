﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace R_CCMESwift
{
    public class PaginaUso
    {

        private Int32? _id_pag = null;
        private string _pag_uso = null;
        private string _PAGINA = null;
        private DateTime? _data = null;


        public Int32? id_pag
        {
            get { return _id_pag; }
            set { _id_pag = value; }
        }

        public string pag_uso
        {
            get { return _pag_uso; }
            set { _pag_uso = value; }
        }

        public string PAGINA
        {
            get { return _PAGINA; }
            set { _PAGINA = value; }

        }

        public DateTime? data
        {
            get { return _data; }
            set { _data = value; }
        }

        public PaginaUso()
        {
        }

        public PaginaUso(SqlDataReader reader)
        {
            //CarregarDados(reader);
        }


        /*int IComparable<Parametro>.CompareTo(Parametro arq)
        {
            if (arq == null)
                throw new ArgumentNullException("arq");
            return this.Nbol.ToString().CompareTo(arq.Nbol.ToString());
        }*/


        //private void CarregarDados(SqlDataReader reader)
        //{

        //    DBase.SetarCampos.RetonarValor(reader, this);
        //}


        public DataSet SelecionarPaginaUso(string strPAGINA)
        {
            db_PaginaUso odb_PaginaUso = new db_PaginaUso();
            DataSet dstRetorno;

            return dstRetorno = odb_PaginaUso.SelecionarPaginaUso(strPAGINA);



        }

        public int AtualizarPaginaUso(int? intid_Pag, string strPag_uso)
        {
            db_PaginaUso odb_PaginaUso = new db_PaginaUso();


            return odb_PaginaUso.AtualizarPaginaUso(intid_Pag, strPag_uso);

        }


        public class db_PaginaUso
        {

            public DataSet SelecionarPaginaUso(string strPAGINA)
            {
                string strConexao = clsFerramentas.Decodificar(System.Configuration.ConfigurationManager.AppSettings.Get("ConnectionString"));

                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@PAGINA", SqlDbType.VarChar);
                strParametros[0].Value = strPAGINA;

                DataSet dstRetorno = SqlHelper.ExecuteDataset(strConexao, CommandType.StoredProcedure, "PR_TBL_PAGINA_USO_Selecionar", strParametros);
                return dstRetorno;

            }

            public int AtualizarPaginaUso(int? intid_Pag, string strPag_uso)
            {

                string strConexao = clsFerramentas.Decodificar(System.Configuration.ConfigurationManager.AppSettings.Get("ConnectionString"));
                SqlParameter[] strParametros = new SqlParameter[2];

                strParametros[0] = new SqlParameter("@pag_uso", SqlDbType.NVarChar);
                strParametros[0].Value = strPag_uso;
                strParametros[1] = new SqlParameter("@Id_pag", SqlDbType.Int);
                strParametros[1].Value =intid_Pag ;
                return SqlHelper.ExecuteNonQuery(strConexao, CommandType.StoredProcedure, "PR_TBL_PAGINA_USO_Atualizar", strParametros);
            }
        }
    }
}

