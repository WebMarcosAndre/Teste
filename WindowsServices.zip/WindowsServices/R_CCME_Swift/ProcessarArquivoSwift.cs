﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Interf_CC_TES;
using System.Collections;
using System.IO;
using Microsoft.ApplicationBlocks.Data;
using System.Net;
using System.Reflection;
using R_CCMESwift.EmailService;
using System.Web.Script.Serialization;
using R_CCMESwift.ModelosCambio;
using R_CCME_Swift.Modelos;
using R_CCME_Swift.EmailService;

namespace R_CCMESwift
{
    public class ProcessarArquivoSwift
    {
        public int intId_LogPai = 0;
        public Parametro oParametro = new Parametro();
        public Parametro oDBParametro = new Parametro();
        public LogCCMESwift oLogCCMESwift = new LogCCMESwift();
        public enum OrigemLog { LC, BO };

        private string IdSistemaVarejoBRSA = System.Configuration.ConfigurationManager.AppSettings.Get("id_SistemaVarejoBRSA");
        private string IdSistemaVarejoCOTA = System.Configuration.ConfigurationManager.AppSettings.Get("id_SistemaVarejoCOTA");
        private string IdSistemaPortalBRSA = System.Configuration.ConfigurationManager.AppSettings.Get("id_SistemaPortalBRSA");
        private string IdSistemaPortalCOTA = System.Configuration.ConfigurationManager.AppSettings.Get("id_SistemaPortalCOTA");

        private string strConexao = clsFerramentas.Decodificar(System.Configuration.ConfigurationManager.AppSettings.Get("ConnectionString"));
        //private string strSistema = System.Configuration.ConfigurationManager.AppSettings.Get("NomeSistema");
        private string wsEmailService = System.Configuration.ConfigurationManager.AppSettings.Get("URL_WSEmail");

        private int RETURN_VALUE = 0;
        private string RETURN_MENSAGEM = null;
        // Historico
        //Hashtable Historico = new Hashtable();

        //Hashtable RetornoMovimentacao = new Hashtable();
        //DataTable dtDados = new DataTable("dtTeste");
        //DataView dvDados = new DataView();

        public ProcessarArquivoSwift()
        {
            //Consulta Parametro 
            oDBParametro = oParametro.ConsultarParametro();

            if (oDBParametro.His_codigo_c == null)
            {
                oLogCCMESwift.DesMetodo = "ConsultarParametro()";
                oLogCCMESwift.DesLog = "Parametro His_codigo não definido, não será possivel efetuar os lançamentos na CCME até que esteja parametrizado, favor verificar tela de parametros do Robô.";
                oLogCCMESwift.TpoLog = "E";
                intId_LogPai = oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

            }
        }

        public void IniciarCCMESwift()
        {
            try
            {
                //Grava Log 
                oDBParametro = oParametro.ConsultarParametro();

                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.DesLog = "Inicio da execução - Versão 19.02.11.09.55";
                oLogCCMESwift.TpoLog = "I";
                oLogCCMESwift.IdLogPai = null;

                oLogCCMESwift.IdLogPai = oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                if (!AutorizarProcessamento())
                {
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                    //Cria pré boleto para swifts de origem google
                    PreBoletosGoogle();
                    //Cria pré boleto quando cliente não possui conta ME
                    PreBoletosNaoGoogle();
                    //Enviar e-mail de Notificação aos clientes com Ordens Recebidas e Pendentes de taxa
                    NotificarClienteComOrdensPendentes();
                    return;
                }
                else
                {
                    //Importa arquivos disponiveis na pasta parametrizada
                    ProcessarArquivo("INSERIR");

                    //Cria os arquivos da empresa BRSA e COTA nas pastas parametrizadas
                    GerarArquivoEmpresas();

                    //Atualiza tabela MT103 com dados do Change
                    Atualiza_MT103_Change();

                    if (HorarioDeCorte_CCME().Equals("S"))
                    {
                        //Efetua os Lançamentos na CCME quando Cliente possui conta ME
                        ProcessarLancamentosCCME();

                    }
                    else
                    {
                        oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                        oLogCCMESwift.DesLog = "Horário de corte excedido, Robô não efetua lançamentos na CCME.";
                        oLogCCMESwift.TpoLog = "I";
                        intId_LogPai = oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                    }

                    //Cria pré boleto para swifts de origem google
                    PreBoletosGoogle();
                    //Cria pré boleto quando cliente não possui conta ME
                    PreBoletosNaoGoogle();
                    //Enviar e-mail de Notificação aos clientes com Ordens Recebidas e Pendentes de taxa
                    NotificarClienteComOrdensPendentes();

                    //********************************************************************
                    //Importa arquivos Lista Restritiva disponiveis na pasta parametrizada
                    //07/2019 - José Carlos Paiva - GPI SWIFT
                    //********************************************************************
                    ProcessarArquivo("INSERIR RE");
                    //********************************************************************
                }
                //Grava Log 
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.DesLog = "Fim da execução";
                oLogCCMESwift.TpoLog = "I";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                // pagina uso 
                intId_LogPai = 0;
            }
            catch (Exception e)
            {
                //Grava log em arquivo texto 
                GravarArquivoLog(e.Message.ToString() + " - " + e.StackTrace);

                //Grava Log 
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.DesLog = e.Message.ToString() + " - " + e.StackTrace;
                oLogCCMESwift.TpoLog = "E";
                intId_LogPai = oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
            intId_LogPai = 0;
        }

        public DataSet BuscarLayoutMT103(string CAMPODB_MT103)
        {
            DataSet dsParametros = null;
            try
            {
                SqlParameter[] strParametros = new SqlParameter[2];
                strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 10);
                strParametros[0].Value = "LISTAR";
                strParametros[1] = new SqlParameter("@CAMPODB_MT103", SqlDbType.VarChar, 30);
                strParametros[1].Value = CAMPODB_MT103;

                dsParametros = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBR_BuscarLayoutMT103", strParametros);

            }
            catch (Exception e)
            {
                // Grava na tabela de log
                oLogCCMESwift.DesLog = "Erro : " + e.Message.ToString() + " - " + e.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                //return 0;
            }
            return dsParametros;
        }
        public int ConsultaArquivoDeEntrada(string Arquivo_Entrada)
        {

            try
            {
                //Verifica se arquivo a ser lido já foi carregado
                SqlParameter[] strParametros = new SqlParameter[2];

                strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 200);
                strParametros[0].Value = "PESQUISA_ARQUIVO_ENTRADA";
                strParametros[1] = new SqlParameter("@ARQUIVO", SqlDbType.VarChar);
                strParametros[1].Value = Arquivo_Entrada;

                DataSet dsParametros = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103", strParametros);
                return Convert.ToInt16(dsParametros.Tables[0].Rows.Count);
            }
            catch (Exception e)
            {
                // Grava na tabela de log
                oLogCCMESwift.DesLog = "Erro : " + e.Message.ToString() + " - " + e.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                return 0;
            }

        }
        public void ProcessarArquivo(string pAcao)
        {

            try
            {
                System.Text.StringBuilder Str = new System.Text.StringBuilder();
                System.Text.StringBuilder closed = new System.Text.StringBuilder();
                int intOrdensDesprezadas = 0;
                //BuscarLayoutMT103 Layout MT103
                DataSet dsLayout = BuscarLayoutMT103(null);
                if (dsLayout != null)
                {
                    if (dsLayout.Tables[0].Rows.Count >= 1)
                    {
                        dsLayout.Tables[0].Columns.Add("Value", Type.GetType("System.String"));
                    }
                }

                //oDBParametro.SWIFT_LEITURA = @"F:\sistemas\MT103\SWIFT_LEITURA";
                //oDBParametro.SWIFT_LIDOS = @"F:\sistemas\MT103\SWIFT_LIDOS";

                string pDir = "";

                List<string> fileList = new List<string>();
                if (pAcao == "INSERIR")
                {
                    pDir = oDBParametro.SWIFT_LEITURA;
                }
                if (pAcao == "INSERIR RE")
                {
                    pDir = oDBParametro.SWIFT_RESTRITIVA;
                }

                DirectoryInfo Dir = new DirectoryInfo(pDir);

                // Busca todos os arquivos no diretório de leitura
                FileInfo[] Files = Dir.GetFiles("*." + oDBParametro.ExtArquivoEntrada, SearchOption.TopDirectoryOnly);
                foreach (FileInfo iFile in Files)
                {
                    //Verifica se arquivo já foi carregado iFile.Name
                    if (ConsultaArquivoDeEntrada(iFile.Name) == 0)
                    {
                        fileList.Add(iFile.Name);
                    }
                    else
                    {
                        if (pAcao == "INSERIR")
                        {
                            if (!System.IO.File.Exists(Path.Combine(oDBParametro.SWIFT_LIDOS, iFile.Name)))
                            {
                                System.IO.File.Move(Path.Combine(oDBParametro.SWIFT_LEITURA, iFile.Name), Path.Combine(oDBParametro.SWIFT_LIDOS, iFile.Name));
                            }
                            else
                            {
                                System.IO.File.Move(Path.Combine(oDBParametro.SWIFT_LEITURA, iFile.Name), Path.Combine(oDBParametro.SWIFT_LIDOS, DateTime.Now.ToString().Replace("/", "").Replace(":", "") + "_" + iFile.Name));
                            }
                        }

                        if (pAcao == "INSERIR RE")
                        {
                            if (!System.IO.File.Exists(Path.Combine(oDBParametro.SWIFT_RESTRITIVA_LIDOS, iFile.Name)))
                            {
                                System.IO.File.Move(Path.Combine(oDBParametro.SWIFT_RESTRITIVA, iFile.Name), Path.Combine(oDBParametro.SWIFT_RESTRITIVA_LIDOS, iFile.Name));
                            }
                            else
                            {
                                System.IO.File.Move(Path.Combine(oDBParametro.SWIFT_RESTRITIVA, iFile.Name), Path.Combine(oDBParametro.SWIFT_RESTRITIVA_LIDOS, DateTime.Now.ToString().Replace("/", "").Replace(":", "") + "_" + iFile.Name));
                            }
                        }

                        oLogCCMESwift.IdLogPai = intId_LogPai;
                        oLogCCMESwift.DesLog = "Arquivo de entrada já processado: " + iFile.Name + " e movido para a pasta :" + oDBParametro.SWIFT_LIDOS;
                        oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                        oLogCCMESwift.TpoLog = "A";
                        oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                    }
                }
                foreach (string fileName in fileList)
                {

                    if (DateTime.Now > System.IO.File.GetLastAccessTime(Path.Combine(Dir.ToString(), fileName)))
                    {
                        //______________________________________________________________________________
                        //Log inicio da leitura do arquivo de entrada
                        oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                        oLogCCMESwift.DesLog = "Inicio : Leitura dos arquivos de Entrada :" + fileName;
                        oLogCCMESwift.TpoLog = "I";
                        oLogCCMESwift.IdLogPai = intId_LogPai;
                        oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                        //______________________________________________________________________________

                        string OpGoogle = "";

                        string text = System.IO.File.ReadAllText(Path.Combine(Dir.ToString(), fileName));
                        //Quebra o arquivo em operações
                        string[] suboper = text.Split('');
                        //string[] suboper = text.Split('$');
                        //Loop em todas as operações existentes no arquivo
                        foreach (string ope in suboper)
                        {
                            if (ope.IndexOf("{2:O103") > 0)
                            {

                                string Operacao = ope;
                                dsLayout.Tables[0].Columns.Remove("Value");
                                dsLayout.Tables[0].Columns.Add("Value", Type.GetType("System.String"));
                                //Definir o tamanho dos campos do arquivo
                                for (int i = 0; i <= dsLayout.Tables[0].Rows.Count - 1; i++)
                                {
                                    DataRow drwLayout = dsLayout.Tables[0].Rows[i];
                                    Operacao = Operacao.Replace(drwLayout["Campo"].ToString() + ":", drwLayout["Campo"].ToString().Replace(":", "|") + "|").Trim();

                                }


                                string StrTrailler = Operacao.Substring(Operacao.IndexOf("-}"), Operacao.Length - Operacao.IndexOf("-}"));
                                string[] OpCols = Operacao.Split('|');
                                string strField = null;
                                try
                                {
                                    for (int i = 0; i <= OpCols.Length - 1; i++)
                                    {
                                        for (int x = 0; x <= dsLayout.Tables[0].Rows.Count - 1; x++)
                                        {
                                            strField = OpCols[i];

                                            if (OpCols[i].Replace("", "").Substring(0, 2) == "{1")
                                            {
                                                dsLayout.Tables[0].Rows[x]["Value"] = OpCols[i];
                                                i++;
                                            }
                                            else if ((":" + OpCols[i]) == dsLayout.Tables[0].Rows[x]["Campo"].ToString())
                                            {
                                                if (OpCols[i + 1].IndexOf("-}{5") > 0)
                                                {
                                                    dsLayout.Tables[0].Rows[x]["Value"] = OpCols[i + 1].Substring(0, OpCols[i + 1].IndexOf("-}"));
                                                    //trailler : 
                                                }
                                                else
                                                {
                                                    if (dsLayout.Tables[0].Rows[x]["Value"].ToString().Length > 0)
                                                    {
                                                        dsLayout.Tables[0].Rows[x]["Value"] += dsLayout.Tables[0].Rows[x]["Campo"].ToString() + ":" + OpCols[i + 1];
                                                    }
                                                    else
                                                    {
                                                        dsLayout.Tables[0].Rows[x]["Value"] = OpCols[i + 1];
                                                    }
                                                }
                                                i++;
                                            }
                                            else if (dsLayout.Tables[0].Rows[x]["Campo"].ToString() == "-}{5:")
                                            {
                                                dsLayout.Tables[0].Rows[x]["Value"] = StrTrailler;
                                            }
                                        }
                                    }
                                }
                                catch (Exception ExLayout)
                                {
                                    oLogCCMESwift.DesLog = "Erro Layout do arquivo : " + strField + " : MSG: " + ExLayout.Message;
                                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                    oLogCCMESwift.TpoLog = "E";
                                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                                }

                                //DEFINE OS PARAMETROS PARA PROCEDURE SPBR_GRAVAR_MT103
                                DataRow[] DsFiltro = dsLayout.Tables[0].Select("Value <> ''");

                                int qtdParametros = DsFiltro.Length + 6;
                                SqlParameter[] strParametros = new SqlParameter[qtdParametros];

                                strParametros[0] = new SqlParameter("@acao", SqlDbType.NVarChar, 10);
                                strParametros[0].Value = pAcao;// "INSERIR";
                                bool blGoogle = false;

                                int r = 1;
                                for (int i = 0; i <= DsFiltro.Length - 1; i++)
                                {
                                    strParametros[r] = new SqlParameter("@" + DsFiltro[i].ItemArray[4].ToString(), SqlDbType.VarChar);
                                    strParametros[r].Value = DsFiltro[i].ItemArray[5].ToString();
                                    if (DsFiltro[i].ItemArray[5].ToString().IndexOf("GOOGLE") >= 0)
                                    {
                                        blGoogle = true;
                                    }
                                    r++;
                                }
                                int ID_identity = 0;
                                strParametros[r] = new SqlParameter("@id_user", SqlDbType.NChar, 10);
                                strParametros[r].Value = oDBParametro.IdUser;
                                r++;
                                strParametros[r] = new SqlParameter("@data_registro", SqlDbType.DateTime);
                                strParametros[r].Value = DateTime.Now;
                                r++;
                                strParametros[r] = new SqlParameter("@arquivo_entrada", SqlDbType.VarChar);
                                strParametros[r].Value = fileName;
                                r++;
                                strParametros[r] = new SqlParameter("@flagGoogle", SqlDbType.Bit);
                                strParametros[r].Value = blGoogle;
                                r++;
                                strParametros[r] = new SqlParameter("@new_identity", SqlDbType.Int);
                                strParametros[r].Value = ID_identity;
                                DataSet dsRetorno = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBR_GRAVAR_MT103", strParametros);
                                if (blGoogle)
                                {
                                    OpGoogle += dsRetorno.Tables[1].Rows[0].ItemArray[0] + ":N,";
                                }
                                if (pAcao == "INSERIR")
                                    GravarArquivoLog("Método : ProcessarArquivoLeitura - Arquivo: " + fileName + " Swift : " + dsLayout.Tables[0].Rows[0]["Value"] + " - ");
                                if (pAcao == "INSERIR RE")
                                    GravarArquivoLog("Método : ProcessarArquivoLeituraListaRestritiva - Arquivo: " + fileName + " Swift : " + dsLayout.Tables[0].Rows[0]["Value"] + " - ");
                                //dsLayout.Tables[0].Rows[1]["Value"]
                                //SqlParameter param = new SqlParameter("@IDSWIFT", SqlDbType.Int);
                                //param.Value = Convert.ToInt32(dsRetorno.Tables[0].Rows[0]["id"].ToString());
                                //SqlHelper.ExecuteDataset(strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103_APROVA_CONTRAPARTIDA", param);
                            }
                            else
                            {
                                if ((oDBParametro.FlagLogDetalhado.ToString() == "S") && (ope.Replace(" ", "").Length > 0))
                                {// Se FlagLogDetalhado = S, registrar Ordens desprezadas Erro aqui
                                    if (ope.IndexOf("{2") >= 0 && ope.IndexOf("{2") + 7 < ope.Length)
                                    {
                                        intOrdensDesprezadas++;
                                        oLogCCMESwift.DesLog = "Tipo de Menssagem desprezada: " + ope.Substring(ope.IndexOf("{2"), 7);
                                        oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                        oLogCCMESwift.TpoLog = "A";
                                        oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                                    }

                                }
                            }
                        }

                        //TODO: REMOVER ROTINA LOTE AUTOMATICO GOOGLE
                        //Ordens Google, o Lote é gerado automaticamente
                        //if (OpGoogle.Length > 0)
                        //{

                        //    SqlParameter[] strParametrosGoogle = new SqlParameter[3];

                        //    strParametrosGoogle[0] = new SqlParameter("@acao", SqlDbType.NVarChar, 10);
                        //    strParametrosGoogle[0].Value = "GERARLOTE";
                        //    strParametrosGoogle[1] = new SqlParameter("@USUARIO", SqlDbType.NVarChar);
                        //    strParametrosGoogle[1].Value = oDBParametro.IdUser;
                        //    strParametrosGoogle[2] = new SqlParameter("@LISTA", SqlDbType.NVarChar);
                        //    strParametrosGoogle[2].Value = OpGoogle.Substring(0, OpGoogle.Length - 1);
                        //    DataSet dsRetorno = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103", strParametrosGoogle);

                        //    if (oDBParametro.FlagLogDetalhado.ToString() == "S")
                        //    {// Se FlagLogDetalhado = S, logar Lote ordens google
                        //        oLogCCMESwift.DesLog = "Criado Lote de Ordens Google Automaticamente :";
                        //        oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                        //        oLogCCMESwift.TpoLog = "A";
                        //        oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                        //    }
                        //}

                        //Move o arquivo lido da pasta de leitura para a pasta de arquivos lidos
                        if (pAcao == "INSERIR")
                        {
                            if (!System.IO.Directory.Exists(oDBParametro.SWIFT_LIDOS))
                            {
                                System.IO.Directory.CreateDirectory(oDBParametro.SWIFT_LIDOS);
                            }
                            if (!System.IO.File.Exists(Path.Combine(oDBParametro.SWIFT_LIDOS, fileName)))
                            {
                                System.IO.File.Move(Path.Combine(oDBParametro.SWIFT_LEITURA, fileName), Path.Combine(oDBParametro.SWIFT_LIDOS, fileName));
                            }
                            else
                            {
                                System.IO.File.Move(Path.Combine(oDBParametro.SWIFT_LEITURA, fileName), Path.Combine(oDBParametro.SWIFT_LIDOS, DateTime.Now.ToString().Replace("/", "").Replace(":", "") + "_" + fileName));
                            }
                        }

                        if (pAcao == "INSERIR RE")
                        {
                            if (!System.IO.Directory.Exists(oDBParametro.SWIFT_RESTRITIVA_LIDOS))
                            {
                                System.IO.Directory.CreateDirectory(oDBParametro.SWIFT_RESTRITIVA_LIDOS);
                            }
                            if (!System.IO.File.Exists(Path.Combine(oDBParametro.SWIFT_RESTRITIVA_LIDOS, fileName)))
                            {
                                System.IO.File.Move(Path.Combine(oDBParametro.SWIFT_RESTRITIVA, fileName), Path.Combine(oDBParametro.SWIFT_RESTRITIVA_LIDOS, fileName));
                            }
                            else
                            {
                                System.IO.File.Move(Path.Combine(oDBParametro.SWIFT_RESTRITIVA, fileName), Path.Combine(oDBParametro.SWIFT_RESTRITIVA_LIDOS, DateTime.Now.ToString().Replace("/", "").Replace(":", "") + "_" + fileName));
                            }
                        }
                        //______________________________________________________________________________
                        //Log Fim da leitura do arquivo de entrada
                        oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                        oLogCCMESwift.DesLog = "Fim : Leitura dos arquivos de Entrada : " + fileName + " com " + suboper.Count() + " ordens e " + intOrdensDesprezadas + " desprezadas";
                        oLogCCMESwift.TpoLog = "I";
                        oLogCCMESwift.IdLogPai = intId_LogPai;
                        oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                        //______________________________________________________________________________
                    }
                }
            }
            catch (Exception e)
            {
                GravarArquivoLog("Método : ProcessarArquivoLeitura - Error : " + e.Message.ToString() + " - " + e.StackTrace);
                // Grava na tabela de log
                oLogCCMESwift.DesLog = "Erro : " + e.Message.ToString() + " - " + e.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }

        }
        private string BuscarCampoLayout(string nomeCampo)
        {

            //BuscarLayoutMT103 Layout MT103
            DataSet dsLayout = BuscarLayoutMT103(nomeCampo);
            string StrCampo = "";
            if (dsLayout != null)
            {
                if (dsLayout.Tables[0].Rows.Count >= 1)
                {
                    StrCampo = dsLayout.Tables[0].Rows[0]["CAMPO"].ToString();
                }
                else
                {
                    StrCampo = "";
                }

            }
            return StrCampo;
        }
        public void GerarArquivoEmpresas()
        {

            //Retorna a lista de operações liberadas para gerar o arquivo
            SqlParameter[] strParametrosBRSA = new SqlParameter[2];
            strParametrosBRSA[0] = new SqlParameter("@acao", SqlDbType.NVarChar, 30);
            strParametrosBRSA[0].Value = "GERAR_ARQUIVOS";
            strParametrosBRSA[1] = new SqlParameter("@EMPRESA", SqlDbType.NVarChar, 100);
            strParametrosBRSA[1].Value = "BRSA";
            DataSet dsRetornoBRSA = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103", strParametrosBRSA);
            if (dsRetornoBRSA.Tables[0].Rows.Count > 0)
            {
                CriarArquivosSwift(dsRetornoBRSA, "BRSA");

                if (oDBParametro.FlagLogDetalhado == "S")
                {
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.DesLog = "BRSA: Criado Arquivo de saída com " + dsRetornoBRSA.Tables[0].Rows.Count + " registros";
                    oLogCCMESwift.TpoLog = "I";
                    oLogCCMESwift.IdLogPai = intId_LogPai;
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                }
                //dsRetornoBRSA.Dispose();
                dsRetornoBRSA.Clear();
            }

            SqlParameter[] strParametrosCOT = new SqlParameter[2];
            strParametrosCOT[0] = new SqlParameter("@acao", SqlDbType.NVarChar, 30);
            strParametrosCOT[0].Value = "GERAR_ARQUIVOS";
            strParametrosCOT[1] = new SqlParameter("@EMPRESA", SqlDbType.NVarChar, 100);
            strParametrosCOT[1].Value = "COTACAO";
            DataSet dsRetornoCOT = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103", strParametrosCOT);
            if (dsRetornoCOT.Tables[0].Rows.Count > 0)
            {
                CriarArquivosSwift(dsRetornoCOT, "COTACAO");
                if (oDBParametro.FlagLogDetalhado == "S")
                {
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.DesLog = "COTAÇÃO: Criado Arquivo de saída com " + dsRetornoCOT.Tables[0].Rows.Count + " registros";
                    oLogCCMESwift.TpoLog = "I";
                    oLogCCMESwift.IdLogPai = intId_LogPai;
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                }
                dsRetornoCOT.Clear();
                //dsRetornoCOT.Dispose();
            }

        }
        private void AssociaBeneficiarioCliente(int idSwift)
        {
            try
            {
                //1. Sugere associação dos beneficiarios das ordens aos clientes
                //2. Associa ordens com O57A a clientes BIC1
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@IDSWIFT", SqlDbType.Int);
                strParametros[0].Value = idSwift;
                DataSet dsRetorno = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103_SUGERIR_ASSOCIACAO", strParametros);

            }
            catch (Exception ex)
            {
                GravarArquivoLog("Método : AssociaBeneficiarioCliente - Error : " + ex.Message.ToString() + " - " + ex.StackTrace);
                // Grava na tabela de log
                oLogCCMESwift.DesLog = "Erro : " + ex.Message.ToString() + " - " + ex.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }

        }
        public void CriarArquivosSwift(DataSet dsRetorno, string Empresa)
        {

            try
            {
                string StrSWIFT_ROW = string.Empty;
                string CampoValue = string.Empty;
                string StrLotes = string.Empty;

                string PATH_ARQUIVO_SAIDA = string.Empty;

                if (Empresa == "BRSA") { PATH_ARQUIVO_SAIDA = oDBParametro.SWIFT_BRSA.ToString(); }
                if (Empresa == "COTACAO") { PATH_ARQUIVO_SAIDA = oDBParametro.SWIFT_COTACAO.ToString(); }

                string NOME_ARQUIVO = string.Empty;

                if (dsRetorno.Tables[0].Rows.Count > 0)
                {
                    //BRSA
                    NOME_ARQUIVO = DateTime.Now.ToString().Replace("/", "").Replace(":", "") + dsRetorno.Tables[0].Rows[0]["EMPRESA"].ToString() + "." + oDBParametro.ExtArquivoSaida.ToLower();

                    //Log Arquivo de Saída
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.DesLog = "Inicio: Criação do arquivo de saída:" + NOME_ARQUIVO + " Empresa: " + Empresa;
                    oLogCCMESwift.TpoLog = "I";
                    oLogCCMESwift.IdLogPai = intId_LogPai;
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                    if (!System.IO.File.Exists(Path.Combine(PATH_ARQUIVO_SAIDA, NOME_ARQUIVO)))
                    {
                        //System.IO.File.Create(NOME_ARQUIVO).Close();
                        System.IO.File.Create(Path.Combine(PATH_ARQUIVO_SAIDA, NOME_ARQUIVO)).Close();
                    }
                    System.IO.TextWriter ArquivoSaida = System.IO.File.AppendText(Path.Combine(PATH_ARQUIVO_SAIDA, NOME_ARQUIVO));


                    for (int i = 0; i <= dsRetorno.Tables[0].Rows.Count - 1; i++)//linhas 
                    {
                        if ((StrLotes.Length == 0) || (StrLotes.IndexOf(dsRetorno.Tables[0].Rows[i]["LOTE"].ToString()) == -1))
                        {
                            StrLotes += dsRetorno.Tables[0].Rows[i]["LOTE"].ToString() + ",";
                        }
                        //Executa verificação de sugestão de associação Beneficiário x Clientes
                        AssociaBeneficiarioCliente(Convert.ToInt32(dsRetorno.Tables[0].Rows[i]["idswift"].ToString()));

                        StrSWIFT_ROW = string.Empty;
                        for (int c = 0; c <= dsRetorno.Tables[0].Columns.Count - 1; c++) //colunas
                        {
                            if (dsRetorno.Tables[0].Rows[i][c].ToString().Length > 0)
                            {
                                if ((dsRetorno.Tables[0].Columns[c].Caption.ToString().Substring(0, 1) == "M") || (dsRetorno.Tables[0].Columns[c].Caption.ToString().Substring(0, 1) == "O"))
                                {
                                    if (dsRetorno.Tables[0].Rows[i][c].ToString().IndexOf("\r\n") == -1)
                                    {
                                        CampoValue = dsRetorno.Tables[0].Rows[i][c].ToString() + "\r\n";
                                    }
                                    else
                                    {
                                        CampoValue = dsRetorno.Tables[0].Rows[i][c].ToString();
                                    }
                                    StrSWIFT_ROW += BuscarCampoLayout(dsRetorno.Tables[0].Columns[c].Caption) + ":" + CampoValue;
                                }
                                else if ((dsRetorno.Tables[0].Columns[c].Caption.ToString() == "HeaderOp") || (dsRetorno.Tables[0].Columns[c].Caption.ToString() == "TrailerOp"))
                                {
                                    StrSWIFT_ROW += dsRetorno.Tables[0].Rows[i][c].ToString();
                                }
                            }
                        }
                        if (StrSWIFT_ROW.Length > 0)
                        {
                            ArquivoSaida.WriteLine(StrSWIFT_ROW + (char)3);
                        }
                    }


                    //encerra Lotes com o arquivo de saída
                    //@ACAO='ENCERRAR_LOTES', @NOMEARQUIVO='TESTE', @CAMINHOARQUIVO='C:\', @DATAARQUIVO='2013/10/31 17:00:00',@LOTE='44,45'
                    SqlParameter[] strParametrosCOT = new SqlParameter[5];
                    strParametrosCOT[0] = new SqlParameter("@acao", SqlDbType.NVarChar, 30);
                    strParametrosCOT[0].Value = "ENCERRAR_LOTES";
                    strParametrosCOT[1] = new SqlParameter("@NOMEARQUIVO", SqlDbType.NVarChar);
                    strParametrosCOT[1].Value = NOME_ARQUIVO;
                    strParametrosCOT[2] = new SqlParameter("@CAMINHOARQUIVO", SqlDbType.NVarChar);
                    strParametrosCOT[2].Value = PATH_ARQUIVO_SAIDA;
                    strParametrosCOT[3] = new SqlParameter("@DATAARQUIVO", SqlDbType.DateTime);
                    strParametrosCOT[3].Value = DateTime.Now;
                    strParametrosCOT[4] = new SqlParameter("@LOTE", SqlDbType.VarChar);
                    strParametrosCOT[4].Value = StrLotes.Substring(0, StrLotes.Length - 1);

                    DataSet dsRet = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103", strParametrosCOT);

                    ArquivoSaida.Close();
                    //Quando Empresa COTACAO, envia cópia para pasta BRSA (Rendimento) 
                    if (Empresa == "COTACAO")
                    {
                        if (System.IO.File.Exists(Path.Combine(PATH_ARQUIVO_SAIDA, NOME_ARQUIVO)))
                        {
                            System.IO.File.Copy(Path.Combine(PATH_ARQUIVO_SAIDA, NOME_ARQUIVO), Path.Combine(oDBParametro.SWIFT_BRSA.ToString(), NOME_ARQUIVO));
                            FileInfo fls = new FileInfo(Path.Combine(oDBParametro.SWIFT_BRSA.ToString(), NOME_ARQUIVO));

                            //Log Arquivo de Saída Cotação
                            oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                            oLogCCMESwift.DesLog = "Cotação: Arquivo de saída:" + NOME_ARQUIVO + " enviado para BRSA:" + oDBParametro.SWIFT_BRSA.ToString();
                            oLogCCMESwift.TpoLog = "I";
                            oLogCCMESwift.IdLogPai = intId_LogPai;
                            oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                            string resposta = null;

                            //Enviar e-mail de notificação 
                            try
                            {
                                var infoEmail = new InfoEmail
                                {
                                    IdSistema = "2",
                                    IdEmpresa = "1",
                                    Codigo = "45",
                                    ListaEmailPara = oDBParametro.email_Notificacao,
                                    ListaEmailCc = "",
                                    Assunto = "Arquivo Swift disponivel para importação (" + NOME_ARQUIVO + ")",
                                    ListaArquivos = null,
                                    ListaParametrosCorpo = new List<EmailService.Parametro>()
                                };

                                infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "EMPRESA_SWIFT", Valor = Empresa });
                                infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "ARQUIVO_SWIFT", Valor = NOME_ARQUIVO });
                                infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "DATA_SWIFT", Valor = fls.CreationTime.ToString("dd/MM/yyyy HH:mm:ss") });

                                var serializer = new JavaScriptSerializer();
                                string dados = serializer.Serialize(infoEmail);

                                var rest = new RestClient(wsEmailService);
                                resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));
                            }
                            catch (Exception x)
                            {
                                oLogCCMESwift.DesLog = "Erro : Resposta=" + resposta + " Msg: " + x.Message.ToString() + " - " + x.StackTrace;
                                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                oLogCCMESwift.TpoLog = "E";
                                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                            }
                        }
                    }
                    //Log Arquivo de saída, empresa e qtde de ordens escritas
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.DesLog = "Fim: Arquivo de saída:" + NOME_ARQUIVO + " Empresa: " + Empresa + " Ordens:" + dsRetorno.Tables[0].Rows.Count;
                    oLogCCMESwift.TpoLog = "I";
                    oLogCCMESwift.IdLogPai = intId_LogPai;
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                }
            }
            catch (Exception e)
            {
                GravarArquivoLog("Método : ProcessarArquivoLeitura - Error : " + e.Message.ToString() + " - " + e.StackTrace);
                oLogCCMESwift.DesLog = "Erro : " + e.Message.ToString() + " - " + e.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
        }
        public void GravarArquivoLog(string strMensagem)
        {
            string strCaminhoArquivoLog = System.Configuration.ConfigurationManager.AppSettings.Get("CaminhoArquivoLog");
            string strNomeArquivoLog = System.Configuration.ConfigurationManager.AppSettings.Get("NomeArquivoLog");

            using (StreamWriter oStreamWriter = new StreamWriter(Path.Combine(strCaminhoArquivoLog, strNomeArquivoLog), true))
            {
                oStreamWriter.WriteLine(DateTime.Now.Date.ToLongDateString() + " " + DateTime.Now.TimeOfDay.ToString());
                oStreamWriter.WriteLine(strMensagem);
                oStreamWriter.WriteLine("----------------------------------");
                oStreamWriter.Close();
            }
        }
        public bool AutorizarProcessamento()
        {
            bool blnRetorno = true;

            string strMensagem = string.Empty;

            if (oDBParametro == null)
            {
                // parametro não encontrado.
                throw new Exception("Não econtrado Parametros para a execução do Robô");
            }

            // Verifica se o Robo está ativo
            if (oDBParametro.FlagAtivo == "N")
            {
                strMensagem = strMensagem + "Robô não está ativo para processar";
                blnRetorno = false;
            }

            // Verifica se eh dia util e processa             
            if (!verificarDiaUtil())
            {
                strMensagem = strMensagem + "Robô não autorizado processar em dia não útil.";
                blnRetorno = false;
            }

            int HoraI = 0;
            int MinutoI = 0;
            HoraI = Convert.ToInt32(oDBParametro.HrInicio.Trim().Substring(0, 2));
            MinutoI = Convert.ToInt32(oDBParametro.HrInicio.Trim().Substring(3, 2));

            int HoraF = 0;
            int MinutoF = 0;
            HoraF = Convert.ToInt32(oDBParametro.HrFim.Trim().Substring(0, 2));
            MinutoF = Convert.ToInt32(oDBParametro.HrFim.Trim().Substring(3, 2));

            DateTime DataInicio = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, HoraI, MinutoI, DateTime.Now.Second, DateTime.Now.Millisecond);
            DateTime DataTermino = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, HoraF, MinutoF, DateTime.Now.Second, DateTime.Now.Millisecond);

            // se o horairio esta dentor 
            if (DateTime.Now < DataInicio)
            {
                strMensagem = strMensagem + "Robô não autorizado processar horário MENOR que o permitido.";
                blnRetorno = false;
            }

            if (DateTime.Now > DataTermino)
            {
                strMensagem = strMensagem + "Robô não autorizado processar horário MAIOR que o permitido.";
                blnRetorno = false;
            }

            if (blnRetorno == false)
            {
                oLogCCMESwift.DesLog = strMensagem;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "A";
            }

            return blnRetorno;
        }
        public int EncaminharEmail(Email oRetorno)
        {
            SqlParameter[] strParametros = new SqlParameter[5];

            strParametros[0] = new SqlParameter("@IDSistema", SqlDbType.Int);
            strParametros[0].Value = oRetorno.IDSistema;

            strParametros[1] = new SqlParameter("@Destino", SqlDbType.VarChar, 500);
            strParametros[1].Value = oRetorno.Destino;

            strParametros[2] = new SqlParameter("@CopiaOculta", SqlDbType.VarChar, 500);
            strParametros[2].Value = oRetorno.CopiaOculta;

            strParametros[3] = new SqlParameter("@Assunto", SqlDbType.VarChar, 255);
            strParametros[3].Value = oRetorno.Assunto;

            strParametros[4] = new SqlParameter("@Corpo", SqlDbType.VarChar, 4000);
            strParametros[4].Value = oRetorno.Corpo;

            return SqlHelper.ExecuteNonQuery(this.strConexao, CommandType.StoredProcedure, "SP_SendMail", strParametros);
        }
        public void ProcessarLancamentosCCME()
        {

            // Procedure SPBCCME_Inserir_Lancamento
            //a.	  @MOV_CLIENTE       INT,    	   = id_cliente associado ao Swift
            //b.	  @MOV_MOEDA         VARCHAR(10),  = Moeda do Swift
            //c.	  @MOV_TIPO          VARCHAR(1),   = C
            //d.	  @MOV_TIPO_OP       VARCHAR(50),  = ‘ROBO’
            //e.	  @MOV_VALOR         DECIMAL(13,2),= valor do Swift
            //f.	  @MOV_PARIDADE      DECIMAL(10,6),= 0
            //g.	  @MOV_HISTORICO     INT,    	   = parâmetro (Criar campo na tela de parâmetros do robô)
            //h.	  @MOV_FLAG_DISP     CHAR(1)       = NULL,  = L  
            //i.	  @MOV_FLAG_BLOQ     CHAR(2)       = NULL,  = LN  
            //j.	  @MOV_OBS           VARCHAR(2000) = NULL,      = “”
            //k.	  @MOV_QTDE_CHEQUES  INT           = 0
            //l.	  @MOV_DATA_DISP     DATETIME      = GETDATE, = GETDATE acessar DBFERIADOS    
            //m.	  @ID_LANCAMENTO     INT,    	   = 0
            //n.	  @SISTEMA           INT           = 1,    
            //o.	  @CL_NUM_DOC        VARCHAR(14)   = NULL,    = CL_NUM_DOC do cliente associado a Swift
            //p.	  @CL_NOME           VARCHAR(500)  = NULL,      = CL_nome do cliente associado ao Swift
            //q.	  @ID_USUARIO        INT           = NULL,    = id_usuário do ROBO
            //r.	  @TIPO_USUARIO      CHAR(1)       = NULL,  = M  
            //s.	  @ID_ORDEM          INT           = NULL,     = 0
            //t.	  @DATA_LIBERACAO    SMALLDATETIME = NULL, = GETDATE acessar DBFERIADOS 
            //u.	  @MOV_CBR_VTM_DE    DATETIME      = NULL,   = null 
            //v.	  @MOV_CBR_VTM_ATE   DATETIME      = NULL,   = null
            //w.	  @ID_LANCAMENTO_OUT VARCHAR(10)   = NULL OUTPUT,    
            //x.	  @MENSAGEM          VARCHAR(300)  = NULL OUTPUT,  
            //y.	  @ID_LANC           INT           = NULL OUTPUT  
            if (oDBParametro.His_codigo_c == null) { return; }


            using (SqlConnection connection = new SqlConnection(this.strConexao))
            {
                connection.Open();
                try
                {
                    SqlParameter[] strParametros = new SqlParameter[1];
                    strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 200);
                    strParametros[0].Value = "GERAR_LANCAMENTOS";
                    bool blLancamento = false;

                    DataSet dsSwift = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103_LANCAMENTO", strParametros);

                    string[] retorno_data = new string[3] { "", "", "" };
                    string[] retorno_data_retroativa = new string[3] { "", "", "" };
                    int Id_Lancamento = 0;
                    int id_lancRetorno = 0;
                    string MsgLog = null;
                    string ObsLanc = null;
                    string obsLanc_msg = null;
                    DateTime DtLancamento;


                    if (dsSwift.Tables.Count > 0)
                    {
                        for (int i = 0; i <= dsSwift.Tables[0].Rows.Count - 1; i++)
                        {
                            SqlTransaction transaction = connection.BeginTransaction(IsolationLevel.ReadCommitted);

                            try
                            {
                                // Se Cliente Não Possui CCME e a Ordem Endereçada para BRSA, não efetuar Lançamento CCME
                                // Somente efetuar Lançamento para:
                                // - Se Cliente possui CCME
                                //   INDIFERENTE se a ordem é para o BRSA ou Cotação  realizar crédito na CCME do Cliente com histórico (Recebimento de O.P) 
                                //   parametro tbl_roboCCMESWIFT.his_codigo 
                                // - Se Cliente não possui CCME e a Ordem endereçada para Cotação
                                //   Credito na CCME da Cotação com histórico (Recebimento de O.P)
                                //   string Moeda = dsSwift.Tables[0].Rows[i]["moeda"].ToString();

                                string Moeda = string.Empty;
                                switch (dsSwift.Tables[0].Rows[i]["moeda"].ToString())
                                {
                                    case "EUR":
                                        Moeda = "EURO";
                                        break;
                                    case "GBP":
                                        Moeda = "STG";
                                        break;
                                    case "AUD":
                                        Moeda = "ATD";
                                        break;
                                    case "CAD":
                                        Moeda = "CAN";
                                        break;
                                    case "JPY":
                                        Moeda = "YEN";
                                        break;
                                    default:
                                        Moeda = dsSwift.Tables[0].Rows[i]["moeda"].ToString();
                                        break;
                                }

                                int Id_Cliente = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["CONTA_CLIENTE"].ToString() == "0" ? dsSwift.Tables[0].Rows[i]["ID_CLIENTE_EMPRESA"].ToString() : dsSwift.Tables[0].Rows[i]["ID_CLIENTE"].ToString());
                                int idSwift = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["IDSwift"].ToString());
                                decimal OrValor = Convert.ToDecimal(dsSwift.Tables[0].Rows[i]["valor"].ToString());

                                //Trata o saldo negativo da tarifa, faz a consulta antes dos lançamentos
                                //Porque hoje a procedure está com with(nolock) e então está considerando os registros sujos
                                //de uma transaction aberta
                                string moeda_tarifa = MoedaTarifa(Moeda, Id_Cliente);
                                string cod_moeda_tarifa = null;

                                if (moeda_tarifa.Equals("D"))
                                {
                                    cod_moeda_tarifa = "USD";
                                }
                                else
                                {
                                    cod_moeda_tarifa = Moeda;
                                }

                                decimal saldoTarifa = ConsultarSaldo(transaction, Id_Cliente, cod_moeda_tarifa);

                                //--------------------------------------------------------------------------------------------------------------------------------------------------------
                                //--------------------------------------------------------------------------------------------------------------------------------------------------------
                                //TESTA VALUE DATE - ME=0

                                GetDataLancamento(transaction,
                                                  idSwift,
                                                  Convert.ToDateTime(dsSwift.Tables[0].Rows[i]["VALUE_DATE"]),
                                                  dsSwift.Tables[0].Rows[i]["moeda"].ToString(),
                                                  OrValor,
                                                  "LC",
                                                  out DtLancamento,
                                                  out blLancamento,
                                                  out obsLanc_msg);



                                //apenas executa o lançamento se data é valida 
                                if (blLancamento)
                                {
                                    ObsLanc = "NUMERO CHANGE:" + dsSwift.Tables[0].Rows[i]["NUMERO"].ToString() + "<BR/><BR/>" + dsSwift.Tables[0].Rows[i]["C59"].ToString() + "<BR/><BR/>" + dsSwift.Tables[0].Rows[i]["C70"].ToString() + obsLanc_msg;

                                    if ((dsSwift.Tables[0].Rows[i]["CONTA_CLIENTE"].ToString() == "1") ||
                                       ((dsSwift.Tables[0].Rows[i]["Empresa"].ToString() != "BRSA") &&
                                        (dsSwift.Tables[0].Rows[i]["CONTA_CLIENTE"].ToString() == "0"))
                                        )
                                    {
                                        // Efetuar Lançamento de Crédito da Ordem de Pagamento
                                        // int id_lancRetorno = RealizaLancamento(transaction, Id_Cliente, Moeda, "C", "ROBO", OrValor, Convert.ToInt32(oDBParametro.His_codigo), Id_Lancamento, "L", "LN", ObsLanc, 0, Convert.ToDateTime(String.Format("{0:yyyy-MM-dd}", retorno_data[2])),Convert.ToDateTime("01/01/1900"), Convert.ToDateTime("01/01/1900"), Convert.ToInt32(oDBParametro.IdUser));
                                        // Efetuar Lançamento de Débito da Tarifa
                                        // int id_lanc = RealizaLancamento(transaction, Id_Cliente, Moeda, "D", "ROBO", OrValor, Convert.ToInt32(oDBParametro.His_codigo), id_lancRetorno, "L", "LN", ObsLanc, 0, Convert.ToDateTime(String.Format("{0:yyyy-MM-dd}", retorno_data[2])),Convert.ToDateTime("01/01/1900"), Convert.ToDateTime("01/01/1900"), Convert.ToInt32(oDBParametro.IdUser));

                                        DataSet drRetorno = RealizaLancamento(transaction,
                                                                              Id_Cliente, Moeda, "C", "ROBO",
                                                                              OrValor,
                                                                              Convert.ToInt32(oDBParametro.His_codigo_c),
                                                                              id_lancRetorno,
                                                                              "L", "LN", ObsLanc, 0,
                                                                              Convert.ToDateTime(String.Format("{0:yyyy-MM-dd}", DtLancamento)),
                                                                              Convert.ToDateTime("01/01/1900"), Convert.ToDateTime("01/01/1900"),
                                                                              Convert.ToInt32(oDBParametro.IdUser),
                                                                              Convert.ToInt32(dsSwift.Tables[0].Rows[i]["IDSwift"].ToString()),
                                                                              dsSwift.Tables[0].Rows[i]["cl_num_doc"].ToString());

                                        decimal OrdemValor = Convert.ToDecimal(dsSwift.Tables[0].Rows[i]["valor"].ToString());
                                        string NmClienteConta = string.Empty;
                                        Id_Lancamento = Convert.ToInt32(drRetorno.Tables[0].Rows[0][0].ToString());
                                        if ((dsSwift.Tables[0].Rows[i]["EMPRESA"].ToString().Equals("COTACAO") &&
                                            dsSwift.Tables[0].Rows[i]["CLIENTE_NIDENT"].ToString().Equals("1")) ||
                                            (dsSwift.Tables[0].Rows[i]["EMPRESA"].ToString().Equals("COTACAO") &&
                                             dsSwift.Tables[0].Rows[i]["CONTA_CLIENTE"].ToString().Equals("0")))
                                        {
                                            NmClienteConta = dsSwift.Tables[0].Rows[i]["NOME_CLIENTE_EMPRESA"].ToString();
                                        }
                                        else
                                        {
                                            NmClienteConta = dsSwift.Tables[0].Rows[i]["NOME"].ToString();
                                        }

                                        MsgLog = "Lançamento ref. ao Recebimento de OP. efetuado com sucesso no valor de " + OrValor + "  " + Moeda + " Cliente: " + NmClienteConta;
                                        DataSet Dres = GravaLOG_Lancamento_CCMESwift(transaction, idSwift, RETURN_VALUE.ToString(), MsgLog, Convert.ToInt32(oDBParametro.IdUser), Moeda, OrValor, Id_Lancamento, "A", 0, 0, "", OrigemLog.LC.ToString());

                                        if (drRetorno.Tables[0].Rows.Count > 0)
                                        {
                                            decimal valor_tarifa = 0;
                                            valor_tarifa = CalcularTarifa(Id_Cliente, Moeda, OrValor, "RECEB_SWIFT");
                                            DataTable DtHis = Get_Historico_tarifa(oDBParametro.His_codigo_c.Value);
                                            id_lancRetorno = Convert.ToInt32(drRetorno.Tables[0].Rows[0][0].ToString());

                                            //SE ORDEM DA COTAÇÃO E LANÇAMENTO EFETIVADO NA CONTA DO CLIENTE REVERTER A EMPRESA DA ORDEM PARA BRSA
                                            if ((dsSwift.Tables[0].Rows[i]["CONTA_CLIENTE"].ToString() == "1") &&
                                                (dsSwift.Tables[0].Rows[i]["Empresa"].ToString() == "COTACAO"))
                                            {
                                                try
                                                {
                                                    SqlParameter[] strParam = new SqlParameter[2];
                                                    DataSet drReversao = null;

                                                    strParam[0] = new SqlParameter("@IDSWIFT", SqlDbType.Int);
                                                    strParam[0].Value = idSwift;
                                                    strParam[1] = new SqlParameter("@ID_USER", SqlDbType.Int);
                                                    strParam[1].Value = oDBParametro.IdUser;

                                                    drReversao = SqlHelper.ExecuteDataset(transaction, CommandType.StoredProcedure, "SPBCCME_TROCA_EMPRESA_SWIFT", strParam);
                                                    if (drReversao != null)
                                                    {
                                                        if (drReversao.Tables[0].Rows.Count > 0)
                                                        {
                                                            //drReversao.Tables[0].Rows[0]["ID_LOTE"].ToString();
                                                            Dres = GravaLOG_Lancamento_CCMESwift(transaction, idSwift, "2003", "Empresa do Swift alterada automaticamente pelo Robô, ordem destinada a cliente com CCME ativa na moeda", Convert.ToInt32(oDBParametro.IdUser), Moeda, OrValor, Id_Lancamento, "A", 0, 0, "", OrigemLog.LC.ToString());
                                                        }
                                                    }


                                                }
                                                catch (Exception ErrReversao)
                                                {
                                                    oLogCCMESwift.DesLog = "Erro ao Reverter Empresa da Ordem: " + ErrReversao.Message.ToString() + " - " + ErrReversao.StackTrace;
                                                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                                    oLogCCMESwift.TpoLog = "E";
                                                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                                                }

                                            }

                                            if (valor_tarifa > 0)
                                            {
                                                if (cod_moeda_tarifa.Trim().Equals(Moeda.Trim()))
                                                {
                                                    saldoTarifa += OrValor;
                                                }

                                                if (saldoTarifa - valor_tarifa >= 0)
                                                {
                                                    // Efetua o débito da tarifa
                                                    drRetorno = RealizaLancamento(transaction,
                                                                                  Id_Cliente, cod_moeda_tarifa, "D", "ROBO",
                                                                                  valor_tarifa,
                                                                                  Convert.ToInt16(DtHis.Rows[0]["HIS_CODIGO"]),
                                                                                  id_lancRetorno,
                                                                                  "L", "LN", ObsLanc, 0,
                                                                                  Convert.ToDateTime(String.Format("{0:yyyy-MM-dd}", DtLancamento)),
                                                                                  Convert.ToDateTime("01/01/1900"), Convert.ToDateTime("01/01/1900"),
                                                                                  Convert.ToInt32(oDBParametro.IdUser),
                                                                                  Convert.ToInt32(dsSwift.Tables[0].Rows[i]["IDSwift"].ToString()),
                                                                                  dsSwift.Tables[0].Rows[i]["cl_num_doc"].ToString());

                                                    if (drRetorno.Tables[0].Rows.Count > 0)
                                                    {
                                                        Id_Lancamento = Convert.ToInt32(drRetorno.Tables[0].Rows[0][0].ToString());
                                                        MsgLog = "Lançamento da Tarifa ref. ao Recebimento de OP (" + OrValor + " " + cod_moeda_tarifa + ") efetuado com sucesso no valor " + valor_tarifa + " " + cod_moeda_tarifa;
                                                        Dres = GravaLOG_Lancamento_CCMESwift(transaction, idSwift, RETURN_VALUE.ToString(), MsgLog, Convert.ToInt32(oDBParametro.IdUser), cod_moeda_tarifa, valor_tarifa, Id_Lancamento, "A", 0, 0, "", OrigemLog.LC.ToString());
                                                    }
                                                    else
                                                    {
                                                        Id_Lancamento = -1;
                                                    }
                                                }
                                                else
                                                {
                                                    transaction.Rollback();
                                                    continue;
                                                }
                                            }
                                            id_lancRetorno = 0;
                                        }
                                    }
                                    else
                                    {
                                        MsgLog = "Cliente não possui Conta Ativa em (" + Moeda + ")";
                                        DataSet Dres = GravaLOG_Lancamento_CCMESwift(transaction, idSwift, "-999", MsgLog, Convert.ToInt32(oDBParametro.IdUser), Moeda, OrValor, Id_Lancamento, "E", 0, 0, "", OrigemLog.LC.ToString());
                                    }

                                    blLancamento = false;
                                }
                                obsLanc_msg = null;
                                transaction.Commit();

                                //O "analista" (Marcelo) solicitou pra fazer isso (idSwift != 258415), pois esta ordem apresenta algum problema
                                if (idSwift != 258415 && Id_Lancamento > 0
                                    && dsSwift.Tables[0].Rows[i]["CL_STATUS"].ToString().Equals("A")
                                    && !dsSwift.Tables[0].Rows[i]["EMPRESA"].ToString().Equals("COTACAO") 
                                    )
                                {
                                    TBL_PRE_BOLETO preboleto = new TBL_PRE_BOLETO();

                                    preboleto.id_cliente = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["ID_CLIENTE"].ToString());
                                    preboleto.EMPRESA = 1;
                                    preboleto.op_val_reais = Convert.ToDecimal(dsSwift.Tables[0].Rows[i]["ValorRecebido"].ToString());

                                    string tipoMoeda = string.Empty;

                                    switch (Moeda)
                                    {
                                        case "STG":
                                            tipoMoeda = "GBP";
                                            break;
                                        case "ATD":
                                            tipoMoeda = "AUD";
                                            break;
                                        case "CAN":
                                            tipoMoeda = "CAD";
                                            break;
                                        default:
                                            tipoMoeda = Moeda;
                                            break;
                                    }

                                    preboleto.op_tipo_moeda = tipoMoeda;

                                    string nomeCliente = dsSwift.Tables[0].Rows[i]["NOME"].ToString();
                                    string numeroContrato = Convert.ToString(Id_Lancamento); //dsSwift.Tables[0].Rows[i]["M20_SENDERREF"].ToString();
                                    string ordenante = dsSwift.Tables[0].Rows[i]["ORDENANTE"].ToString();

                                    oLogCCMESwift.DesMetodo = MethodBase.GetCurrentMethod().Name;
                                    oLogCCMESwift.DesLog = string.Format("Enviar e-mail Número Referência CCME: {0}, do Cliente: {1}, CL_STATUS: {2}, EMPRESA {3} ", numeroContrato, nomeCliente, dsSwift.Tables[0].Rows[i]["CL_STATUS"].ToString(), dsSwift.Tables[0].Rows[i]["EMPRESA"].ToString());
                                    oLogCCMESwift.TpoLog = "I";
                                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                                    // - Enviar e-mail para operações manual  
                                    EnviarEmailCCME(preboleto, IdSistemaPortalBRSA, nomeCliente, ordenante, numeroContrato);
                                }

                            }
                            catch (Exception Err)
                            {
                                if (transaction != null)
                                    transaction.Rollback();

                                // Grava na tabela de log
                                oLogCCMESwift.DesLog = "Erro : " + Err.Message.ToString() + " - " + Err.StackTrace;
                                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                oLogCCMESwift.TpoLog = "E";
                                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                            }

                        } //fim for

                    } //fim IF
                }

                catch (Exception e)
                {
                    // Grava na tabela de log
                    oLogCCMESwift.DesLog = "Erro : " + e.Message.ToString() + " - " + e.StackTrace;
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.TpoLog = "E";
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);


                }
            }
        }
        public void NotificarClienteComOrdensPendentes()
        {
            using (SqlConnection connection = new SqlConnection(this.strConexao))
            {
                connection.Open();
                try
                {
                    SqlParameter[] strParametros = new SqlParameter[1];
                    strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 30);
                    strParametros[0].Value = "ORDENS_SEMTAXA";

                    DataSet dsOrdens = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103_EMAIL_NOTIFICACAO", strParametros);

                    if (dsOrdens != null)
                    {
                        if (dsOrdens.Tables[0].Rows.Count > 0)
                        {
                            for (int i = 0; i <= dsOrdens.Tables[0].Rows.Count - 1; i++)
                            {
                                SqlTransaction transaction = connection.BeginTransaction();
                                try
                                {
                                    string SistemaEmail = null;
                                    if ((dsOrdens.Tables[0].Rows[i]["EMPRESA"].ToString().Equals("1")) &&
                                       (dsOrdens.Tables[0].Rows[i]["SISTEMA_ORIGEM"].ToString().Equals("PC")))
                                    {
                                        SistemaEmail = IdSistemaPortalBRSA;
                                    }
                                    if ((dsOrdens.Tables[0].Rows[i]["EMPRESA"].ToString().Equals("1")) &&
                                       (dsOrdens.Tables[0].Rows[i]["SISTEMA_ORIGEM"].ToString().Equals("SF")))
                                    {
                                        SistemaEmail = IdSistemaVarejoBRSA;
                                    }
                                    if ((dsOrdens.Tables[0].Rows[i]["EMPRESA"].ToString().Equals("2")) &&
                                       (dsOrdens.Tables[0].Rows[i]["SISTEMA_ORIGEM"].ToString().Equals("PC")))
                                    {
                                        SistemaEmail = IdSistemaPortalCOTA;
                                    }
                                    if ((dsOrdens.Tables[0].Rows[i]["EMPRESA"].ToString().Equals("2")) &&
                                       (dsOrdens.Tables[0].Rows[i]["SISTEMA_ORIGEM"].ToString().Equals("SF")))
                                    {
                                        SistemaEmail = IdSistemaVarejoCOTA;
                                    }

                                    DateTime DtInclusao = Convert.ToDateTime(dsOrdens.Tables[0].Rows[i]["op_data_inclusao"].ToString());
                                    string resposta = null;
                                    //Enviar e-mail de notificação 
                                    try
                                    {
                                        string dados = null;
                                        if (dsOrdens.Tables[0].Rows[i]["SISTEMA_ORIGEM"].ToString().Equals("PC"))
                                        {
                                            var infoEmail = new InfoEmail
                                            {
                                                IdSistema = SistemaEmail.ToString(),
                                                IdEmpresa = dsOrdens.Tables[0].Rows[i]["EMPRESA"].ToString(),
                                                Codigo = "52",
                                                ListaEmailPara = dsOrdens.Tables[0].Rows[i]["EmailPara"].ToString(),
                                                ListaEmailCc = "",
                                                Assunto = "Crédito recebido do exterior (" + dsOrdens.Tables[0].Rows[i]["op_n_boleto"].ToString() + ") - Aguardando retorno",
                                                ListaArquivos = null,
                                                ListaParametrosCorpo = new List<EmailService.Parametro>()
                                            };


                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "EnderecoExternoImagens", Valor = dsOrdens.Tables[0].Rows[i]["LINK"].ToString() + "/Cambio_On-line" });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "URL_COL", Valor = dsOrdens.Tables[0].Rows[i]["LINK"].ToString().Trim() });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "REMETENTE", Valor = dsOrdens.Tables[0].Rows[i]["Remetente"].ToString() });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "MOEDA", Valor = dsOrdens.Tables[0].Rows[i]["op_tipo_moeda"].ToString() });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "VALOR_ME", Valor = Convert.ToDecimal(dsOrdens.Tables[0].Rows[i]["op_val_moeda"]).ToString("N", new System.Globalization.CultureInfo("pt-BR").NumberFormat) });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "DATA", Valor = DtInclusao.ToString("dd/MM/yyyy") });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "COL", Valor = dsOrdens.Tables[0].Rows[i]["SISTEMA_ORIGEM"].ToString() });


                                            var serializer = new JavaScriptSerializer();
                                            dados = serializer.Serialize(infoEmail);
                                        }
                                        else
                                        {

                                            string UrlImagem = null;
                                            if (dsOrdens.Tables[0].Rows[i]["EMPRESA"].Equals(1))
                                            {
                                                UrlImagem = System.Configuration.ConfigurationManager.AppSettings.Get("URLImagensVArejoBRSA");
                                            }
                                            else
                                            {
                                                UrlImagem = System.Configuration.ConfigurationManager.AppSettings.Get("URLImagensVArejoCOTA");
                                            }

                                            var infoEmail = new InfoEmail
                                            {
                                                IdSistema = SistemaEmail,
                                                IdEmpresa = dsOrdens.Tables[0].Rows[i]["EMPRESA"].ToString(),
                                                Codigo = "37",
                                                ListaEmailPara = dsOrdens.Tables[0].Rows[i]["EmailPara"].ToString(),
                                                ListaEmailCc = "",
                                                Assunto = "Aviso de Ordem de Pagamento Recebida",
                                                ListaArquivos = null,
                                                ListaParametrosCorpo = new List<EmailService.Parametro>()
                                            };


                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "cl_email", Valor = dsOrdens.Tables[0].Rows[i]["EmailPara"].ToString() });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "nome", Valor = dsOrdens.Tables[0].Rows[i]["nome_cliente"].ToString() });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "op_n_boleto", Valor = Convert.ToInt32(dsOrdens.Tables[0].Rows[i]["op_n_boleto"].ToString()).ToString() });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "EnderecoExternoImagens", Valor = UrlImagem });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "op_inf_fav", Valor = dsOrdens.Tables[0].Rows[i]["op_inf_fav"].ToString() });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "op_val_moeda_aux", Valor = Convert.ToDecimal(dsOrdens.Tables[0].Rows[i]["op_val_moeda"].ToString()).ToString("N", new System.Globalization.CultureInfo("pt-BR").NumberFormat) });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "moeda", Valor = dsOrdens.Tables[0].Rows[i]["op_tipo_moeda"].ToString() });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "dataCredito", Valor = Convert.ToDateTime(dsOrdens.Tables[0].Rows[i]["op_data_inclusao"]).ToString("dd/MM/yyyy") });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "dataVencimento", Valor = Convert.ToDateTime(dsOrdens.Tables[0].Rows[i]["op_data_inclusao"]).AddDays(180).ToString("dd/MM/yyyy") });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "op_taxa_cambio_email", Valor = "false" });

                                            var serializer = new JavaScriptSerializer();
                                            dados = serializer.Serialize(infoEmail);
                                        }

                                        var rest = new RestClient(wsEmailService);
                                        resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));

                                        if (!resposta.Equals("Não foi possivel enviar o email"))//enviado com sucesso
                                        {
                                            oLogCCMESwift.DesLog = "E-mail: Enviado id: " + resposta + " Boleto: " + dsOrdens.Tables[0].Rows[i]["op_n_boleto"].ToString() + " Cliente:" + dsOrdens.Tables[0].Rows[i]["EmailPara"].ToString();
                                            oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                            oLogCCMESwift.TpoLog = "I";
                                            oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                                            //logar CRM o envio do Email 
                                            //"insert into TBL_CRM (id_usuario,id_corretora,crm_cpf_cnpj,crm_ocorrencia,crm_passaporte,crm_nboleto) values ('"&us_con&"','"&us_corretora_con&"','"&cl_num_doc&"','Email de Aviso de Ordem de Pagamento Recebida enviado para: "&cl_email&" | Taxa Sugerida: R$ "&FormataValor2(op_taxa_cambio_email)&" / US$.','"&cl_passaporte&"','"&op_n_boleto&"')"
                                        }
                                        else //erro ao enviar o email 
                                        {//Não foi possivel enviar o email
                                            oLogCCMESwift.DesLog = "Erro ao Enviar E-mail: Resposta=" + resposta + "  boleto:" + dsOrdens.Tables[0].Rows[i]["op_n_boleto"].ToString();
                                            oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                            oLogCCMESwift.TpoLog = "E";
                                            oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                                        }



                                    }
                                    catch (Exception x)
                                    {
                                        transaction.Rollback();
                                        oLogCCMESwift.DesLog = "Erro SendMail: Resposta=" + resposta + " Msg: " + x.Message.ToString() + " - " + x.StackTrace;
                                        oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                        oLogCCMESwift.TpoLog = "E";
                                        oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                                    }

                                    transaction.Commit();
                                }
                                catch (Exception DbEx)
                                {
                                    transaction.Rollback();
                                    oLogCCMESwift.DesLog = "Erro :  Msg: " + DbEx.Message.ToString() + " - " + DbEx.StackTrace;
                                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                    oLogCCMESwift.TpoLog = "E";
                                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                                }

                            }

                        }
                    }

                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.DesLog = "Notificar cliente com ordens pendentes";
                    oLogCCMESwift.TpoLog = "I";
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                }
                catch (Exception ex)
                {
                    //transaction.Rollback();
                    oLogCCMESwift.DesLog = "Erro Msg: " + ex.Message.ToString() + " - " + ex.StackTrace;
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.TpoLog = "E";
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                }
            }
        }

        public void PreBoletosGoogle(int NrBoleto = 0)
        {
            using (SqlConnection conexao = new SqlConnection(this.strConexao))
            {
                try
                {
                    conexao.Open();

                    //Obtém os parametros do robô
                    var roboParametros = oParametro.ConsultarParametro();

                    //Atualiza os registros google automaticamente, associando os registros com o id_cliente corretamente.

                    AtualizarAprovarAutomaticamenteSwifts(conexao);

                    //Verifica se arquivo a ser lido já foi carregado
                    SqlParameter[] strParametros = new SqlParameter[2];
                    strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 200);
                    strParametros[0].Value = "GERAR_PRE_BOLETO";
                    strParametros[1] = new SqlParameter("@FLAG_GOOGLE", SqlDbType.Bit);
                    strParametros[1].Value = 1;
                    /*
                    #if DEBUG 

                                        if (NrBoleto > 0)
                                        {
                                            strParametros[2] = new SqlParameter("@NrBoleto", SqlDbType.Int);
                                            strParametros[2].Value = NrBoleto;
                                        }
                    #endif*/
                    DataSet dsSwift = SqlHelper.ExecuteDataset(conexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103_LANCAMENTO", strParametros);

                    if (dsSwift.Tables.Count > 0 && dsSwift.Tables[0].Rows.Count > 0)
                    {
                        List<EmailGoogle> emailGoogleList = new List<EmailGoogle>();
                        for (int i = 0; i < (NrBoleto == 0 ? dsSwift.Tables[0].Rows.Count : 1); i++)
                        {
                            var transacao = conexao.BeginTransaction();

                            try
                            {
                                //Inteiros
                                int IdCliente = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["ID_CLIENTE"].ToString());
                                int idSwift = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["IDSwift"].ToString());
                                int idUserBoleto = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["ID_USER_ROBO"].ToString());
                                int idUserBoletoGoogle = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["ID_USER_ROBO_GOOGLE"].ToString());
                                int idCorretora = dsSwift.Tables[0].Rows[i]["id_corretora"] != null ? Convert.ToInt32(dsSwift.Tables[0].Rows[i]["id_corretora"].ToString()) : 1;
                                int paisBancoOrdem = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["PAIS_BANCO_ORDEM"].ToString());
                                int idUsuarioRobo = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["ID_USER_ROBO"].ToString());
                                //Decimais
                                decimal OrValorUSD = Convert.ToDecimal(dsSwift.Tables[0].Rows[i]["VALOR_USD"].ToString());
                                decimal tx_operacao = dsSwift.Tables[0].Rows[i]["TAXA"] != DBNull.Value ? Convert.ToDecimal(dsSwift.Tables[0].Rows[i]["TAXA"].ToString()) : 0;
                                decimal valor_me = Convert.ToDecimal(dsSwift.Tables[0].Rows[i]["VALOR_ME"].ToString());
                                decimal valor_mn = dsSwift.Tables[0].Rows[i]["VALOR_MN"] != DBNull.Value ? Convert.ToDecimal(dsSwift.Tables[0].Rows[i]["VALOR_MN"]) : 0;
                                //Datas
                                DateTime DtLancamento;
                                //Boleanos
                                bool blLancamento = false;
                                bool googleAutomatico = dsSwift.Tables[0].Rows[i]["flg_aceita_efet_auto_ordem"].ToString().Trim().Equals("S");
                                bool processaGooglePortal = dsSwift.Tables[0].Rows[i]["Flg_ProcessaGooglePortal"].ToString().Trim().Equals("S");
                                bool clienteIsentoIOF = dsSwift.Tables[0].Rows[i]["IOF_ISENTO"].ToString().Trim().Equals("S");
                                bool clienteIsentoIR = dsSwift.Tables[0].Rows[i]["IR_ISENTO"].ToString().Trim().Equals("S");
                                //Strings
                                string IDSistemaEmail = string.Empty;
                                string Moeda = TratarMoedas(dsSwift.Tables[0].Rows[i]["moeda"].ToString());
                                string operaSomenteBanco = dsSwift.Tables[0].Rows[i]["cl_OperaSomenteBanco"].ToString();
                                string nomeCliente = dsSwift.Tables[0].Rows[i]["NOME"].ToString();
                                string cliTipo = dsSwift.Tables[0].Rows[i]["cli_tipo"] != DBNull.Value ? dsSwift.Tables[0].Rows[i]["cli_tipo"].ToString().Trim() : string.Empty;
                                string clStatus = dsSwift.Tables[0].Rows[i]["CL_STATUS"].ToString();
                                string clienteNaoIdentificado = dsSwift.Tables[0].Rows[i]["CLIENTE_NAOIDENTIFICADO"].ToString();
                                string clNumeroDocumento = dsSwift.Tables[0].Rows[i]["CL_NUM_DOC"].ToString();
                                string clPassaporte = dsSwift.Tables[0].Rows[i]["CL_PASSAPORTE"].ToString();
                                string clCodVendedor = dsSwift.Tables[0].Rows[i]["CL_COD_VENDEDOR"].ToString();
                                string boletoAutomatico = dsSwift.Tables[0].Rows[i]["PreBoletoCompraAutomatico"].ToString();
                                string empresa = dsSwift.Tables[0].Rows[i]["Empresa"].ToString();
                                string auxDatamnme = dsSwift.Tables[0].Rows[i]["DIASMNME"].ToString();
                                string acessaPortal = dsSwift.Tables[0].Rows[i]["ACESSAPORTAL"].ToString().Trim();
                                string acessaPortalCotacao = dsSwift.Tables[0].Rows[i]["PORTALCOTACAO"].ToString().Trim();
                                string nomeBancoOrdem = dsSwift.Tables[0].Rows[i]["NOME_BANCO_ORDEM"].ToString().Replace("\r\n", "");
                                string bancoOrdem = dsSwift.Tables[0].Rows[i]["BANCO_ORDEM"].ToString().Replace("\r\n", "");
                                string ordenante = removerCaracteresEstranhos(dsSwift.Tables[0].Rows[i]["ORDENANTE"].ToString().Replace("\r\n", ""));
                                string link = dsSwift.Tables[0].Rows[i]["LINK"].ToString().Replace("\r\n", "");
                                string obsLanc_msg = null;
                                bool flag_virada_geral = dsSwift.Tables[0].Rows[i]["Flag_virada_geral"].ToString().Trim().Equals("1");

                                if (/*(clStatus.Equals("A")) &&*/
                                    (clienteNaoIdentificado.Equals("N")) &&
                                    /*acessaPortal.Equals("A") &&*/
                                    (boletoAutomatico.Equals("S")) && (empresa.Equals("BRSA")) && (processaGooglePortal || flag_virada_geral))
                                {
                                    GetDataLancamento(transacao,
                                          idSwift,
                                          Convert.ToDateTime(dsSwift.Tables[0].Rows[i]["VALUE_DATE"]),
                                          dsSwift.Tables[0].Rows[i]["moeda"].ToString(),
                                          valor_me,
                                          "BO",
                                          out DtLancamento,
                                          out blLancamento,
                                          out obsLanc_msg);

                                    TBL_PRE_BOLETO pre = new TBL_PRE_BOLETO();


                                    // - Campos null conforme criação no Varejo
                                    pre.ID_EMPRESA_REMITANCE = null;
                                    pre.ID_BENEFICIARIO = null;
                                    pre.taxa_IR = null;
                                    pre.Vlr_IR = null;
                                    pre.valor_moeda_ir = null;
                                    pre.valor_reais_ir = null;
                                    pre.id_corretora_envio = null;
                                    pre.sistema_origem = "PC";
                                    pre.ID_USER_EDICAO = null;
                                    pre.aux_datamnme = auxDatamnme;
                                    pre.id_corretora = idCorretora; //pegar da tabela de clientes
                                    pre.id_user_criacao = idUserBoleto;
                                    pre.ID_USER_EDICAO = idUserBoletoGoogle;
                                    pre.id_user_corretora = 0;
                                    pre.id_user_banco = 0;
                                    pre.id_cliente = IdCliente;
                                    pre.op_tipo_operacao = "C";
                                    pre.op_tipo_entrega = "ORDEM";//COMPRA.ASP
                                    pre.op_tipo_moeda = Moeda;
                                    pre.op_status = "P";
                                    pre.OP_DADOS_SWIFT = "0";
                                    pre.EMPRESA = 1;
                                    pre.op_numero_ordem = formatarNumeroOrdem(dsSwift.Tables[0].Rows[i]["ID_LANC"].ToString());
                                    pre.op_data_sistema = DateTime.Now;
                                    pre.op_data_boleto = DateTime.Now;
                                    pre.op_val_moeda = valor_me;
                                    pre.op_val_reais = valor_mn;

                                    //Se acesso ao portal de cambio     
                                    //if (processaGooglePortal)
                                    //{
                                    //pre.sistema_origem = "PC";
                                    IDSistemaEmail = IdSistemaPortalBRSA;
                                    //}
                                    //else
                                    //{
                                    //    pre.sistema_origem = "SF";
                                    //    IDSistemaEmail = IdSistemaVarejoCOTA;
                                    //}

                                    // - Se for cliente automatico google, calcula e lança automaticamente, caso contrário não calcula e fica com o pre_boleto_status = 0
                                    if (googleAutomatico)
                                    {
                                        CalcularBoletoGoogle(transacao, clienteIsentoIOF, cliTipo, pre);
                                        pre.op_grupo1 = "1";
                                        pre.op_grp_bancarios = 1;
                                        decimal op_tarifa_operacao = CalculaTarifaOperacao(pre.id_cliente.ToString(), pre.op_tipo_moeda, "C", pre.op_tipo_entrega, pre.op_val_moeda);
                                        pre.op_valor1 = pre.op_val_reais.Value - pre.op_tarifa_operacao - pre.Vlr_IOF;
                                        //pre
                                    }
                                    else
                                    {
                                        pre.op_grupo1 = "0";
                                        pre.op_valor1 = 0;
                                    }

                                    pre.op_tipo_liq = "";

                                    // - aprovacao_credito
                                    if (pre.op_val_reais.HasValue && pre.op_val_reais > 0)
                                    {
                                        pre.aprovacao_credito = "S"; // - Simplificando regra do Varejo 
                                    }

                                    if (pre.op_val_reais.HasValue && pre.op_val_reais > 0 && valor_mn == 0)
                                    {
                                        valor_mn = pre.op_val_reais.Value;
                                    }

                                    // - Aprova documentação e assina boleto
                                    AprovarDocumentacao(transacao, pre, valor_mn, true);

                                    // - aprovacao_compliance 
                                    AprovacaoCompliance(pre);

                                    // - Aprovação contra partida
                                    AprovarContraPartida(transacao, pre, idSwift, empresa);

                                    // - Leitura dados swift
                                    LeituraDadosSwift(pre);

                                    pre.op_inf_compl = "Boleto incluido via RoboSwift em " + DateTime.Now + " referente a Ordem de Pagamento No." + pre.op_numero_ordem;
                                    pre.op_inf_fav = ordenante;

                                    if (nomeBancoOrdem.Length > 0)
                                    {
                                        pre.op_swift_code = bancoOrdem;
                                        pre.op_inf_banco = nomeBancoOrdem;
                                        pre.OP_PAISES = paisBancoOrdem;
                                    }
                                    else
                                    {
                                        pre.op_swift_code = null;
                                        pre.op_inf_banco = null;
                                        pre.OP_PAISES = paisBancoOrdem;
                                    }
                                    pre.op_verificada = "S";
                                    pre.op_data_follow_up = DtLancamento; //Verificar
                                    pre.id_filial = 0;//

                                    pre.foiprocessadaremessaexpressa = true;

                                    pre.CRM_OCORRENCIA = "Pré-Boleto de Compra criado automaticamente pelo Robô Swift referente a Ordem de Pagamento No. " + pre.op_numero_ordem + "- Pré-Boleto:";
                                    pre.CRM_CPF_CNPJ = clNumeroDocumento;
                                    pre.CRM_PASSAPORTE = clPassaporte;
                                    pre.op_vend_comp = clCodVendedor;

                                    if (pre.op_tx_operacao == 0)
                                    {
                                        pre.op_tx_operacao = null;
                                    }
                                    
                                    // - Adiciona o ColPreBoleto automaticamente com status 1
                                    pre.pre_boleto_status = 0;
                                    if (googleAutomatico)
                                    {
                                        var natureza = BuscarNatureza(Convert.ToInt32(pre.op_natureza), transacao);
                                        if (natureza != null)
                                            pre.op_inf_motivo = natureza.Descricao;
                                        
                                        pre.op_tipo_liq = "TED";
                                        pre.op_inf_operacao = nomeCliente;

                                    }

                                    // - Insere o preboleto
                                    if (NrBoleto > 0)
                                    {
                                        EnviarEmail_Test obj = new EnviarEmail_Test();
                                        pre = obj.GetPreBoleto(NrBoleto);
                                        cliTipo = "CPF";
                                    }
                                    else
                                        CriarPreBoleto(transacao, pre, googleAutomatico, true);


                                    GravaLOG_Lancamento_CCMESwift(transacao,
                                                                         idSwift,
                                                                         "2000",
                                                                         "Pré-boleto No." + pre.op_n_boleto + " criado no sistema " + pre.sistema_origem + ", referente a Ordem de Pagamento No." + pre.op_numero_ordem,
                                                                         Convert.ToInt32(oDBParametro.IdUser),
                                                                         Moeda,
                                                                         valor_me, -1, "A",
                                                                         pre.op_n_boleto,
                                                                         (empresa.Equals("BRSA") ? 1 : 2),
                                                                         pre.sistema_origem, OrigemLog.BO.ToString());


                                    //Insere registro na TBL_COL_STATUS_PREBOLETO, com status de acordo com a Ordem 

                                    Inserir_COL_Status_Pre_boleto(transacao, pre.op_n_boleto, pre.EMPRESA);

                                    StringBuilder sbUp = new StringBuilder();
                                    sbUp.Append("UPDATE TBL_CRM SET ");
                                    sbUp.AppendFormat("CRM_NBOLETO={0} WHERE crm_cpf_cnpj='{1}' AND crm_ocorrencia LIKE '%{2}%'", pre.op_n_boleto, clNumeroDocumento, pre.op_n_boleto);

                                    SqlHelper.ExecuteNonQuery(transacao, CommandType.Text, sbUp.ToString());

                                    // - aprovacao_contrapartida - Log CRM
                                    AprovarContraPartidaLog(transacao, pre, idUsuarioRobo, pre.op_n_boleto.ToString(), clNumeroDocumento);
                                    if (clStatus.Equals("I"))
                                    {
                                        pre.op_tx_operacao = null;
                                        googleAutomatico = false;
                                    }

                                    emailGoogleList.Add(new EmailGoogle(pre, IDSistemaEmail, nomeCliente, link, googleAutomatico, cliTipo));

                                }
                                else
                                {
                                    GravarLogLancamento(empresa, clienteNaoIdentificado, acessaPortal, operaSomenteBanco, boletoAutomatico, clStatus, idSwift, Moeda, valor_me, processaGooglePortal, transacao);
                                }

                                transacao.Commit();
                            }
                            catch (Exception ex)
                            {
                                transacao.Rollback();
                                // Grava na tabela de log
                                oLogCCMESwift.DesLog = "Erro : " + ex.Message.ToString() + " - " + ex.StackTrace;
                                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                oLogCCMESwift.TpoLog = "E";
                                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                            }
                        }
                        oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                        oLogCCMESwift.DesLog = "Fim da Criação de Pre Boleto Google";
                        oLogCCMESwift.TpoLog = "I";
                        oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                        oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                        oLogCCMESwift.DesLog = "Início dos envios de e-mail Google";
                        oLogCCMESwift.TpoLog = "I";
                        oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                        foreach (EmailGoogle emailGoogle in emailGoogleList)
                        {

                            var transacao = conexao.BeginTransaction();
                            try
                            {
                                if (emailGoogle.googleAutomatico)
                                {
                                    if (!string.IsNullOrWhiteSpace(emailGoogle.pre.op_assinado) && emailGoogle.pre.op_assinado == "N")
                                    {
                                        // - Enviar e-mail para operações automáticas que tem pendências de procuração
                                        EnviarEmailGoogleAutomaticoOperacoesEmAberto(transacao, emailGoogle.pre, emailGoogle.IDSistemaEmail, emailGoogle.nomeCliente, emailGoogle.link, emailGoogle.googleAutomatico, emailGoogle.cliTipo);
                                    }
                                    else
                                    {
                                        // - Enviar e-mail para operações automáticas que não tem pendências  
                                        EnviarEmailGoogleAutomaticoOperacoesFinalizadas(transacao, emailGoogle.pre, emailGoogle.IDSistemaEmail, emailGoogle.nomeCliente, emailGoogle.link, emailGoogle.googleAutomatico, emailGoogle.cliTipo);
                                    }
                                }
                                else
                                {
                                    // - Enviar e-mail para operações manual  
                                    EnviarEmailGoogleManual(transacao, emailGoogle.pre, emailGoogle.IDSistemaEmail, emailGoogle.nomeCliente, emailGoogle.link, emailGoogle.googleAutomatico, emailGoogle.cliTipo);
                                }
                                transacao.Commit();
                            }
                            catch (Exception ex)
                            {
                                transacao.Rollback();
                                oLogCCMESwift.DesLog = string.Format(@"Erro Envio de email Google - Boleto : {0} - Msg : {1} - Stack : {2}", emailGoogle.pre.op_n_boleto, ex.Message.ToString(), ex.StackTrace);
                                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                oLogCCMESwift.TpoLog = "E";
                                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                            }
                        }

                        oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                        oLogCCMESwift.DesLog = "Fim dos envios de e-mail Google";
                        oLogCCMESwift.TpoLog = "I";
                        oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                    }

                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.DesLog = "Fim da execução";
                    oLogCCMESwift.TpoLog = "I";
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                }
                catch (Exception ex)
                {
                    // Grava na tabela de log
                    oLogCCMESwift.DesLog = "Erro PreBoleto Google: " + ex.Message.ToString() + " - " + ex.StackTrace;
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.TpoLog = "E";
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                }
            }
        }

        public void PreBoletosNaoGoogle()
        {
            using (SqlConnection connection = new SqlConnection(this.strConexao))
            {
                connection.Open();

                try
                {
                    string IDSistemaEmail = null;
                    //string MsgLog = null;
                    //string ObsLanc = null;
                    string obsLanc_msg = null;
                    DateTime DtLancamento;
                    bool blLancamento = false;
                    DataSet Dres;
                    int ID_USER_BOLETO = 0;

                    //Verifica se arquivo a ser lido já foi carregado
                    SqlParameter[] strParametros = new SqlParameter[1];
                    strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 200);
                    strParametros[0].Value = "GERAR_PRE_BOLETO";

                    DataSet dsSwift = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103_LANCAMENTO", strParametros);

                    if (dsSwift.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i <= dsSwift.Tables[0].Rows.Count - 1; i++)
                        {
                            SqlTransaction transaction = connection.BeginTransaction();

                            try
                            {
                                int Id_Cliente = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["ID_CLIENTE"].ToString());
                                int idSwift = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["IDSwift"].ToString());
                                decimal OrValor = Convert.ToDecimal(dsSwift.Tables[0].Rows[i]["VALOR_ME"].ToString());
                                decimal OrValorUSD = Convert.ToDecimal(dsSwift.Tables[0].Rows[i]["VALOR_USD"].ToString());
                                string Moeda = string.Empty;
                                string cli_tipo = dsSwift.Tables[0].Rows[i]["cli_tipo"] != null ? dsSwift.Tables[0].Rows[i]["cli_tipo"].ToString() : string.Empty;

                                switch (dsSwift.Tables[0].Rows[i]["moeda"].ToString())
                                {
                                    case "EUR":
                                        Moeda = "EURO";
                                        break;
                                    case "GBP":
                                        Moeda = "STG";
                                        break;
                                    case "AUD":
                                        Moeda = "ATD";
                                        break;
                                    case "CAD":
                                        Moeda = "CAN";
                                        break;
                                    case "JPY":
                                        Moeda = "YEN";
                                        break;
                                    default:
                                        Moeda = dsSwift.Tables[0].Rows[i]["moeda"].ToString();
                                        break;
                                }

                                if (((dsSwift.Tables[0].Rows[i]["CL_STATUS"].ToString().Equals("A")) &&
                                     (dsSwift.Tables[0].Rows[i]["CLIENTE_NAOIDENTIFICADO"].ToString().Equals("N")) &&
                                     (dsSwift.Tables[0].Rows[i]["PreBoletoCompraAutomatico"].ToString().Equals("S")) &&
                                     (dsSwift.Tables[0].Rows[i]["Empresa"].ToString() == "BRSA") //&&  //ordem BRSA e OperaSomente banco S
                                                                                                 //(dsSwift.Tables[0].Rows[i]["cl_OperaSomenteBanco"].Equals("S")) 
                                     ) ||
                                     ((dsSwift.Tables[0].Rows[i]["CL_STATUS"].ToString().Equals("A")) &&
                                     (dsSwift.Tables[0].Rows[i]["CLIENTE_NAOIDENTIFICADO"].ToString().Equals("N")) &&
                                     (dsSwift.Tables[0].Rows[i]["PreBoletoCompraAutomatico"].ToString().Equals("S")) &&
                                     (dsSwift.Tables[0].Rows[i]["Empresa"].ToString() == "COTACAO") &&  //ordem cotacao e OperaSomente banco N
                                     (dsSwift.Tables[0].Rows[i]["cl_OperaSomenteBanco"].Equals("N")) &&
                                     (!string.IsNullOrEmpty(dsSwift.Tables[0].Rows[i]["ID_LANC"].ToString()))
                                     ))
                                {
                                    //--------------------------------------------------------------------------------------------------------------------------------------------------------
                                    //--------------------------------------------------------------------------------------------------------------------------------------------------------
                                    //TESTA VALUE DATE - ME=0



                                    GetDataLancamento(transaction,
                                                      idSwift,
                                                      Convert.ToDateTime(dsSwift.Tables[0].Rows[i]["VALUE_DATE"]),
                                                      dsSwift.Tables[0].Rows[i]["moeda"].ToString(),
                                                      OrValor,
                                                      "BO",
                                                      out DtLancamento,
                                                      out blLancamento,
                                                      out obsLanc_msg);

                                    ModelosCambio.TBL_PRE_BOLETO pre = new ModelosCambio.TBL_PRE_BOLETO();

                                    // - Campos null conforme criação no Varejo
                                    pre.ID_EMPRESA_REMITANCE = null;
                                    pre.ID_BENEFICIARIO = null;
                                    pre.taxa_IR = null;
                                    pre.Vlr_IR = null;
                                    pre.valor_moeda_ir = null;
                                    pre.valor_reais_ir = null;
                                    pre.id_corretora_envio = null;
                                    pre.sistema_origem = "SF";
                                    pre.ID_USER_EDICAO = null;
                                    //COTACAO
                                    if (dsSwift.Tables[0].Rows[i]["Empresa"].ToString() != "COTACAO")
                                    {
                                        pre.EMPRESA = 1;
                                        ID_USER_BOLETO = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["ID_USER_ROBO"].ToString());
                                        pre.op_numero_ordem = formatarNumeroOrdem(dsSwift.Tables[0].Rows[i]["NUMERO"].ToString());
                                        //Se acesso ao portal de cambio 
                                        if ((dsSwift.Tables[0].Rows[i]["ACESSAPORTAL"].Equals("A"))
                                         && (dsSwift.Tables[0].Rows[i]["PORTALCOTACAO"].Equals("S")))
                                        {
                                            pre.sistema_origem = "PC";
                                            //preboleto DBVAREJO, sistema_origem = PC
                                            IDSistemaEmail = IdSistemaPortalBRSA;
                                        }
                                        else if ((dsSwift.Tables[0].Rows[i]["ACESSAPORTAL"].Equals("N"))
                                             || (dsSwift.Tables[0].Rows[i]["PORTALCOTACAO"].Equals("N")))
                                        {
                                            pre.sistema_origem = "SF";
                                            IDSistemaEmail = IdSistemaVarejoBRSA;
                                            //pre_coleto DB_VAREJO, sistema_origem = SF
                                        }
                                    }
                                    //BRSA -- SEM CCME
                                    else
                                    {
                                        pre.EMPRESA = 2;
                                        ID_USER_BOLETO = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["ID_USER_ROBO"].ToString());
                                        pre.op_numero_ordem = formatarNumeroOrdem(dsSwift.Tables[0].Rows[i]["ID_LANC"].ToString());
                                        //Se acesso ao portal de cambio     
                                        if ((dsSwift.Tables[0].Rows[i]["ACESSAPORTAL"].Equals("A"))
                                         && (dsSwift.Tables[0].Rows[i]["PORTALCOTACAO"].Equals("S")))
                                        {
                                            pre.sistema_origem = "PC";
                                            //preboleto IK_VAREJO, sistema_origem = PC
                                            IDSistemaEmail = IdSistemaPortalCOTA;
                                        }
                                        else if ((dsSwift.Tables[0].Rows[i]["ACESSAPORTAL"].Equals("N"))
                                             || (dsSwift.Tables[0].Rows[i]["PORTALCOTACAO"].Equals("N")))
                                        {
                                            pre.sistema_origem = "SF";
                                            //pre_coleto IK_VAREJO, sistema_origem = SF
                                            IDSistemaEmail = IdSistemaVarejoCOTA;
                                        }
                                    }

                                    //1. Validar se cliente possui conta CCME = OK
                                    //2. Cliente possui Portal de Cambio, qual COTAÇÂO/RENDIMENTO = OK
                                    pre.aux_datamnme = dsSwift.Tables[0].Rows[i]["DIASMNME"].ToString();

                                    pre.id_corretora = dsSwift.Tables[0].Rows[i]["id_corretora"] != null ? Convert.ToInt32(dsSwift.Tables[0].Rows[i]["id_corretora"].ToString()) : 1; //pegar da tabela de clientes
                                    pre.id_user_criacao = ID_USER_BOLETO;
                                    pre.id_user_corretora = 0;
                                    pre.id_user_banco = 0;
                                    pre.id_cliente = Id_Cliente;
                                    pre.op_tipo_operacao = "C";
                                    pre.op_tipo_entrega = "ORDEM";//COMPRA.ASP
                                    pre.op_tipo_moeda = Moeda;
                                    pre.op_status = "P";
                                    pre.OP_DADOS_SWIFT = "0";

                                    //pre.Txa_IOF = 0;
                                    //pre.Vlr_IOF = 0; 


                                    decimal valor_mn = dsSwift.Tables[0].Rows[i]["VALOR_MN"] != DBNull.Value ? Convert.ToDecimal(dsSwift.Tables[0].Rows[i]["VALOR_MN"]) : 0;

                                    // ----------------------------------------------------------------------
                                    // SE NÃO FOR BOFA, OU SEJA, NÃO VEM COM A TAXA FECHADA
                                    // ----------------------------------------------------------------------

                                    if (valor_mn.Equals(0))
                                    {
                                        pre.op_tx_operacao = 0;
                                        pre.op_val_moeda = OrValor;
                                        pre.op_val_reais = null; // Ao criar o pre-boleto deve-se colocar op_val_reais = NULL e não 0 (somente quando for BOFA essa regra não é valida) - Igor em 12/05/2015
                                        pre.op_resul_minimo = 0;

                                        DataSet ds;
                                        decimal[] taxas = CalculaTaxaPronto(pre.op_tipo_moeda, "C");

                                        // - Cálculo op_tx_operacao
                                        pre.op_tx_operacao = dsSwift.Tables[0].Rows[i]["TAXA"] != DBNull.Value ? Convert.ToDecimal(dsSwift.Tables[0].Rows[i]["TAXA"].ToString()) : 0;
                                        // - Cálculo op_taxa_pronto_d

                                        ds = new DataSet();
                                        ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, "select tx_compra from Varejo..TMOEDAS where cod_moeda = 'USD'");
                                        pre.op_taxa_pronto_d = ds.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(ds.Tables[0].Rows[0]["tx_compra"].ToString()) : 0;


                                        // - Cálculo op_tarifa_banco e op_tarifa_banco_d
                                        decimal tarifa_banco_d = CalculaTarifaBanco(pre.op_tipo_moeda, "C", pre.op_tipo_entrega, pre.op_val_moeda);
                                        // taxas[1] => taxaPronto_d

                                        pre.op_tarifa_banco = Math.Round(tarifa_banco_d * taxas[1], 2, MidpointRounding.AwayFromZero);
                                        pre.op_tarifa_banco_d = tarifa_banco_d;
                                        pre.op_paridade = taxas[2];
                                        // - Cálculo op_tarifa_operacao - mesmo cálculo do COL                                        
                                        // taxas[1] => taxaPronto_d
                                        decimal op_tarifa_operacao = CalculaTarifaOperacao(pre.id_cliente.ToString(), pre.op_tipo_moeda, "C", pre.op_tipo_entrega, pre.op_val_moeda);
                                        pre.op_tarifa_operacao = Math.Round(op_tarifa_operacao * taxas[1], 2, MidpointRounding.AwayFromZero);
                                    }
                                    else
                                    {
                                        DataSet ds;

                                        decimal[] taxas = CalculaTaxaPronto(pre.op_tipo_moeda, "C");

                                        decimal valor_me = dsSwift.Tables[0].Rows[i]["VALOR_ME"] != DBNull.Value ? Convert.ToDecimal(dsSwift.Tables[0].Rows[i]["VALOR_ME"].ToString()) : 0;
                                        pre.op_val_moeda = valor_me;
                                        pre.op_val_reais = valor_mn;

                                        // - Cálculo op_tx_operacao
                                        pre.op_tx_operacao = dsSwift.Tables[0].Rows[i]["TAXA"] != DBNull.Value ? Convert.ToDecimal(dsSwift.Tables[0].Rows[i]["TAXA"].ToString()) : 0;


                                        // - Cálculo op_taxa_pronto_d
                                        ds = new DataSet();
                                        ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, "select tx_compra from Varejo..TMOEDAS where cod_moeda = 'USD'");
                                        pre.op_taxa_pronto_d = ds.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(ds.Tables[0].Rows[0]["tx_compra"].ToString()) : 0;


                                        // - Cálculo op_tarifa_banco e op_tarifa_banco_d
                                        decimal tarifa_banco_d = CalculaTarifaBanco(pre.op_tipo_moeda, "C", pre.op_tipo_entrega, pre.op_val_moeda);
                                        // taxas[1] => taxaPronto_d

                                        pre.op_tarifa_banco = Math.Round(tarifa_banco_d * taxas[1], 2, MidpointRounding.AwayFromZero);
                                        pre.op_tarifa_banco_d = tarifa_banco_d;

                                        ds = new DataSet();
                                        ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("select * from tbl_moedas where moe_simbolo = '{0}'", pre.op_tipo_moeda));
                                        decimal moe_desvio = ds.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(ds.Tables[0].Rows[0]["moe_desvio"].ToString()) : 0;

                                        pre.op_taxa_banco = Math.Round(taxas[0] + ((moe_desvio * taxas[0]) / 100), 6, MidpointRounding.AwayFromZero);
                                        //pre.op_paridade = ds.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(ds.Tables[0].Rows[0]["paridade"].ToString()) : 0;

                                        // taxas[2] => paridade
                                        pre.op_paridade = taxas[2];


                                        // - Cálculo op_tarifa_operacao - mesmo cálculo do COL                                        
                                        // taxas[1] => taxaPronto_d
                                        decimal op_tarifa_operacao = CalculaTarifaOperacao(pre.id_cliente.ToString(), pre.op_tipo_moeda, "C", pre.op_tipo_entrega, pre.op_val_moeda);
                                        pre.op_tarifa_operacao = Math.Round(op_tarifa_operacao * taxas[1], 2, MidpointRounding.AwayFromZero);

                                        // - Cálculo op_spread
                                        decimal spread = pre.op_val_moeda * (pre.op_taxa_banco - Convert.ToDecimal(pre.op_tx_operacao));
                                        pre.op_spread = spread; // calcular  spread = cdbl(op_val_moeda) * (cdbl(taxa_banco) - cdbl(op_tx_operacao)) editar_op_c.asp   


                                        // - op_resul_minimo
                                        //decimal aux = (cl_tarifa - pre.op_tx_operacao);
                                        decimal aux = (op_tarifa_operacao - Convert.ToDecimal(pre.op_tx_operacao));
                                        decimal resultado_minimo = 0;

                                        if (pre.op_val_moeda > 0 && pre.op_tx_operacao > 0)
                                            resultado_minimo = spread + aux;

                                        pre.op_resul_minimo = resultado_minimo;
                                    }

                                    //30-06-2015 - removido o tratamento de grupos bancários do pre boleto, 
                                    // por solicitação dos analistas
                                    //chamado 329119 - correções pós implantação
                                    pre.op_grupo1 = "0";
                                    pre.op_valor1 = 0;
                                    pre.op_tipo_liq = "";

                                    // - aprovacao_credito
                                    if (pre.op_val_reais > 0) pre.aprovacao_credito = "S"; // - Simplificando regra do Varejo 


                                    // - aprovacao_documentos
                                    DataSet dsDataSet = new DataSet();
                                    dsDataSet = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("select V.paridade, M.moe_tipo from Varejo..TMOEDAS V, ik_varejo..TBL_MOEDAS M where V.cod_moeda COLLATE DATABASE_DEFAULT = M.moe_simbolo and V.cod_moeda='{0}'", pre.op_tipo_moeda));

                                    decimal paridade = dsDataSet.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(dsDataSet.Tables[0].Rows[0]["paridade"].ToString()) : 0;
                                    string moe_tipo = dsDataSet.Tables[0].Rows.Count > 0 ? dsDataSet.Tables[0].Rows[0]["moe_tipo"].ToString() : string.Empty;
                                    decimal valor_conv = 0;

                                    if (paridade > 1)
                                    {
                                        if (moe_tipo.Equals("B"))
                                            valor_conv = (pre.op_val_moeda * paridade);
                                        else
                                            valor_conv = (pre.op_val_moeda / paridade);
                                    }
                                    else
                                        valor_conv = (pre.op_val_moeda * paridade);

                                    pre.aprovacao_documentos = GetAprovAuto("C", valor_conv);


                                    // - op_assinado
                                    if (valor_mn.Equals(0) || string.IsNullOrEmpty(valor_mn.ToString()))
                                    {
                                        pre.op_assinado = null;
                                    }
                                    else
                                    {
                                        pre.op_assinado = valor_conv > 0 ? GetAprovAuto("V", valor_conv) : "N";
                                    }


                                    // - aprovacao_compliance 
                                    AprovacaoCompliance(pre);

                                    #region Código Substituido Por Metódo
                                    //string complianceReceita = "N";

                                    //if (consultaDoc(pre.id_cliente).Equals("NOK"))
                                    //    complianceReceita = "S";

                                    //if (complianceReceita.Equals("S"))
                                    //    pre.aprovacao_compliance = "N";
                                    //else
                                    //{
                                    //    if (pre.op_val_reais > 0)
                                    //    {
                                    //        dsDataSet = new DataSet();
                                    //        dsDataSet = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("SELECT cl_nivel_compliance FROM TBL_CLIENTES (NOLOCK) WHERE id_cliente = {0}", pre.id_cliente));
                                    //        string cl_nivel_compliance = dsDataSet.Tables[0].Rows.Count > 0 ? dsDataSet.Tables[0].Rows[0]["cl_nivel_compliance"].ToString() : string.Empty;

                                    //        decimal complianceMes = 0, complianceAno = 0;

                                    //        if (cl_nivel_compliance.Equals("Especial"))
                                    //        {
                                    //            dsDataSet = new DataSet();
                                    //            dsDataSet = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("SELECT ISNULL(comp_mes, 0) AS comp_mes, ISNULL(comp_ano, 0) AS comp_ano FROM TBL_CLIENTES WHERE id_cliente = {0}", pre.id_cliente));
                                    //            complianceMes = dsDataSet.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(dsDataSet.Tables[0].Rows[0]["comp_mes"].ToString()) : 0;
                                    //            complianceAno = dsDataSet.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(dsDataSet.Tables[0].Rows[0]["comp_ano"].ToString()) : 0;
                                    //        }
                                    //        else
                                    //        {
                                    //            complianceMes = Nivel_Compliance("m", cl_nivel_compliance);
                                    //            complianceAno = Nivel_Compliance("a", cl_nivel_compliance);
                                    //        }

                                    //        decimal valor_oper_m = Valor_Operado_Compliance("m", pre.id_cliente, 0);
                                    //        decimal creditoCompliance = Math.Round((complianceMes - valor_oper_m), 2);

                                    //        if (pre.op_val_reais > creditoCompliance)
                                    //            pre.aprovacao_compliance = "N";

                                    //        decimal valor_oper_a = Valor_Operado_Compliance("a", pre.id_cliente, 0);
                                    //        creditoCompliance = Math.Round((complianceAno - valor_oper_a), 2);

                                    //        if (pre.op_val_reais > creditoCompliance)
                                    //            pre.aprovacao_compliance = "N";
                                    //    }
                                    //    else
                                    //        pre.aprovacao_compliance = "N";
                                    //}
                                    #endregion

                                    // - aprovacao_contrapartida
                                    /*
                                    dsDataSet = new DataSet();                                    
                                    dsDataSet = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("SELECT ISNULL(dbo.fn_RetornarValorMoeda({0}, 'USD'), 0) AS VALOR_USD", pre.op_val_moeda.ToString().Replace(",", ".")));
                                    decimal valor_usd = Convert.ToDecimal(dsDataSet.Tables[0].Rows[0]["VALOR_USD"].ToString());

                                    dsDataSet = new DataSet();
                                    dsDataSet = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, "SELECT VL_CAMPO FROM TBL_VAREJO_PARAMETROS WHERE NM_CAMPO = 'ValorLimiteAprovaContraPartidaAutomaticaUSD'");
                                    decimal valor_contrapartida = Convert.ToDecimal(dsDataSet.Tables[0].Rows[0]["VL_CAMPO"].ToString());

                                    pre.aprovacao_contrapartida = (valor_usd <= valor_contrapartida) ? "S" : "N";*/

                                    // Aprovacao da contraPartida pelo Limite do usuario ROBO_CCME_SWIFT
                                    if (string.IsNullOrEmpty(pre.op_val_reais.ToString()))
                                    {
                                        pre.aprovacao_contrapartida = AprovaContraPartidaPorLimite(dsSwift.Tables[0].Rows[i]["Empresa"].ToString(), pre.op_taxa_pronto_d, pre.op_val_moeda, pre.op_val_reais.ToString());
                                    }

                                    if ((string.IsNullOrEmpty(pre.aprovacao_contrapartida)) && (string.IsNullOrEmpty(pre.op_val_reais.ToString())))
                                    {
                                        SqlParameter paramContraPartida = new SqlParameter("@IDSWIFT", SqlDbType.Int);
                                        paramContraPartida.Value = idSwift;

                                        dsDataSet = new DataSet();
                                        dsDataSet = SqlHelper.ExecuteDataset(strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103_APROVA_CONTRAPARTIDA", paramContraPartida);
                                        pre.aprovacao_contrapartida = (dsDataSet.Tables[0].Rows.Count > 0 && !dsDataSet.Tables[0].Rows[0]["APROVADA_CC"].ToString().Equals("")) ? dsDataSet.Tables[0].Rows[0]["APROVADA_CC"].ToString() : "N";
                                    }

                                    // - c50k_dados_swift
                                    dsDataSet = new DataSet();
                                    dsDataSet = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("SELECT cl_nome, cl_tip_doc, cl_num_doc, cl_cidade, cl_estado, cl_pais, cl_endereco FROM TBL_CLIENTES WHERE id_cliente= {0}", pre.id_cliente));

                                    string cl_tipo_doc = dsDataSet.Tables[0].Rows[0]["cl_tip_doc"].ToString();
                                    string cl_nome = dsDataSet.Tables[0].Rows[0]["cl_nome"].ToString();
                                    string endereco_c50k = dsDataSet.Tables[0].Rows[0]["cl_endereco"].ToString();
                                    string cidade_c50k = dsDataSet.Tables[0].Rows[0]["cl_cidade"].ToString() + " " + dsDataSet.Tables[0].Rows[0]["cl_estado"].ToString() + " " + dsDataSet.Tables[0].Rows[0]["cl_pais"].ToString();
                                    string num_doc_c50K = "CPF/CNPJ/ID " + dsDataSet.Tables[0].Rows[0]["cl_num_doc"].ToString();
                                    pre.c50k_dados_swift = getCampoC50k(cl_tipo_doc, pre.id_cliente, cl_nome, endereco_c50k, cidade_c50k, num_doc_c50K);

                                    pre.op_data_sistema = DateTime.Now;
                                    pre.op_data_boleto = DateTime.Now;
                                    pre.op_inf_compl = "Boleto incluido via RoboSwift em " + DateTime.Now + " referente a Ordem de Pagamento No." + pre.op_numero_ordem;
                                    pre.op_inf_fav = removerCaracteresEstranhos(dsSwift.Tables[0].Rows[i]["ORDENANTE"].ToString().Replace("\r\n", ""));

                                    if (dsSwift.Tables[0].Rows[i]["NOME_BANCO_ORDEM"].ToString().Replace("\r\n", "").Length > 0)
                                    {
                                        pre.op_swift_code = dsSwift.Tables[0].Rows[i]["BANCO_ORDEM"].ToString().Replace("\r\n", "");
                                        pre.op_inf_banco = dsSwift.Tables[0].Rows[i]["NOME_BANCO_ORDEM"].ToString();
                                        pre.OP_PAISES = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["PAIS_BANCO_ORDEM"].ToString());
                                    }
                                    else
                                    {
                                        pre.op_swift_code = null;
                                        pre.op_inf_banco = null;
                                        pre.OP_PAISES = Convert.ToInt32(dsSwift.Tables[0].Rows[i]["PAIS_BANCO_ORDEM"].ToString());
                                    }
                                    pre.op_verificada = "S";
                                    pre.op_data_follow_up = DtLancamento; //Verificar
                                    pre.id_filial = 0;//
                                    pre.pre_boleto_status = 0;//

                                    pre.foiprocessadaremessaexpressa = true;

                                    pre.CRM_OCORRENCIA = "Pré-Boleto de Compra criado automaticamente pelo Robô Swift referente a Ordem de Pagamento No. " + pre.op_numero_ordem + "- Pré-Boleto:";
                                    pre.CRM_CPF_CNPJ = dsSwift.Tables[0].Rows[i]["CL_NUM_DOC"].ToString();
                                    pre.CRM_PASSAPORTE = dsSwift.Tables[0].Rows[i]["CL_PASSAPORTE"].ToString();

                                    pre.op_vend_comp = dsSwift.Tables[0].Rows[i]["CL_COD_VENDEDOR"].ToString();

                                    if (pre.op_tx_operacao == 0)
                                    {
                                        pre.op_tx_operacao = null;
                                    }

                                    // - Insere o preboleto
                                    DataSet dtSt = CriarPreBoleto(transaction, pre, false, false);

                                    Dres = GravaLOG_Lancamento_CCMESwift(transaction,
                                                                         Convert.ToInt32(dsSwift.Tables[0].Rows[i]["IDSwift"].ToString()),
                                                                         "2000",
                                                                         "Pré-boleto No." + dtSt.Tables[0].Rows[0]["ID_OPERACAO"].ToString() + " criado no sistema " + pre.sistema_origem + ", referente a Ordem de Pagamento No." + pre.op_numero_ordem,
                                                                         Convert.ToInt32(oDBParametro.IdUser),
                                                                         Moeda,
                                                                         OrValor, -1, "A",
                                                                         Convert.ToInt32(dtSt.Tables[0].Rows[0]["ID_OPERACAO"].ToString()),
                                                                         (dsSwift.Tables[0].Rows[i]["EMPRESA"].ToString().Equals("BRSA") ? 1 : 2),
                                                                         pre.sistema_origem, OrigemLog.BO.ToString());


                                    //Insere registro na TBL_COL_STATUS_PREBOLETO, com status de acordo com a Ordem 
                                    Dres = Inserir_COL_Status_Pre_boleto(transaction, (int)dtSt.Tables[0].Rows[0]["ID_OPERACAO"], pre.EMPRESA);

                                    StringBuilder sbUp = new StringBuilder();
                                    sbUp.Append("UPDATE TBL_CRM SET ");
                                    sbUp.AppendFormat("CRM_NBOLETO={0} WHERE crm_cpf_cnpj='{1}' AND crm_ocorrencia LIKE '%{2}%'", dtSt.Tables[0].Rows[0]["ID_OPERACAO"].ToString(), dsSwift.Tables[0].Rows[i]["CL_NUM_DOC"].ToString(), dtSt.Tables[0].Rows[0]["ID_OPERACAO"].ToString());

                                    SqlHelper.ExecuteNonQuery(transaction, CommandType.Text, sbUp.ToString());

                                    // - aprovacao_contrapartida - Log CRM
                                    if (!string.IsNullOrEmpty(pre.aprovacao_contrapartida) && pre.aprovacao_contrapartida.Equals("S"))
                                    {

                                        StringBuilder sb = new StringBuilder();
                                        sb.Append("INSERT INTO TBL_CRM (ID_USUARIO, CRM_CPF_CNPJ, ID_CORRETORA, CRM_OCORRENCIA, CRM_NBOLETO, CRM_DATA) VALUES ");
                                        sb.AppendFormat("({0}, {1}, {2},'Contra-partida aprovada automaticamente pelo Robô Swift', {3}, GETDATE())",
                                            ID_USER_BOLETO, dsSwift.Tables[0].Rows[i]["CL_NUM_DOC"].ToString(), pre.id_corretora.ToString(), dtSt.Tables[0].Rows[0]["ID_OPERACAO"].ToString());

                                        SqlHelper.ExecuteNonQuery(transaction, CommandType.Text, sb.ToString());

                                    }


                                    DataTable dtMAIL = Get_Email_Para(Id_Cliente);
                                    string email_para = null;
                                    if (dtMAIL.Rows.Count > 0)
                                        email_para = dtMAIL.Rows[0]["EMAIL_PARA"].ToString();


                                    string resposta = null;
                                    //Enviar e-mail de notificação 
                                    try
                                    {
                                        string dados = "";
                                        if (pre.sistema_origem.Equals("PC"))
                                        {
                                            var infoEmail = new InfoEmail
                                            {
                                                IdSistema = IDSistemaEmail.ToString(),
                                                IdEmpresa = pre.EMPRESA.ToString(),
                                                Codigo = "50",
                                                ListaEmailPara = email_para,
                                                ListaEmailCc = "",
                                                Assunto = "Aviso de Pagamento Recebido do Exterior (" + String.Format("{0:dd/MM/yyyy}", DtLancamento) + ") - " + dtSt.Tables[0].Rows[0]["id_operacao"],
                                                ListaArquivos = null,
                                                ListaParametrosCorpo = new List<EmailService.Parametro>()
                                            };
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "EnderecoExternoImagens", Valor = dsSwift.Tables[0].Rows[i]["LINK"].ToString() + "/Cambio_On-line" });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "UrlEmpresa", Valor = dsSwift.Tables[0].Rows[i]["LINK"].ToString() });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "REMETENTE", Valor = pre.op_inf_fav });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "MOEDA", Valor = Moeda });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "VALOR_ME", Valor = OrValor.ToString("N", new System.Globalization.CultureInfo("pt-BR").NumberFormat) });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "DATA", Valor = DtLancamento.ToString("dd/MM/yyyy") });
                                            var serializer = new JavaScriptSerializer();
                                            dados = serializer.Serialize(infoEmail);
                                        }
                                        else
                                        {
                                            string UrlImagem = null;
                                            if (pre.EMPRESA.Equals(1))
                                            {
                                                UrlImagem = System.Configuration.ConfigurationManager.AppSettings.Get("URLImagensVArejoBRSA");
                                            }
                                            else
                                            {
                                                UrlImagem = System.Configuration.ConfigurationManager.AppSettings.Get("URLImagensVArejoCOTA");
                                            }

                                            var infoEmail = new InfoEmail
                                            {
                                                IdSistema = IDSistemaEmail.ToString(),
                                                IdEmpresa = pre.EMPRESA.ToString(),
                                                Codigo = "37",
                                                ListaEmailPara = email_para,
                                                ListaEmailCc = "",
                                                Assunto = "Aviso de Ordem de Pagamento Recebida",
                                                ListaArquivos = null,
                                                ListaParametrosCorpo = new List<EmailService.Parametro>()
                                            };
                                            string nomeCliente = dsSwift.Tables[0].Rows[i]["nome"].ToString();
                                            string cliTipo = dsSwift.Tables[0].Rows[i]["cli_tipo"] != DBNull.Value ? dsSwift.Tables[0].Rows[i]["cli_tipo"].ToString().Trim() : string.Empty;
                                            //CarregarParametrosGoogle(transaction, infoEmail, pre, nomeCliente, false, cliTipo);

                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "cl_email", Valor = email_para });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "nome", Valor = dsSwift.Tables[0].Rows[i]["nome"].ToString() });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "op_n_boleto", Valor = Convert.ToInt32(dtSt.Tables[0].Rows[0]["ID_OPERACAO"].ToString()).ToString() });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "EnderecoExternoImagens", Valor = UrlImagem });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "op_inf_fav", Valor = pre.op_inf_fav });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "op_val_moeda_aux", Valor = OrValor.ToString("N", new System.Globalization.CultureInfo("pt-BR").NumberFormat) });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "moeda", Valor = Moeda });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "dataCredito", Valor = DtLancamento.ToString("dd/MM/yyyy") });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "dataVencimento", Valor = DtLancamento.AddDays(180).ToString("dd/MM/yyyy") });
                                            infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "op_taxa_cambio_email", Valor = "false" });

                                            var serializer = new JavaScriptSerializer();
                                            dados = serializer.Serialize(infoEmail);
                                        }
                                        var rest = new RestClient(wsEmailService);
                                        resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));
                                        if (!resposta.Equals("Não foi possivel enviar o email"))//enviado com sucesso
                                        {
                                            oLogCCMESwift.DesLog = "E-mail: Enviado id: " + resposta + " Boleto: " + dtSt.Tables[0].Rows[0]["ID_OPERACAO"].ToString() + " Cliente:" + dsSwift.Tables[0].Rows[i]["nome"].ToString();
                                            oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                            oLogCCMESwift.TpoLog = "I";
                                            oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                                            //logar CRM o envio do Email 
                                            //"insert into TBL_CRM (id_usuario,id_corretora,crm_cpf_cnpj,crm_ocorrencia,crm_passaporte,crm_nboleto) values ('"&us_con&"','"&us_corretora_con&"','"&cl_num_doc&"','Email de Aviso de Ordem de Pagamento Recebida enviado para: "&cl_email&" | Taxa Sugerida: R$ "&FormataValor2(op_taxa_cambio_email)&" / US$.','"&cl_passaporte&"','"&op_n_boleto&"')"
                                            string msgEmail = null;
                                            msgEmail = "Email de Aviso de Ordem de Pagamento Recebida enviado para: " + email_para + " | Taxa Sugerida: R$ / US$.";

                                            StringBuilder sb = new StringBuilder();
                                            sb.Append("INSERT INTO TBL_CRM (ID_USUARIO, CRM_CPF_CNPJ, ID_CORRETORA, CRM_OCORRENCIA, CRM_NBOLETO, CRM_DATA) VALUES ");
                                            sb.AppendFormat("({0}, {1}, {2},'{3}', {4}, GETDATE())",
                                            ID_USER_BOLETO, dsSwift.Tables[0].Rows[i]["CL_NUM_DOC"].ToString(), pre.id_corretora.ToString(), msgEmail, dtSt.Tables[0].Rows[0]["ID_OPERACAO"].ToString());

                                            SqlHelper.ExecuteNonQuery(transaction, CommandType.Text, sb.ToString());

                                        }
                                        else //erro ao enviar o email 
                                        {//Não foi possivel enviar o email
                                            oLogCCMESwift.DesLog = "Erro ao Enviar E-mail: Resposta=" + resposta + "  boleto:" + dtSt.Tables[0].Rows[0]["ID_OPERACAO"].ToString();
                                            oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                            oLogCCMESwift.TpoLog = "E";
                                            oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                                        }


                                    }
                                    catch (Exception x)
                                    {
                                        oLogCCMESwift.DesLog = "Erro ao Enviar E-mail: Resposta=" + resposta + " Msg: " + x.Message.ToString() + " - " + x.StackTrace;
                                        oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                        oLogCCMESwift.TpoLog = "E";
                                        oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                                    }


                                }
                                else
                                {
                                    // Cliente Inativo no Varejo
                                    // Cliente Bloqueado
                                    // Opera somente Banco
                                    // Cliente não Identificado
                                    if ((dsSwift.Tables[0].Rows[i]["Empresa"].ToString() == "COTACAO") &&  //ordem cotacao e OperaSomente banco N
                                       (dsSwift.Tables[0].Rows[i]["cl_OperaSomenteBanco"].Equals("S")))
                                    {
                                        Dres = GravaLOG_Lancamento_CCMESwift(transaction,
                                                                             Convert.ToInt32(dsSwift.Tables[0].Rows[i]["IDSwift"].ToString()),
                                                                             "-999",
                                                                             "Cliente Somente Banco, necessário estornar o lançamento na CCME da Cotação e gerar o procedimento manual.",
                                                                             Convert.ToInt32(oDBParametro.IdUser),
                                                                             Moeda,
                                                                             OrValor, -1, "E", 0, 0, "", OrigemLog.BO.ToString());
                                    }

                                    if (dsSwift.Tables[0].Rows[i]["CLIENTE_NAOIDENTIFICADO"].ToString().Equals("S"))
                                    {
                                        Dres = GravaLOG_Lancamento_CCMESwift(transaction,
                                                                             Convert.ToInt32(dsSwift.Tables[0].Rows[i]["IDSwift"].ToString()),
                                                                             "-998",
                                                                             "Cliente não identificado ",
                                                                             Convert.ToInt32(oDBParametro.IdUser),
                                                                             Moeda,
                                                                             OrValor, -1, "E", 0, 0, "", OrigemLog.BO.ToString());

                                    }
                                    if (dsSwift.Tables[0].Rows[i]["PreBoletoCompraAutomatico"].ToString().Equals("N"))
                                    {
                                        Dres = GravaLOG_Lancamento_CCMESwift(transaction,
                                                                             Convert.ToInt32(dsSwift.Tables[0].Rows[i]["IDSwift"].ToString()),
                                                                             "-997",
                                                                             "Cliente não habilitado a receber pré-boleto automático.",
                                                                             Convert.ToInt32(oDBParametro.IdUser),
                                                                             Moeda,
                                                                             OrValor, -1, "E", 0, 0, "", OrigemLog.BO.ToString());

                                    }
                                    if (dsSwift.Tables[0].Rows[i]["CL_STATUS"].ToString().Equals("I"))
                                    {
                                        Dres = GravaLOG_Lancamento_CCMESwift(transaction,
                                                                             Convert.ToInt32(dsSwift.Tables[0].Rows[i]["IDSwift"].ToString()),
                                                                             "-996",
                                                                             "Não foi possível criar o pré boleto, Cliente com status Inativo no Varejo",
                                                                             Convert.ToInt32(oDBParametro.IdUser),
                                                                             Moeda,
                                                                             OrValor, -1, "E", 0, 0, "", OrigemLog.BO.ToString());
                                    }
                                    if (dsSwift.Tables[0].Rows[i]["CL_STATUS"].ToString().Equals("B"))
                                    {
                                        Dres = GravaLOG_Lancamento_CCMESwift(transaction,
                                                                             Convert.ToInt32(dsSwift.Tables[0].Rows[i]["IDSwift"].ToString()),
                                                                             "-996",
                                                                             "Não foi possível criar o pré boleto, Cliente com status Bloqueado no Varejo",
                                                                             Convert.ToInt32(oDBParametro.IdUser),
                                                                             Moeda,
                                                                             OrValor, -1, "E", 0, 0, "", OrigemLog.BO.ToString());
                                    }
                                }
                                blLancamento = false;
                                obsLanc_msg = null;

                                transaction.Commit();
                            }
                            catch (Exception Err)
                            {
                                transaction.Rollback();
                                // Grava na tabela de log
                                oLogCCMESwift.DesLog = "Erro : " + Err.Message.ToString() + " - " + Err.StackTrace;
                                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                                oLogCCMESwift.TpoLog = "E";
                                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                            }
                        }
                    }

                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.DesLog = "Fim da execução";
                    oLogCCMESwift.TpoLog = "I";
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                }
                catch (Exception ex)
                {
                    // Grava na tabela de log
                    oLogCCMESwift.DesLog = "Erro PreBoleto: " + ex.Message.ToString() + " - " + ex.StackTrace;
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.TpoLog = "E";
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                }
            }
        }

        public DataSet CriarPreBoleto(SqlTransaction Transaction, TBL_PRE_BOLETO preBoleto, bool googleAutomatico, bool boletoGoogle)
        {
            RETURN_VALUE = 0;
            RETURN_MENSAGEM = null;
            DataSet DR = null;

            try
            {
                var strParametros = getParametersFromObject(preBoleto);

                if (googleAutomatico)
                {
                    strParametros.RemoveAll(p => p.ParameterName.Equals("EMPRESA"));

                    var sistemaOrigem = strParametros.Where(p => p.ParameterName.Equals("SISTEMA_ORIGEM")).FirstOrDefault();

                    if (sistemaOrigem != null)
                        sistemaOrigem.ParameterName = "OP_SISTEMAORIGEM";

                    DR = SqlHelper.ExecuteDataset(Transaction, CommandType.StoredProcedure, "PR_INSERIR_ORDEM_UNIFICADA", strParametros.ToArray());

                }
                else
                {
                    strParametros.RemoveAll(p => p.ParameterName.Equals("OP_DATA_TAXA_OPERACAO"));
                    DR = SqlHelper.ExecuteDataset(Transaction, CommandType.StoredProcedure, "PR_INSERIR_PRE_BOLETO_ROBO_SWIFT", strParametros.ToArray());
                }

                if (DR.Tables.Count > 0 && DR.Tables[0].Rows.Count > 0)
                {
                    preBoleto.op_n_boleto = Convert.ToInt32(DR.Tables[0].Rows[0]["ID_OPERACAO"]);

                    if (boletoGoogle)
                        SqlHelper.ExecuteNonQuery(Transaction, CommandType.Text, string.Format("UPDATE TBL_PRE_BOLETO SET aprovacao_documentos = 'S' WHERE op_n_boleto = {0}", preBoleto.op_n_boleto.ToString()));
                }

            }
            catch (Exception ex)
            {
                oLogCCMESwift.DesLog = "Erro CriarPreBoleto: " + ex.Message.ToString() + " - " + ex.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
            return DR;
        }
        public DataSet RealizaLancamento(SqlTransaction Transaction, int id_cliente, string cod_moeda, string tipo, string tipo_operacao, decimal valor_operacao, int historico, int id_lancamento, string flag_disp, string flag_bloq, string obs, int quant_cheques, DateTime data_disp, DateTime mov_cbr_vtm_de, DateTime mov_cbr_vtm_ate, int id_user, int idSwift, string ClNumDoc)
        {

            RETURN_VALUE = 0;
            RETURN_MENSAGEM = null;
            DataSet DR = null;
            try
            {

                SqlParameter[] strParametros = new SqlParameter[21];
                strParametros[0] = new SqlParameter("@MOV_CLIENTE", SqlDbType.Int);
                strParametros[0].Value = id_cliente;
                strParametros[1] = new SqlParameter("@MOV_MOEDA", SqlDbType.VarChar, 10);
                strParametros[1].Value = cod_moeda;
                strParametros[2] = new SqlParameter("@MOV_TIPO", SqlDbType.VarChar, 1);
                strParametros[2].Value = tipo;
                strParametros[3] = new SqlParameter("@MOV_TIPO_OP", SqlDbType.VarChar, 50);
                strParametros[3].Value = tipo_operacao;
                strParametros[4] = new SqlParameter("@MOV_VALOR", SqlDbType.Money);
                strParametros[4].Value = valor_operacao;
                strParametros[5] = new SqlParameter("@MOV_PARIDADE", SqlDbType.Money);
                strParametros[5].Value = 0;
                strParametros[6] = new SqlParameter("@MOV_HISTORICO", SqlDbType.Int);
                strParametros[6].Value = historico;
                strParametros[7] = new SqlParameter("@MOV_FLAG_DISP", SqlDbType.Char, 1);
                strParametros[7].Value = flag_disp;
                strParametros[8] = new SqlParameter("@MOV_FLAG_BLOQ", SqlDbType.Char, 2);
                strParametros[8].Value = flag_bloq;
                strParametros[9] = new SqlParameter("@MOV_OBS", SqlDbType.VarChar, 2000);
                strParametros[9].Value = obs;
                strParametros[10] = new SqlParameter("@MOV_QTDE_CHEQUES", SqlDbType.Int);
                strParametros[10].Value = quant_cheques;
                strParametros[11] = new SqlParameter("@MOV_DATA_DISP", SqlDbType.DateTime);
                strParametros[11].Value = String.Format("{0:yyyy-MM-dd}", data_disp);
                strParametros[12] = new SqlParameter("@ID_LANCAMENTO", SqlDbType.Int);
                strParametros[12].Value = id_lancamento;
                strParametros[13] = new SqlParameter("@SISTEMA", SqlDbType.Int);
                strParametros[13].Value = 1;
                strParametros[14] = new SqlParameter("@ID_USUARIO", SqlDbType.Int);
                strParametros[14].Value = Convert.ToInt32(id_user);
                strParametros[15] = new SqlParameter("@CL_NUM_DOC", SqlDbType.VarChar, 14);
                strParametros[15].Value = ClNumDoc;
                // CCME WEB Admin........................M
                // Automatico Varejo.....................J
                // Automatico Cambio Boletagem...........B
                // CCME WEB Cliente......................W

                string origemCcmeWebAdmin = "M";

                strParametros[16] = new SqlParameter("@TIPO_USUARIO", SqlDbType.Char);
                strParametros[16].Value = origemCcmeWebAdmin;
                strParametros[17] = new SqlParameter("@MOV_CBR_VTM_DE", SqlDbType.DateTime);
                if (mov_cbr_vtm_de == Convert.ToDateTime("01/01/1900"))
                {
                    strParametros[17].Value = DBNull.Value;
                }
                else
                {
                    strParametros[17].Value = String.Format("{0:yyyy-MM-dd}", mov_cbr_vtm_de);
                }
                strParametros[18] = new SqlParameter("@MOV_CBR_VTM_ATE", SqlDbType.DateTime);
                if (mov_cbr_vtm_ate == Convert.ToDateTime("01/01/1900"))
                {
                    strParametros[18].Value = DBNull.Value;
                }
                else
                {
                    strParametros[18].Value = String.Format("{0:yyyy-MM-dd}", mov_cbr_vtm_ate);
                }
                strParametros[19] = new SqlParameter("@RETURN_VALUE", SqlDbType.Int);
                strParametros[19].Direction = ParameterDirection.ReturnValue;
                strParametros[20] = new SqlParameter("@MENSAGEM", SqlDbType.VarChar, 300);
                strParametros[20].Direction = ParameterDirection.Output;

                DR = SqlHelper.ExecuteDataset(Transaction, CommandType.StoredProcedure, "SPBCCME_Inserir_Lancamento", strParametros);

                DataSet Dres = new DataSet();
                if ((strParametros[19].Value.ToString() != "0") && (DR.Tables.Count == 0))
                {
                    RETURN_VALUE = Convert.ToInt32(strParametros[19].Value.ToString());
                    RETURN_MENSAGEM = strParametros[20].Value.ToString();

                    Dres = GravaLOG_Lancamento_CCMESwift(Transaction, idSwift, strParametros[19].Value.ToString(), strParametros[20].Value.ToString(), id_user, cod_moeda, valor_operacao, id_lancamento, "I", 0, 0, "", OrigemLog.LC.ToString());
                }
                else if (DR.Tables[0].Rows.Count > 0)
                {
                    id_lancamento = Convert.ToInt32(DR.Tables[0].Rows[0][0].ToString());
                }
                else
                {
                    id_lancamento = -1;
                    Dres = GravaLOG_Lancamento_CCMESwift(Transaction, idSwift, strParametros[19].Value.ToString(), "Ordem destinada a BRSA e Cliente sem CCME na Moeda, não houve lançamento (Fase 3 não implementada)", id_user, cod_moeda, valor_operacao, id_lancamento, "E", 0, 0, "", OrigemLog.LC.ToString());
                }
            }
            catch (Exception ex)
            {
                oLogCCMESwift.DesLog = "Erro : " + ex.Message.ToString() + " - " + ex.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
            return DR;

        }
        public string[] Get_Proximo_Dia_Util(DateTime data, string praca, string moeda, int diasMN, int diasME)
        {
            SqlDataReader dr = null;

            string[] data_util = new string[3] { "", "", "" };

            try
            {

                SqlParameter[] strParametros = new SqlParameter[7];

                strParametros[0] = new SqlParameter("@DataBase", SqlDbType.SmallDateTime);
                strParametros[0].Value = data;
                strParametros[1] = new SqlParameter("@QtdDiasME", SqlDbType.Int);
                strParametros[1].Value = diasME;
                strParametros[2] = new SqlParameter("@QtdDiasMN", SqlDbType.Int);
                strParametros[2].Value = diasMN;
                strParametros[3] = new SqlParameter("@Praca", SqlDbType.VarChar, 2);
                strParametros[3].Value = "SP";
                strParametros[4] = new SqlParameter("@Moeda", SqlDbType.VarChar, 4);
                strParametros[4].Value = moeda;
                strParametros[5] = new SqlParameter("@IdSistema", SqlDbType.Int);
                strParametros[5].Value = Convert.ToInt16(System.Configuration.ConfigurationManager.AppSettings["Id_SistemaFeriados"].ToString().Trim());
                strParametros[6] = new SqlParameter("@IdOperacao", SqlDbType.VarChar, 2);
                strParametros[6].Value = "V";
                //strParametros[7] = new SqlParameter("@HoraCorte", SqlDbType.Int);
                //strParametros[7].Value = li_hora_corte;
                //strParametros[8] = new SqlParameter("@MinutoCorte", SqlDbType.Int);
                //strParametros[8].Value = li_minuto_corte;

                dr = SqlHelper.ExecuteReader(this.strConexao, CommandType.StoredProcedure, "dbFeriado..SPBR_Verifica_Proxima_Data_Vigente", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    data_util[0] = dr[0].ToString();
                    data_util[1] = dr[1].ToString();
                    data_util[2] = dr[2].ToString();
                }

                return data_util;
            }
            catch (Exception ex)
            {
                oLogCCMESwift.DesLog = "Erro : " + ex.Message.ToString() + " - " + ex.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                return data_util;
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }
        }
        public DataSet Inserir_COL_Status_Pre_boleto(SqlTransaction transaction, int op_n_boleto, int Empresa)
        {
            SqlParameter[] strParam = new SqlParameter[2];
            strParam[0] = new SqlParameter("@op_n_boleto", SqlDbType.Int);
            strParam[0].Value = Convert.ToInt32(op_n_boleto);
            strParam[1] = new SqlParameter("@empresa", SqlDbType.Int);
            strParam[1].Value = Convert.ToInt32(Empresa);

            DataSet dr1 = SqlHelper.ExecuteDataset(transaction, CommandType.StoredProcedure, "SPBCCME_INSERIR_COL_STATUS_PRE_BOLETO", strParam);

            return dr1;

        }

        public DataSet GravaLOG_Lancamento_CCMESwift(SqlTransaction transaction, int id_swift, string cdMsg, string sMsgLog, int id_user, string OrMoeda, decimal OrValor, int id_Lancamento, string TpLog, int OP_N_BOLETO, int OP_N_BOLETO_EMPRESA, string OP_N_BOLETO_SISTEMA, string OrigemLog)
        {
            DataSet dr1 = null;
            try
            {
                //Retornado Erro No Lançamento da CCME
                SqlParameter[] strParam = new SqlParameter[13];
                strParam[0] = new SqlParameter("@id_swift", SqlDbType.Int);
                strParam[0].Value = Convert.ToInt32(id_swift);
                strParam[1] = new SqlParameter("@CdMsg", SqlDbType.NChar);
                strParam[1].Value = Convert.ToString(cdMsg);
                strParam[2] = new SqlParameter("@DsMsgLog", SqlDbType.NVarChar);
                strParam[2].Value = Convert.ToString(sMsgLog);
                strParam[3] = new SqlParameter("@id_user", SqlDbType.Int);
                strParam[3].Value = Convert.ToInt32(id_user);
                strParam[4] = new SqlParameter("@OrMoeda", SqlDbType.NChar);
                strParam[4].Value = OrMoeda;
                strParam[5] = new SqlParameter("@OrValor", SqlDbType.Decimal);
                strParam[5].Value = Convert.ToDecimal(OrValor);
                strParam[6] = new SqlParameter("@TpLog", SqlDbType.NChar);
                strParam[6].Value = TpLog;
                strParam[7] = new SqlParameter("@ID_Lanc", SqlDbType.Int);
                strParam[7].Value = id_Lancamento;
                strParam[8] = new SqlParameter("@OP_N_BOLETO", SqlDbType.Int);
                strParam[8].Value = OP_N_BOLETO;
                strParam[9] = new SqlParameter("@OP_N_BOLETO_EMPRESA", SqlDbType.Int);
                strParam[9].Value = OP_N_BOLETO_EMPRESA;
                strParam[10] = new SqlParameter("@OP_N_BOLETO_SISTEMA", SqlDbType.NChar);
                strParam[10].Value = OP_N_BOLETO_SISTEMA;
                strParam[11] = new SqlParameter("@OrigemLog", SqlDbType.NChar);
                strParam[11].Value = OrigemLog;
                strParam[12] = new SqlParameter("@ur_username", SqlDbType.NChar);
                strParam[12].Value = "ROBO_CCME_SWIFT";

                dr1 = SqlHelper.ExecuteDataset(transaction, CommandType.StoredProcedure, "SPBCCME_GRAVAR_LOG_CCMESWIFT", strParam);

            }
            catch (Exception ex)
            {
                oLogCCMESwift.DesLog = "Erro GravaLOG_Lancamento_CCMESwift: " + ex.Message.ToString() + " - " + ex.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
            return dr1;
        }

        public DataSet Atualiza_MT103_Change()
        {
            DataSet dr1 = new DataSet();

            try
            {
                //ATUALIZA DADOS DO CHANGE RENDIMENTO COM MT103 
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@ACAO", SqlDbType.Char);
                strParametros[0].Value = "R";

                dr1 = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_ATUALIZA_MT103_CHANGE", strParametros);

                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.DesLog = "Change Rendimento atualizado com MT103";
                oLogCCMESwift.TpoLog = "I";
                intId_LogPai = oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                SqlParameter[] strParametrosCBOLETO = new SqlParameter[1];
                strParametrosCBOLETO[0] = new SqlParameter("@ACAO", SqlDbType.Char);
                strParametrosCBOLETO[0].Value = "CBOLETO";

                dr1 = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_ATUALIZA_MT103_CHANGE", strParametrosCBOLETO);

                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.DesLog = "Boletos Cotação atualizado com MT103";
                oLogCCMESwift.TpoLog = "I";
                intId_LogPai = oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

                SqlParameter[] strParametrosC = new SqlParameter[1];
                strParametrosC[0] = new SqlParameter("@ACAO", SqlDbType.Char);
                strParametrosC[0].Value = "C";

                dr1 = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_ATUALIZA_MT103_CHANGE", strParametrosC);

                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.DesLog = "Lançamento CCME Cotação atualizados com MT103";
                oLogCCMESwift.TpoLog = "I";
                intId_LogPai = oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
            catch (Exception ex)
            {
                oLogCCMESwift.DesLog = "Erro Atualiza_MT103_Change: " + ex.Message.ToString() + " - " + ex.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

            }
            finally
            {

            }
            return dr1;
        }

        public DataTable GetConfiguracoes()
        {
            DataSet ds = new DataSet();
            DataTable tbl = new DataTable("Configuracoes");
            DataSet dr = null;


            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@ID_CONFIG", SqlDbType.Int);
                strParametros[0].Value = 1;

                dr = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_Get_Config", strParametros);

                if (dr.Tables[0].Rows.Count > 0)
                {
                    tbl.Load(dr.Tables[0].CreateDataReader());
                }
            }
            catch (Exception ex)
            {
                oLogCCMESwift.DesLog = "Erro : " + ex.Message.ToString() + " - " + ex.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
            finally
            {
            }

            return tbl;
        }

        public string HorarioDeCorte_CCME()
        {
            SqlDataReader dr = null;
            string retorno = "";
            try
            {
                dr = SqlHelper.ExecuteReader(this.strConexao, CommandType.StoredProcedure, "VALIDAR_HORARIO_CORTE_CCME");

                if (dr.HasRows == true)
                {
                    dr.Read();
                    retorno = dr["EXECUTAR"].ToString();
                }
            }
            catch (Exception ex)
            {
                oLogCCMESwift.DesLog = "Erro : " + ex.Message.ToString() + " - " + ex.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }
            return retorno;

        }

        public void GetDataLancamento(SqlTransaction transaction, int idSwift, DateTime Value_Date, string Moeda, decimal OrValor, string OrigemLog, out DateTime DtLancamento, out bool BlLancamento, out string obsLanc_msg)
        {

            DtLancamento = Convert.ToDateTime("01/01/1900");
            BlLancamento = false;
            obsLanc_msg = null;
            //Define a data de lançamento na CCME e pre_boleto
            string[] retorno_data = new string[3] { "", "", "" };
            //string[] retorno_data_retroativa = new string[3] { "", "", "" };

            try
            {
                retorno_data = Get_Proximo_Dia_Util(Convert.ToDateTime(Value_Date), "SP", Moeda, 0, 0);
                DtLancamento = Convert.ToDateTime("01/01/1900");

                if (Convert.ToDateTime(retorno_data[2]) <= DateTime.Today)
                {
                    DtLancamento = DateTime.Today;
                    BlLancamento = true;
                }
                else
                {
                    DataSet Dres = GravaLOG_Lancamento_CCMESwift(transaction, idSwift, "1000", "Lançamento agendado para " + string.Format("{0:d/MM/yyyy}", retorno_data[2].ToString()) + " em virtude de Regra de Feriado no sistema CCME", Convert.ToInt32(oDBParametro.IdUser), Moeda, OrValor, 0, "A", 0, 0, "", OrigemLog);
                    BlLancamento = false;
                }

                #region Código Antigo
                /*
                if (Convert.ToDateTime(retorno_data[2]) == DateTime.Today)
                {
                    //DtLancamento = Convert.ToDateTime(retorno_data[2]+ DateTime.Now.Hour);
                    DtLancamento = Convert.ToDateTime(retorno_data[2].Substring(0, 10) + " " + DateTime.Now.TimeOfDay);
                    BlLancamento = true;
                }
                else if (Convert.ToDateTime(retorno_data[2]) > DateTime.Today)
                {
                    DataSet Dres = GravaLOG_Lancamento_CCMESwift(transaction, idSwift, "1000", "Lançamento agendado para " + string.Format("{0:d/MM/yyyy}", retorno_data[2].ToString()) + " em virtude de Regra de Feriado no sistema CCME", Convert.ToInt32(oDBParametro.IdUser), Moeda, OrValor, 0, "A", 0, 0, "", OrigemLog);
                    BlLancamento = false;
                }
                else if (Convert.ToDateTime(retorno_data[2]) < DateTime.Today)
                {
                    //testa retroativo
                    retorno_data_retroativa = Get_Proximo_Dia_Util(Convert.ToDateTime(Value_Date), "SP", Moeda, 0, 1);

                    if (Convert.ToDateTime(retorno_data_retroativa[2]) >= DateTime.Today)
                    {
                        //lançamento retroativo
                        //DtLancamento = Convert.ToDateTime(Value_Date);
                        DtLancamento = Convert.ToDateTime(Value_Date.ToString().Substring(0, 10) + " " + DateTime.Now.TimeOfDay);
                        BlLancamento = true;
                        obsLanc_msg = "<br /><br /><font color='red'>Atenção: Lançamento Retroativo</font>";
                    }
                    else if (Convert.ToDateTime(retorno_data_retroativa[2]) < DateTime.Today)
                    {
                        //lançamento ATRASADO lança CCME data atual

                        retorno_data_retroativa = Get_Proximo_Dia_Util(Convert.ToDateTime(DateTime.Today), "SP", Moeda, 0, 0);
                        if (Convert.ToDateTime(retorno_data_retroativa[2]) == DateTime.Today)
                        {
                            DtLancamento = Convert.ToDateTime(retorno_data_retroativa[2].Substring(0, 10) + " " + DateTime.Now.TimeOfDay);

                            BlLancamento = true;
                        }
                    }
                }*/
                #endregion
            }
            catch (Exception ex)
            {
                DtLancamento = Convert.ToDateTime("01/01/1900");
                BlLancamento = false;
                obsLanc_msg = null;
                oLogCCMESwift.DesLog = "Erro : " + ex.Message.ToString() + " - " + ex.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }

        }
        public decimal CalcularTarifa(int id_cliente, string cod_moeda_operacao, decimal valor_operacao, string tipo_tarifa)
        {
            decimal valor_tarifa = 0;
            SqlDataReader dr = null;
            string moeda_tarifa = null;
            string cod_moeda_tarifa = null;

            moeda_tarifa = MoedaTarifa(cod_moeda_operacao, id_cliente);

            if (moeda_tarifa.Equals("D"))
            {
                cod_moeda_tarifa = "USD";
            }
            else
            {
                cod_moeda_tarifa = cod_moeda_operacao;
            }
            try
            {
                SqlParameter[] strParametros = new SqlParameter[5];
                strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                strParametros[0].Value = id_cliente;

                strParametros[1] = new SqlParameter("@VALOR_OPERACAO", SqlDbType.Money);
                strParametros[1].Value = valor_operacao;

                strParametros[2] = new SqlParameter("@COD_MOEDA", SqlDbType.VarChar, 10);
                strParametros[2].Value = cod_moeda_operacao;

                strParametros[3] = new SqlParameter("@TIPO_TARIFA", SqlDbType.VarChar, 50);
                strParametros[3].Value = tipo_tarifa;

                strParametros[4] = new SqlParameter("@MOEDA_TARIFA", SqlDbType.VarChar, 10);
                strParametros[4].Value = cod_moeda_tarifa;

                dr = SqlHelper.ExecuteReader(this.strConexao, CommandType.StoredProcedure, "SPBCCME_Calcular_Tarifa", strParametros);

                if (dr.HasRows == true)
                {
                    dr.Read();
                    valor_tarifa = Convert.ToDecimal(dr["VALOR_TARIFA"]);
                }

            }
            catch (Exception ex)
            {
                oLogCCMESwift.DesLog = "Erro : " + ex.Message.ToString() + " - " + ex.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }
            return valor_tarifa;
        }
        public string MoedaTarifa(string cod_moeda, int id_cliente)
        {
            SqlDataReader dr = null;

            string moeda_tarifa = "D";

            try
            {
                SqlParameter[] strParametros = new SqlParameter[2];
                strParametros[0] = new SqlParameter("@COD_MOEDA", SqlDbType.VarChar, 10);
                strParametros[0].Value = cod_moeda;

                strParametros[1] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                strParametros[1].Value = id_cliente;


                dr = SqlHelper.ExecuteReader(this.strConexao, CommandType.StoredProcedure, "SPBCCME_Get_Moeda_Tarifa", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    moeda_tarifa = Convert.ToString(dr["SUB_MOEDA_TARIFA"]);
                }
            }
            catch (Exception ex)
            {
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name + "" + ex.Message;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return moeda_tarifa;
        }

        public decimal ConsultarSaldo(SqlTransaction transaction, int id_cliente, string cod_moeda)
        {
            SqlDataReader dr = null;

            decimal valor_saldo = 0;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[2];
                strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                strParametros[0].Value = id_cliente;

                strParametros[1] = new SqlParameter("@MOEDA", SqlDbType.VarChar, 10);
                strParametros[1].Value = cod_moeda;

                dr = SqlHelper.ExecuteReader(transaction, CommandType.StoredProcedure, "SPBCCME_Saldos_SaldoAtual", strParametros);

                if (dr.HasRows == true)
                {
                    dr.Read();
                    valor_saldo = Convert.ToDecimal(dr["SALDO_ATUAL"]);
                }
                else
                {
                    valor_saldo = 0;
                }

            }
            catch (Exception ex)
            {
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name + "" + ex.Message;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return valor_saldo;
        }

        public DataTable Get_Historico_tarifa(int historico)
        {
            SqlParameter[] strParametros = new SqlParameter[2];

            strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
            strParametros[0].Value = "LER_HISTORICO";

            strParametros[1] = new SqlParameter("@HIS_CODIGO", SqlDbType.Int);
            strParametros[1].Value = historico;

            DataSet dr = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_Admin_Historico", strParametros);
            return dr.Tables[0];

        }

        public DataTable Get_Email_Para(int Id_Cliente)
        {

            SqlParameter[] strParametros = new SqlParameter[2];

            strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
            strParametros[0].Value = "EMAIL_CLIENTE";

            strParametros[1] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[1].Value = Id_Cliente;

            DataSet dr = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103_EMAIL_NOTIFICACAO", strParametros);
            return dr.Tables[0];
        }

        public DataTable Get_Email_Para(SqlTransaction transacao, int Id_Cliente)
        {

            SqlParameter[] strParametros = new SqlParameter[2];

            strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
            strParametros[0].Value = "EMAIL_CLIENTE";

            strParametros[1] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[1].Value = Id_Cliente;

            DataSet dr = SqlHelper.ExecuteDataset(transacao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103_EMAIL_NOTIFICACAO", strParametros);
            return dr.Tables[0];
        }

        public static List<SqlParameter> getParametersFromObject(object obj)
        {
            List<SqlParameter> list = new List<SqlParameter>();
            foreach (FieldInfo info in obj.GetType().GetFields(BindingFlags.Public | BindingFlags.Instance))
            {
                string nomeIdent = "id_operacao";//= ((ModelosCambio.TBL_PRE_BOLETO)obj).nomeIdentificador;
                if (info.Name.ToUpper() != nomeIdent.ToUpper() && info.GetValue(obj) != null)
                {
                    SqlParameter item = new SqlParameter();
                    item.ParameterName = info.Name.ToUpper();
                    if (info.FieldType.Name.ToLower().Contains("int"))
                        item.SqlDbType = SqlDbType.Int;
                    else if (info.FieldType.Name.ToLower().Contains("string"))
                        item.SqlDbType = SqlDbType.VarChar;
                    else if (info.FieldType.Name.ToLower().Contains("decimal"))
                        item.SqlDbType = SqlDbType.Decimal;
                    else if (info.FieldType.Name.ToLower().Contains("datetime"))
                        item.SqlDbType = SqlDbType.DateTime;
                    else if (info.FieldType.Name.ToLower().Contains("bool"))
                        item.SqlDbType = SqlDbType.Bit;

                    if (info.FieldType.Name.ToLower().Contains("datetime"))
                    {
                        DateTime campoData = Convert.ToDateTime(info.GetValue(obj));
                        // Data valida
                        if (campoData.Year > 1900)
                        {
                            item.Value = campoData;
                            list.Add(item);
                        }
                    }
                    else
                    {
                        item.Value = info.GetValue(obj);
                        list.Add(item);
                    }
                }
            }
            return list;
        }

        private string TratarMoedas(string moeda)
        {
            if (!string.IsNullOrWhiteSpace(moeda))
            {
                switch (moeda)
                {
                    case "EUR":
                        return "EURO";
                    case "GBP":
                        return "STG";
                    case "AUD":
                        return "ATD";
                    case "CAD":
                        return "CAN";
                    case "JPY":
                        return "YEN";
                    default:
                        return moeda;
                }
            }
            else
            {
                return moeda;
            }
        }

        private string consultaDoc(int idCli)
        {
            string cliDoc = string.Empty, cliTipDoc = string.Empty, cliPas = string.Empty, cliRes = string.Empty, cliStReceita = string.Empty, statusDoc = "NOK";

            string strSQL = string.Format("SELECT cl_num_doc, cl_tip_doc, cl_passaporte, cl_residente FROM tbl_clientes (NOLOCK) WHERE id_cliente = {0}", idCli);
            DataSet ds = new DataSet();
            ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, strSQL);

            if (ds.Tables[0].Rows.Count > 0)
            {
                if (ds.Tables[0].Rows[0]["cl_num_doc"] != DBNull.Value) cliDoc = ds.Tables[0].Rows[0]["cl_num_doc"].ToString();
                if (ds.Tables[0].Rows[0]["cl_tip_doc"] != DBNull.Value) cliTipDoc = ds.Tables[0].Rows[0]["cl_tip_doc"].ToString().Trim();
                if (ds.Tables[0].Rows[0]["cl_passaporte"] != DBNull.Value) cliPas = ds.Tables[0].Rows[0]["cl_passaporte"].ToString();
                if (ds.Tables[0].Rows[0]["cl_residente"] != DBNull.Value) cliRes = ds.Tables[0].Rows[0]["cl_residente"].ToString();
            }

            if (cliRes.Equals("N"))
                strSQL = string.Format("SELECT cpf_st_receita FROM TBL_CPFS (nolock) WHERE cpf_num = '{0}' AND cl_passaporte = '{1}'", cliDoc, cliPas);
            else
                strSQL = string.Format("SELECT cpf_st_receita FROM TBL_CPFS (nolock) WHERE cpf_num = '{0}'", cliDoc);

            ds = new DataSet();
            ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, strSQL);

            if (ds.Tables[0].Rows.Count > 0)
            {
                if (ds.Tables[0].Rows[0]["cpf_st_receita"] != DBNull.Value) cliStReceita = ds.Tables[0].Rows[0]["cpf_st_receita"].ToString();

                if ((cliStReceita.Equals("0") && cliTipDoc.Equals("CPF")) || (cliStReceita.Equals("2") && cliTipDoc.Equals("CNPJ")))
                    statusDoc = "OK";
            }
            return statusDoc;
        }

        private string GetAprovAuto(string tipo, decimal valorBoleto)
        {
            valorBoleto = valorBoleto < 0 ? 0 : valorBoleto;

            string sql = string.Empty;
            string ConfigTipo = string.Empty;
            string aux = string.Empty;

            switch (tipo)
            {
                case "D": // Doc Venda
                    ConfigTipo = "BOLETO";
                    aux = " AND config_op = 'V'";
                    break;
                case "C": // Doc Compra
                    ConfigTipo = "BOLETO";
                    aux = " AND config_op = 'C'";
                    break;
                case "A": // Assinatura
                    ConfigTipo = "DISPBOL";
                    break;
                case "V": // Verificação de Dispensa de Assinatura
                    ConfigTipo = "ASSINATURA";
                    break;
            }

            sql = "SELECT config_valor = ISNULL(config_valor, 0) FROM TBL_CONFIGURACOES (NOLOCK) WHERE config_tipo = '" + ConfigTipo + "' " + aux;

            string aprovacao = "N";

            DataSet ds = new DataSet();
            ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, sql);

            decimal ValorDisp = ds.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(ds.Tables[0].Rows[0]["config_valor"].ToString()) : 0;

            if (valorBoleto < ValorDisp)
                switch (tipo)
                {
                    case "D": // Doc Venda
                        aprovacao = "S";
                        break;
                    case "C": // Doc Compra
                        aprovacao = "S";
                        break;
                    case "A": // Assinatura
                        aprovacao = "D";
                        break;
                    case "V": // Verificação de Dispensa de Assinatura
                        aprovacao = "D";
                        break;
                }

            return aprovacao;
        }

        private decimal Nivel_Compliance(string tipo, string id_nivel)
        {
            decimal nivelCompliance = 0;

            DataSet ds = new DataSet();
            ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("SELECT comp_mes, comp_ano FROM tbl_aprovacao_compliance (NOLOCK) WHERE comp_nivel = '{0}'", id_nivel.Replace("E", "0")));

            if (ds.Tables[0].Rows.Count > 0)
            {
                if (tipo.ToUpper().Equals("M"))
                    nivelCompliance = Convert.ToDecimal(ds.Tables[0].Rows[0]["comp_mes"].ToString());
                else if (tipo.ToUpper().Equals("A"))
                    nivelCompliance = Convert.ToDecimal(ds.Tables[0].Rows[0]["comp_ano"].ToString());
            }

            return nivelCompliance;
        }

        private decimal Valor_Operado_Compliance(string tipo, int id_cliente, int id_operacao)
        {
            id_operacao = id_operacao > 0 ? id_operacao : 0;

            SqlParameter[] strParametros = new SqlParameter[3];
            strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[0].Value = id_cliente;
            strParametros[1] = new SqlParameter("@ID_OPERACAO", SqlDbType.Int);
            strParametros[1].Value = id_operacao;
            strParametros[2] = new SqlParameter("@TIPO", SqlDbType.Char);
            strParametros[2].Value = tipo;

            DataSet dstRetorno = SqlHelper.ExecuteDataset(strConexao, CommandType.StoredProcedure, "SPBVAR_Valor_Operado_Compliance", strParametros);

            return dstRetorno.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(dstRetorno.Tables[0].Rows[0]["SOMA"].ToString()) : 0;
        }

        private decimal GetLimiteAprovacaoContraPartida(string Empresa)
        {
            DataSet ds = new DataSet();
            StringBuilder sb = new StringBuilder();

            sb.Append("SELECT (CASE WHEN '" + Empresa + "'='BRSA' THEN ");
            sb.Append("             (SELECT ISNULL(UR_OP_VAL_REAIS_MAX,'-1') FROM IK_VAREJO.DBO.TBL_USERS WHERE UR_NOME ='ROBO_CCME_SWIFT') ");
            sb.Append("        ELSE ");
            sb.Append("             (SELECT ISNULL(UR_OP_VAL_REAIS_MAX,'-1') FROM DBVAREJO.DBO.TBL_USERS WHERE UR_NOME ='ROBO_CCME_SWIFT')");
            sb.Append("        END ) AS UR_OP_VAL_REAIS_MAX");
            ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, sb.ToString());

            if (ds.Tables[0].Rows.Count > 0)
            {
                return Convert.ToDecimal(ds.Tables[0].Rows[0]["UR_OP_VAL_REAIS_MAX"] != null ? ds.Tables[0].Rows[0]["UR_OP_VAL_REAIS_MAX"] : -1);
            }
            else
            {
                return -1;
            }
        }

        private string AprovaContraPartidaPorLimite(string empresa, decimal op_taxa_pronto, decimal op_val_moeda, string op_val_reais)
        {

            try
            {
                decimal val_reais;
                decimal val_limite;

                val_limite = GetLimiteAprovacaoContraPartida(empresa);

                if (string.IsNullOrEmpty(op_val_reais.ToString()))
                {
                    val_reais = (op_taxa_pronto * op_val_moeda);
                }

                if ((op_taxa_pronto * op_val_moeda) < val_limite)
                {
                    return "S";
                }
                else
                {
                    return "N";
                }
            }
            catch (Exception e)
            {
                // - Grava na tabela de log
                oLogCCMESwift.DesLog = "Erro - Aprovacao Contra Partida Limite usuario ROBO_CCME_SWIFT: " + e.Message.ToString() + " - " + e.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }

            return "N";
        }



        private string AprovaContraPartidaPorLimiteGoogle(string empresa, decimal op_taxa_pronto, decimal op_val_moeda, string op_val_reais)
        {

            try
            {

                decimal val_limite;

                val_limite = GetLimiteAprovacaoContraPartidaGoogle(empresa);


                if (op_val_moeda <= val_limite)
                {
                    return "S";
                }
                else
                {
                    return "N";
                }
            }
            catch (Exception e)
            {
                // - Grava na tabela de log
                oLogCCMESwift.DesLog = "Erro - Aprovacao Contra Partida Limite usuario ROBO_CCME_SWIFT: " + e.Message.ToString() + " - " + e.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }

            return "N";
        }





        private decimal GetLimiteAprovacaoContraPartidaGoogle(string Empresa)
        {
            DataSet ds = new DataSet();
            StringBuilder sb = new StringBuilder();

            //sb.Append("SELECT (CASE WHEN '" + Empresa + "'='BRSA' THEN ");
            //sb.Append("             (SELECT ISNULL(UR_OP_VAL_REAIS_MAX,'-1') FROM IK_VAREJO.DBO.TBL_USERS WHERE UR_NOME ='ROBO_CCME_SWIFT') ");
            //sb.Append("        ELSE ");
            //sb.Append("             (SELECT ISNULL(UR_OP_VAL_REAIS_MAX,'-1') FROM DBVAREJO.DBO.TBL_USERS WHERE UR_NOME ='ROBO_CCME_SWIFT')");
            //sb.Append("        END ) AS UR_OP_VAL_REAIS_MAX");
            sb.Append("SELECT VL_CAMPO as UR_OP_VAL_REAIS_MAX FROM ik_varejo.dbo.TBL_VAREJO_PARAMETROS (nolock) where NM_CAMPO = 'ValorLimiteAprovaContraPartidaAutomaticaUSD'");


            ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, sb.ToString());

            if (ds.Tables[0].Rows.Count > 0)
            {
                return Convert.ToDecimal(ds.Tables[0].Rows[0]["UR_OP_VAL_REAIS_MAX"] != null ? ds.Tables[0].Rows[0]["UR_OP_VAL_REAIS_MAX"] : -1);
            }
            else
            {
                return -1;
            }
        }

        private string formatarNumeroOrdem(string op_numero_ordem)
        {
            int rest = 0;
            int tam = op_numero_ordem.Length;
            string compl = string.Empty;

            rest = 10 - tam;
            op_numero_ordem = "OP" + op_numero_ordem.PadLeft(10, '0') + "001";

            //for (int i = 0; i < rest; i++)
            //    compl = compl + "0";
            //op_numero_ordem = "OP" + compl + op_numero_ordem + "001";

            return op_numero_ordem;
        }

        private string removerCaracteresEstranhos(string txt)
        {
            txt = txt.Replace("*", "")
                .Replace("-", "")
                .Replace("?", "")
                .Replace("#", "")
                .Replace("+", " ")
                .Replace("(", "")
                .Replace(")", "")
                .Replace("!", "")
                .Replace("'", "")
                .Replace(((char)34).ToString(), "")
                .Replace("&", "")
                .Replace(".", "")
                .Replace(",", "")
                .Replace("!", "")
                .Replace("@", "")
                .Replace("$", "")
                .Replace("%", "")
                .Replace("_", "")
                .Replace("=", "")
                .Replace("º", "")
                .Replace("ª", "")
                .Replace("°", "")
                .Replace("§", "");

            return txt.ToUpper();
        }

        private string retirarAcentos(string str)
        {
            str = str.Replace("Š", "S")
                   .Replace("Ž", "Z")
                   .Replace("š", "s")
                   .Replace("ž", "z")
                   .Replace("Ÿ", "Y")
                   .Replace("À", "A")
                   .Replace("Á", "A")
                   .Replace("Â", "A")
                   .Replace("Ã", "A")
                   .Replace("Ä", "A")
                   .Replace("Å", "A")
                   .Replace("Ç", "C")
                   .Replace("Ç", "C")
                   .Replace("È", "E")
                   .Replace("É", "E")
                   .Replace("Ê", "E")
                   .Replace("Ë", "E")
                   .Replace("Ì", "I")
                   .Replace("Í", "I")
                   .Replace("Î", "I")
                   .Replace("Ï", "I")
                   .Replace("Ð", "D")
                   .Replace("Ñ", "N")
                   .Replace("Ò", "O")
                   .Replace("Ó", "O")
                   .Replace("Ô", "O")
                   .Replace("Õ", "O")
                   .Replace("Ö", "O")
                   .Replace("Ù", "U")
                   .Replace("Ú", "U")
                   .Replace("Û", "U")
                   .Replace("Ü", "U")
                   .Replace("Ý", "Y")
                   .Replace("à", "a")
                   .Replace("á", "a")
                   .Replace("â", "a")
                   .Replace("ã", "a")
                   .Replace("ä", "a")
                   .Replace("å", "a")
                   .Replace("ç", "c")
                   .Replace("è", "e")
                   .Replace("é", "e")
                   .Replace("ê", "e")
                   .Replace("ë", "e")
                   .Replace("ì", "i")
                   .Replace("í", "i")
                   .Replace("î", "i")
                   .Replace("ï", "i")
                   .Replace("ñ", "n")
                   .Replace("ò", "o")
                   .Replace("ó", "o")
                   .Replace("ô", "o")
                   .Replace("õ", "o")
                   .Replace("ö", "o")
                   .Replace("ù", "u")
                   .Replace("ú", "u")
                   .Replace("û", "u")
                   .Replace("ü", "u")
                   .Replace("ý", "y")
                   .Replace("ÿ", "y");

            return str;
        }

        private string[] getGrupoBancario(bool possuiCPF, int id_cliente)
        {
            DataSet ds = new DataSet();

            string[] strArray = new string[5];

            try
            {
                StringBuilder sb = new StringBuilder();

                if (possuiCPF)
                {
                    sb.Append("SELECT abrev_banco, ");
                    sb.Append(" CASE ");
                    sb.Append("  WHEN bc_agencia IS NOT NULL THEN bc_agencia ");
                    sb.Append("  WHEN bc_agencia2 IS NOT NULL THEN bc_agencia2 ");
                    sb.Append(" ELSE bc_agencia3 END AS bc_agencia, ");
                    sb.Append(" CASE ");
                    sb.Append("  WHEN bc_cod_banco IS NOT NULL THEN bc_cod_banco ");
                    sb.Append("  WHEN bc_cod_banco2 IS NOT NULL THEN bc_cod_banco2 ");
                    sb.Append(" ELSE bc_cod_banco3 END AS bc_cod_banco, ");
                    sb.Append(" CASE ");
                    sb.Append("  WHEN bc_conta IS NOT NULL THEN bc_conta ");
                    sb.Append("  WHEN bc_conta2 IS NOT NULL THEN bc_conta2 ");
                    sb.Append(" ELSE bc_conta3 END AS bc_conta, ");
                    sb.Append(" CASE ");
                    sb.Append("  WHEN bc_tipo_conta IS NOT NULL THEN bc_tipo_conta ");
                    sb.Append("  WHEN bc_tipo_conta2 IS NOT NULL THEN bc_tipo_conta2 ");
                    sb.Append(" ELSE bc_tipo_conta3 END AS bc_tipo_conta ");
                    sb.AppendFormat(" FROM tbl_cli_banco_comercio b(NOLOCK) LEFT JOIN tbl_cod_bancos c ON c.cod_banco = b.bc_cod_banco WHERE id_cliente = {0}", id_cliente);

                    ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, sb.ToString());
                }
                else
                {
                    sb.Append("SELECT abrev_banco, ");
                    sb.Append(" CASE ");
                    sb.Append("  WHEN cl_agencia IS NOT NULL THEN cl_agencia ");
                    sb.Append("  WHEN cl_agencia2 IS NOT NULL THEN cl_agencia2 ");
                    sb.Append(" ELSE cl_agencia3 END AS bc_agencia, ");
                    sb.Append(" CASE ");
                    sb.Append("  WHEN cl_cod_banco IS NOT NULL THEN cl_cod_banco ");
                    sb.Append("  WHEN cl_cod_banco2 IS NOT NULL THEN cl_cod_banco2 ");
                    sb.Append(" ELSE cl_cod_banco3 END AS bc_cod_banco, ");
                    sb.Append(" CASE ");
                    sb.Append("  WHEN cl_conta IS NOT NULL THEN cl_conta ");
                    sb.Append("  WHEN cl_conta2 IS NOT NULL THEN cl_conta2 ");
                    sb.Append(" ELSE cl_conta3 END AS bc_conta, ");
                    sb.Append(" CASE ");
                    sb.Append("  WHEN cl_tipo_conta IS NOT NULL THEN cl_tipo_conta ");
                    sb.Append("  WHEN cl_tipo_conta2 IS NOT NULL THEN cl_tipo_conta2 ");
                    sb.Append(" ELSE cl_tipo_conta3 END AS bc_tipo_conta ");
                    sb.AppendFormat(" FROM tbl_clientes b (NOLOCK)  LEFT JOIN tbl_cod_bancos c ON c.cod_banco =  b.cl_cod_banco WHERE ID_CLIENTE = {0}", id_cliente);

                    ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, sb.ToString());
                }

                if (ds.Tables[0].Rows.Count > 0)
                {
                    strArray[0] = ds.Tables[0].Rows[0]["abrev_banco"] != null ? ds.Tables[0].Rows[0]["abrev_banco"].ToString() : string.Empty;
                    strArray[1] = ds.Tables[0].Rows[0]["bc_agencia"] != null ? ds.Tables[0].Rows[0]["bc_agencia"].ToString() : string.Empty;
                    strArray[2] = ds.Tables[0].Rows[0]["bc_cod_banco"] != null ? ds.Tables[0].Rows[0]["bc_cod_banco"].ToString() : string.Empty;
                    strArray[3] = ds.Tables[0].Rows[0]["bc_conta"] != null ? ds.Tables[0].Rows[0]["bc_conta"].ToString() : string.Empty;
                    strArray[4] = ds.Tables[0].Rows[0]["bc_tipo_conta"] != null ? ds.Tables[0].Rows[0]["bc_tipo_conta"].ToString() : string.Empty;
                }
            }
            catch (Exception e)
            {
                // - Grava na tabela de log
                oLogCCMESwift.DesLog = "Erro - Cliente sem dados bancários cadastrados: " + e.Message.ToString() + " - " + e.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }

            return strArray;
        }

        private string getCampoC50k(string cl_tip_doc, int id_cliente, string nome, string endereco_c50k, string cidade_c50k, string num_doc_c50K)
        {
            bool possuiCPF = false;
            possuiCPF = cl_tip_doc.Trim().ToUpper().Equals("CPF");

            string[] gBanco = getGrupoBancario(possuiCPF, id_cliente);
            string base2 = "                                                                                                                                                                     ";
            string linhatexto1 = "";
            if (gBanco[3] != null)
            {
                linhatexto1 = retirarAcentos("/ACC/" + gBanco[3].ToString().Trim() + " " + gBanco[0].ToString().Trim() + " " + gBanco[2].ToString().Trim() + " " + "Ag " + gBanco[1].ToString().Trim());
                linhatexto1 = removerCaracteresEstranhos(linhatexto1);
                linhatexto1 = string.Concat(linhatexto1, base2).Substring(0, 34);
            }
            else
            {
                linhatexto1 = retirarAcentos("/ACC/");
                linhatexto1 = string.Concat(linhatexto1, base2).Substring(0, 34);
            }

            string linhatexto2 = retirarAcentos(nome);
            linhatexto2 = removerCaracteresEstranhos(linhatexto2);
            linhatexto2 = string.Concat(linhatexto2, base2).Substring(0, 35);

            string linhatexto3 = retirarAcentos(endereco_c50k);
            linhatexto3 = removerCaracteresEstranhos(linhatexto3);
            linhatexto3 = string.Concat(linhatexto2, base2).Substring(0, 35);

            string linhatexto4 = retirarAcentos(cidade_c50k);
            linhatexto4 = removerCaracteresEstranhos(linhatexto4);
            linhatexto4 = string.Concat(linhatexto2, base2).Substring(0, 35);

            string linhatexto5 = retirarAcentos(num_doc_c50K);
            linhatexto5 = removerCaracteresEstranhos(linhatexto5);
            linhatexto5 = string.Concat(linhatexto2, base2).Substring(0, 35);

            return linhatexto1 + linhatexto2 + linhatexto3 + linhatexto4 + linhatexto5;
        }

        public decimal CalculaTarifaOperacao(string id_cliente, string moeda, string tipoOp, string tipoEntrega, decimal valor)
        {
            decimal tarifa_op = 0;
            try
            {

                SqlParameter[] strParametros = new SqlParameter[5];
                strParametros[0] = new SqlParameter("@VALOR_ME", SqlDbType.Decimal);
                strParametros[0].Value = valor;
                strParametros[1] = new SqlParameter("@TIPO_OP", SqlDbType.Char, 10);
                strParametros[1].Value = tipoEntrega;
                strParametros[2] = new SqlParameter("@TIPO_MOEDA", SqlDbType.Char, 5);
                strParametros[2].Value = moeda;
                strParametros[3] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                strParametros[3].Value = id_cliente;
                strParametros[4] = new SqlParameter("@COMPRA_VENDA", SqlDbType.Char, 1);
                strParametros[4].Value = tipoOp;

                DataSet dsParametros = null;
                dsParametros = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "GET_TARIFA_CLIENTE", strParametros);

                return Convert.ToDecimal(dsParametros.Tables[0].Rows[0]["TP_TARIFA"].ToString());


            }
            catch (Exception e)
            {
                // - Grava na tabela de log
                oLogCCMESwift.DesLog = "Erro - CalculaTarifaOperacao: " + e.Message.ToString() + " - " + e.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
            return tarifa_op;
        }

        public decimal[] CalculaTaxaPronto(string moeda, string tipoOp)
        {
            decimal taxa_d = 0;
            decimal taxaPronto_d = 0;
            decimal taxaPronto = 0;
            decimal paridade_d = 0;
            decimal paridade = 0;
            try
            {
                StringBuilder sb_tmoedas = new StringBuilder();
                sb_tmoedas.Append("SELECT Cod_moeda,	Tx_Banco,	Tx_Cotacao,	Custo,	Tx_cotacaoC,	HoraCot,	Paridade,	rowguid,	ordem,	Tx_Compra,	Tx_Venda,	clas_paridade,	Codigo_Moeda,	mes_letra");
                sb_tmoedas.Append(" FROM VAREJO..TMOEDAS b (NOLOCK) WHERE b.cod_moeda = 'USD'");
                DataSet dt_d = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, sb_tmoedas.ToString());

                //ModelosVarejo.TMOEDAS tMoedas = new ModelosVarejo.TMOEDAS();
                //DataTable dt_d = tMoedas.obterDataTable("cod_moeda = 'USD'");
                //ds.Tables[0].Rows[0]["abrev_banco"]
                if (dt_d.Tables[0].Rows.Count > 0)
                {
                    if (tipoOp == "V")
                        taxa_d = Convert.ToDecimal("0" + dt_d.Tables[0].Rows[0]["tx_venda"].ToString());
                    else
                        taxa_d = Convert.ToDecimal("0" + dt_d.Tables[0].Rows[0]["tx_compra"].ToString());

                    paridade_d = Convert.ToDecimal("0" + dt_d.Tables[0].Rows[0]["paridade"].ToString());
                }

                taxaPronto_d = Math.Round(taxa_d * paridade_d, 8);

                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT id_moedas,id_user,moe_simbolo,moe_codigo,moe_nome,moe_tipo,moe_desvio,moe_dt_inclusao,MOE_ARB_ONLINE");
                sb.Append(" ,MOE_PERMITE_ME,moe_casa_dec,MOE_PADRAO_ME,moe_swift,moe_cambio_online,moe_nomeresumido,MOE_DESCCCME,moe_desvio_col");
                sb.Append(" , MOE_CASASDEC_COL,MOE_ORDEMLISTA_COL,MOE_SOMENTE_CONSULTA_CCME,moe_somenteBanco");
                sb.AppendFormat(" FROM TBL_MOEDAS b (NOLOCK) WHERE b.moe_simbolo = '{0}'", moeda);
                DataSet ds_m = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, sb.ToString());

                DataTable dt_m = ds_m.Tables[0];
                /* Taxas na moeda */

                //Modelos.ModelosCambio.TBL_MOEDAS tblMoedas = new Modelos.ModelosCambio.TBL_MOEDAS();
                //DataTable dt_m = tblMoedas.obterDataTable("moe_simbolo = '" + moeda + "'");

                string moeda_tipo = "A";
                if (dt_m.Rows.Count > 0)
                {
                    moeda_tipo = dt_m.Rows[0]["moe_tipo"].ToString();
                }

                StringBuilder sb_tmoedasOp = new StringBuilder();
                sb_tmoedasOp.Append("SELECT Cod_moeda,	Tx_Banco,	Tx_Cotacao,	Custo,	Tx_cotacaoC,	HoraCot,	Paridade,	rowguid,	ordem,	Tx_Compra,	Tx_Venda,	clas_paridade,	Codigo_Moeda,	mes_letra");
                sb_tmoedasOp.AppendFormat(" FROM VAREJO..TMOEDAS b (NOLOCK) WHERE b.cod_moeda = '{0}'", moeda);
                DataSet dt_p = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, sb_tmoedasOp.ToString());

                DataTable dt = dt_p.Tables[0];
                //DataTable dt = tMoedas.obterDataTable("cod_moeda = '" + moeda + "'");
                if (dt.Rows.Count > 0)
                {
                    paridade = Convert.ToDecimal("0" + dt.Rows[0]["paridade"].ToString());
                }

                if (paridade > 0)
                {
                    if (moeda_tipo == "A")
                        taxaPronto = Math.Round(taxa_d / paridade, 8);
                    else
                        taxaPronto = Math.Round(taxa_d * paridade, 8);
                }
            }
            catch (Exception ex)
            {
                // Grava na tabela de log
                oLogCCMESwift.DesLog = "Erro (CalculaTaxaPronto): " + ex.Message.ToString() + " - " + ex.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }

            return (new decimal[] { taxaPronto, taxaPronto_d, paridade });
        }

        public decimal CalculaTarifaBanco(string moeda, string tipoOp, string tipoEntrega, decimal valor)
        {

            try
            {
                decimal tarifa_banco = 0;
                DataSet ds = new DataSet();
                ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("SELECT id_rt,id_user,rt_tipo,rt_operacao,rt_val_minimo,rt_val_maximo,rt_moeda,rt_val_tarifa,rt_dt_inclusao,rt_obs FROM TBL_REGRAS_TARIFAS (NOLOCK) WHERE rt_operacao = '{0}' and rt_tipo = '{1}'", tipoOp, tipoEntrega));

                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        if (item["rt_moeda"].ToString().Trim() == "US$")
                        {
                            if (moeda.Trim() == "USD")
                            {
                                tarifa_banco = Convert.ToDecimal(item["rt_val_tarifa"].ToString());
                                break;
                            }
                        }
                        else if (item["rt_moeda"].ToString().Trim() == "EURO")
                        {
                            if (moeda.Trim() == "EURO")
                            {
                                tarifa_banco = Convert.ToDecimal(item["rt_val_tarifa"].ToString());
                                break;
                            }
                        }
                        else if (item["rt_moeda"].ToString().Trim() == "ATD")
                        {
                            if (moeda.Trim() == "ATD")
                            {
                                tarifa_banco = Convert.ToDecimal(item["rt_val_tarifa"].ToString());
                                break;
                            }
                        }
                        else if (item["rt_moeda"].ToString().Trim() == "OUTRAS")
                        {
                            if (moeda.Trim() != "USD" && moeda.Trim() != "EURO" && moeda.Trim() != "ATD")
                            {
                                tarifa_banco = Convert.ToDecimal(item["rt_val_tarifa"].ToString());
                                break;
                            }
                        }
                        else if (item["rt_moeda"].ToString().Trim() == "TODAS")
                        {
                            tarifa_banco = Convert.ToDecimal(item["rt_val_tarifa"].ToString());
                            break;
                        }
                    }

                }


                return tarifa_banco;
            }

            catch (Exception ex)
            {
                oLogCCMESwift.DesLog = "Erro : " + ex.Message.ToString() + " - " + ex.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                return 0;
            }
        }

        public bool verificarDiaUtil()
        {
            bool bResultado = true;
            DateTime dataDiaUtil = DateTime.MinValue;
            string tipoFeriado = string.Empty;

            using (SqlConnection connection = new SqlConnection(this.strConexao))
            {
                connection.Open();

                DateTime dataAtual = DateTime.Now.Date;

                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@DATABASE", SqlDbType.SmallDateTime);
                strParametros[0].Value = dataAtual;

                DataSet ds = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "DBFERIADO.dbo.SPBR_Verifica_Proxima_Data_Vigente", strParametros);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        dataDiaUtil = ds.Tables[0].Rows[i]["DATAMN"] != null ?
                            Convert.ToDateTime(ds.Tables[0].Rows[i]["DATAMN"].ToString()) :
                            (ds.Tables[0].Rows[i]["DATAME"] != null ?
                            Convert.ToDateTime(ds.Tables[0].Rows[i]["DATAME"].ToString()) : DateTime.Now.Date);

                        tipoFeriado = ds.Tables[0].Rows[i]["TIPOFERIADO"] != null ? ds.Tables[0].Rows[i]["TIPOFERIADO"].ToString() : string.Empty;
                    }
                }

                if (dataAtual != dataDiaUtil) // - Fim de semana
                    bResultado = false;
                else if (!string.IsNullOrEmpty(tipoFeriado)) // - Feriado (Nacional)
                {
                    if (tipoFeriado.Equals("Nacional"))
                        bResultado = false;
                }
            }

            return bResultado;
        }

        public bool ExisteProcuracaoAprovada(SqlTransaction transacao, int idCliente)
        {
            //StringBuilder sql = new StringBuilder();
            //sql.Append("SELECT * FROM TBL_COL_UPLOAD_ARQUIVOS AS U ");
            //sql.Append("INNER JOIN TBL_STATUSPROCURACAO AS S ");
            //sql.Append("ON U.STATUS  = S.STP_CODIGO ");
            //sql.Append("WHERE NR_DOCTO = @ID_CLIENTE AND TIPO_OPERACAO = 'P' AND STP_NOME = 'APROVADO'");

            //SqlParameter[] parametros = new SqlParameter[1];
            //parametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            //parametros[0].Value = idCliente;

            //var ds = SqlHelper.ExecuteDataset(transacao, CommandType.Text, sql.ToString(), parametros);

            SqlParameter[] parametros = new SqlParameter[5];
            parametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 100);
            parametros[0].Value = "SELECT";
            parametros[1] = new SqlParameter("@ID", SqlDbType.Int);
            parametros[1].Value = DBNull.Value;
            parametros[2] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            parametros[2].Value = idCliente;
            parametros[3] = new SqlParameter("@TIPO_PROCURACAO", SqlDbType.Char, 1);
            parametros[3].Value = DBNull.Value;
            parametros[4] = new SqlParameter("@STATUS", SqlDbType.Char, 1);
            parametros[4].Value = 3;

            var dt = SqlHelper.ExecuteDataset(transacao, CommandType.StoredProcedure, "PR_PROCURACAO_CLIENTE", parametros);

            return dt != null && dt.Tables.Count > 0 && dt.Tables[0].Rows.Count > 0;
        }

        private void EnviarEmail(TBL_PRE_BOLETO preboleto, string IDSistemaEmail, DateTime DtLancamento)
        {
            string resposta = null;
            string email_para = null;
            string dados = "";

            try
            {
                DataTable dtMAIL = Get_Email_Para(preboleto.id_cliente);
                if (dtMAIL.Rows.Count > 0)
                    email_para = dtMAIL.Rows[0]["EMAIL_PARA"].ToString();

                if (preboleto.sistema_origem.Equals("PC"))
                {
                    //var infoEmail = new InfoEmail
                    //{
                    //    IdSistema = IDSistemaEmail,
                    //    IdEmpresa = preboleto.EMPRESA.ToString(),
                    //    Codigo = "50",
                    //    ListaEmailPara = email_para,
                    //    ListaEmailCc = "",
                    //    Assunto = "Aviso de Pagamento Recebido do Exterior (" + String.Format("{0:dd/MM/yyyy}", DtLancamento) + ") - " + dtSt.Tables[0].Rows[0]["id_operacao"],
                    //    ListaArquivos = null,
                    //    ListaParametrosCorpo = new List<EmailService.Parametro>()
                    //};
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "EnderecoExternoImagens", Valor = dsSwift.Tables[0].Rows[i]["LINK"].ToString() + "/Cambio_On-line" });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "UrlEmpresa", Valor = dsSwift.Tables[0].Rows[i]["LINK"].ToString() });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "REMETENTE", Valor = pre.op_inf_fav });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "MOEDA", Valor = Moeda });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "VALOR_ME", Valor = OrValor.ToString("N", new System.Globalization.CultureInfo("pt-BR").NumberFormat) });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "DATA", Valor = DtLancamento.ToString("dd/MM/yyyy") });
                    //var serializer = new JavaScriptSerializer();
                    //dados = serializer.Serialize(infoEmail);
                }
                else
                {
                    string UrlImagem = null;
                    if (preboleto.EMPRESA.Equals(1))
                    {
                        UrlImagem = System.Configuration.ConfigurationManager.AppSettings.Get("URLImagensVArejoBRSA");
                    }
                    else
                    {
                        UrlImagem = System.Configuration.ConfigurationManager.AppSettings.Get("URLImagensVArejoCOTA");
                    }

                    var infoEmail = new InfoEmail
                    {
                        IdSistema = IDSistemaEmail.ToString(),
                        IdEmpresa = preboleto.EMPRESA.ToString(),
                        Codigo = "67",
                        ListaEmailPara = email_para,
                        ListaEmailCc = "",
                        Assunto = "Aviso de Ordem de Pagamento Recebida",
                        ListaArquivos = null,
                        ListaParametrosCorpo = new List<EmailService.Parametro>()
                    };

                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "cl_email", Valor = email_para });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "nome", Valor = dsSwift.Tables[0].Rows[i]["nome"].ToString() });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "op_n_boleto", Valor = Convert.ToInt32(dtSt.Tables[0].Rows[0]["ID_OPERACAO"].ToString()).ToString() });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "EnderecoExternoImagens", Valor = UrlImagem });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "op_inf_fav", Valor = pre.op_inf_fav });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "op_val_moeda_aux", Valor = OrValor.ToString("N", new System.Globalization.CultureInfo("pt-BR").NumberFormat) });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "moeda", Valor = Moeda });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "dataCredito", Valor = DtLancamento.ToString("dd/MM/yyyy") });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "dataVencimento", Valor = DtLancamento.AddDays(180).ToString("dd/MM/yyyy") });
                    //infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "op_taxa_cambio_email", Valor = "false" });

                    var serializer = new JavaScriptSerializer();
                    dados = serializer.Serialize(infoEmail);
                }
                var rest = new RestClient(wsEmailService);
                resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));
                if (!resposta.Equals("Não foi possivel enviar o email"))//enviado com sucesso
                {
                    //oLogCCMESwift.DesLog = "E-mail: Enviado id: " + resposta + " Boleto: " + dtSt.Tables[0].Rows[0]["ID_OPERACAO"].ToString() + " Cliente:" + dsSwift.Tables[0].Rows[i]["nome"].ToString();
                    //oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    //oLogCCMESwift.TpoLog = "I";
                    //oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                    ////logar CRM o envio do Email 
                    ////"insert into TBL_CRM (id_usuario,id_corretora,crm_cpf_cnpj,crm_ocorrencia,crm_passaporte,crm_nboleto) values ('"&us_con&"','"&us_corretora_con&"','"&cl_num_doc&"','Email de Aviso de Ordem de Pagamento Recebida enviado para: "&cl_email&" | Taxa Sugerida: R$ "&FormataValor2(op_taxa_cambio_email)&" / US$.','"&cl_passaporte&"','"&op_n_boleto&"')"
                    //string msgEmail = null;
                    //msgEmail = "Email de Aviso de Ordem de Pagamento Recebida enviado para: " + email_para + " | Taxa Sugerida: R$ / US$.";

                    //StringBuilder sb = new StringBuilder();
                    //sb.Append("INSERT INTO TBL_CRM (ID_USUARIO, CRM_CPF_CNPJ, ID_CORRETORA, CRM_OCORRENCIA, CRM_NBOLETO, CRM_DATA) VALUES ");
                    //sb.AppendFormat("({0}, {1}, {2},'{3}', {4}, GETDATE())",
                    //ID_USER_BOLETO, dsSwift.Tables[0].Rows[i]["CL_NUM_DOC"].ToString(), preboleto.id_corretora.ToString(), msgEmail, dtSt.Tables[0].Rows[0]["ID_OPERACAO"].ToString());

                    //SqlHelper.ExecuteNonQuery(strConexao, CommandType.Text, sb.ToString());

                }
                else //erro ao enviar o email 
                {//Não foi possivel enviar o email
                    //oLogCCMESwift.DesLog = "Erro ao Enviar E-mail: Resposta=" + resposta + "  boleto:" + dtSt.Tables[0].Rows[0]["ID_OPERACAO"].ToString();
                    //oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    //oLogCCMESwift.TpoLog = "E";
                    //oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                }


            }
            catch (Exception x)
            {
                oLogCCMESwift.DesLog = "Erro ao Enviar E-mail: Resposta=" + resposta + " Msg: " + x.Message.ToString() + " - " + x.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
        }

        public void EnviarEmailGoogleManual(SqlTransaction transacao, TBL_PRE_BOLETO preboleto, string idSistemaEmail, string nomeCliente, string link, bool googleautomatico, string cliTipo, string pEmailPara = null)
        {
            string resposta = null;
            string email_para = null;
            string dados = "";

            try
            {
                var cultureInfo = new System.Globalization.CultureInfo("pt-br");

                DataTable dtMAIL = Get_Email_Para(preboleto.id_cliente);
                if (dtMAIL.Rows.Count > 0)
                    email_para = dtMAIL.Rows[0]["EMAIL_PARA"].ToString();
                email_para = string.IsNullOrEmpty(pEmailPara) ? email_para : pEmailPara;
                var infoEmail = new InfoEmail
                {
                    IdSistema = idSistemaEmail,
                    IdEmpresa = preboleto.EMPRESA.ToString(),
                    Codigo = "67",
                    ListaEmailPara = email_para,
                    ListaEmailCc = "",
                    Assunto = "Aviso de Ordem de Pagamento Recebida",
                    ListaArquivos = null,
                    ListaParametrosCorpo = new List<EmailService.Parametro>()
                };

                CarregarParametrosGoogle(transacao, infoEmail, preboleto, nomeCliente, googleautomatico, cliTipo);

                /*  

                infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "EnderecoExternoImagens", Valor = link + "/images/cabecalhoportalemail.gif" });
                infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "UrlEmpresa", Valor = link });
                infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "Cliente", Valor = nomeCliente });
                infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "NumeroBoleto", Valor = preboleto.op_n_boleto.ToString() });
                infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "Data", Valor = preboleto.op_data_follow_up.ToString("dd/MM/yyyy") });
                infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "Ordenante", Valor = preboleto.op_inf_fav });
                infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "Moeda", Valor = preboleto.op_tipo_moeda });
                infoEmail.ListaParametrosCorpo.Add(new EmailService.Parametro { Nome = "ValorMe", Valor = preboleto.op_val_moeda.ToString("N", cultureInfo.NumberFormat) });

                */

                var serializer = new JavaScriptSerializer();

                // infoEmail.IdSistema = "16";
                // infoEmail.ListaEmailPara = "marcos.costa.ext@cotacao.com.br";
                // //wsEmailService = @"http://wstemplateemail/Service/EnviarEmail";
                // wsEmailService = @"http://wstemplateEmail.homologacao/Service/EnviarEmail";
                // //wsEmailService = @"http://localhost/WSTemplateEmail/Service/EnviarEmail";
                //// wsEmailService = @"http://wsemail.desenvolvimento/Service/EnviarEmail";
                dados = serializer.Serialize(infoEmail);



                var rest = new RestClient(wsEmailService);
                resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));
                if (!resposta.Equals("Não foi possivel enviar o email"))//enviado com sucesso
                {
                    oLogCCMESwift.DesLog = "E-mail: Enviado id: " + resposta + " Boleto: " + preboleto.op_n_boleto + " Cliente:" + nomeCliente;
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.TpoLog = "I";
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                    //logar CRM o envio do Email 
                    string msgEmail = string.Format("Email de Aviso de Ordem de Pagamento Recebida enviado para: {0} | Valor: {1} {2}.", email_para, preboleto.op_tipo_moeda, preboleto.op_val_moeda);

                    StringBuilder sb = new StringBuilder();
                    sb.Append("INSERT INTO TBL_CRM (ID_USUARIO, CRM_CPF_CNPJ, ID_CORRETORA, CRM_OCORRENCIA, CRM_NBOLETO, CRM_DATA) VALUES ");
                    sb.AppendFormat("({0}, {1}, {2},'{3}', {4}, GETDATE())",
                    preboleto.id_user_criacao, preboleto.CRM_CPF_CNPJ, preboleto.id_corretora.ToString(), msgEmail, preboleto.op_n_boleto);

                    SqlHelper.ExecuteNonQuery(transacao, CommandType.Text, sb.ToString());
                }
                else //erro ao enviar o email 
                {//Não foi possivel enviar o email
                    oLogCCMESwift.DesLog = "Erro ao Enviar E-mail: Resposta=" + resposta + "  boleto:" + preboleto.op_n_boleto;
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.TpoLog = "E";
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                }
            }
            catch (Exception x)
            {
                oLogCCMESwift.DesLog = "Erro ao Enviar E-mail: Resposta=" + resposta + " Msg: " + x.Message.ToString() + " - " + x.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
        }

        private void CarregarParametrosGoogle(SqlTransaction transacao, InfoEmail info, TBL_PRE_BOLETO obj, string NomeCliente, bool googleautomatico, string cliTipo)
        {

            var serializer = new JavaScriptSerializer();
            decimal vlrReceber = obj.op_val_reais.HasValue ? (obj.op_val_reais.Value - obj.Vlr_IOF - obj.op_tarifa_operacao) : 0;

            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            { Nome = "NomeCliente", Valor = NomeCliente });
            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            { Nome = "Ordenante", Valor = obj.op_inf_fav });
            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            { Nome = "NumeroContrato", Valor = obj.op_n_boleto.ToString() });
            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            { Nome = "ValorRecebido", Valor = obj.op_val_moeda.ToString("N", new System.Globalization.CultureInfo("pt-br").NumberFormat) });


            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            {
                Nome = "TaxaCambio",
                Valor = obj.op_tx_operacao.HasValue ? obj.op_tx_operacao.Value.ToString().Replace('.', ',')
            : "0,00"
            });

            if (obj.op_tx_operacao.HasValue)
            {
                info.ListaParametrosCorpo.Add(new EmailService.Parametro()
                { Nome = "Tarifa", Valor = obj.op_tarifa_operacao.ToString("N", new System.Globalization.CultureInfo("pt-br").NumberFormat) });
                info.ListaParametrosCorpo.Add(new EmailService.Parametro()
                { Nome = "IOF", Valor = obj.Vlr_IOF.ToString("N", new System.Globalization.CultureInfo("pt-br").NumberFormat) });
                info.ListaParametrosCorpo.Add(new EmailService.Parametro()
                { Nome = "VET", Valor = Convert.ToString(vlrReceber == 0 ? 0 : (Math.Round(vlrReceber / obj.op_val_moeda, 4, MidpointRounding.AwayFromZero))) });
                info.ListaParametrosCorpo.Add(new EmailService.Parametro()
                { Nome = "Total", Valor = vlrReceber.ToString("N") });
            }



            string notificacao = string.Empty;
            string data = string.Empty;
            string tituloStatus = string.Empty;

            bool BoletoAcimaDoLimite = GetAprovAuto("V", obj.op_val_reais.HasValue ? obj.op_val_reais.Value : 0) == "N";
            bool ExisteAssinaturaOuProcuracao = obj.op_assinado != "N" || ExisteProcuracaoAprovada(transacao, obj.id_cliente);
            bool PermitidoEmitirBoleto = BoletoAcimaDoLimite && ExisteAssinaturaOuProcuracao || !BoletoAcimaDoLimite;

            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            {
                Nome = "Informativo",
                Valor = string.Format("O prazo para pagamento está sujeito a possível solicitação e análise documental{0}.",
                                       PermitidoEmitirBoleto ? string.Empty : " bem como assinatura do contrato de câmbio")
            });

            //   Zero faz aparecer a faixa com o informe da necessidade da procuração ou assinatura. 

            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            {
                Nome = "StatusProcuracao",
                Valor = Convert.ToInt32(PermitidoEmitirBoleto && obj.op_tx_operacao.HasValue).ToString()
            });

            #region Status Google
            List<EmailService.Parametro> param = new List<EmailService.Parametro>();
            //3A
            param.Add(new EmailService.Parametro() { Nome = "Nome", Valor = "Remessa recebida do exterior" });
            param.Add(new EmailService.Parametro() { Nome = "Notificacao", Valor = notificacao });
            param.Add(new EmailService.Parametro() { Nome = "Data", Valor = obj.op_data_boleto.ToString("dd/MM/yyyy") });


            //3B 4B            
            notificacao = "Para fechamento da sua operação acesse www.cambiorendimento.com.br => Menu => Remessas Recebidas.";//Se fechamento manual
            data = string.Empty;
            tituloStatus = "Fechamento do câmbio pendente";
            if (googleautomatico)
            {
                notificacao = string.Empty;
                data = obj.op_data_boleto.ToString("dd/MM/yyyy");
                tituloStatus = "Fechamento do câmbio realizado";
            }
            param.Add(new EmailService.Parametro() { Nome = "Nome", Valor = tituloStatus });
            param.Add(new EmailService.Parametro() { Nome = "Notificacao", Valor = notificacao });
            param.Add(new EmailService.Parametro() { Nome = "Data", Valor = data });

            //3C 4C
            notificacao = cliTipo.Trim() == "CPF" ? @"Para efetuar a assinatura, acesse www.cambiorendimento.com.br => menu => clique na opção Assinar Contratos" //pf
             : @"Para efetuar a assinatura, acesse www.cambiorendimento.com.br => Menu => Consultar => Remessas Recebidas e clique na opção Contrato de Câmbio"; //pj
            data = string.Empty;
            if (PermitidoEmitirBoleto && obj.op_tx_operacao.HasValue)
            {
                tituloStatus = "Envio do contrato assinado (dispensado)";
                notificacao = string.Empty;
                data = obj.op_data_boleto.ToString("dd/MM/yyyy");
            }
            else tituloStatus = "Envio do contrato assinado (pendente)";
            param.Add(new EmailService.Parametro() { Nome = "Nome", Valor = tituloStatus });
            param.Add(new EmailService.Parametro() { Nome = "Notificacao", Valor = notificacao });
            param.Add(new EmailService.Parametro() { Nome = "Data", Valor = data });


            //3D 4D              
            // operacao abaixo ou acima de 10k
            notificacao = (BoletoAcimaDoLimite) ? "Para consultar suas operações, acesse www.cambiorendimento.com.br => Menu => Consultar => Remessas Recebidas"
            : "Para consultar suas operações, acesse www.cambiorendimento.com.br => Menu => Consultar => Remessas Recebidas";
            tituloStatus = "Pagamento dos valores em Reais (pendente)";
            data = string.Empty;
            if (googleautomatico && PermitidoEmitirBoleto)
            {
                tituloStatus = "Pagamento dos valores em Reais (* Liberado - Até 1 dia útil)";
                data = obj.op_data_boleto.ToString("dd/MM/yyyy");
            }

            param.Add(new EmailService.Parametro() { Nome = "Nome", Valor = tituloStatus });
            param.Add(new EmailService.Parametro() { Nome = "Notificacao", Valor = notificacao });
            param.Add(new EmailService.Parametro() { Nome = "Data", Valor = data });


            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            { Nome = "ListaStatusGoogle", Valor = serializer.Serialize(param) });

            #endregion

        }

        /// <summary>
        /// Carrega os parâmetros para montar o corpo do e-mail CCME
        /// </summary>
        /// <param name="info"></param>
        /// <param name="obj"></param>
        /// <param name="NomeCliente"></param>
        private void CarregarParametrosCCME(InfoEmail info, TBL_PRE_BOLETO obj, string nomeCliente, string ordenante, string numeroReferenciaCCME)
        {
            var serializer = new JavaScriptSerializer();

            string valorRecebido = Convert.ToDecimal(obj.op_val_reais).ToString("N", new System.Globalization.CultureInfo("pt-br").NumberFormat);

            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            { Nome = "NomeCliente", Valor = nomeCliente.Trim() });
            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            { Nome = "Ordenante", Valor = ordenante.Trim() });
            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            { Nome = "NumeroContrato", Valor = numeroReferenciaCCME.Trim() });
            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            { Nome = "ValorRecebido", Valor = string.Format("{0}$ {1}", obj.op_tipo_moeda, valorRecebido.ToString()) });

            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            {
                Nome = "Informativo",
                Valor = string.Format("O valor recebido já está disponível em sua conta de moeda estrangeira. Para consultar sua movimentação acesse o portal de câmbio na opção CCME.")
            });

            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            {
                Nome = "StatusProcuracao",
                Valor = "1"
            });

            //List<Parametro> param = new List<Parametro>();

            info.ListaParametrosCorpo.Add(new EmailService.Parametro()
            { Nome = "ListaStatusGoogle", Valor = serializer.Serialize(new List<Parametro>()) });
        }

        private void EnviarEmailGoogleAutomaticoOperacoesFinalizadas(SqlTransaction transacao, TBL_PRE_BOLETO preboleto, string idSistemaEmail, string nomeCliente, string link, bool googleautomatico, string cliTipo, string pEmailPara = null)
        {
            string resposta = null;
            string email_para = null;
            string dados = "";

            try
            {
                var cultureInfo = new System.Globalization.CultureInfo("pt-br");

                DataTable dtMAIL = Get_Email_Para(preboleto.id_cliente);
                if (dtMAIL.Rows.Count > 0)
                    email_para = dtMAIL.Rows[0]["EMAIL_PARA"].ToString();

                var infoEmail = new InfoEmail
                {
                    IdSistema = idSistemaEmail,
                    IdEmpresa = preboleto.EMPRESA.ToString(),
                    Codigo = "67",
                    ListaEmailPara = email_para,
                    ListaEmailCc = "",
                    Assunto = "Aviso de Ordem de Pagamento Recebida",
                    ListaArquivos = null,
                    ListaParametrosCorpo = new List<EmailService.Parametro>()
                };
                CarregarParametrosGoogle(transacao, infoEmail, preboleto, nomeCliente, googleautomatico, cliTipo);

                var serializer = new JavaScriptSerializer();
                dados = serializer.Serialize(infoEmail);

                var rest = new RestClient(wsEmailService);
                resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));
                if (!resposta.Equals("Não foi possivel enviar o email"))//enviado com sucesso
                {
                    oLogCCMESwift.DesLog = "E-mail: Enviado id: " + resposta + " Boleto: " + preboleto.op_n_boleto + " Cliente:" + nomeCliente;
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.TpoLog = "I";
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                    //logar CRM o envio do Email 
                    string msgEmail = string.Format("Email de Aviso de Ordem de Pagamento Recebida enviado para: {0} | Taxa Sugerida: {1} | Valor: {2} {3}.", email_para, preboleto.op_tx_operacao, preboleto.op_tipo_moeda, preboleto.op_val_moeda);

                    StringBuilder sb = new StringBuilder();
                    sb.Append("INSERT INTO TBL_CRM (ID_USUARIO, CRM_CPF_CNPJ, ID_CORRETORA, CRM_OCORRENCIA, CRM_NBOLETO, CRM_DATA) VALUES ");
                    sb.AppendFormat("({0}, {1}, {2},'{3}', {4}, GETDATE())",
                    preboleto.id_user_criacao, preboleto.CRM_CPF_CNPJ, preboleto.id_corretora.ToString(), msgEmail, preboleto.op_n_boleto);

                    SqlHelper.ExecuteNonQuery(transacao, CommandType.Text, sb.ToString());
                }
                else //erro ao enviar o email 
                {//Não foi possivel enviar o email
                    oLogCCMESwift.DesLog = "Erro ao Enviar E-mail: Resposta=" + resposta + "  boleto:" + preboleto.op_n_boleto;
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.TpoLog = "E";
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                }
            }
            catch (Exception x)
            {
                oLogCCMESwift.DesLog = "Erro ao Enviar E-mail: Resposta=" + resposta + " Msg: " + x.Message.ToString() + " - " + x.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
        }

        private void EnviarEmailGoogleAutomaticoOperacoesEmAberto(SqlTransaction transacao, TBL_PRE_BOLETO preboleto, string idSistemaEmail, string nomeCliente, string link, bool googleautomatico, string cliTipo, string pEmailPara = null)
        {
            string resposta = null;
            string email_para = null;
            string dados = "";

            try
            {
                var cultureInfo = new System.Globalization.CultureInfo("pt-br");

                DataTable dtMAIL = Get_Email_Para(preboleto.id_cliente);
                if (dtMAIL.Rows.Count > 0)
                    email_para = dtMAIL.Rows[0]["EMAIL_PARA"].ToString();

                var infoEmail = new InfoEmail
                {
                    IdSistema = idSistemaEmail,
                    IdEmpresa = preboleto.EMPRESA.ToString(),
                    Codigo = "67",
                    ListaEmailPara = email_para,
                    ListaEmailCc = "",
                    Assunto = "Aviso de Ordem de Pagamento Recebida",
                    ListaArquivos = null,
                    ListaParametrosCorpo = new List<EmailService.Parametro>()
                };
                CarregarParametrosGoogle(transacao, infoEmail, preboleto, nomeCliente, googleautomatico, cliTipo);

                var serializer = new JavaScriptSerializer();
                dados = serializer.Serialize(infoEmail);

                var rest = new RestClient(wsEmailService);
                resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));
                if (!resposta.Equals("Não foi possivel enviar o email"))//enviado com sucesso
                {
                    oLogCCMESwift.DesLog = "E-mail: Enviado id: " + resposta + " Boleto: " + preboleto.op_n_boleto + " Cliente:" + nomeCliente;
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.TpoLog = "I";
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                    //logar CRM o envio do Email 
                    string msgEmail = string.Format("Email de Aviso de Ordem de Pagamento Recebida enviado para: {0} | Taxa Sugerida: {1} | Valor: {2} {3}.", email_para, preboleto.op_tx_operacao, preboleto.op_tipo_moeda, preboleto.op_val_moeda);

                    StringBuilder sb = new StringBuilder();
                    sb.Append("INSERT INTO TBL_CRM (ID_USUARIO, CRM_CPF_CNPJ, ID_CORRETORA, CRM_OCORRENCIA, CRM_NBOLETO, CRM_DATA) VALUES ");
                    sb.AppendFormat("({0}, {1}, {2},'{3}', {4}, GETDATE())",
                    preboleto.id_user_criacao, preboleto.CRM_CPF_CNPJ, preboleto.id_corretora.ToString(), msgEmail, preboleto.op_n_boleto);

                    SqlHelper.ExecuteNonQuery(transacao, CommandType.Text, sb.ToString());
                }
                else //erro ao enviar o email 
                {//Não foi possivel enviar o email
                    oLogCCMESwift.DesLog = "Erro ao Enviar E-mail: Resposta=" + resposta + "  boleto:" + preboleto.op_n_boleto;
                    oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                    oLogCCMESwift.TpoLog = "E";
                    oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
                }
            }
            catch (Exception x)
            {
                oLogCCMESwift.DesLog = "Erro ao Enviar E-mail: Resposta=" + resposta + " Msg: " + x.Message.ToString() + " - " + x.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
        }

        /// <summary>
        /// Enviar e-mail para cliente que recebeu crédito na CCME com ordem recebida do exterior 
        /// </summary>
        /// <param name="transacao"></param>
        /// <param name="preboleto"></param>
        /// <param name="idSistemaEmail"></param>
        /// <param name="nomeCliente"></param>
        /// <param name="link"></param>
        /// <param name="googleautomatico"></param>
        /// <param name="cliTipo"></param>
        /// <param name="pEmailPara"></param>
        private void EnviarEmailCCME(TBL_PRE_BOLETO preboleto, string idSistemaEmail, string nomeCliente, string ordenante, string numeroReferenciaCCME)
        {
            string resposta = null;
            string email_para = null;
            string dados = "";

            try
            {
                var cultureInfo = new System.Globalization.CultureInfo("pt-br");

                DataTable dtMAIL = Get_Email_Para(preboleto.id_cliente);

                if (dtMAIL.Rows.Count > 0)
                    email_para = dtMAIL.Rows[0]["EMAIL_PARA"].ToString();

                var infoEmail = new InfoEmail
                {
                    IdSistema = idSistemaEmail,
                    IdEmpresa = preboleto.EMPRESA.ToString(),
                    Codigo = "69",
                    ListaEmailPara = email_para,
                    ListaEmailCc = "",
                    Assunto = "Aviso de Ordem de Pagamento Recebida",
                    ListaArquivos = null,
                    ListaParametrosCorpo = new List<EmailService.Parametro>()
                };

                CarregarParametrosCCME(infoEmail, preboleto, nomeCliente, ordenante, numeroReferenciaCCME);

                var serializer = new JavaScriptSerializer();

                dados = serializer.Serialize(infoEmail);

                var rest = new RestClient(wsEmailService);

                resposta = rest.SendPost(string.Format("dadosSerializados={0}", dados));

                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;

                if (!resposta.Equals("Não foi possivel enviar o email"))//enviado com sucesso
                {
                    oLogCCMESwift.DesLog = string.Format("E-mail: Enviado id: {0} Número Referência CCME: {1} Cliente: {2}", resposta, numeroReferenciaCCME, nomeCliente);
                    oLogCCMESwift.TpoLog = "I";
                }
                else //erro ao enviar o email 
                {
                    //Não foi possivel enviar o email
                    oLogCCMESwift.DesLog = string.Format("Erro ao Enviar E-mail: Resposta={0} Número Referência CCME: {1}", resposta, numeroReferenciaCCME);
                    oLogCCMESwift.TpoLog = "E";
                }

                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);

            }
            catch (Exception x)
            {
                oLogCCMESwift.DesLog = "Erro ao Enviar E-mail: Resposta=" + resposta + " Msg: " + x.Message.ToString() + " - " + x.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
        }

        private Tuple<string, decimal> SpreadGoogle(SqlTransaction transacao)
        {
            SqlParameter[] strParametros = new SqlParameter[1];
            strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 10);
            strParametros[0].Value = "LISTAR";

            var ds = SqlHelper.ExecuteDataset(transacao, CommandType.StoredProcedure, "SPCOL_PARAMETROS_PORTALPRODUTOS", strParametros);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                if (!string.IsNullOrWhiteSpace(ds.Tables[0].Rows[0]["TIPO_DESCONTO_GOOGLE"].ToString()) &&
                    !string.IsNullOrWhiteSpace(ds.Tables[0].Rows[0]["DESCONTO_GOOGLE_AUTOMATICO"].ToString()))
                {
                    return new Tuple<string, decimal>(ds.Tables[0].Rows[0]["TIPO_DESCONTO_GOOGLE"].ToString().Trim(), Convert.ToDecimal(ds.Tables[0].Rows[0]["DESCONTO_GOOGLE_AUTOMATICO"]));
                }
            }

            return null;
        }

        private ParametroOrdensChange ParametrosOrdensChangeGoogle(SqlTransaction transacao, string tipoPessoa)
        {
            SqlParameter[] strParametros = new SqlParameter[1];
            strParametros[0] = new SqlParameter("@TIPOPESSOA", SqlDbType.VarChar, 2);
            strParametros[0].Value = tipoPessoa;

            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT TOP 1 IDNATUREZA, IDVINCULO, CODVENDEDOR, RRMCCIID, CODPAGADOR, IOFISENTOCOMPRA, TAXAIOFCOMPRA ");
            sb.Append("FROM TBL_PARAM_ORDENS_CHANGE ");
            sb.Append("WHERE TIPOPESSOA = @TIPOPESSOA");

            var ds = SqlHelper.ExecuteDataset(transacao, CommandType.Text, sb.ToString(), strParametros);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                var parametro = new ParametroOrdensChange();
                parametro.IdNatureza = Convert.ToInt32(ds.Tables[0].Rows[0]["IDNATUREZA"]);
                parametro.IdVinculo = Convert.ToInt32(ds.Tables[0].Rows[0]["IDVINCULO"]);
                parametro.RRMCCIID = Convert.ToInt32(ds.Tables[0].Rows[0]["RRMCCIID"]);
                parametro.CodPagador = ds.Tables[0].Rows[0]["CODPAGADOR"].ToString();
                parametro.CodVendedor = ds.Tables[0].Rows[0]["CODVENDEDOR"].ToString();
                parametro.IsentoIOFCompra = ds.Tables[0].Rows[0]["IOFISENTOCOMPRA"].ToString().Equals("S");
                parametro.TaxaIOFCompra = Convert.ToDecimal(ds.Tables[0].Rows[0]["TAXAIOFCOMPRA"]);

                return parametro;
            }

            return null;
        }

        private decimal TaxaGoogleAutomatico(SqlTransaction transacao)
        {
            var ds = SqlHelper.ExecuteDataset(transacao, CommandType.Text, "select Tx_Compra from Varejo..TMOEDAS where cod_moeda='USD'");

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return Convert.ToDecimal(ds.Tables[0].Rows[0]["Tx_Compra"]);
            }
            else
            {
                throw new Exception("TaxaGoogleAutomatico: Não foi encontrado o Vlr_Taxa_cambio na tabela TBL_TAXA_CAMBIO para esta operação");
            }
        }

        private void CalcularBoletoGoogle(SqlTransaction transacao, bool clienteIsentoIOF, string clienteTipo, TBL_PRE_BOLETO preboleto)
        {
            var tipo = string.Empty;

            if (!string.IsNullOrWhiteSpace(clienteTipo) && clienteTipo.Equals("CNPJ"))
                tipo = "PJ";
            else if (!string.IsNullOrWhiteSpace(clienteTipo) && clienteTipo.Equals("CPF"))
                tipo = "PF";

            var parametroOrdensChangeGoogle = ParametrosOrdensChangeGoogle(transacao, tipo);

            if (parametroOrdensChangeGoogle != null)
            {
                preboleto.op_natureza = parametroOrdensChangeGoogle.IdNatureza.ToString();
                preboleto.ID_Vinculo = parametroOrdensChangeGoogle.IdVinculo;
                preboleto.op_vend_comp = parametroOrdensChangeGoogle.CodVendedor;
                preboleto.op_cod_RMMCCI = parametroOrdensChangeGoogle.RRMCCIID;
                preboleto.op_pag_receb = parametroOrdensChangeGoogle.CodPagador;

                var tipoSpread = SpreadGoogle(transacao);

                if (tipoSpread != null)
                {
                    decimal[] taxas = CalculaTaxaPronto(preboleto.op_tipo_moeda, "C");

                    // - Calculo conforme regra google.
                    if (tipoSpread.Item1.Equals("P"))
                    {
                        preboleto.op_tx_operacao = TaxaGoogleAutomatico(transacao) * (1 - tipoSpread.Item2 / 100);
                    }
                    else
                    {
                        preboleto.op_tx_operacao = TaxaGoogleAutomatico(transacao) - tipoSpread.Item2;
                    }

                    preboleto.OP_DATA_TAXA_OPERACAO = DateTime.Now;

                    preboleto.op_val_reais = preboleto.op_tx_operacao.Value * preboleto.op_val_moeda;

                    // - Cálculo op_taxa_pronto_d
                    preboleto.op_taxa_pronto_d = taxas[1];

                    // - Cálculo op_tarifa_banco e op_tarifa_banco_d
                    preboleto.op_tarifa_banco_d = CalculaTarifaBanco(preboleto.op_tipo_moeda, "C", preboleto.op_tipo_entrega, preboleto.op_val_moeda);
                    preboleto.op_tarifa_banco = Math.Round(preboleto.op_tarifa_banco_d * taxas[1], 2, MidpointRounding.AwayFromZero);

                    var ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("select * from tbl_moedas where moe_simbolo = '{0}'", preboleto.op_tipo_moeda));
                    decimal moe_desvio = ds.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(ds.Tables[0].Rows[0]["moe_desvio"].ToString()) : 0;

                    preboleto.op_taxa_banco = Math.Round(taxas[0] + ((moe_desvio * taxas[0]) / 100), 6, MidpointRounding.AwayFromZero);
                    //pre.op_paridade = ds.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(ds.Tables[0].Rows[0]["paridade"].ToString()) : 0;

                    // taxas[2] => paridade
                    preboleto.op_paridade = taxas[2];

                    // - Cálculo op_tarifa_operacao - mesmo cálculo do COL                                        
                    // taxas[1] => taxaPronto_d
                    decimal op_tarifa_operacao = CalculaTarifaOperacao(preboleto.id_cliente.ToString(), preboleto.op_tipo_moeda, "C", preboleto.op_tipo_entrega, preboleto.op_val_moeda);
                    preboleto.op_tarifa_operacao = Math.Round(op_tarifa_operacao * taxas[1], 2, MidpointRounding.AwayFromZero);

                    // - Cálculo op_spread
                    preboleto.op_spread = preboleto.op_val_moeda * (preboleto.op_taxa_banco - preboleto.op_tx_operacao.Value);

                    // - op_resul_minimo
                    //decimal aux = (cl_tarifa - pre.op_tx_operacao);
                    decimal aux = (op_tarifa_operacao - Convert.ToDecimal(preboleto.op_tx_operacao));
                    decimal resultado_minimo = 0;

                    if (preboleto.op_val_moeda > 0 && preboleto.op_tx_operacao > 0)
                        resultado_minimo = preboleto.op_spread + aux;

                    preboleto.op_resul_minimo = resultado_minimo;

                    if (clienteIsentoIOF || parametroOrdensChangeGoogle.IsentoIOFCompra)
                    {
                        preboleto.Txa_IOF = 0;
                        preboleto.Vlr_IOF = 0;
                    }
                    else
                    {
                        preboleto.Txa_IOF = parametroOrdensChangeGoogle.TaxaIOFCompra;
                        preboleto.Vlr_IOF = Math.Round((preboleto.op_val_reais.Value * (preboleto.Txa_IOF / 100)) * 100) / 100;


                        var op_val_reais = preboleto.op_val_reais.Value;
                        var op_tx_iof = parametroOrdensChangeGoogle.TaxaIOFCompra;

                        decimal resultado = (op_val_reais * (op_tx_iof / 100));

                        decimal valor_iof = (Math.Round(resultado * 100) / 100);

                    }

                }
                else
                {
                    throw new Exception("Spread Google: Nenhum spread google cadastrado foi encontrado");
                }
            }
            else
            {
                throw new Exception("TBL_PARAM_ORDENS_CHANGE: Nenhum parametro cadastrado foi encontrado para ordens Google");
            }


        }

        private void AprovarDocumentacao(SqlTransaction transacao, TBL_PRE_BOLETO preboleto, decimal valor_mn, bool google)
        {
            // - aprovacao_documentos
            DataSet dsDataSet = new DataSet();
            dsDataSet = SqlHelper.ExecuteDataset(transacao, CommandType.Text, string.Format("select V.paridade, M.moe_tipo from Varejo..TMOEDAS V, ik_varejo..TBL_MOEDAS M where V.cod_moeda COLLATE DATABASE_DEFAULT = M.moe_simbolo and V.cod_moeda='{0}'", preboleto.op_tipo_moeda));

            decimal paridade = dsDataSet.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(dsDataSet.Tables[0].Rows[0]["paridade"].ToString()) : 0;
            string moe_tipo = dsDataSet.Tables[0].Rows.Count > 0 ? dsDataSet.Tables[0].Rows[0]["moe_tipo"].ToString() : string.Empty;
            decimal valor_conv = 0;

            if (paridade > 1)
            {
                if (moe_tipo.Equals("B"))
                    valor_conv = (preboleto.op_val_moeda * paridade);
                else
                    valor_conv = (preboleto.op_val_moeda / paridade);
            }
            else
                valor_conv = (preboleto.op_val_moeda * paridade);

            preboleto.aprovacao_documentos = google ? "S" : GetAprovAuto("C", valor_conv);

            // - op_assinado
            if (valor_mn.Equals(0) || string.IsNullOrEmpty(valor_mn.ToString()))
            {
                preboleto.op_assinado = null;
            }
            else
            {
                preboleto.op_assinado = valor_conv > 0 ? GetAprovAuto("V", valor_conv) : "N";
            }
        }

        private void AprovarContraPartida(SqlTransaction transacao, TBL_PRE_BOLETO preboleto, int idSwift, string empresa)
        {
            // Aprovacao da contraPartida pelo Limite do usuario ROBO_CCME_SWIFT

            preboleto.aprovacao_contrapartida = AprovaContraPartidaPorLimiteGoogle(empresa, preboleto.op_taxa_pronto_d, preboleto.op_val_moeda, preboleto.op_val_reais.ToString());



        }

        private void AprovarContraPartidaLog(SqlTransaction transacao, TBL_PRE_BOLETO preboleto, int idUsuarioRobo, string idOperacao, string clNumeroDocumento)
        {
            if (!string.IsNullOrEmpty(preboleto.aprovacao_contrapartida) && preboleto.aprovacao_contrapartida.Equals("S"))
            {

                StringBuilder sb = new StringBuilder();
                sb.Append("INSERT INTO TBL_CRM (ID_USUARIO, CRM_CPF_CNPJ, ID_CORRETORA, CRM_OCORRENCIA, CRM_NBOLETO, CRM_DATA) VALUES ");
                sb.AppendFormat("({0}, {1}, {2},'Contra-partida aprovada automaticamente pelo Robô Swift', {3}, GETDATE())",
                    idUsuarioRobo, clNumeroDocumento, preboleto.id_corretora.ToString(), idOperacao);

                SqlHelper.ExecuteNonQuery(transacao, CommandType.Text, sb.ToString());
            }
        }

        private void AprovacaoCompliance(TBL_PRE_BOLETO preboleto)
        {
            preboleto.aprovacao_compliance = "S";
            string complianceReceita = "N";

            if (consultaDoc(preboleto.id_cliente).Equals("NOK"))
                complianceReceita = "S";

            if (complianceReceita.Equals("S"))
                preboleto.aprovacao_compliance = "N";
            else
            {
                if (preboleto.op_val_reais > 0)
                {
                    var dsDataSet = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("SELECT cl_nivel_compliance, ISNULL(comp_mes, 0) AS comp_mes, ISNULL(comp_ano, 0) AS comp_ano FROM TBL_CLIENTES (NOLOCK) WHERE id_cliente = {0}", preboleto.id_cliente));

                    string cl_nivel_compliance = dsDataSet.Tables[0].Rows.Count > 0 ? dsDataSet.Tables[0].Rows[0]["cl_nivel_compliance"].ToString() : string.Empty;

                    decimal complianceMes = 0, complianceAno = 0;

                    if (cl_nivel_compliance.Equals("Especial"))
                    {
                        complianceMes = dsDataSet.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(dsDataSet.Tables[0].Rows[0]["comp_mes"].ToString()) : 0;
                        complianceAno = dsDataSet.Tables[0].Rows.Count > 0 ? Convert.ToDecimal(dsDataSet.Tables[0].Rows[0]["comp_ano"].ToString()) : 0;
                    }
                    else
                    {
                        complianceMes = Nivel_Compliance("m", cl_nivel_compliance);
                        complianceAno = Nivel_Compliance("a", cl_nivel_compliance);
                    }

                    decimal valor_oper_m = Valor_Operado_Compliance("m", preboleto.id_cliente, 0);
                    decimal creditoCompliance = Math.Round((complianceMes - valor_oper_m), 2);

                    if (preboleto.op_val_reais > creditoCompliance)
                        preboleto.aprovacao_compliance = "N";

                    decimal valor_oper_a = Valor_Operado_Compliance("a", preboleto.id_cliente, 0);
                    creditoCompliance = Math.Round((complianceAno - valor_oper_a), 2);

                    if (preboleto.op_val_reais > creditoCompliance)
                        preboleto.aprovacao_compliance = "N";
                }
                else
                    preboleto.aprovacao_compliance = "N";
            }
        }

        //Associa os clientes automaticamente, cria um lote e o fecha
        private void AtualizarAprovarAutomaticamenteSwifts(SqlConnection conexao)
        {
            try
            {
                var strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 200);
                strParametros[0].Value = "GERARLOTEGOOGLE";

                SqlHelper.ExecuteNonQuery(conexao, CommandType.StoredProcedure, "SPBCCME_MEWEB_MT103_GOOGLE", strParametros);

                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.DesLog = "Associa os clientes automaticamente, cria um lote e o fecha";
                oLogCCMESwift.TpoLog = "I";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
            catch (Exception ex)
            {
                // Grava na tabela de log
                oLogCCMESwift.DesLog = "Erro PreBoleto Google: " + ex.Message.ToString() + " - " + ex.StackTrace;
                oLogCCMESwift.DesMetodo = System.Reflection.MethodInfo.GetCurrentMethod().Name;
                oLogCCMESwift.TpoLog = "E";
                oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
            }
        }

        private void LeituraDadosSwift(TBL_PRE_BOLETO preboleto)
        {
            var dsDataSet = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("SELECT cl_nome, cl_tip_doc, cl_num_doc, cl_cidade, cl_estado, cl_pais, cl_endereco FROM TBL_CLIENTES WHERE id_cliente= {0}", preboleto.id_cliente));

            string cl_tipo_doc = dsDataSet.Tables[0].Rows[0]["cl_tip_doc"].ToString();
            string cl_nome = dsDataSet.Tables[0].Rows[0]["cl_nome"].ToString();
            string endereco_c50k = dsDataSet.Tables[0].Rows[0]["cl_endereco"].ToString();
            string cidade_c50k = dsDataSet.Tables[0].Rows[0]["cl_cidade"].ToString() + " " + dsDataSet.Tables[0].Rows[0]["cl_estado"].ToString() + " " + dsDataSet.Tables[0].Rows[0]["cl_pais"].ToString();
            string num_doc_c50K = "CPF/CNPJ/ID " + dsDataSet.Tables[0].Rows[0]["cl_num_doc"].ToString();
            preboleto.c50k_dados_swift = getCampoC50k(cl_tipo_doc, preboleto.id_cliente, cl_nome, endereco_c50k, cidade_c50k, num_doc_c50K);
        }

        private void GravarLogLancamento(string empresa, string clienteNaoIdentificado, string acessaPortal, string operaSomenteBanco, string boletoAutomatico, string cl_status, int idSwift, string moeda, decimal valor, bool processaGooglePortal, SqlTransaction transacao)
        {

            // Cliente Inativo no Varejo
            // Cliente Bloqueado
            // Opera somente Banco
            // Cliente não Identificado
            if ((empresa == "COTACAO") &&  //ordem cotacao e OperaSomente banco N
               (operaSomenteBanco.Equals("S")))
            {
                GravaLOG_Lancamento_CCMESwift(transacao,
                                              idSwift,
                                              "-999",
                                              "Cliente Somente Banco, necessário estornar o lançamento na CCME da Cotação e gerar o procedimento manual.",
                                              Convert.ToInt32(oDBParametro.IdUser),
                                              moeda,
                                              valor, -1, "E", 0, 0, "", OrigemLog.BO.ToString());
            }

            if (clienteNaoIdentificado.Equals("S"))
            {
                GravaLOG_Lancamento_CCMESwift(transacao,
                                              idSwift,
                                              "-998",
                                              "Cliente não identificado ",
                                              Convert.ToInt32(oDBParametro.IdUser),
                                              moeda,
                                              valor, -1, "E", 0, 0, "", OrigemLog.BO.ToString());

            }
            if (boletoAutomatico.Equals("N"))
            {
                GravaLOG_Lancamento_CCMESwift(transacao,
                                              idSwift,
                                              "-997",
                                              "Cliente não habilitado a receber pré-boleto automático.",
                                              Convert.ToInt32(oDBParametro.IdUser),
                                              moeda,
                                              valor, -1, "E", 0, 0, "", OrigemLog.BO.ToString());

            }
            if (cl_status.Equals("I"))
            {
                GravaLOG_Lancamento_CCMESwift(transacao,
                                              idSwift,
                                              "-996",
                                              "Não foi possível criar o pré boleto, Cliente com status Inativo no Varejo",
                                              Convert.ToInt32(oDBParametro.IdUser),
                                              moeda,
                                              valor, -1, "E", 0, 0, "", OrigemLog.BO.ToString());
            }
            if (cl_status.Equals("B"))
            {
                GravaLOG_Lancamento_CCMESwift(transacao,
                                              idSwift,
                                              "-996",
                                              "Não foi possível criar o pré boleto, Cliente com status Bloqueado no Varejo",
                                              Convert.ToInt32(oDBParametro.IdUser),
                                              moeda,
                                              valor, -1, "E", 0, 0, "", OrigemLog.BO.ToString());
            }

            if (!processaGooglePortal)
            {
                GravaLOG_Lancamento_CCMESwift(transacao,
                                    idSwift,
                                    "-995",
                                    "Não foi possível criar o pré boleto, Cliente com status (Recebe Ordem no Portal de Câmbio) desativado no Varejo",
                                    Convert.ToInt32(oDBParametro.IdUser),
                                    moeda,
                                    valor, -1, "E", 0, 0, "", OrigemLog.BO.ToString());
            }

            if (!acessaPortal.Equals("A"))
            {
                GravaLOG_Lancamento_CCMESwift(transacao,
                          idSwift,
                          "-994",
                          "Não foi possível criar o pré boleto, Cliente com status (Status do cliente no Câmbio On-Line) desativado no Portal",
                          Convert.ToInt32(oDBParametro.IdUser),
                          moeda,
                          valor, -1, "E", 0, 0, "", OrigemLog.BO.ToString());
            }

        }

        private Natureza BuscarNatureza(int idNatureza, SqlTransaction transacao)
        {
            SqlParameter[] strParametros = new SqlParameter[1];
            strParametros[0] = new SqlParameter("@IDNATUREZA", SqlDbType.Int);
            strParametros[0].Value = idNatureza;

            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT TOP 1 ID_NATUREZA, NAT_CODIGO, NAT_DESCRICAO ");
            sb.Append("FROM TBL_NATUREZA ");
            sb.Append("WHERE ID_NATUREZA = @IDNATUREZA");

            var ds = SqlHelper.ExecuteDataset(transacao, CommandType.Text, sb.ToString(), strParametros);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                var parametro = new Natureza();
                parametro.Id = Convert.ToInt32(ds.Tables[0].Rows[0]["ID_NATUREZA"]);
                parametro.Codigo = Convert.ToInt32(ds.Tables[0].Rows[0]["NAT_CODIGO"]);
                parametro.Descricao = ds.Tables[0].Rows[0]["NAT_DESCRICAO"].ToString();

                return parametro;
            }

            return null;
        }

        private int GravaLog(string desLog, string desMetodo, string tpoLog, Int32 idLogPai)
        {
            oLogCCMESwift.DesLog = desLog;
            oLogCCMESwift.DesMetodo = desMetodo;
            oLogCCMESwift.TpoLog = tpoLog;
            return oLogCCMESwift.IncluirLogCCMESwift(oLogCCMESwift);
        }

        //#endregion
    }
}
