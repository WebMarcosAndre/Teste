﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
using System.Reflection;

namespace R_CCMESwift
{
    public class SetarCampos
    {
        public static void RetonarValor(SqlDataReader oSqlDataReader, object pthis)
        {
            Type type = pthis.GetType();

            for (int i = 0; i < oSqlDataReader.VisibleFieldCount; i++)
            {
                string nomeDaColuna = "_" + oSqlDataReader.GetName(i);

                FieldInfo field = type.GetField(nomeDaColuna,
                    BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.IgnoreCase);

                if (field != null)
                {
                    object value = oSqlDataReader.GetValue(i);

                    try
                    {
                        if (value != DBNull.Value || value == null)
                        {
                            if (oSqlDataReader.GetDataTypeName(i).ToLower().Trim() == "bit")
                                value = Convert.ToInt16(value);

                            field.SetValue(pthis, value);// , Convert.ChangeType(value, field.DeclaringType));
                        }
                        else
                            field.SetValue(pthis, ObtemValorNuloParaTipo(field.FieldType));
                    }
                    catch (Exception ex)
                    {
                        string erro = ex.Message;
                        throw;
                    }
                }
            }
        }

        // -----------------------

        private static object ObtemValorNuloParaTipo(Type type)
        {
            string tipoComoString = type.Name.ToLower();

            switch (tipoComoString)
            {
                case "float":
                    return -1.0f;
                case "double":
                    return -1.0;
                case "decimal":
                    return -1.0M;
                case "byte":
                    return default(byte);
                case "datetime":
                    return new DateTime(1900, 1, 1);
                case "string":
                    return string.Empty;
                case "int16":
                    return (short)-1;
                case "int32":
                    return -1;
                case "int64":
                    return -1L;
                default:
                    return null;
            }
        }
    }
}
