﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace R_CCMESwift
{
    public class LogContaCorrente
    {

        private Int32?      _Op_N_Boleto        = null;
		private Int32?      _Id_Operacao	    = null;
		private Int32?      _Id_Corretora       = null;
        private string      _Cl_Num_Doc         = null;
		private string      _Op_Tipo_Operacao   = null; 
        private string      _Cl_Passaporte		= null; 
		private string      _Coligada			= null;
		private string      _Agencia			= null;
        private string      _CodAgenciaCli		= null;
	    private string      _CodAgenciaDes		= null;
		private string      _NroConta			= null;
		private string      _DataMovto			= null;
		private Int32?      _Documento			= null;
		private string      _Historico			= null;
		private decimal?    _Valor				= null;
		private decimal?    _vlr_Reais          = null;
        private decimal?    _vlr_total          = null;
        private decimal?    _Valor_Total_Cliente = null;
		private decimal?    _vlr_TarifaOP       = null;
		private decimal?    _vlr_IOF            = null;
        private decimal?    _vlr_IR             = null;
        private string      _SisOrigem			= null;
		private Int32?      _CodUsuario			= null;
        private decimal?    _PrazoBloq			= null;
        private string      _DescRetorno		= null;
        private Int16?      _FlgSucesso         = null;
        private string      _flg_RecolheIR      = null;
        private string      _tpo_Cliente        = null;
        private string      _auxDescRetorno     = null;
        private string      _sDocumentoAjustado = null;
        private string      _sHistoricoAjustado = null;
        
        public Int32? Op_N_Boleto
        {
            get { return _Op_N_Boleto; }
            set { _Op_N_Boleto = value; }
        }

        public Int32? Id_Operacao
        {
            get { return _Id_Operacao; }
            set { _Id_Operacao = value; }
        }

        public Int32? Id_Corretora
        {
            get { return _Id_Corretora; }
            set { _Id_Corretora = value; }
        }

        public string Cl_Num_Doc
        {
            get { return _Cl_Num_Doc; }
            set { _Cl_Num_Doc = value; }        
        }

        public string Op_Tipo_Operacao
        {
            get { return _Op_Tipo_Operacao; }
            set { _Op_Tipo_Operacao = value; }        
        }

        public string Cl_Passaporte
        {
            get { return _Cl_Passaporte; }
            set { _Cl_Passaporte = value; }  
        }

        public string Coligada
        {
            get { return _Coligada; }
            set { _Coligada = value; }  
        }

        public string Agencia
        {
            get { return _Agencia; }
            set { _Agencia = value; }  
        }

        public string CodAgenciaCli
        {
            get { return _CodAgenciaCli; }
            set { _CodAgenciaCli = value; }  
        }

        public string CodAgenciaDes
        {
            get { return _CodAgenciaDes; }
            set { _CodAgenciaDes = value; } 
        }

        public string NroConta
        {
            get { return _NroConta; }
            set { _NroConta = value; } 
        }

        public string DataMovto
        {
            get { return _DataMovto; }
            set { _DataMovto = value; } 
        }

        public Int32? Documento
        {
            get { return _Documento; }
            set { _Documento = value; } 
        }

        public string Historico
        {
            get { return _Historico; }
            set { _Historico = value; } 
        }

        public decimal? Valor
        {
            get { return _Valor; }
            set { _Valor = value; } 
        }

        public decimal? vlr_Reais
        {
            get { return _vlr_Reais; }
            set { _vlr_Reais = value; } 
        }

        public decimal? vlr_total
        { 
         get { return _vlr_total; }
         set { _vlr_total = value; } 
        }

        public decimal? Valor_Total_Cliente
        {
            get { return _Valor_Total_Cliente; }
            set { _Valor_Total_Cliente = value; }
        }
        
        

   
        public decimal? vlr_TarifaOP
        {
            get { return _vlr_TarifaOP; }
            set { _vlr_TarifaOP = value; } 
        }
        public decimal? vlr_IOF
        {
            get { return _vlr_IOF; }
            set { _vlr_IOF = value; } 
        }
        public decimal? vlr_IR
        {
            get { return _vlr_IR; }
            set { _vlr_IR = value; } 
        }



        public string SisOrigem
        {
            get { return _SisOrigem; }
            set { _SisOrigem = value; } 
        }

        public Int32? CodUsuario
        {
            get { return _CodUsuario; }
            set { _CodUsuario = value; } 
        }

        public decimal? PrazoBloq
        {
            get { return _PrazoBloq; }
            set { _PrazoBloq = value; } 
        }

        public string DescRetorno
        {
            get { return _DescRetorno; }
            set { _DescRetorno = value; } 
        }

        public Int16? FlgSucesso
        {
            get { return _FlgSucesso; }
            set { _FlgSucesso = value; } 
        }

        public string flg_RecolheIR
        {
            get { return _flg_RecolheIR; }
            set { _flg_RecolheIR = value; } 
        }

        public string tpo_Cliente
        {
            get { return _tpo_Cliente; }
            set { _tpo_Cliente = value; } 
        }

        public string auxDescRetorno
        {
            get { return _auxDescRetorno; }
            set { _auxDescRetorno = value; }
        }

        public string sDocumentoAjustado
        {
            get { return _sDocumentoAjustado; }
            set { _sDocumentoAjustado = value; }
        }

        public string sHistoricoAjustado
        {
            get { return _sHistoricoAjustado; }
            set { _sHistoricoAjustado = value; }
        }

        public LogContaCorrente() {
		}

        public LogContaCorrente(SqlDataReader reader)
		{
			CarregarDados(reader);
		}


        /*int IComparable<Parametro>.CompareTo(Parametro arq)
        {
            if (arq == null)
                throw new ArgumentNullException("arq");
            return this.Nbol.ToString().CompareTo(arq.Nbol.ToString());
        }*/


		private void CarregarDados(SqlDataReader reader)
		{
            SetarCampos.RetonarValor(reader, this);
		}

        public DataSet ConsultarLogContaCorrente(LogContaCorrente oRetorno)
        {
            db_LogContaCorrente odb_LogContaCorrente = new db_LogContaCorrente();
            DataSet dstLogContaCorrente;


            return dstLogContaCorrente = odb_LogContaCorrente.ConsultarLogContaCorrente(oRetorno);
        }

        public int IncluirLogContaCorrente(LogContaCorrente oRetorno)
        {
            db_LogContaCorrente odb_LogContaCorrente = new db_LogContaCorrente();
            return odb_LogContaCorrente.IncluirLogContaCorrente(oRetorno);

        }


        public class db_LogContaCorrente
        {
            private string strConexao = clsFerramentas.Decodificar(System.Configuration.ConfigurationManager.AppSettings.Get("ConnectionString"));

            public DataSet ConsultarLogContaCorrente(LogContaCorrente oRetorno)
            {

                SqlParameter[] strParametros = new SqlParameter[4];

                strParametros[0] = new SqlParameter("@Documento", SqlDbType.Int);
                strParametros[0].Value = oRetorno.Documento;

                strParametros[1] = new SqlParameter("@Historico", SqlDbType.Char, 5);
                strParametros[1].Value = oRetorno.Historico;

                strParametros[2] = new SqlParameter("@Flg_sucesso", SqlDbType.Int);
                strParametros[2].Value = oRetorno.FlgSucesso;

                strParametros[3] = new SqlParameter("@DataMovto", SqlDbType.DateTime);
                strParametros[3].Value = DateTime.Now.ToString("yyyy-MM-dd");

                DataSet dstRetorno = SqlHelper.ExecuteDataset(this.strConexao, CommandType.StoredProcedure, "SPBVAR_Log_Conta_Corrente_Consultar", strParametros);

                return dstRetorno;
                
            }

            public int IncluirLogContaCorrente( LogContaCorrente oRetorno)
            {

                SqlParameter[] strParametros = new SqlParameter[20];

                strParametros[0] = new SqlParameter("@Op_N_Boleto", SqlDbType.Int);
                strParametros[0].Value = oRetorno.Op_N_Boleto;

                strParametros[1] = new SqlParameter("@Id_Operacao", SqlDbType.Int);
                strParametros[1].Value = oRetorno.Id_Operacao;

                strParametros[2] = new SqlParameter("@Id_Corretora", SqlDbType.Int);
                strParametros[2].Value = oRetorno.Id_Corretora;

                strParametros[3] = new SqlParameter("@Cl_Num_Doc", SqlDbType.VarChar, 18);
                strParametros[3].Value = oRetorno.Cl_Num_Doc;

                strParametros[4] = new SqlParameter("@Op_Tipo_Operacao", SqlDbType.Char, 1);
                strParametros[4].Value = oRetorno.Op_Tipo_Operacao;

                strParametros[5] = new SqlParameter("@Cl_Passaporte", SqlDbType.VarChar, 18);
                strParametros[5].Value = oRetorno.Cl_Passaporte;

                strParametros[6] = new SqlParameter("@Coligada", SqlDbType.Char, 3);
                strParametros[6].Value = oRetorno.Coligada;

                strParametros[7] = new SqlParameter("@Agencia", SqlDbType.Char, 5);
                strParametros[7].Value = oRetorno.Agencia;

                strParametros[8] = new SqlParameter("@CodAgenciaCli", SqlDbType.Char, 5);
                strParametros[8].Value = oRetorno.CodAgenciaCli;

                strParametros[9] = new SqlParameter("@CodAgenciaDes", SqlDbType.Char, 5);
                strParametros[9].Value = oRetorno.CodAgenciaDes;

                strParametros[10] = new SqlParameter("@NroConta", SqlDbType.Char, 10);
                strParametros[10].Value = oRetorno.NroConta;

                strParametros[11] = new SqlParameter("@DataMovto", SqlDbType.DateTime);
                strParametros[11].Value = DateTime.Now.ToString("yyyy/MM/dd");

                strParametros[12] = new SqlParameter("@Documento", SqlDbType.Int);
                strParametros[12].Value = oRetorno.Documento;

                strParametros[13] = new SqlParameter("@Historico", SqlDbType.Char, 5);
                strParametros[13].Value = oRetorno.Historico;

                strParametros[14] = new SqlParameter("@Valor", SqlDbType.Decimal);
                strParametros[14].Value = oRetorno.Valor;

                strParametros[15] = new SqlParameter("@SisOrigem", SqlDbType.Char, 10);
                strParametros[15].Value = oRetorno.SisOrigem;

                strParametros[16] = new SqlParameter("@CodUsuario", SqlDbType.Int);
                strParametros[16].Value = oRetorno.CodUsuario;

                strParametros[17] = new SqlParameter("@PrazoBloq", SqlDbType.Decimal);
                strParametros[17].Value = oRetorno.PrazoBloq;

                strParametros[18] = new SqlParameter("@DescRetorno", SqlDbType.VarChar, 255);
                strParametros[18].Value = oRetorno.DescRetorno;

                strParametros[19] = new SqlParameter("@FlgSucesso", SqlDbType.Int);
                strParametros[19].Value = oRetorno.FlgSucesso;

                SqlDataReader drRetorno = SqlHelper.ExecuteReader(this.strConexao, CommandType.StoredProcedure, "SPBVAR_Log_Conta_Corrente_Incluir", strParametros);

                Int32 intRetorno = 0;

                if (drRetorno.Read())
                {
                    intRetorno = int.Parse(drRetorno.GetValue(0).ToString());
                }

                return intRetorno;

            }

        }

    }
}
