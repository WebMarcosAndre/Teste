﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R_CCME_Swift.Modelos
{
    public class ParametroOrdensChange
    {
        public int IdNatureza { get; set; }
        public int IdVinculo { get; set; }
        public int RRMCCIID { get; set; }
        public string CodVendedor { get; set; }
        public string CodPagador { get; set; }
        public bool IsentoIOFCompra { get; set; }
        public decimal TaxaIOFCompra { get; set; }
    }
}
