USE DBVAREJO
GO
--UPDATE TBL_COL_PARAM_PRODUTOS SET HORARIO_SABADOS_DE = '00:01', HORARIO_SABADOS_ATE =  '23:59', FLAG_SABADOS = 1
DECLARE @Login VARCHAR(20) = '31294721852'
		, @QuantidadeMoeda VARCHAR(20) = '10,00'
		, @SimboloMoeda VARCHAR(4) = 'EURO'
		, @TaxaMoeda VARCHAR(20) = '4,482'
		, @IOF VARCHAR(20) = '1,1'
		, @Ambiente VARCHAR(3) = 'LOC' -- escolher entre HOM e DEV

		/*
		
		UPDATE dbCorpLoginUnico.dbo.TokenTemporario SET DataValidade = DATEADD(DAY, -1, GETDATE())
		
		*/
	

DECLARE @UsuarioId INT, @TokenId INT , @ClienteId INT, @URL VARCHAR(50)
SELECT @UsuarioId = UsuarioId FROM dbCorpLoginUnico.dbo.Usuario (NOLOCK) WHERE Login = @Login

SELECT @TokenId = TokenTemporarioId
FROM dbCorpLoginUnico.dbo.TokenTemporario (NOLOCK) WHERE DataValidade < DATEADD(DAY, -1, GETDATE())

SELECT @ClienteId = li_idcliente 
FROM IK_VAREJO.dbo.TBL_LOGIN_INTEGRADO (NOLOCK) WHERE li_doc = @Login

IF(@UsuarioId IS NULL)
	BEGIN
	PRINT 'Login n�o encontrado na base do Login �nico (dbCorpLoginUnico.dbo.Usuario)'
	RETURN
	END

IF(@TokenId IS NULL)
	BEGIN
	PRINT 'N�o encontramos nenhum Token antigo para utilizar como exemplo, chama o Marc�o (dbCorpLoginUnico.dbo.TokenTemporario)'
	RETURN
	END

IF(@ClienteId IS NULL)
	BEGIN
	PRINT 'Login n�o encontrado na base TBL_LOGIN_INTEGRADO (IK_VAREJO.dbo.TBL_LOGIN_INTEGRADO)'
	RETURN
	END
	
IF NOT EXISTS (	
	SELECT  * FROM IK_VAREJO.dbo.TBL_MOEDAS m (NOLOCK) 
	WHERE m.moe_cambio_online='S' AND m.moe_somente_consulta_ccme = 'N' 
		AND moe_simbolo = @SimboloMoeda AND moe_simbolo NOT IN (
				SELECT cod_moeda FROM IK_VAREJO.dbo.TBL_ME_SUBCONTA sc (NOLOCK) 
				WHERE id_cliente = @ClienteId AND sub_status = 'A' AND cod_moeda = @SimboloMoeda
		)
)
BEGIN 
	SELECT  * FROM IK_VAREJO.dbo.TBL_MOEDAS m (NOLOCK) 
	WHERE m.moe_cambio_online='S' AND m.moe_somente_consulta_ccme = 'N' 
		AND moe_simbolo NOT IN (
				SELECT cod_moeda FROM IK_VAREJO.dbo.TBL_ME_SUBCONTA sc (NOLOCK) 
				WHERE id_cliente = @ClienteId AND sub_status = 'A'
				)
	PRINT 'Este Login n�o possui permiss�o de envio de remessa para essa moeda'
	RETURN
END

DECLARE @MoedaSwift VARCHAR(5)

SELECT @MoedaSwift = moe_swift FROM IK_VAREJO.dbo.TBL_MOEDAS m (NOLOCK) 
	WHERE m.moe_cambio_online='S' AND m.moe_somente_consulta_ccme = 'N' 
		AND moe_simbolo NOT IN (
				SELECT cod_moeda FROM IK_VAREJO.dbo.TBL_ME_SUBCONTA sc (NOLOCK) 
				WHERE id_cliente = @ClienteId AND sub_status = 'A'
				)

UPDATE dbCorpLoginUnico.dbo.TokenTemporario 
SET DataAcesso = GETDATE(), DataValidade = DATEADD(DAY, 1, GETDATE()) , UsuarioId = @UsuarioId, Usado = 0
WHERE TokenTemporarioId = @TokenId 

SET @URL = 'http://portaldecambio.desenvolvimento/login.aspx?token='
IF(@Ambiente = 'HOM')
	SET @URL = 'http://cambiocotacao.homologacao/login.aspx?token='
ELSE
IF(@Ambiente = 'LOC')
	SET @URL = 'http://localhost/portalcambio/login.aspx?token='
ELSE
IF(@Ambiente = 'REM')
	SET @URL = 'http://REND-SIST-141/portalcambio/login.aspx?token='

/*
SET @URL = 'http://cambiocotacao.homologacao/login.aspx?token='
IF EXISTS (SELECT 1 WHERE @@SERVERNAME LIKE '%REND-SRVDSQL%')
	SET @URL = 'http://portaldecambio.desenvolvimento/login.aspx?token='	
*/


SELECT @URL + REVERSE(Token)
+'&Taxa='+@TaxaMoeda+'&Quantidade='+@QuantidadeMoeda+'&Moeda='+@MoedaSwift
+'&IOF='+@IOF,
Token
FROM dbCorpLoginUnico.dbo.TokenTemporario (NOLOCK) 
WHERE TokenTemporarioId = @TokenId

SELECT @Ambiente
--USE DBVAREJO

--GO

SELECT FLAG_SABADOS FROM TBL_COL_PARAM_PRODUTOS (NOLOCK)
--UPDATE TBL_COL_PARAM_PRODUTOS SET FLAG_SABADOS = 1,HORARIO_SABADOS_DE = '09:00', HORARIO_SABADOS_ATE = '19:00'

http://localhost/portalcambio/login.aspx?token=9proQr1c3wlClxjXkPZvYCEgnWbePO7HH4aNSAVPfjjItVMbPJGxjXxa3Apl7XBc6UWwNzgrC9HKc7gSAZ0Qr3cftoCzrWPnuCGQoN0GayqC1gE6zYAN9vfDlCCD56es&Taxa=4,482&Quantidade=10,00&Moeda=ZAR&IOF=1,1

--&Quantidade=100,00&Moeda=gbp&Taxa=4,482&IOF=0,38
