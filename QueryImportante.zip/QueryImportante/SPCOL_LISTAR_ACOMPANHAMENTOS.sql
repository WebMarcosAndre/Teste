USE IK_VAREJO

GO

/***
-------------------------------------------------------------
Nome    : SPCOL_LISTAR_ACOMPANHAMENTOS
Desc	: Lista as opera��es da tela de recebimento de remessa e do contador no topo do cambio online
Autor	: Desconhecido
Data	: Desconhecido
***********************
Hist�rico de altera��es 
***********************
Date		Author				Description 
17/05/2019  Marcos Costa		Adicionado NOLOCK 
update TBL_PRE_BOLETO set id_cliente = 278341  WHERE id_cliente = 243385

USE IK_VAREJO

GO
SELECT LI_IDCLIENTE FROM TBL_LOGIN_INTEGRADO (NOLOCK) WHERE li_doc = '36604723879'



SPCOL_LISTAR_ACOMPANHAMENTOS
@DATA_INICIO  ='20190410', @DATA_FIM  ='20190710', @TIPO ='C', @STATUS  = 1, @ID_CLIENTE  = 243385 


sp_helptext SPCOL_LISTAR_ACOMPANHAMENTOS
-------------------------------------------------------------
***/
DECLARE
--ALTER PROCEDURE [dbo].[SPCOL_LISTAR_ACOMPANHAMENTOS]   
--(  
		@DATA_INICIO DATETIME ='20190410',  
		@DATA_FIM DATETIME ='20190710',  
		@TIPO CHAR(1)='C',  
		@STATUS INT = 1,  
		@ID_CLIENTE INT = 19037 
--)  
--AS  
--BEGIN  
--	SET NOCOUNT ON;  

	DROP TABLE #TBL

	CREATE TABLE #TBL (OP_N_BOLETO INT, ID_STATUS INT)  

	INSERT INTO #TBL    
	SELECT   
	A.OP_N_BOLETO,   
	[dbo].[fn_GetFaseCompra](A.OP_N_BOLETO, 1) AS STATUS   
	FROM TBL_PRE_BOLETO A  WITH (NOLOCK)
	WHERE A.ID_CLIENTE = @ID_CLIENTE 
		AND  A.OP_TIPO_OPERACAO = 'C'
		AND A.SISTEMA_ORIGEM IN ('PC', 'SF') 
		AND NOT (A.PRE_BOLETO_STATUS = 0 AND A.sistema_origem = 'SF') 
		/*AND	A.OP_N_BOLETO NOT IN     
				(SELECT OP_N_BOLETO FROM IK_VAREJO.DBO.TBL_MEWEB_MT103 AS M WITH(NOLOCK) 
				INNER JOIN TBL_CLIENTES AS C WITH(NOLOCK) ON M.ID_CLIENTE = C.ID_CLIENTE
				WHERE C.id_cliente = @ID_CLIENTE AND  ISNULL(C.flg_aceita_efet_auto_ordem,'N') = 'S' 
				AND  
				M.FLAGGOOGLE=1 AND M.OP_N_BOLETO IS NOT NULL)        */

	SELECT * FROM #TBL

	SELECT
	TOP 10 b.op_data_boleto, b.op_n_boleto
	--,  M.M20_SenderRef--,MTC.REFREM 
	FROM #TBL A   
		INNER JOIN TBL_PRE_BOLETO B WITH (NOLOCK) ON A.OP_N_BOLETO = B.OP_N_BOLETO  
		INNER JOIN TBL_COL_STATUS C WITH (NOLOCK) ON A.ID_STATUS = C.ID_STATUS  
		INNER JOIN TBL_MOEDAS E  WITH (NOLOCK) ON B.op_tipo_moeda = E.moe_simbolo
		INNER JOIN TBL_CLIENTES CL WITH(NOLOCK) ON B.ID_CLIENTE = CL.ID_CLIENTE  
		LEFT JOIN TBL_COL_PREBOLETO P WITH (NOLOCK) ON B.ID_OPERACAO = P.ID_OPERACAO
		LEFT JOIN IK_VAREJO.dbo.TBL_MEWEB_MT103 M ON M.OP_N_BOLETO = B.OP_N_BOLETO
		INNER JOIN TBL_MEWEB_MT103_CHANGE MTC on MTC.REFREM = M.M20_SenderRef

	WHERE   b.op_n_boleto = 2718461 AND
		 
		B.OP_DATA_BOLETO BETWEEN @DATA_INICIO AND @DATA_FIM AND
		 (
				(
					B.pre_boleto_status <> 3 AND B.SISTEMA_ORIGEM IN ('PC', 'SF')
				) OR (
					B.pre_boleto_status = 3 AND B.SISTEMA_ORIGEM IN ('PC')
					)
			) 
		AND B.op_tipo_operacao = @TIPO 
		AND	
		B.id_cliente = @ID_CLIENTE 
		AND	(  
				(@STATUS = 0  AND B.pre_boleto_status IN (0,1,2,3)) OR  
				(@STATUS = 1  AND B.pre_boleto_status IN (0,1)) OR  
				(@STATUS = 2  AND B.pre_boleto_status = 2) OR  
				(@STATUS = 3  AND B.pre_boleto_status = 3)  
		)  		
		ORDER BY B.op_n_boleto DESC  
--END