
 DECLARE @documento VARCHAR(20) = '11715848810' -- PREENCHER COM O LOGIN DO CLIENTE
		, @botao VARCHAR(20) = '' --PREENCHER COM A OP��O REMESSA ou CCME
		, @IdCliente INT 
 SELECT @IdCliente = li_idcliente FROM TBL_LOGIN_INTEGRADO (NOLOCK) WHERE li_doc = @documento

 IF @botao = 'REMESSA'
	 IF EXISTS (	SELECT cod_moeda FROM TBL_ME_SUBCONTA sc (NOLOCK) WHERE id_cliente = @IdCliente AND sub_status = 'A' )
		
			 SELECT TOP 10 * FROM TBL_MOEDAS m (NOLOCK) WHERE m.moe_cambio_online='S' AND m.moe_somente_consulta_ccme = 'N' 
			 AND moe_simbolo NOT IN (
					SELECT cod_moeda FROM TBL_ME_SUBCONTA sc (NOLOCK) WHERE id_cliente = @IdCliente AND sub_status = 'A'
			 )
	 ELSE
			 SELECT TOP 10 * FROM TBL_MOEDAS m (NOLOCK) WHERE m.moe_cambio_online='S' and m.moe_somente_consulta_ccme = 'N' 
			 AND moe_simbolo IS NOT NULL AND moe_nomeresumido IS NOT NULL
ELSE IF @botao = 'CCME'
	  IF EXISTS (	SELECT cod_moeda FROM TBL_ME_SUBCONTA sc (NOLOCK) WHERE id_cliente = @IdCliente AND sub_status = 'A' )
		
			 SELECT TOP 10 * FROM TBL_MOEDAS m (NOLOCK) WHERE m.moe_cambio_online='S' AND m.moe_somente_consulta_ccme = 'N' 
			 AND moe_simbolo IN (
					SELECT cod_moeda FROM TBL_ME_SUBCONTA sc (NOLOCK) WHERE id_cliente = @IdCliente AND sub_status = 'A'
			 )