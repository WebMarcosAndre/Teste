﻿using ContaCorrente.Domain.Dtos;
using ContaCorrente.Domain.Interfaces.Repositories;
using ContaCorrente.Domain.Interfaces.Services;

namespace ContaCorrente.Services.Services
{
    public class ContaCorrenteService : IContaCorrenteService
    {
        private readonly IContaCorrenteRepository _contaCorrenteRepository;

        public ContaCorrenteService(IContaCorrenteRepository contaCorrenteRepository)
        {
            _contaCorrenteRepository = contaCorrenteRepository;
        }

        public void DebitarValor(AtualizarSaldoDto dto)
        {
            var contaCorrente = _contaCorrenteRepository.ObterPorId(dto.ContaCorrenteId);
            contaCorrente.Saldo += dto.Valor;
            _contaCorrenteRepository.AtualizarSaldo(contaCorrente);
        }

        public void CreditarValor(AtualizarSaldoDto dto)
        {
            var contaCorrente = _contaCorrenteRepository.ObterPorId(dto.ContaCorrenteId);
            contaCorrente.Saldo += dto.Valor;
            _contaCorrenteRepository.AtualizarSaldo(contaCorrente);
        }
    }
}
