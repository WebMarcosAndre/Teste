﻿namespace ContaCorrente.Domain.ValueObjects
{
    public enum TipoOperacaoEnum
    {
        Credito = 1,
        Debito = 2
    }
}
