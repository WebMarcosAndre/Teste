﻿namespace ContaCorrente.Domain.ValueObjects
{
    public enum TipoLancamentoEnum
    {
        Transferencia = 1,
        Saque = 2
    }
}
