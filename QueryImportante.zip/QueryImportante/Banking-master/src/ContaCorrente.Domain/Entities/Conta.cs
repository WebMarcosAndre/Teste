﻿namespace ContaCorrente.Domain.Entities
{
    public class Conta : BaseEntity
    {
        public decimal Saldo { get; set; }
    }
}
