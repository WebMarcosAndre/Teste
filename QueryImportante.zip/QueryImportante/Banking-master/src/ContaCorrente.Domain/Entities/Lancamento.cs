﻿using System;

namespace ContaCorrente.Domain.Entities
{
    public class Lancamento : BaseEntity
	{
        public int ContaCorrenteOrigemId { get; set; }
        public int ContaCorrenteDestinoId { get; set; }
        public DateTime DataLancamento { get; set; }
        public int TipoTransacao { get; set; }
        public int TipoOperacao { get; set; }
        public decimal Valor { get; set; }
    }
}
