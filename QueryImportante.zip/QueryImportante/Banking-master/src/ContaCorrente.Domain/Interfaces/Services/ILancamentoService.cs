﻿using ContaCorrente.Domain.Arguments;

namespace ContaCorrente.Domain.Interfaces.Services
{
    public interface ILancamentoService
    {
        void EfetuarTransferencia(TransferenciaRequest request);
    }
}
