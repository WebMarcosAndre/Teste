﻿using ContaCorrente.Domain.Dtos;

namespace ContaCorrente.Domain.Interfaces.Services
{
    public interface IContaCorrenteService
    {
        void DebitarValor(AtualizarSaldoDto dto);
        void CreditarValor(AtualizarSaldoDto dto);
    }
}
