﻿using ContaCorrente.Domain.Entities;

namespace ContaCorrente.Domain.Interfaces.Repositories
{
    public interface IContaCorrenteRepository : IBaseRepository<Conta>
    {
        Conta ObterContaCorrente(int contaCorrenteId);
        void AtualizarSaldo(Conta contaCorrente);
    }
}
