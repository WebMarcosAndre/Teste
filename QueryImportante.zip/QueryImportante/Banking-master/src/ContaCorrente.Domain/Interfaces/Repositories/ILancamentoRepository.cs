﻿using ContaCorrente.Domain.Entities;

namespace ContaCorrente.Domain.Interfaces.Repositories
{
    public interface ILancamentoRepository : IBaseRepository<Lancamento>
    {
        Lancamento IncluirLancamento(Lancamento lancamento);
    }
}
