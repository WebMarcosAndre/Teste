﻿using ContaCorrente.Domain.ValueObjects;

namespace ContaCorrente.Domain.Dtos
{
    public class AtualizarSaldoDto
    {
        public int ContaCorrenteId { get; set; }
        public decimal Valor { get; set; }
    }
}
