﻿namespace ContaCorrente.Domain.Arguments
{
    public class TransferenciaRequest
	{
        public int ContaOrigem { get; set; }
        public int ContaDestino { get; set; }
        public decimal Valor { get; set; }
    }
}
