﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ContaCorrente.Infra.UnitOfWork;

namespace ContaCorrente.Api.Controllers
{
    public class BaseController : ControllerBase
    {
        protected IUnitOfWork _unitOfWork;

        public BaseController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        protected StatusCodeResult OkResponse()
        {
            _unitOfWork.Commit();
            return StatusCode(StatusCodes.Status200OK);
        }

        protected StatusCodeResult InternalServerErrorResponse()
        {
            return StatusCode(StatusCodes.Status500InternalServerError);
        }
    }
}
