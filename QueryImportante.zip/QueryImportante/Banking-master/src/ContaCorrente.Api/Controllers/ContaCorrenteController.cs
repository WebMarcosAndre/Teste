﻿using System;
using Microsoft.AspNetCore.Mvc;
using ContaCorrente.Domain.Arguments;
using ContaCorrente.Domain.Interfaces.Services;
using ContaCorrente.Infra.UnitOfWork;

namespace ContaCorrente.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContaCorrenteController : BaseController
    {
        private readonly ILancamentoService _lancamentoService;

        public ContaCorrenteController(IUnitOfWork unitOfWork, ILancamentoService lancamentoService)
            : base(unitOfWork)
        {
            _lancamentoService = lancamentoService;
            _unitOfWork = unitOfWork;
        }

        [HttpPost("Transferencia")]
        [ProducesResponseType(typeof(StatusCodeResult), 200)]
        [ProducesResponseType(typeof(StatusCodeResult), 500)]
        public StatusCodeResult Transferencia(TransferenciaRequest request)
        {
            try
            {
                _lancamentoService.EfetuarTransferencia(request);
                return OkResponse();
            }
            catch (Exception)
            {
                return InternalServerErrorResponse();
            }
        }
    }
}
