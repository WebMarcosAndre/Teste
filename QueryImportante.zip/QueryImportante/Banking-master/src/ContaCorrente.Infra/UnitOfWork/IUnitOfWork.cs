﻿using Microsoft.EntityFrameworkCore.Storage;

namespace ContaCorrente.Infra.UnitOfWork
{
    public interface IUnitOfWork
    {
        void Commit();
        IDbContextTransaction BeginTransaction();
    }
}
