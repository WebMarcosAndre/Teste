﻿using ContaCorrente.Infra.Context;
using Microsoft.EntityFrameworkCore.Storage;

namespace ContaCorrente.Infra.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly SqlContext _context;

        public UnitOfWork(SqlContext context)
        {
            _context = context;
        }

        public IDbContextTransaction BeginTransaction()
        {
            return _context.Database.BeginTransaction();
        }

        public void Commit()
        {
            _context.SaveChanges();
        }
    }
}
