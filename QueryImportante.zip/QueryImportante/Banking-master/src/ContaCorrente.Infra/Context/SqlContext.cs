﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using ContaCorrente.Domain.Entities;

namespace ContaCorrente.Infra.Context
{
    public partial class SqlContext : DbContext
	{
		public SqlContext()
		{ }

		public SqlContext(DbContextOptions<SqlContext> options)
			: base(options)
		{ }

		public virtual DbSet<Conta> Conta { get; set; }
        public virtual DbSet<Lancamento> Lancamento { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=test;Integrated Security=True;Pooling=False");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
            modelBuilder.Entity<Conta>(entity =>
			{
				entity.Property(e => e.Id).HasColumnName("ContaCorrenteId").IsRequired();
                entity.Property(e => e.Saldo).IsRequired();
            });

            modelBuilder.Entity<Lancamento>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("LancamentoId").IsRequired();
                entity.Property(e => e.ContaCorrenteOrigemId).IsRequired();
                entity.Property(e => e.ContaCorrenteDestinoId).IsRequired();
                entity.Property(e => e.DataLancamento).IsRequired();
                entity.Property(e => e.TipoTransacao).IsRequired();
                entity.Property(e => e.TipoOperacao).IsRequired();
                entity.Property(e => e.Valor).IsRequired();
            });
        }
	}
}
