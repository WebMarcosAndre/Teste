﻿using ContaCorrente.Domain.Entities;
using ContaCorrente.Domain.Interfaces.Repositories;
using ContaCorrente.Infra.Context;

namespace ContaCorrente.Infra.Repositories
{
    public class LancamentoRepository : BaseRepository<Lancamento>, ILancamentoRepository
    {
        public LancamentoRepository(SqlContext context) 
            : base(context)
        { }

        public Lancamento IncluirLancamento(Lancamento lancamento)
        {
            return Adicionar(lancamento);
        }
    }
}
