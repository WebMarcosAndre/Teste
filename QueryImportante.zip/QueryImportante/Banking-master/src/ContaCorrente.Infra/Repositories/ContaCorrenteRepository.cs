﻿using ContaCorrente.Domain.Entities;
using ContaCorrente.Domain.Interfaces.Repositories;
using ContaCorrente.Infra.Context;

namespace ContaCorrente.Infra.Repositories
{
    public class ContaCorrenteRepository : BaseRepository<Conta>, IContaCorrenteRepository
    {
        public ContaCorrenteRepository(SqlContext context)
            : base(context)
        { }

        public Conta ObterContaCorrente(int contaCorrenteId)
        {
            return ObterPorId(contaCorrenteId);
        }

        public void AtualizarSaldo(Conta contaCorrente)
        {
            Atualizar(contaCorrente);
        }
    }
}
