﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using ContaCorrente.Domain.Entities;
using ContaCorrente.Domain.Interfaces.Repositories;
using ContaCorrente.Infra.Context;
using ContaCorrente.Infra.UnitOfWork;

namespace ContaCorrente.Infra.Repositories
{
    public class BaseRepository<TEntity> : IBaseRepository<TEntity> where TEntity : BaseEntity
    {
        protected SqlContext _context;
        protected DbSet<TEntity> dbSet;

        public BaseRepository(SqlContext context)
        {
            _context = context;
            dbSet = _context.Set<TEntity>();
        }

        public virtual TEntity Adicionar(TEntity obj)
        {
            return dbSet.Add(obj).Entity;
        }

        public virtual TEntity ObterPorId(int id)
        {
            return dbSet.Find(id);
        }

        public virtual IEnumerable<TEntity> ObterTodos()
        {
            return dbSet;
        }

        public virtual TEntity Atualizar(TEntity obj)
        {
            var entry = _context.Entry(obj);
            dbSet.Attach(obj);
            entry.State = EntityState.Modified;

            return obj;
        }

        public virtual void Remover(int id)
        {
            dbSet.Remove(dbSet.Find(id));
        }

        public IEnumerable<TEntity> Buscar(Expression<Func<TEntity, bool>> predicate)
        {
            return dbSet.Where(predicate);
        }

        public int SaveChanges()
        {
            return _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}
