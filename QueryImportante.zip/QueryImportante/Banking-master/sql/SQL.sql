﻿-- CRIAR BANCO DE DADOS

CREATE TABLE [dbo].[Lancamento] (
    [LancamentoId]           INT             IDENTITY (1, 1) NOT NULL,
    [ContaCorrenteOrigemId]  INT             NOT NULL,
    [ContaCorrenteDestinoId] INT             NOT NULL,
    [DataLancamento]         DATETIME2 (7)   NOT NULL,
    [TipoTransacao]          INT             NOT NULL,
    [TipoOperacao]           INT             NOT NULL,
    [Valor]                  DECIMAL (18, 2) NOT NULL,
    CONSTRAINT [PK_Lancamento] PRIMARY KEY CLUSTERED ([LancamentoId] ASC)
);

CREATE TABLE [dbo].[Conta] (
    [ContaCorrenteId] INT             IDENTITY (1, 1) NOT NULL,
    [Saldo]           DECIMAL (18, 2) NOT NULL,
    CONSTRAINT [PK_Conta] PRIMARY KEY CLUSTERED ([ContaCorrenteId] ASC)
);

-- SEED

INSERT INTO Conta VALUES
(185199.00)

INSERT INTO Conta VALUES
(125500.00)

SELECT * FROM Conta
SELECT * FROM Lancamento