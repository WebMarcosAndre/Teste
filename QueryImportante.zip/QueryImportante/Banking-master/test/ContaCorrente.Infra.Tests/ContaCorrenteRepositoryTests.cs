﻿using System;
using Microsoft.EntityFrameworkCore;
using ContaCorrente.Domain.Entities;
using ContaCorrente.Domain.Interfaces.Repositories;
using ContaCorrente.Infra.Context;
using ContaCorrente.Infra.Repositories;
using Xunit;

namespace ContaCorrente.Infra.Tests
{
    public class ContaCorrenteRepositoryTests
    {
        private IContaCorrenteRepository GetInMemoryContaCorrenteRepository()
        {
            var builder = new DbContextOptionsBuilder<SqlContext>();
            builder.UseInMemoryDatabase(Guid.NewGuid().ToString());
            var options = builder.Options;
            var sqlContext = new SqlContext(options);
            sqlContext.Database.EnsureCreated();
            return new ContaCorrenteRepository(sqlContext);
        }

        [Fact]
        public void Adicionar()
        {
            // Arrange
            var contaCorrenteRepository = GetInMemoryContaCorrenteRepository();
            var contaCorrente = new Conta()
            {
                Id = 1,
                Saldo = 185199M
            };

            // Act
            var contaCorrenteSalva = contaCorrenteRepository.Adicionar(contaCorrente);

            // Assert
            Assert.Equal(contaCorrente, contaCorrenteSalva);
        }
    }
}
