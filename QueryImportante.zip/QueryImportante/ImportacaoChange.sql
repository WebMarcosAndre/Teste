USE IK_VAREJO

GO

SELECT pb.op_data_inclusao, pb.op_data_boleto, pb.op_n_boleto_change, mt.idSwift, mtc.idSwift , mtc2.M20_SenderRef
FROM TBL_PRE_BOLETO pb (NOLOCK) 
	LEFT JOIN TBL_MEWEB_MT103 mt (NOLOCK)
			ON pb.op_n_boleto = mt.OP_N_BOLETO
	LEFT JOIN TBL_MEWEB_MT103_CHANGE mtc (NOLOCK)
			ON mt.idSwift = mtc.idSwift
	LEFT JOIN TBL_MEWEB_MT103_CHANGE mtc2 (NOLOCK)
			ON mtc.REFREM = mt.M20_SenderRef
WHERE pb.op_data_boleto > '20180521' --AND op_n_boleto = 2629995
ORDER BY pb.op_data_boleto DESC

SELECT TOP 100 *
 FROM  LKD_CAMBIO.CAMBIO.DBO.OR01 AS CA WITH(NOLOCK)   
             WHERE ca.datavl>= getdate() - 5
ORDER BY ca.datavl DESC

--SELECT TOP 10 * FROM TBL_MEWEB_MT103_CHANGE (NOLOCK) ORDER BY DATAVL DESC

--TBL_LOGIN_INTEGRADO
