USE DBVAREJO
GO



--SELECT top 10 * FROM TBL_PRE_BOLETO (NOLOCK) ORDER BY op_n_boleto DESC

SELECT dbo.fn_GetFaseCompra(2888092, 2) as Fase

--CREATE FUNCTION [dbo].[fn_GetFaseCompra]       
--(      
DECLARE
 @OP_N_BOLETO INT = 2888092,      
 @CAMPO INT   = 2   
--)      
--RETURNS INT      
--AS      
--BEGIN      
----      
 DECLARE @FASE INT      
 DECLARE @nat_obriga_doc BIT     
 DECLARE @nat_obriga_bol_assinado bit     
 DECLARE @op_val_moeda DECIMAL(10,2)   
 DECLARE @OP_TIPO_MOEDA CHAR(6)      
 DECLARE @PARIDADE DECIMAL(10,4)      
 DECLARE @MOE_TIPO VARCHAR(10)      
 DECLARE @VALOR_EM_DOLLAR DECIMAL(10,2)       
 DECLARE @LIMITE_ASSINATURA DECIMAL(10,2)      
 DECLARE @LIMITE_BOLETO DECIMAL(10,2)      
 DECLARE @FLAG_ASSINA_DIGITALMENTE CHAR(1)      
       
 --Preenche os campos necess�rios       
 SELECT TOP 1 @nat_obriga_doc = N.nat_obriga_doc, @op_val_moeda = B.op_val_moeda, @OP_TIPO_MOEDA = op_tipo_moeda,     
 @FLAG_ASSINA_DIGITALMENTE = C.Flg_Assina_Digitalmente, @nat_obriga_bol_assinado = N.nat_obriga_bol_assinado         
 FROM TBL_PRE_BOLETO AS B WITH(NOLOCK)      
 INNER JOIN tbl_natureza AS N WITH(NOLOCK) ON OP_NATUREZA = id_natureza       
 INNER JOIN TBL_CLIENTES AS C WITH(NOLOCK) ON C.ID_CLIENTE = B.ID_CLIENTE       
 WHERE OP_N_BOLETO = @OP_N_BOLETO      
      
 SELECT @PARIDADE= A.PARIDADE, @MOE_TIPO = B.MOE_TIPO       
 FROM VAREJO..TMOEDAS A WITH(NOLOCK)      
 INNER JOIN TBL_MOEDAS B WITH(NOLOCK) ON A.COD_MOEDA COLLATE DATABASE_DEFAULT = B.MOE_SIMBOLO COLLATE DATABASE_DEFAULT       
 WHERE A.COD_MOEDA COLLATE DATABASE_DEFAULT = @OP_TIPO_MOEDA COLLATE DATABASE_DEFAULT      
      
 IF @MOE_TIPO = 'A'       
 BEGIN      
  IF @PARIDADE>1      
   SET @VALOR_EM_DOLLAR = @op_val_moeda/@PARIDADE       
  ELSE      
   SET @VALOR_EM_DOLLAR = @op_val_moeda*@PARIDADE       
   END      
 ELSE        
 BEGIN      
   SET @VALOR_EM_DOLLAR = @op_val_moeda*@PARIDADE       
 END      
      
 --Obt�m o limite da opera��o      
    SET @LIMITE_ASSINATURA = (SELECT TOP 1 config_valor FROM TBL_CONFIGURACOES WITH(NOLOCK) WHERE CONFIG_TIPO = 'ASSINATURA')      
 SET @LIMITE_BOLETO = (SELECT TOP 1 config_valor FROM TBL_CONFIGURACOES WITH(NOLOCK) WHERE CONFIG_TIPO = 'BOLETO' AND CONFIG_OP = 'V')      
 --Campo status      
 IF @CAMPO = 1       
 BEGIN      
   -- 10 - Pendente Fechamento de C�mbio      
   IF NOT EXISTS(      
     SELECT id_operacao      
     FROM TBL_PRE_BOLETO WITH (NOLOCK)       
     WHERE OP_N_BOLETO = @OP_N_BOLETO      
     AND ISNUMERIC(ID_VINCULO) = 1      
     AND OP_NATUREZA > 0      
     AND OP_TARIFA_OPERACAO >= 0      
     AND LEN(OP_PAG_RECEB) > 0      
     AND OP_TX_OPERACAO > 0      
     AND Vlr_IOF >= 0)      
   BEGIN      
    SELECT @FASE = 10       
   END       
      
   -- 20 - Definir dados banc�rios      
   ELSE IF NOT EXISTS(      
      SELECT id_operacao      
      FROM TBL_PRE_BOLETO A WITH (NOLOCK)      
      WHERE OP_N_BOLETO = @OP_N_BOLETO       
      AND OP_GRP_BANCARIOS > 0      
      AND LEN(OP_TIPO_LIQ) > 0      
      AND (OP_GRUPO1 > 0 OR OP_GRUPO2 > 0 OR OP_GRUPO3 > 0)      
   )      
   BEGIN       
    SELECT @FASE = 20       
   END       
      
                                           -- 30 - Anexar Procura��o      
 --ELSE IF ( @temProcuracao = 0 AND (@valorEmDolar > @valorMaxOperacao)      
         
   /*      
   SELECT COUNT(*)      
   FROM TBL_COL_UPLOAD_ARQUIVOS       
   WHERE TIPO_OPERACAO = 'P' AND NR_DOCTO = @OP_N_BOLETO*/      
 --   )       
 --BEGIN      
 --  SELECT @FASE = 30       
 --END      
      
 -- 40 - Contrato de C�mbio Pendente de Assinatura (Imprimir e Anexar Boleto)      
 --       
      
 -- TODO O TEMPO QUE OP_ASSINADO SEJA 'N' e:      
        
 -- 1. nao anexou ainda o boleto assinado --> SOLICITAR boleto      
 -- 2. ja anexou e foi rejeitado --> SOLICITAR boleto      
        
 -- COMO FUNCIONA A FLAG BOLETO_ASSINADO_REJEITADO      
 -- QUANDO o boleto assinado FOR REJEITADo PELO VAREJO, SERA ENVIADO EMAIL AO CLIENTE E BOLETO_ASSINADO_REJEITADO= 'S'      
 -- QUANDO O CLIENTE ANEXAR UM NOVO boleto A FLAG FICA BOLETO_ASSINADO_REJEITADO= 'N'      
      
   ELSE IF (      
    SELECT SUM(A.C1) FROM (      
      SELECT COUNT(*) AS C1      
      FROM TBL_PRE_BOLETO A WITH (NOLOCK)      
      JOIN TBL_COL_PREBOLETO C WITH (NOLOCK)      
      ON  A.OP_N_BOLETO = C.PRE_N_BOLETO      
      WHERE OP_N_BOLETO = @OP_N_BOLETO       
      AND  OP_ASSINADO = 'N'      
      AND  NOT EXISTS (SELECT TOP 1 * FROM TBL_COL_UPLOAD_ARQUIVOS WITH (NOLOCK) WHERE NR_DOCTO = @OP_N_BOLETO and TIPO_OPERACAO = 'B')      
      
      UNION      
      
      SELECT COUNT(*) AS C1      
      FROM TBL_PRE_BOLETO A WITH (NOLOCK)      
      JOIN TBL_COL_PREBOLETO C WITH (NOLOCK)      
      ON  A.OP_N_BOLETO = C.PRE_N_BOLETO      
      WHERE OP_N_BOLETO = @OP_N_BOLETO       
      AND  OP_ASSINADO = 'N'      
      AND  BOLETO_ASSINADO_REJEITADO = 'S') AS A      
          
      ) > 0 AND @VALOR_EM_DOLLAR > @LIMITE_ASSINATURA AND ISNULL(@FLAG_ASSINA_DIGITALMENTE,'N') = 'N'  AND @nat_obriga_bol_assinado = 0       
   BEGIN       
    SELECT @FASE = 40       
   END      
      
                     -- 50 - Documenta��o Pendente      
        
 -- TODO O TEMPO QUE APROVACAO_DOCUMENTACAO SEJA N E:      
        
 -- 1. TEM ARQUIVO NA TABELA DE EUPLOAD - E DOCUMENTACAO REJEITADA --> SOLICITAR DOCUMENTACAO      
 -- 2. NAO TEM ARQUIVO NA TABELA DE UPLOAD --> SOLICITAR DOCUMENTACAO      
        
 -- COMO FUNCIONA A FLAG DOCUMENTACAO_REJEITADA       
 -- QUANDO A DOCUMENTACAO FOR REJEITADA PELO VAREJO, SERA ENVIADO EMAIL AO CLIENTE E DOCUMENTACAO_REJEITADA= 'S'      
 -- QUANDO O CLIENTE ANEXAR UM NOVO DOCUMENTO A FLAG FICA DOCUMENTACAO_REJEITADA= 'N'      
      
   ELSE IF (      
    SELECT SUM(A.C1) FROM (      
      SELECT COUNT(*) AS C1      
      FROM TBL_PRE_BOLETO A WITH (NOLOCK)      
      JOIN TBL_COL_PREBOLETO C WITH (NOLOCK)      
      ON  A.OP_N_BOLETO = C.PRE_N_BOLETO      
      WHERE OP_N_BOLETO = @OP_N_BOLETO       
      AND  APROVACAO_DOCUMENTOS = 'N'      
      AND  NOT EXISTS (SELECT TOP 1 * FROM TBL_COL_UPLOAD_ARQUIVOS WITH (NOLOCK) WHERE NR_DOCTO = @OP_N_BOLETO and TIPO_OPERACAO = 'D')      
      
      UNION      
      
      SELECT COUNT(*) AS C1      
      FROM TBL_PRE_BOLETO A WITH (NOLOCK)      
      JOIN TBL_COL_PREBOLETO C WITH (NOLOCK)      
      ON  A.OP_N_BOLETO = C.PRE_N_BOLETO      
      WHERE OP_N_BOLETO = @OP_N_BOLETO       
      AND  APROVACAO_DOCUMENTOS = 'N'      
      AND  DOCUMENTACAO_REJEITADA = 'S'      
      AND  EXISTS (SELECT TOP 1 * FROM TBL_COL_UPLOAD_ARQUIVOS WITH (NOLOCK) WHERE NR_DOCTO = @OP_N_BOLETO and TIPO_OPERACAO = 'D') ) AS A      
          
      ) > 0 AND ISNULL(@nat_obriga_doc,0) = 0 AND @VALOR_EM_DOLLAR > @LIMITE_BOLETO      
   BEGIN       
    SELECT @FASE = 50       
   END      
      
   -- 60 - Conclu�da      
      
   ELSE IF (      
      
      SELECT COUNT(*)      
      FROM TBL_PRE_BOLETO A WITH (NOLOCK)      
      WHERE OP_N_BOLETO = @OP_N_BOLETO       
      AND  a.pre_boleto_status = 2      
          
      ) > 0      
   BEGIN       
     SELECT @FASE = 60       
   END      
      
      
   -- 70 - Em Processamento      
   ELSE IF (      
      
      SELECT COUNT(*)      
      FROM TBL_PRE_BOLETO A WITH (NOLOCK)      
      JOIN TBL_COL_PREBOLETO C WITH (NOLOCK)      
      ON  A.OP_N_BOLETO = C.PRE_N_BOLETO      
      WHERE OP_N_BOLETO = @OP_N_BOLETO       
      AND  A.PRE_BOLETO_STATUS = 1      
      AND  (APROVACAO_DOCUMENTOS = 'S' or DOCUMENTACAO_REJEITADA = 'n')      
      AND  (OP_ASSINADO <> 'N' or BOLETO_ASSINADO_REJEITADO = 'n')      
      AND  (OP_GRUPO1 <> 0 OR OP_GRUPO2 <> 0 OR OP_GRUPO3 <> 0) -- J� DEFINIU OS DADOS BANC�RIOS PARA RECEBER A TED      
          
      ) > 0      
   BEGIN       
     SELECT @FASE = 70       
   END      
      
        
        
   -- 80 - Cancelada      
   ELSE IF ( 
      
      SELECT COUNT(*)      
      FROM TBL_PRE_BOLETO A WITH (NOLOCK)      
      WHERE OP_N_BOLETO = @OP_N_BOLETO       
      AND  a.pre_boleto_status = 3      
          
      ) > 0      
   BEGIN       
     SELECT @FASE = 80       
   END       
       
   -- 90 - Em Verifica��o       
        
   ELSE       
      
   BEGIN       
    SELECT @FASE = 90       
   END       
 END      
 ELSE IF @CAMPO = 3 --Campo Documento est� ativo = 1 n�o ativo = 0      
 BEGIN      
   IF ISNULL(@nat_obriga_doc,0) = 0 AND @VALOR_EM_DOLLAR > @LIMITE_BOLETO      
   BEGIN       
    SELECT @FASE = 1       
   END      
   ELSE      
   BEGIN      
    SELECT @FASE = 0      
   END      
 END      
 ELSE IF @CAMPO = 2      
 BEGIN      
     
  IF @VALOR_EM_DOLLAR > @LIMITE_ASSINATURA AND ISNULL(@FLAG_ASSINA_DIGITALMENTE,'N') = 'N' AND ISNULL(@nat_obriga_bol_assinado,0) = 0           
   BEGIN       
    SELECT @FASE = 1       
   END      
   ELSE      
   BEGIN      
    SELECT @FASE = 0       
   END      
 END      
   ELSE IF @CAMPO = 4      
 BEGIN      
   IF @VALOR_EM_DOLLAR > @LIMITE_ASSINATURA AND ISNULL(@nat_obriga_bol_assinado,0) = 0        
   BEGIN       
    SELECT @FASE = 1       
   END      
   ELSE      
   BEGIN      
    SELECT @FASE = 0       
   END      
 END        
      

      select @VALOR_EM_DOLLAR 'VALOR EM DOLAR', @LIMITE_ASSINATURA 'LIMITE DE ASSINATURA' ,ISNULL(@FLAG_ASSINA_DIGITALMENTE,'N') 'ASSINA DIGITALMENTE' ,ISNULL(@nat_obriga_bol_assinado,0)  'NAT OBRIGA ASSINATURA'      
 SELECT @FASE    
   
        SELECT TOP 10 n.portal_titulo, N.nat_obriga_doc,  B.op_val_moeda,  op_tipo_moeda,     
 C.Flg_Assina_Digitalmente, N.nat_obriga_bol_assinado   , C.id_cliente  , op_n_boleto    
 FROM TBL_PRE_BOLETO AS B WITH(NOLOCK)      
 LEFT JOIN tbl_natureza AS N WITH(NOLOCK) ON b.OP_NATUREZA = n.id_natureza       
 INNER JOIN TBL_CLIENTES AS C WITH(NOLOCK) ON C.ID_CLIENTE = B.ID_CLIENTE       
 WHERE OP_N_BOLETO = @OP_N_BOLETO 
--END 

--SELECT TOP 10 * FROM TBL_CRM (NOLOCK) where crm_nboleto= 2887909 ORDER BY 1 DESC
--use dbvarejo
--go
--SELECT TOP 1000 * FROM TBL_CRM (NOLOCK) where crm_ocorrencia LIKE '%assinar%' ORDER BY 1 DESC 