SELECT TOP 1000 * FROM IK_VAREJO.DBO.TBL_LOGIN_INTEGRADO (NOLOCK) WHERE li_nome  LIKE '%CESAR%' AND li_nome  LIKE '%MENDES%'

SELECT TOP 1000 li_email,* FROM IK_VAREJO.DBO.TBL_LOGIN_INTEGRADO (NOLOCK) WHERE li_doc = '02323948000103' or li_doc = '31294721852'


--UPDATE IK_VAREJO.DBO.TBL_LOGIN_INTEGRADO
--SET li_email = 'marcos.costa.ext@cotacao.com.br' WHERE li_doc = '02323948000103' or li_doc = '31294721852'

--roberto.sanovicz@advtour.com.br
--teste@teste.com

SELECT  li_email FROM IK_VAREJO.DBO.TBL_LOGIN_INTEGRADO_LOG (NOLOCK) WHERE li_doc = '02323948000103' or li_doc = '31294721852'

begin transaction

declare @senha VARBINARY(255)
set @senha = CONVERT(VARBINARY(255), ik_varejo.DBO.FN_RE_ENCDECRC4('LOGININTEGRADO','Rend123'))
--select @senha
update TBL_LOGIN_INTEGRADO 
set li_senha = @senha
where LI_ID = 24
go
rollback
commit
use ik_varejo
select * from ik_varejo.dbo.tbl_login_integrado where li_id = 24


???

???�