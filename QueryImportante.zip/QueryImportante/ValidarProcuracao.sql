
USE IK_VAREJO
GO


DECLARE @NrBoleto INT = 2630227

SELECT  b.op_assinado, b.id_cliente, b.op_n_boleto, 
b.op_data_boleto, b.op_data_inclusao, c.DT_INCLUSAO, c.DT_ATIVACAO, c.DT_APROVAVACAO, c.DT_REVOGACAO,
i.li_doc, li_nome
--, * 
,d.OP_N_BOLETO boletoAssinado
FROM dbo.tbl_pre_boleto b (NOLOCK) 
	LEFT JOIN dbo.TBL_PROCURACAO_CLIENTE C (NOLOCK)
			ON b.id_cliente = c.ID_CLIENTE
	LEFT JOIN dbo.TBL_LOGIN_INTEGRADO i (NOLOCK)
			ON b.ID_CLIENTE = i.LI_IDCLIENTE
	LEFT JOIN dbo.TBL_BOLETO_ASSINADO_DIGITALMENTE d (NOLOCK)
			ON b.op_n_boleto = d.OP_N_BOLETO
WHERE b.op_data_inclusao > '20180604'
	AND b.op_n_boleto = 2630227
ORDER BY b.op_n_boleto DESC

--2630201