USE IK_VAREJO
GO


DECLARE @Arq VARCHAR(20) =   '25062019D'

BEGIN TRANSACTION
 
 
DELETE mc
FROM TBL_MEWEB_MT103 m (NOLOCK)  
	LEFT JOIN TBL_MEWEB_MT103_LOTE ml (NOLOCK)
			ON m.id_Lote  = ml.Lote
	LEFT JOIN TBL_MEWEB_MT103_CHANGE mc (NOLOCK)
			ON m.idSwift = mc.idSwift
 WHERE m.Arquivo_entrada like '%'+@Arq+'%' 

DELETE m
FROM TBL_MEWEB_MT103 m (NOLOCK)  
	LEFT JOIN TBL_MEWEB_MT103_LOTE ml (NOLOCK)
			ON m.id_Lote  = ml.Lote
	LEFT JOIN TBL_MEWEB_MT103_CHANGE mc (NOLOCK)
			ON m.idSwift = mc.idSwift
 WHERE m.Arquivo_entrada like '%'+@Arq+'%' 
 
DELETE ml
FROM TBL_MEWEB_MT103 m (NOLOCK)  
	LEFT JOIN TBL_MEWEB_MT103_LOTE ml (NOLOCK)
			ON m.id_Lote  = ml.Lote
	LEFT JOIN TBL_MEWEB_MT103_CHANGE mc (NOLOCK)
			ON m.idSwift = mc.idSwift
 WHERE m.Arquivo_entrada like '%'+@Arq+'%' 
 
 COMMIT

 /*
 
 UPDATE TBL_ROBOCCMESWIFT SET FLAG_HABILITA_TELAS_CCME = 'S'

 */