USE IK_VAREJO


DECLARE @DOC VARCHAR(100)		=	'30968177824'	,
		@ValorEmDolar DECIMAL	=	'15000.00'			,	--	Caso queira setar um valor da opera��o 37150224000190
		@Google INT				=	1				,
		@Assinado VARCHAR(1)		=	'N'


		--select * from TBL_LOGIN_INTEGRADO (nolock) where li_nome like 'bras%'
		-- update tbl_pre_boleto set id_cliente = 463888 where id_cliente = 463887
		--select cl_tip_doc  from tbl_clientes where cl_num_doc = '37150224000190'
		--select li_tipocliente from TBL_LOGIN_INTEGRADO where li_doc = '37150224000190'
		--update TBL_LOGIN_INTEGRADO set LI_TIPOCLIENTE = 4 where li_doc = '31294721852'
		--UPDATE TBL_CLIENTES SET cl_tip_doc = 'CPF' WHERE cl_num_doc = '31294721852'

DECLARE @IdCliente INT = 278340, -- Usu�rio que vai receber os boletos
		@NrBoletoExemplo INT = 2878632 -- Boleto j� existente na base que ser� utilizado como exemplo

SELECT @IdCliente = ID_CLIENTE FROM TBL_CLIENTES (NOLOCK) WHERE cl_num_doc = @DOC
		--878633 Google de exemplo dbvarejo de dev
		SELECT 		@IdCliente

		SELECT @NrBoletoExemplo = op_n_boleto FROM 
				IK_VAREJO.dbo.TBL_MEWEB_MT103 M  (NOLOCK) 
		INNER JOIN IK_VAREJO.dbo.TBL_MEWEB_MT103_CHANGE MTC (NOLOCK)
				ON MTC.REFREM = M.M20_SenderRef
		WHERE m.flaggoogle = @google
		IF @NrBoletoExemplo IS NULL
		BEGIN
			SELECT 'N�o encontrado boleto'
			RETURN
		END

DECLARE @INF_FAV VARCHAR(100) 

SET @INF_FAV = ' TESTE DO MARCOS'
IF(@Google=1)
	SET @INF_FAV = ' GOOGLE TESTE DO MARCOS'

BEGIN	TRY  

			BEGIN TRANSACTION

					INSERT INTO TBL_PRE_BOLETO
						(
									ID_CORRETORA,
									ID_USER_CRIACAO,   
									ID_CLIENTE,
									OP_TIPO_OPERACAO,
									OP_TIPO_ENTREGA,
									OP_TIPO_MOEDA,  
									OP_VAL_MOEDA,   
									OP_DATA_SISTEMA,
									OP_DATA_BOLETO,   
									OP_INF_COMPL,     
									OP_STATUS,  
									OP_INF_FAV,
									OP_INF_BANCO,
									OP_SWIFT_CODE, 
									OP_PAGA,   
									OP_VERIFICADA,
									OP_PAISES,
									OP_ASSINADO,
									OP_DATA_INCLUSAO,   
									OP_DATA_FOLLOW_UP,      
									PRE_BOLETO_STATUS,
									APROVACAO_COMPLIANCE,   
									APROVACAO_DOCUMENTOS,
									AUX_DATAMNME,
									APROVACAO_CONTRAPARTIDA,
									OP_CONTRAPARTIDA,
									OP_DATA_MN_BOL,
									OP_DATA_ME_BOL,
									AP_COMP_SEM_NIVEL,
									ID_USER_EDICAO,   
									OP_ASSINADO_USUARIO,  
									C50K_DADOS_SWIFT,     
									OP_NUMERO_ORDEM,  
									FOIPROCESSADAREMESSAEXPRESSA,  
									SISTEMA_ORIGEM,  
									APROVACAO_HORARIOCORTE  
						) VALUES (
									10,												--ID_CORRETORA,
									3337,											--ID_USER_CRIACAO,   
									@IdCliente,										--ID_CLIENTE,
									'C',											--OP_TIPO_OPERACAO,
									'ORDEM',										--OP_TIPO_ENTREGA,
									'USD',											--OP_TIPO_MOEDA,  
									3.73343080,										--op_tx_operacao
									76.6100,										--op_tarifa_operacao
									77.76960332,									--op_resul_minimo
									35,63410332,									--op_spread
									3.830500,										--op_taxa_banco									
									367.10,											--op_val_moeda
									1370.54,										--op_val_reais  
									'2019-06-25 00:00:00.000',						--OP_DATA_SISTEMA,
									'2019-06-25 00:00:00.000',						--OP_DATA_BOLETO,
									'2019-06-25 00:00:00.000',						--op_data_mn
									'2019-06-25 00:00:00.000',						--op_data_me
									'',												--OP_INF_COMPL,   
									'P',										    --OP_STATUS,  
									 @INF_FAV,										--OP_INF_FAV,
									'BANK OF AMERICA, N.A.',						--OP_INF_BANCO,
									'BOFAUS3N',										--OP_SWIFT_CODE, 
									'N',											--OP_PAGA,   
									'S',											--OP_VERIFICADA,
									2496,											--OP_PAISES,
									@Assinado,											--OP_ASSINADO,
									GETDATE(),										--OP_DATA_INCLUSAO,   
									GETDATE(),										--OP_DATA_FOLLOW_UP,      
									1,												--PRE_BOLETO_STATUS,
									'N',											--APROVACAO_COMPLIANCE,   
									'S',											--APROVACAO_DOCUMENTOS,
									'D0D0',											--AUX_DATAMNME,
									'S',											--APROVACAO_CONTRAPARTIDA,
									'N',											--OP_CONTRAPARTIDA,
									GETDATE(),										--OP_DATA_MN_BOL,
									GETDATE(),										--OP_DATA_ME_BOL,
									'N',											--AP_COMP_SEM_NIVEL,
									'496',											--ID_USER_EDICAO,   
									'N',											--OP_ASSINADO_USUARIO,  
									'Teste',										--C50K_DADOS_SWIFT,     
									'OP0000000000001',								--OP_NUMERO_ORDEM,  
									1,												--FOIPROCESSADAREMESSAEXPRESSA,  
									'PC',											--SISTEMA_ORIGEM,  
									'S'												--APROVACAO_HORARIOCORTE 
					)						 

					    
					DECLARE @IdOperacao INT = @@Identity


					INSERT INTO TBL_NUM_OPERACAO (ID_PRE_BOLETO)
						   VALUES (@IdOperacao)
					DECLARE @NrBoleto INT = @@Identity	   


					UPDATE TBL_PRE_BOLETO SET op_n_boleto = @NrBoleto WHERE id_operacao = @IdOperacao
					    
					    
					SELECT @NrBoleto 'N�mero do Boleto'
					
					
					INSERT INTO IK_VAREJO.DBO.TBL_MEWEB_MT103 (
							[HeaderOp]
							,[M20_SenderRef]
							,[O21_TransactionReference]
							,[M23B_BankOperCode]
							,[O23E_InstructionCode]
							,[M32A_VDateCurrencyInterbank]
							,[O33B_CurrencyInstructed]
							,[O36_ExchangeRate]
							,[M50A_OrderingCustomer]
							,[M50K_OrderingCustomer]
							,[O50F_AdditionalInformation]
							,[O52A_OrderingInstitution]
							,[O52D_OrderingInstitution]
							,[O53A_SenderCorrespondent]
							,[M53B_SenderCorrespondent]
							,[O54A_ReceiverCorrespondent]
							,[O56A_IntermediaryInstitution]
							,[O57A_AccountInstitution]
							,[O57D_AccountInstitution]
							,[O58D_BeneficiaryInstitution]
							,[M59_BeneficiaryCustomer]
							,[O70_RemittanceInformation]
							,[M71A_DetailsOfCharges]
							,[O71F_SenderCharges]
							,[O71G_ReceiverCharges]
							,[O72_SenderToReceiverInf]
							,[TrailerOp]
							,[id_Lote]
							,[id_user]
							,[data_registro]
							,[Arquivo_entrada]
							,[FlagGoogle]
							,[data_lancamento]
							,[data_lancamento_robo]
							,[status_lanc]
							,[Tipo_Lanc]
							,[ID_LANC]
							,[id_cliente]
							,[Lc_Automatico]
							,[ID_CLIENTE_FASE1]
							,[O54D_ReceiverCorrespondent]
							,[M53D_SenderCorrespondent]
							,[OP_N_BOLETO]
							,[OP_N_BOLETO_EMPRESA]
							,[OP_N_BOLETO_SISTEMA]
							,[STATUS_PREBOLETO]
							,[BENEFICIARIO]
							,[ORDENANTE]
							,[O26T_TransactionTypeCode]
					)
					SELECT 			
							[HeaderOp]
							,[M20_SenderRef]
							,[O21_TransactionReference]
							,[M23B_BankOperCode]
							,[O23E_InstructionCode]
							,[M32A_VDateCurrencyInterbank]
							,[O33B_CurrencyInstructed]
							,[O36_ExchangeRate]
							,[M50A_OrderingCustomer]
							,[M50K_OrderingCustomer]
							,[O50F_AdditionalInformation]
							,[O52A_OrderingInstitution]
							,[O52D_OrderingInstitution]
							,[O53A_SenderCorrespondent]
							,[M53B_SenderCorrespondent]
							,[O54A_ReceiverCorrespondent]
							,[O56A_IntermediaryInstitution]
							,[O57A_AccountInstitution]
							,[O57D_AccountInstitution]
							,[O58D_BeneficiaryInstitution]
							,[M59_BeneficiaryCustomer]
							,[O70_RemittanceInformation]
							,[M71A_DetailsOfCharges]
							,[O71F_SenderCharges]
							,[O71G_ReceiverCharges]
							,[O72_SenderToReceiverInf]
							,[TrailerOp]
							,[id_Lote]
							,[id_user]
							,[data_registro]
							,[Arquivo_entrada]
							,@Google
							,[data_lancamento]
							,[data_lancamento_robo]
							,[status_lanc]
							,[Tipo_Lanc]
							,[ID_LANC]
							,[id_cliente]
							,[Lc_Automatico]
							,[ID_CLIENTE_FASE1]
							,[O54D_ReceiverCorrespondent]
							,[M53D_SenderCorrespondent]
							,@NrBoleto
							,[OP_N_BOLETO_EMPRESA]
							,[OP_N_BOLETO_SISTEMA]
							,[STATUS_PREBOLETO]
							,[BENEFICIARIO]
							,[ORDENANTE]
							,[O26T_TransactionTypeCode]
					FROM IK_VAREJO.DBO.[TBL_MEWEB_MT103] 
					WHERE OP_N_BOLETO = @NrBoletoExemplo
										    
					COMMIT
END TRY
BEGIN CATCH
					ROLLBACK
END CATCH
