USE IK_VAREJO
GO

DECLARE @NrBoleto INT = 2550205 --2629927

SELECT  [dbo].[fn_GetFaseCompra](OP_N_BOLETO, 1) AS STATUS   , * FROM TBL_PRE_BOLETO (NOLOCK) WHERE op_n_boleto = @NrBoleto
SELECT * FROM TBL_COL_PREBOLETO (NOLOCK) WHERE pre_n_boleto = @NrBoleto
/**/
	UPDATE	TBL_PRE_BOLETO 
	SET 
		/*			Fase 10			*/
			pre_boleto_status	= 0	     
			,OP_NATUREZA		= 0      
			,OP_TARIFA_OPERACAO = 0      
			,OP_PAG_RECEB		= 0      
			,OP_TX_OPERACAO		= 0      
			,Vlr_IOF			= 0
		/*			Fase 20			*/
			,OP_GRP_BANCARIOS	= 0      
			,OP_TIPO_LIQ		= 0      
			,OP_GRUPO1			= 0
			,OP_GRUPO2			= 0 
			,OP_GRUPO3			= 0 
		/*			Fase 40			*/
			,OP_ASSINADO = 'N'
	/*				Fase 5*/
			,APROVACAO_DOCUMENTOS = 'N' 
	WHERE 
			op_n_boleto			= @NrBoleto
			--AND id_cliente		= @id
	
	UPDATE TBL_COL_PREBOLETO 
	SET PRE_FASE_CONCLUIDO = 0 
	WHERE pre_n_boleto = @NrBoleto
		
	DELETE FROM TBL_COL_UPLOAD_ARQUIVOS WHERE NR_DOCTO = @NrBoleto and TIPO_OPERACAO = 'B'
	DELETE FROM TBL_COL_UPLOAD_ARQUIVOS WHERE NR_DOCTO = @NrBoleto and TIPO_OPERACAO = 'D'     
  /**/    
  
  
  /*
  
  op_val_reais
  
  
  
  DECLARE @NrBoleto INT = 2550199-- 2550218 
SELECT * FROM TBL_PRE_BOLETO WHERE op_n_boleto = @NrBoleto


	UPDATE TBL_PRE_BOLETO SET op_val_moeda = 20000.00, op_val_reais = 0 WHERE op_n_boleto = @NrBoleto

DECLARE @EMPRESA CHAR(1) = 'R', @ID_NATUREZA INT = 241
SELECT LTRIM(RTRIM(B.cod_pagador)) AS cod_pagador, B.id_motivo_envio, B.tipo_envio_Portal 
FROM TBL_Natureza_Motivo_Envio A WITH (NOLOCK)
		INNER JOIN TBL_Motivo_Envio B WITH (NOLOCK) 
			ON A.id_motivo_envio = B.id_motivo_envio 
WHERE A.portal_nat_empresa IN ('A', @EMPRESA) AND B.tipo_operacao = 'C' AND A.id_natureza = @ID_NATUREZA 
	AND B.HABILITA_PF=1 
SELECT * FROM TBL_Natureza (NOLOCK) WHERE ID_Natureza = @ID_Natureza	
  */
  
  SELECT TOP 10 * FROM LOG_DOC_SUCESSO ORDER BY 1 DESC