USE DBVAREJO

GO

DECLARE @Moeda VARCHAR(4) = 'EURO',
		@NrBoleto INT = NULL

IF OBJECT_ID('tempdb..#TBL_Results') IS NOT NULL
    DROP TABLE #TBL_Results


DECLARE @moe_tipo VARCHAR(1) = NULL

SELECT @moe_tipo = moe_tipo FROM TBL_MOEDAS (NOLOCK) WHERE moe_simbolo = @Moeda

SELECT b.op_n_boleto,  b.op_val_moeda, m.moe_simbolo, b.op_paridade--, m.moe_tipo
		, b.op_assinado, 
		CASE WHEN b.op_paridade > 1 OR m.moe_tipo = 'B' THEN
				b.op_val_moeda * b.op_paridade
		ELSE 
				b.op_val_moeda / b.op_paridade
		END ValorEmDolar
INTO #TBL_Results
FROM TBL_PRE_BOLETO b (NOLOCK) 
	INNER JOIN TBL_MOEDAS m (NOLOCK)
			ON b.op_tipo_moeda = m.moe_simbolo
WHERE b.sistema_origem = 'PC' 
AND b.op_data_inclusao > '20181116'
AND b.op_n_boleto = ISNULL(b.op_n_boleto, @NrBoleto)

DECLARE @limite DECIMAL(16,2) 
SELECT @limite = config_valor		
FROM DBO.TBL_CONFIGURACOES WITH(NOLOCK) WHERE config_tipo = 'ASSINATURA'

SELECT *, CASE /*WHEN t.ValorEmDolar > @limite AND op_assinado = 'D' THEN 'Excedeu o limite, necess�rio an�lise'*/
			WHEN t.ValorEmDolar < @limite AND op_assinado = 'D' THEN 'N�o excedeu o limite de assinatura, dispensado corretamente'
			/*WHEN op_assinado = 'P' THEN 'Possui procura��o'
			WHEN op_assinado = 'A' THEN 'Assinado'
			WHEN op_assinado = 'N' THEN 'Pendente de assinatura'*/
	ELSE '' END validacao
FROM #TBL_Results t
	
		

