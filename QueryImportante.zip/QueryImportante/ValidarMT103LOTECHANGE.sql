USE IK_VAREJO

GO

DECLARE @Arq	VARCHAR(20) = '27062019H'
,		@CdMsg	INT			= NULL		--2005
,		@IdSwift INT		= NULL
--SELECT * FROM TBL_LogRoboCCMESwift (NOLOCK) WHERE DtaLog > '20190624' ORDER BY 1 DESC

 
--SELECT m.IDSWIFT, m.ARQUIVO_ENTRADA, m.flaggoogle, m.id_cliente, m.status_lanc,m.STATUS_PREBOLETO, m.op_n_boleto, m.beneficiario, m.ordenante, m.id_lote,
-- 		mc.idSwift Change, m.data_registro, mc.numero, c.cl_status
--		INTO #tmp
--FROM tbl_meweb_MT103 m (NOLOCK)  
--	LEFT JOIN TBL_MEWEB_MT103_LOTE ml (NOLOCK)
--			ON m.id_Lote  = ml.Lote
--	LEFT JOIN TBL_MEWEB_MT103_CHANGE mc (NOLOCK)
--			ON m.idSwift = mc.idSwift
--	LEFT JOIN TBL_CLIENTES c (NOLOCK)
--			ON m.id_cliente = c.id_cliente
-- WHERE m.Arquivo_entrada like '%'+@Arq+'%' 
  

  /*    */
  
   SELECT flaggoogle, 
  CASE WHEN op_n_boleto IS NULL THEN 0 ELSE 1 END op_n_boleto, id_lote, 
  CASE WHEN Change IS NULL THEN 0 ELSE 1 END Change, cl_status, COUNT(1) qtd 
  FROM #tmp 
  GROUP BY flaggoogle, 
  CASE WHEN op_n_boleto IS NULL THEN 0 ELSE 1 END, id_lote, 
  CASE WHEN Change IS NULL THEN 0 ELSE 1 END, cl_status

  

  SELECT * FROM #tmp

  SELECT flaggoogle, 
  CASE WHEN op_n_boleto IS NULL THEN 0 ELSE 1 END op_n_boleto, COUNT(1) qtd
  FROM #tmp 
  GROUP BY flaggoogle, 
  CASE WHEN op_n_boleto IS NULL THEN 0 ELSE 1 END

  SELECT flaggoogle,  id_lote, COUNT(1) qtd 
  FROM #tmp 
  GROUP BY flaggoogle, 
  id_lote
  
  SELECT flaggoogle,   
  CASE WHEN Change IS NULL THEN 0 ELSE 1 END Change,  COUNT(1) qtd 
  FROM #tmp 
  GROUP BY flaggoogle,   
  CASE WHEN Change IS NULL THEN 0 ELSE 1 END
  
 SELECT flaggoogle,  cl_status, COUNT(1) qtd 
  FROM #tmp 
  GROUP BY flaggoogle,  cl_status

  

SELECT * FROM TBL_ME_LOG_LANC_CCMESWIFT (NOLOCK) WHERE ID_SWIFT IN(
	SELECT IDSWIFT
	FROM tbl_meweb_MT103 WITH(NOLOCK)  
	WHERE Arquivo_entrada like '%'+@Arq+'%' 
	AND CdMsg = ISNULL(@CdMsg, CdMsg)
	AND idSwift = ISNULL(@IdSwift, idSwift)
)
 
 --DROP TABLE #tmp

/*


select AprovadorSwiftCCME from tbl_users (nolock) where ur_username = 'thais.boas'

select AprovadorSwiftCCME, COUNT(1) qtd from tbl_users (nolock) group by AprovadorSwiftCCME

*/