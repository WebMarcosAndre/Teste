EXEC [SPBR_GRAVAR_MT103]
	@ACAO							= 'INSERIR'
	,	@HeaderOp						= '{1:F21RENDBRSPAXXX4484472426}{4:{177:1906181100}{451:0}}{1:F01RENDBRSPAXXX4484472426}{2:O1031000190618BOFAUS3NBXXX29905432651906181100N}{3:{108:1906180265785-03}{111:001}{121:52ed3e50-56b2-4a73-b9bb-5d5a7ee59930}}{4:'
	,	@M20_SenderRef                  = '2019061806265785'
	,	@O21_TransactionReference		= 'CRED'
	,	@M23B_BankOperCode              = NULL
	,	@O23E_InstructionCode           = NULL
	,	@M32A_VDateCurrencyInterbank    = '190618USD3672,9'
	,	@O33B_CurrencyInstructed		= 'USD3005,9'   
	,	@O36_ExchangeRate               = NULL
	,	@M50A_OrderingCustomer          = NULL
	,	@M50K_OrderingCustomer          = '/H10716000557
WEG INDUSTRIES INDIA PVT LTD
1 E-20 SIPCOT INDUSTRIAL COMPLEX HO
SUR 635109
'
	,	@O50F_AdditionalInformation     = NULL
	,	@O52A_OrderingInstitution       = 'BACXCZPP'
	,	@O52D_OrderingInstitution       = NULL
	,	@O53A_SenderCorrespondent       = NULL
	,	@M53B_SenderCorrespondent       = NULL
	,	@O54A_ReceiverCorrespondent     = 'BOFAUS3N'
	,	@O56A_IntermediaryInstitution   = NULL
	,	@O57A_AccountInstitution        = NULL
	,	@O57D_AccountInstitution        = NULL
	,	@O58D_BeneficiaryInstitution    = NULL
	,	@M59_BeneficiaryCustomer        = '/BR426890081000001046846470111
WR ASSESSORIA MARITIMA EIRELLI - ME
WALMER RODRIGUES
ONZE DE JUNHO, 212 COMPLEMENTO 43A.
11320160 ITARARE
'
	,	@O70_RemittanceInformation      = 'INV. 08' 
	,	@M71A_DetailsOfCharges          = 'SHA'
	,	@O71F_SenderCharges             = 'USD32, :71F:USD0, 	@O71G_ReceiverCharges           '
	,	@O72_SenderToReceiverInf        = NULL
	,	@O54D_ReceiverCorrespondent		= NULL
	,	@M53D_SenderCorrespondent       = NULL 
	,	@TrailerOp						= N'-}{5:{MAC:00000000}{CHK:F95BB7175A4A}}{S:{SAC:}{COP:S}}'	
	,	@id_user                        = 216
	,	@data_registro                  ='20190628'
	,	@Arquivo_entrada                = 'teste.txt'
	,	@FlagGoogle						= 1
	,	@O26T_TransactionTypeCode		= NULL
	,	@new_identity					= 0

	--SELECT * FROM TBL_USERS (NOLOCK) WHERE ID_USER = 216
	--SELECT * FROM TBL_USERS (NOLOCK) WHERE ur_nome LIKE '%teste%'


	--372592
SELECT TOP 30
IDSWIFT,
O53A_SenderCorrespondent, 
O54A_ReceiverCorrespondent,
O33B_CurrencyInstructed,
M50K_ORDERINGCUSTOMER,O50F_ADDITIONALINFORMATION,M50A_ORDERINGCUSTOMER,
ORDENANTE,
M59_BENEFICIARYCUSTOMER,
[DBO].[MT103_FORMATA_BENEFICIARIO] (M59_BENEFICIARYCUSTOMER),
BENEFICIARIO
FROM TBL_MEWEB_MT103 (NOLOCK) 
ORDER BY IDSWIFT DESC



--SELECT	 ISNULL(tr_ord_bco_Correspondente,''), 
--			 ISNULL(tr_ord_Moeda,0) ,
--			 ISNULL(tr_ord_vlr_Inicial,0) ,
--			 ISNULL(tr_ord_vlr_Final,0) 
--	FROM	TBL_ME_TARIFAS WITH(NOLOCK)

--UPDATE TBL_ME_TARIFAS SET tr_ord_bco_Correspondente= 'BOFAUS3M', tr_ord_Moeda = 'USD', tr_ord_vlr_Inicial = 0, tr_ord_vlr_Final = 3000.00
