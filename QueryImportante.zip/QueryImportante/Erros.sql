USE IK_VAREJO
GO

DECLARE @data DATETIME = '20180718 11:00',
		@desMetodo VARCHAR(50) = 'EnviarEmailGoogleManual',
		@boleto INT = 2864526
		SELECT * FROM dbCorpLoginUnico.dbo.Usuario (NOLOCK) WHERE login  = '45927863191'
SELECT TOP 1000 * 
FROM TBL_LogRoboCCMESwift (NOLOCK) 
WHERE DtaLog  > @data 
		 --BETWEEN '20180101' AND		'20180609'
 	--AND DesMetodo LIKE '%Google%' /*DesMetodo = ISNULL(@desMetodo, DesMetodo)*/
	--AND DesLog LIKE '%Erro%'
	AND TpoLog = 'E'
ORDER BY DtaLog DESC


SPBR_BuscarLayoutMT103 @acao = 'LISTAR'


Erro ao Enviar E-mail: Resposta=3968396 Msg: Could not find stored procedure ''. -    at System.Data.SqlClient.SqlConnection.OnError(SqlException exception, Boolean breakConnection, Action`1 wrapCloseInAction)     at System.Data.SqlClient.TdsParser.ThrowExceptionAndWarning(TdsParserStateObject stateObj, Boolean callerHasConnectionLock, Boolean asyncClose)     at System.Data.SqlClient.TdsParser.TryRun(RunBehavior runBehavior, SqlCommand cmdHandler, SqlDataReader dataStream, BulkCopySimpleResultSe
SELECT TOP 100 * 
FROM EMAIL_SERVICE.dbo.TBL_EMAIL_Historico (NOLOCK) 
WHERE data_email > @data AND 
corpo_email LIKE '%Google%' 
ORDER BY data_email DESC

return

SELECT TOP 1000 * 
FROM EMAIL_SERVICE.dbo.TBL_EMAIL (NOLOCK) 
WHERE data_email > @data 
ORDER BY data_email DESC

TBL_COL_LOG_ERROS
sp_helptext SPBCCME_Criar_Sessao

--SELECT TOP 1000 * FROM TBL_MEWEB_ERROS (NOLOCK) 
--WHERE error_date > @data 
--ORDER BY error_date DESC

SELECT TOP 1000 * FROM TBL_CRM (NOLOCK)
WHERE crm_data > @data
	AND crm_nboleto = ISNULL(@boleto, crm_nboleto)
	
	
	TBL_COL_LOG_ERROS
	--Erro ao Enviar E-mail: Resposta=N�o foi possivel enviar o email  boleto:2863976
	
	
use ik_varejo

go

select *
from   TBL_LogRoboCCMESwift a with (nolock)
where  dtalog>= '06/12/2018'
 and DesLog LIKE '%erro%'
order by a.dtalog desc

SELECT TOP 10 * FROM IK_VAREJO.dbo.TBL_MEWEB_MT103 (NOLOCK) ORDER BY data_registro DESC