SELECT pre_n_boleto,id_cliente, pre_data_prevEmbarque,pre_cod_mod_imp,pre_disp_LI 
FROM TBL_COL_PREBOLETO (NOLOCK) 
WHERE pre_n_boleto IN(
3384646 , 3278855
)
SELECT pre_n_boleto, id_cliente, pre_data_prevEmbarque,pre_cod_mod_imp,pre_disp_LI 
FROM TBL_COL_PREBOLETO (NOLOCK) 
WHERE pre_n_boleto IN(
3380074 , 3381040
)

SELECT TOP 10 * FROM TBL_COL_IMP_LI (NOLOCK) WHERE op_n_boleto IN(
3384646 , 3278855,
3380074 , 3381040
)
--SELECT TOP 10 * FROM TBL_COL_IMP_DI (NOLOCK) WHERE op_n_boleto IN(
--3384646 , 3278855,
--3380074 , 3381040
--)
--SELECT TOP 10 * FROM TBL_COL_IMP_COEMB (NOLOCK) WHERE op_n_boleto IN(
--3384646 , 3278855,
--3380074 , 3381040
--)

SELECT op_n_boleto, outras_especificacoes, op_natureza, op_data_inclusao , ID_CLIENTE
FROM TBL_PRE_BOLETO (NOLOCK) WHERE op_n_boleto IN(
3384646 , 3278855,
3380074 , 3381040
)


SELECT B.LI_OPERA_IMPORTACAO, A.CODMODIMP  , B.li_doc, B.LI_IDCLIENTE
From TBL_LOGIN_MOD_IMP A, TBL_LOGIN_INTEGRADO B 
WHERE A.LI_ID = B.LI_ID /*AND A.LI_DOC IN(
	'11502765000146',	'09637852000169',	'17072799000124',	'14930555000147'
)*/
AND B.LI_IDCLIENTE IN (
127267, 90342, 
277615, 342552
)

SELECT * FROM TBL_PRE_BOLETO (NOLOCK) WHERE op_n_boleto IN (
2887430, -- Com dispensa
2887431 -- Sem dispensa
)

SELECT LI_TIPOCLIENTE, LI_IDCLIENTE, * FROM TBL_LOGIN_INTEGRADO (NOLOCK) WHERE LI_IDCLIENTE IN(
127267,
90342,
277615,
342552
)




SELECT B.LI_OPERA_IMPORTACAO, A.CODMODIMP  , B.li_doc
From TBL_LOGIN_MOD_IMP A, TBL_LOGIN_INTEGRADO B 
WHERE A.LI_ID = B.LI_ID AND A.LI_DOC IN(
	'11502765000146',	'09637852000169',	'17072799000124',	'14930555000147'
)


SELECT TOP 10 B.LI_OPERA_IMPORTACAO, A.CODMODIMP  , B.li_doc, a.li_doc, b.LI_IDCLIENTE, b.li_dtinclusao, b.li_dtalteracao
FROM TBL_LOGIN_INTEGRADO B 
		LEFT JOIN TBL_LOGIN_MOD_IMP A 
				ON b.li_id = a.li_id
WHERE 
 b.LI_DOC IN(
	'11502765000146',	'09637852000169',	'17072799000124',	'14930555000147'
)
ORDER BY B.li_dtinclusao DESC



SELECT TOP 10 * FROM TBL_LOGIN_INTEGRADO_LOG (NOLOCK) WHERE LI_DOC = '17072799000124'





SELECT B.LI_OPERA_IMPORTACAO, A.CODMODIMP  , B.li_doc, a.li_doc, b.LI_IDCLIENTE, b.li_dtinclusao, b.li_dtalteracao
FROM TBL_LOGIN_INTEGRADO B 
		LEFT JOIN TBL_LOGIN_MOD_IMP A 
				ON b.li_id = a.li_id
WHERE a.li_id IS NULL AND B.LI_OPERA_IMPORTACAO = 'S'
ORDER BY B.li_dtinclusao DESC













	USE IK_VAREJO
	GO                         

	SELECT TOP 2000 b.op_data_inclusao, l.li_dtinclusao, l.li_dtalteracao, l.li_doc , c.cl_num_doc, b.op_val_moeda, b.op_val_reais, l.li_nome, c.cl_razao_social
	FROM TBL_PRE_BOLETO b (NOLOCK)
		INNER JOIN TBL_LOGIN_INTEGRADO l (NOLOCK)
				ON b.id_cliente = l.LI_IDCLIENTE
		INNER JOIN TBL_CLIENTES c (NOLOCK)
				ON l.li_idcliente = c.id_cliente
	WHERE b.op_natureza = 233 
			AND l.LI_OPERA_IMPORTACAO = 'S'
			AND l.li_id NOT IN 
			(
				SELECT li_id FROM TBL_LOGIN_MOD_IMP (NOLOCK)
			)
	ORDER BY l.li_dtinclusao DESC, b.id_operacao DESC

	


	USE DBVAREJO
	GO                         

	SELECT TOP 2000 b.op_data_inclusao, l.li_dtinclusao, l.li_dtalteracao, l.li_doc , c.cl_num_doc, b.op_val_moeda, b.op_val_reais, l.li_nome, c.cl_razao_social
	FROM TBL_PRE_BOLETO b (NOLOCK)
		INNER JOIN TBL_LOGIN_INTEGRADO l (NOLOCK)
				ON b.id_cliente = l.LI_IDCLIENTE
		INNER JOIN TBL_CLIENTES c (NOLOCK)
				ON l.li_idcliente = c.id_cliente
	WHERE b.op_natureza = 233 
			AND l.LI_OPERA_IMPORTACAO = 'S'
			AND l.li_id NOT IN 
			(
				SELECT li_id FROM TBL_LOGIN_MOD_IMP (NOLOCK)
			)
	ORDER BY l.li_dtinclusao DESC, b.id_operacao DESC






USE IK_VAREJO
GO

SELECT TOP 2000  l.li_dtinclusao, l.li_dtalteracao, l.li_doc , c.cl_num_doc, l.li_nome, c.cl_razao_social
	FROM TBL_LOGIN_INTEGRADO l (NOLOCK)				
		INNER JOIN TBL_CLIENTES c (NOLOCK)
				ON l.li_idcliente = c.id_cliente
	WHERE l.LI_OPERA_IMPORTACAO = 'S'
			AND l.li_id NOT IN 
			(
				SELECT li_id FROM TBL_LOGIN_MOD_IMP (NOLOCK)
			)
	ORDER BY l.li_dtinclusao DESC


USE DBVAREJO
GO

SELECT TOP 2000  l.li_dtinclusao, l.li_dtalteracao, l.li_doc , c.cl_num_doc, l.li_nome, c.cl_razao_social
	FROM TBL_LOGIN_INTEGRADO l (NOLOCK)				
		INNER JOIN TBL_CLIENTES c (NOLOCK)
				ON l.li_idcliente = c.id_cliente
	WHERE l.LI_OPERA_IMPORTACAO = 'S'
			AND l.li_id NOT IN 
			(
				SELECT li_id FROM TBL_LOGIN_MOD_IMP (NOLOCK)
			)
	ORDER BY l.li_dtinclusao DESC



















SELECT 
li_doc, data_inclusao, li_dtinclusao, 
li_dtalteracao, li_opera_importacao
FROM TBL_LOGIN_INTEGRADO_LOG (NOLOCK) 
WHERE li_doc IN 
(
			SELECT TOP 1000  c.cl_num_doc
			FROM TBL_PRE_BOLETO b (NOLOCK)
				INNER JOIN TBL_LOGIN_INTEGRADO l (NOLOCK)
						ON b.id_cliente = l.LI_IDCLIENTE
				INNER JOIN TBL_CLIENTES c (NOLOCK)
						ON l.li_idcliente = c.id_cliente
			WHERE b.op_natureza = 233 
					AND l.LI_OPERA_IMPORTACAO = 'S'
					AND l.li_id NOT IN 
					(
							SELECT li_id FROM TBL_LOGIN_MOD_IMP (NOLOCK)
					)
			GROUP BY c.cl_num_doc
) ORDER BY li_doc, data_inclusao






