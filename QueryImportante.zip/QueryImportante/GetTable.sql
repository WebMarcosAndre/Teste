DECLARE		@database		VARCHAR(200)	=	NULL
		,	@table			VARCHAR(200)	=	NULL
		,	@column			VARCHAR(200)	=	'id_cliente'
		,	@isPrimaryKey	VARCHAR(1)		=	NULL
		,	@isIdentity		VARCHAR(1)		=	NULL


DECLARE cursor_database CURSOR FOR 
	SELECT TOP 10 name, @table, @column FROM master.dbo.sysdatabases WHERE name = ISNULL( @database,name)
OPEN cursor_database
FETCH NEXT FROM cursor_database
INTO @database, @table, @column

WHILE @@FETCH_STATUS = 0
BEGIN
	DECLARE @cabecalho VARCHAR(200) =' SELECT '''
								+ISNULL(@database,'NULL')+''' AS base	,'''
								+ISNULL(@table,'NULL')+'''	AS tabela, '''
								+ISNULL(@column,'NULL')+''' AS 	coluna
								'
	DECLARE @query VARCHAR(MAX) =
		'IF EXISTS (
			SELECT '''+@database+''' DATABASE_NAME , t.TABLE_NAME, c.COLUMN_NAME , 
					ISNULL(OBJECTPROPERTY(OBJECT_ID(CONSTRAINT_SCHEMA + ''.'' + QUOTENAME(CONSTRAINT_NAME)), ''IsPrimaryKey''),''0'') IsPrimaryKey	,
					ISNULL(COLUMNPROPERTY(OBJECT_ID(sc.TABLE_SCHEMA + ''.'' + sc.TABLE_NAME), sc.COLUMN_NAME, ''IsIdentity''),''0'') IsIdentity			
			FROM	'+@database+'.INFORMATION_SCHEMA.TABLES t
				INNER JOIN '+@database+'.INFORMATION_SCHEMA.COLUMNS c
						ON t.TABLE_NAME = c.TABLE_NAME	AND t.TABLE_CATALOG = c.TABLE_CATALOG
				LEFT JOIN INFORMATION_SCHEMA.COLUMNS sc
						ON		t.TABLE_NAME	= sc.TABLE_NAME			COLLATE Latin1_General_CI_AS	
							AND t.TABLE_CATALOG = sc.TABLE_CATALOG		COLLATE Latin1_General_CI_AS
							AND c.COLUMN_NAME	= sc.COLUMN_NAME		COLLATE Latin1_General_CI_AS
				LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE scu
						ON		t.TABLE_NAME	= scu.TABLE_NAME			COLLATE Latin1_General_CI_AS	
							AND t.TABLE_CATALOG = scu.TABLE_CATALOG		COLLATE Latin1_General_CI_AS
							AND c.COLUMN_NAME	= scu.COLUMN_NAME			COLLATE	Latin1_General_CI_AS
			WHERE t.TABLE_TYPE =''BASE TABLE'''
		+	CASE WHEN @isPrimaryKey IS NOT NULL THEN 
				' AND OBJECTPROPERTY(OBJECT_ID(CONSTRAINT_SCHEMA + ''.'' + QUOTENAME(CONSTRAINT_NAME)), ''IsPrimaryKey'') =	'''+@isPrimaryKey +''''
				ELSE '' END
		+	CASE WHEN @isIdentity IS NOT NULL THEN 
				' AND COLUMNPROPERTY(OBJECT_ID(sc.TABLE_SCHEMA + ''.'' + sc.TABLE_NAME), sc.COLUMN_NAME, ''IsIdentity'')=	'''+@isIdentity +''''
				ELSE '' END
		+	CASE WHEN @table IS NOT NULL THEN ' AND t.TABLE_NAME LIKE ''%'+@table+'%''' ELSE '' END 
		+	CASE WHEN @column IS NOT NULL THEN ' AND c.COLUMN_NAME LIKE ''%'+@column+'%''' ELSE '' END
		+' )
		'
		
		SET @query = 	@query	+ 'BEGIN
		
		'	+	@cabecalho	+	SUBSTRING(@query,16, LEN(@query)-20)	+'	END	
		
		'
		
		EXEC(@query)
	
		
	FETCH NEXT FROM cursor_database INTO @database  , @table, @column
END   
CLOSE cursor_database
DEALLOCATE cursor_database

