-- USE IK_VAREJO GO sp_helptext SPBCCME_MEWEB_MT103_LANCAMENTO


USE IK_VAREJO
GO


/***
	Nome: SPBCCME_MEWEB_MT103_LANCAMENTO
	Desc: 
	Autor: 
	Data:  
	***********************
	Hist�rico de Altera��es
	***********************
	PR								Date		Autor				Description
	SPBCCME_MEWEB_MT103_LANCAMENTO	10/01/2019	Cidicley Rodrigues  Na a��o GERAR_LANCAMENTOS, incluido o campo CL_STATUS
	SPBCCME_MEWEB_MT103_LANCAMENTO	20/03/2019	Cidicley Rodrigues  No GERAR_PRE_BOLETO, Inativa��o de clientes google que n�o recebem ordens pelo BOFA. Quando o cliente Google receber uma ordem por um banco diferente do BOFA, o sistema deve inativar o cliente
 para que o pagamento n�o seja efetuado.
***/

 DROP TABLE #TBL_TEMP                  
  DECLARE
--ALTER PROCEDURE [dbo].[SPBCCME_MEWEB_MT103_LANCAMENTO]     
--(                    
@Arq VARCHAR(20) =   NULL,                            
 @ACAO VARCHAR(30) = 'FILTRAR',                                                        
 @DATAINICIAL DATETIME = '20190626',                                                        
 @DATAFINAL DATETIME ='20190627',                                                    
 @EMPRESA VARCHAR(100) = 'TODAS',                                                        
 @PERIODO VARCHAR(30) = 'DataCredito' ,                                                    
 @CLIENTE VARCHAR(300) = '',                                                  
 @BENEFICIARIO VARCHAR(300) = NULL,                                                  
 @ORDENANTE VARCHAR(300) = NULL,                                                     
 @IDCLIENTE INT = NULL,                                                    
 @IDUSUARIO INT = NULL,                                                    
 @IDASSOCIACAO INT = NULL,                                                    
 @IDSWIFT INT = NULL,                                                    
 @TIPOLANCAMENTO NCHAR(30) = 'Todos',                                                    
 @PROCESSADO INT = NULL, -- Valor Null ou 1                                                    
 @EMPROCESSAMENTO INT = NULL,-- Valor Null ou 0                                                    
 @ERRO INT = NULL, -- Valor Null ou 2,                                         
 @RECUSADO INT = NULL, -- Valor Null ou 3                                        
 @APROVADO INT = NULL, -- Valor Null ou 4                                              
 @NAOPROCESSADO INT = NULL, -- Valor Null ou 5,                    
 @BAIXADOS INT = NULL, -- Valor Null ou 7                                 
 @LANCADOCHANGE VARCHAR(30) = 'SIM',   
 @UR_USERNAME VARCHAR(30) = NULL,   
 @FLAG_GOOGLE BIT = NULL, 
 @MENSAGEMLOGLANCAMENTO VARCHAR(500) = NULL
 --,                                                  
 --@IDASSOCIACAORETORNO INT = NULL OUTPUT                                
--)                                                        
--AS         
DECLARE @1IDCLIENTE_NAO_IDENTIFICADO INT = (SELECT TOP 1 ID_CLIENTE FROM TBL_ROBOCCMESWIFT WHERE NomRobo = 'ROBO_CCME_SWIFT')                                                       
     
 DECLARE     
@1ACAO VARCHAR(30),                                                        
 @1DATAINICIAL DATETIME,                                                        
 @1DATAFINAL DATETIME ,                                                        
 @1EMPRESA VARCHAR(100) ,                                                        
 @1PERIODO VARCHAR(30) ,                                                    
 @1CLIENTE VARCHAR(300),                                                  
 @1BENEFICIARIO VARCHAR(300) ,                                                  
 @1ORDENANTE VARCHAR(300) ,                                                     
 @1IDCLIENTE INT ,                                                    
 @1IDUSUARIO INT ,                                                    
 @1IDASSOCIACAO INT ,                                                    
 @1IDSWIFT INT,                                                    
 @1TIPOLANCAMENTO NCHAR(30) ,                                                    
 @1PROCESSADO INT, -- Valor Null ou 1                                                    
 @1EMPROCESSAMENTO INT ,-- Valor Null ou 0                                                    
 @1ERRO INT , -- Valor Null ou 2,                                         
 @1RECUSADO INT , -- Valor Null ou 3                                        
 @1APROVADO INT , -- Valor Null ou 4                                              
 @1NAOPROCESSADO INT , -- Valor Null ou 5,                    
 @1BAIXADOS INT , -- Valor Null ou 7                                 
 @1LANCADOCHANGE VARCHAR(30) ,   
 @1UR_USERNAME VARCHAR(30) ,   
 @1MENSAGEMLOGLANCAMENTO VARCHAR(500) ,                                                  
 @1IDASSOCIACAORETORNO INT      
        
 SELECT   
 @1ACAO =@ACAO,                                                        
 @1DATAINICIAL =@DATAINICIAL,                                                        
 @1DATAFINAL= @DATAFINAL,                                                        
 @1EMPRESA=@EMPRESA,                                                        
 @1PERIODO =@PERIODO,                                                    
 @1CLIENTE =@CLIENTE,                                                  
 @1BENEFICIARIO =@BENEFICIARIO,                                                  
 @1ORDENANTE =@ORDENANTE,                                                     
 @1IDCLIENTE =@IDCLIENTE,                                                    
 @1IDUSUARIO =@IDUSUARIO,                                                    
 @1IDASSOCIACAO =@IDASSOCIACAO,                                                    
 @1IDSWIFT =@IDSWIFT,                                                    
 @1TIPOLANCAMENTO = @TIPOLANCAMENTO,                                                    
 @1PROCESSADO = @PROCESSADO, -- Valor Null ou 1                                                    
 @1EMPROCESSAMENTO = @EMPROCESSAMENTO,-- Valor Null ou 0                                                    
 @1ERRO = @ERRO, -- Valor Null ou 2,                                         
 @1RECUSADO = @RECUSADO, -- Valor Null ou 3                                        
 @1APROVADO = @APROVADO, -- Valor Null ou 4                                              
 @1NAOPROCESSADO = @NAOPROCESSADO, -- Valor Null ou 5,                    
 @1BAIXADOS = @BAIXADOS, -- Valor Null ou 7                                 
 @1LANCADOCHANGE = @LANCADOCHANGE,   
 @1UR_USERNAME = @UR_USERNAME,   
 @1MENSAGEMLOGLANCAMENTO = @MENSAGEMLOGLANCAMENTO
 --,                                                  
 --@1IDASSOCIACAORETORNO = @IDASSOCIACAORETORNO           
        
DECLARE @FLAG_HABILITA_TELAS_CCME CHAR(1) = NULL

SELECT TOP 1 @FLAG_HABILITA_TELAS_CCME = FLAG_HABILITA_TELAS_CCME FROM TBL_ROBOCCMESWIFT with (nolock)
      
      

  
  
	SELECT         
			IDSWIFT ,        
			M59_BENEFICIARYCUSTOMER ,        
			M50K_ORDERINGCUSTOMER ,        
			O50F_ADDITIONALINFORMATION ,        
			M50A_ORDERINGCUSTOMER ,        
			M.ID_CLIENTE,        
			M20_SENDERREF ,        
			M32A_VDATECURRENCYINTERBANK,        
			DATALOTE   ,         
			DATA_LANCAMENTO_ROBO ,        
			STATUS_LANC,        
			DATA_LANCAMENTO ,         
			L.Empresa,         
			DATA_REGISTRO ,       
			ID_LANC,        
			LC_AUTOMATICO,       
			OP_N_BOLETO,        
			STATUS_PREBOLETO,        
			SC.id_sub_conta  AS ID_SUBCONTA  ,  
			m.beneficiario,  
			m.ordenante,  
			NULL AS id_associado,
			FlagGoogle  
			INTO #TBL_TEMP        
	FROM	[IK_VAREJO].[DBO].[TBL_MEWEB_MT103] AS M WITH(NOLOCK)         
		JOIN		[IK_VAREJO].[DBO].[TBL_MEWEB_MT103_LOTE] AS L WITH(NOLOCK) ON M.ID_LOTE = L.LOTE         
		LEFT JOIN	TBL_ME_SUBCONTA SC  WITH(NOLOCK) 
				ON M.ID_CLIENTE = SC.ID_CLIENTE 
						AND SC.SUB_STATUS <> 'I' 
						AND SC.cod_moeda = 
						(
							CASE SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)        
								WHEN 'EUR' THEN 'EURO'             
								WHEN 'GBP' THEN 'STG'     
								WHEN 'AUD' THEN 'ATD'     
								WHEN 'CAD' THEN 'CAN'            
								WHEN 'JPY' THEN 'YEN'      
								ELSE SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)         
								END
						)        
	                            
	WHERE (Arquivo_entrada LIKE '%'+@Arq+'%' OR @Arq IS NULL )AND
	(
		FLAGGOOGLE = 0  OR (
								FLAGGOOGLE = 1 
								AND @FLAG_HABILITA_TELAS_CCME = 'S'
								-- VIRADA CHAVE GERAL
								AND m.id_cliente IS NOT NULL
								AND m.OP_N_BOLETO IS NULL
							)
	)               
 AND(                                            
(@1PROCESSADO IS NULL AND @1EMPROCESSAMENTO IS NULL AND @1ERRO IS NULL AND @1NAOPROCESSADO IS NULL AND @1RECUSADO IS NULL AND @1APROVADO IS NULL AND @1BAIXADOS IS NULL) OR                                            
  @1PROCESSADO = STATUS_LANC OR                        
@1EMPROCESSAMENTO = STATUS_LANC OR                                             
  @1ERRO = STATUS_LANC OR                                          
  @1APROVADO = STATUS_LANC OR                                        
  @1RECUSADO = STATUS_LANC OR                         
  @1BAIXADOS = STATUS_LANC OR             
 (@1NAOPROCESSADO = 5 AND STATUS_LANC IS NULL))          
  AND (LEN(@1EMPRESA) = 0 OR ISNULL(@1EMPRESA,'TODAS') = 'TODAS' OR L.Empresa = @1EMPRESA)                                                    
  AND (ISNULL(@1TIPOLANCAMENTO,'TODOS') = 'TODOS' OR (@1TIPOLANCAMENTO = TIPO_LANC OR TIPO_LANC = 'AMBOS'))         
  AND (                                     
    (@1PERIODO = 'DATACREDITO' AND CONVERT(DATE,SUBSTRING(M32A_VDATECURRENCYINTERBANK,1,6),101) BETWEEN CONVERT(DATE,@1DATAINICIAL,101) AND CONVERT(DATE,@1DATAFINAL,101)) OR                                            
    (@1PERIODO = 'DATAREGISTRO' AND CONVERT(DATE,DATA_REGISTRO,101) BETWEEN CONVERT(DATE,@1DATAINICIAL,101) AND CONVERT(DATE,@1DATAFINAL,101)) OR                                     
    (@1PERIODO = 'DATALANCAMENTO' AND CONVERT(DATE,DATA_LANCAMENTO,101) BETWEEN CONVERT(DATE,@1DATAINICIAL,101) AND CONVERT(DATE,@1DATAFINAL,101))                                                        
  )           
        

        
    update   M  
   set       id_associado = a.id  
   from             #TBL_TEMP m  
   join             [TBL_MEWEB_ASSOCIA_CLIENTES] AS A WITH(NOLOCK)  
   on  m.Beneficiario = [DBO].[FULL_TRIM](A.BENEFICIARIO_SWIFT)   
    AND        m.ordenante = [DBO].[FULL_TRIM](A.ORDENANTE_SWIFT)       
      
	  
	  SELECT * FROM #TBL_TEMP
	      
IF @1PERIODO <> 'DATAASSOCIACAO'        
  BEGIN         
  SELECT DISTINCT                             
  (CASE WHEN A.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END) AS CLIENTE_ASSOCIADO,                                                  
  A.ID_CLIENTE AS ID_CLIENTE_ASSOCIADO,                                                      
  (CASE WHEN S.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END ) AS CLIENTE_SUGESTAO,                                                   
  S.ID_CLIENTE AS ID_CLIENTE_SUGESTAO,                                      
  ltrim(rtrim((CASE WHEN M.ID_CLIENTE IS NOT NULL THEN  ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END))) AS CLIENTE_LANCAMENTO,                                                
  M.ID_CLIENTE AS ID_CLIENTE_LANCAMENTO,                                                   
  A.ID, A.DATAASSOCIA,CONVERT(DATE,SUBSTRING(M32A_VDATECURRENCYINTERBANK,1,6),101) AS DATACREDITO,                                                   
  M.DATA_LANCAMENTO_ROBO,M.STATUS_LANC,M.ID_CLIENTE, M.DATA_LANCAMENTO, M.EMPRESA, M.DATA_REGISTRO,M.IDSWIFT,M.LC_AUTOMATICO,                                                    
  m.BENEFICIARIO AS BENEFICIARIO,                                                       
  m.ordenante as ORDENANTE,      
  (SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,10,15) +' / '+SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)) AS VALOR_MOEDA,   
  ([IK_VAREJO].[dbo].[CALCULA_MOEDA](SUBSTRING(M32A_VDateCurrencyInterbank,7,3),LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(SUBSTRING(M32A_VDateCurrencyInterbank,10,15),CHAR(13),''),CHAR(10),''),',','.'))))) AS VALOR_USD,                                         
 


 
   
  
  
          
  CA.NUMERO AS NUMERO,LO.DATAMSG, LO.CDMSG, M.DATALOTE,M.OP_N_BOLETO,M.STATUS_PREBOLETO,M.ID_SUBCONTA,C.PreBoletoCompraAutomatico, M.ID_LANC,        
  (CASE         
   WHEN M.ID_SUBCONTA IS NOT NULL THEN 2        
   WHEN M.ID_CLIENTE = @1IDCLIENTE_NAO_IDENTIFICADO THEN 1        
 ELSE 0        
  END) AS CONTA_CLIENTE,
  M.FlagGoogle 
FROM             #TBL_TEMP M          
 LEFT JOIN [IK_VAREJO].[DBO].[TBL_MEWEB_ASSOCIA_CLIENTES] AS A WITH(NOLOCK) ON (                   
 m.id_associado = a.id)      
  LEFT JOIN [DBO].[TBL_MEWEB_MT103_SUGEST] AS S WITH(NOLOCK) ON M.IDSWIFT = S.IDSWIFT        
  LEFT JOIN TBL_CLIENTES AS C WITH(NOLOCK) ON C.ID_CLIENTE =  (CASE                       
                  WHEN M.ID_CLIENTE IS NOT NULL THEN M.ID_CLIENTE                      
  WHEN A.ID_CLIENTE IS NOT NULL THEN A.ID_CLIENTE        
                  WHEN S.ID_CLIENTE IS NOT NULL THEN S.ID_CLIENTE                      
ELSE NULL                      
           END)                          
  LEFT JOIN(SELECT IDSWIFT, MAX(NUMERO) AS NUMERO FROM TBL_MEWEB_MT103_CHANGE WITH(NOLOCK) GROUP BY IDSWIFT) AS CA ON M.IDSWIFT = CA.IDSWIFT        
  LEFT JOIN( SELECT B.ID_SWIFT, B.CDMSG, C.DATAMSG               
  FROM TBL_ME_LOG_LANC_CCMESWIFT  B WITH(NOLOCK) INNER JOIN               
  (SELECT ID_SWIFT, MAX(DATAMSG) AS DATAMSG              
  FROM TBL_ME_LOG_LANC_CCMESWIFT  WITH(NOLOCK)               
  WHERE CDMSG IN ('2000','2001')              
  GROUP BY ID_SWIFT) AS C         
  ON B.ID_SWIFT = C.ID_SWIFT  AND B.DATAMSG = C.DATAMSG) AS LO ON M.IDSWIFT = LO.ID_SWIFT          
  WHERE         
  (         
   (@1CLIENTE IS NULL OR LEN(@1CLIENTE) = 0) OR                                                      
   [DBO].[MT103_FORMATA_ORDENANTE] (M.M50K_ORDERINGCUSTOMER,M.O50F_ADDITIONALINFORMATION,M.M50A_ORDERINGCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR                                                    
   [DBO].[MT103_FORMATA_BENEFICIARIO] (M59_BENEFICIARYCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR         
   ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) LIKE '%' + @1CLIENTE +'%' OR        
   CONVERT(VARCHAR,M.OP_N_BOLETO) LIKE @1CLIENTE +'%'        
  )        
  AND (@1LANCADOCHANGE = 'TODOS' OR (ISNULL(@1LANCADOCHANGE,'SIM') = 'SIM' AND CA.NUMERO IS NOT NULL) OR (@1LANCADOCHANGE = 'NAO' AND CA.NUMERO IS NULL))         
        
 END        
         
 ELSE        
 BEGIN        
   SELECT DISTINCT                             
   (CASE WHEN A.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END) AS CLIENTE_ASSOCIADO,                                                  
   A.ID_CLIENTE AS ID_CLIENTE_ASSOCIADO,                                                      
   (CASE WHEN S.ID_CLIENTE IS NOT NULL THEN ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END ) AS CLIENTE_SUGESTAO,                                                   
   S.ID_CLIENTE AS ID_CLIENTE_SUGESTAO,                                      
   LTRIM(RTRIM((CASE WHEN M.ID_CLIENTE IS NOT NULL THEN  ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) +' - '+ C.CL_NUM_DOC ELSE NULL END))) AS CLIENTE_LANCAMENTO,                                                
   M.ID_CLIENTE AS ID_CLIENTE_LANCAMENTO,                                                   
   A.ID, A.DATAASSOCIA,CONVERT(DATE,SUBSTRING(M32A_VDATECURRENCYINTERBANK,1,6),101) AS DATACREDITO,                                                   
   M.DATA_LANCAMENTO_ROBO,M.STATUS_LANC,M.ID_CLIENTE, M.DATA_LANCAMENTO, M.EMPRESA, M.DATA_REGISTRO,M.IDSWIFT,M.LC_AUTOMATICO,                                                    
    m.BENEFICIARIO AS BENEFICIARIO,                                                        
  m.ordenante as ORDENANTE,      
   (SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,10,15) +' / '+SUBSTRING(M.M32A_VDATECURRENCYINTERBANK,7,3)) AS VALOR_MOEDA,  
   ([IK_VAREJO].[dbo].[CALCULA_MOEDA](SUBSTRING(M32A_VDateCurrencyInterbank,7,3),LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(SUBSTRING(M32A_VDateCurrencyInterbank,10,15),CHAR(13),''),CHAR(10),''),',','.'))))) AS VALOR_USD,                  
   CA.NUMERO AS NUMERO,LO.DATAMSG, LO.CDMSG, M.DATALOTE,M.OP_N_BOLETO,M.STATUS_PREBOLETO,M.ID_SUBCONTA,C.PreBoletoCompraAutomatico, M.ID_LANC,     
   (CASE         
WHEN M.ID_SUBCONTA IS NOT NULL THEN 2        
    WHEN M.ID_CLIENTE = @1IDCLIENTE_NAO_IDENTIFICADO THEN 1        
    ELSE 0        
   END) AS CONTA_CLIENTE,
   M.FlagGoogle          
   FROM  #TBL_TEMP  M      
 LEFT JOIN [IK_VAREJO].[DBO].[TBL_MEWEB_ASSOCIA_CLIENTES] AS A WITH(NOLOCK) ON (                   
 m.id_associado = a.id)      
   LEFT JOIN [DBO].[TBL_MEWEB_MT103_SUGEST] AS S WITH(NOLOCK) ON M.IDSWIFT = S.IDSWIFT                                                    
   LEFT JOIN TBL_CLIENTES AS C WITH(NOLOCK) ON C.ID_CLIENTE =  (CASE               
                   WHEN M.ID_CLIENTE IS NOT NULL THEN M.ID_CLIENTE                      
                   WHEN A.ID_CLIENTE IS NOT NULL THEN A.ID_CLIENTE                      
  WHEN S.ID_CLIENTE IS NOT NULL THEN S.ID_CLIENTE                      
          ELSE NULL                      
                   END)                          
   LEFT JOIN(SELECT IDSWIFT, MAX(NUMERO) AS NUMERO FROM TBL_MEWEB_MT103_CHANGE WITH(NOLOCK) GROUP BY IDSWIFT) AS CA ON M.IDSWIFT = CA.IDSWIFT             
   LEFT JOIN( SELECT B.ID_SWIFT, B.CDMSG, C.DATAMSG               
   FROM TBL_ME_LOG_LANC_CCMESWIFT  B WITH(NOLOCK) INNER JOIN               
   (SELECT ID_SWIFT, MAX(DATAMSG) AS DATAMSG              
   FROM TBL_ME_LOG_LANC_CCMESWIFT  WITH(NOLOCK)               
   WHERE CDMSG IN ('2000','2001')              
   GROUP BY ID_SWIFT) AS C              
   ON B.ID_SWIFT = C.ID_SWIFT              
   AND B.DATAMSG = C.DATAMSG) AS LO ON M.IDSWIFT = LO.ID_SWIFT         
  WHERE        
  (         
   (@1CLIENTE IS NULL OR LEN(@1CLIENTE) = 0) OR                                                      
   [DBO].[MT103_FORMATA_ORDENANTE] (M.M50K_ORDERINGCUSTOMER,M.O50F_ADDITIONALINFORMATION,M.M50A_ORDERINGCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR                                                    
   [DBO].[MT103_FORMATA_BENEFICIARIO] (M59_BENEFICIARYCUSTOMER) LIKE '%' + @1CLIENTE +'%' OR         
   ISNULL(C.CL_NOME,C.CL_RAZAO_SOCIAL) LIKE '%' + @1CLIENTE +'%' OR        
   CONVERT(VARCHAR,M.OP_N_BOLETO) LIKE @1CLIENTE +'%'        
  )                                                                              
   AND (@1LANCADOCHANGE = 'TODOS' OR (ISNULL(@1LANCADOCHANGE,'SIM') = 'SIM' AND CA.NUMERO IS NOT NULL) OR (@1LANCADOCHANGE = 'NAO' AND CA.NUMERO IS NULL))          
   AND CONVERT(DATE,DATAASSOCIA,101) BETWEEN CONVERT(DATE,@1DATAINICIAL,101) AND CONVERT(DATE,@1DATAFINAL,101)          
                
 END       
       
   
   