USE IK_VAREJO

GO

DECLARE
--ALTER PROCEDURE [dbo].[SPBCCME_MEWEB_MT103]                        
--(                        
@Arq VARCHAR(20) = NULL,
 @ACAO VARCHAR(30) = 'FILTRAR',                        
 @DATAINICIAL DATETIME = '20140101',                        
 @DATAFINAL DATETIME = '20141231',                        
 @PERIODO VARCHAR(30) = 'DataCredito',                        
 @STATUSLOTE VARCHAR(30)= 'Pendente',                        
 @EMPRESA VARCHAR(100) = 'Todas',                        
 @ARQUIVO VARCHAR(400) = NULL,                        
 @USUARIO VARCHAR(100) = NULL,                        
 @LISTA VARCHAR(max) = NULL,                        
 @NOMEARQUIVO VARCHAR(400) = NULL,                        
 @CAMINHOARQUIVO VARCHAR(400) = NULL,                        
 @DATAARQUIVO DATETIME = NULL,                        
 @LOTE VARCHAR(500) = NULL,                        
 @IDSWIFT INT = NULL,                  
 @IDCLIENTE INT  = NULL,                  
 @IDLOTE INT = NULL,      
 @ID_USER INT = NULL,
 @UR_USERNAME VARCHAR(30) = NULL,
 @MSGLOTE VARCHAR(500) = NULL
              
                    
--)                         
--AS                        
                       
  DECLARE @COMANDO VARCHAR(8000)                         
  DECLARE @Campo VARCHAR(10), @num_caracter_Linha INT, @Num_linhas INT, @Ativo CHAR(1), @CampoDB_Mt103 VARCHAR(30), @SeqId INT                        
                        
                    
                        
IF @ACAO = 'FILTRAR'                        
BEGIN
DECLARE @BICCODECOTACAO VARCHAR(300) = NULL
DECLARE @FLAG_HABILITA_TELAS_CCME CHAR(1) = NULL
            
SELECT TOP 1 @FLAG_HABILITA_TELAS_CCME = FLAG_HABILITA_TELAS_CCME FROM TBL_ROBOCCMESWIFT  
SELECT TOP 1 @BICCODECOTACAO = VL_CAMPO FROM TBL_VAREJO_PARAMETROS WHERE NM_CAMPO = 'BICCODECOTACAO'

CREATE TABLE #TBL_TEMP1
(
	 ID INT NULL,
	 ID_CLIENTE_ASSOCIADO INT NULL,
	 ID_CLIENTE_SUGESTAO INT NULL,
	 ID_CLIENTE_LANCAMENTO INT NULL,
	 CLIENTE_ASSOCIADO VARCHAR(MAX) NULL,
	 CLIENTE_SUGESTAO VARCHAR(MAX) NULL,
	 CLIENTE_LANCAMENTO VARCHAR(MAX) NULL,
	 CL_OPERASOMENTEBANCO VARCHAR(MAX) NULL,
	 IDSWIFT INT,
	 M59_BENEFICIARYCUSTOMER VARCHAR(600) NULL,
	 M50K_ORDERINGCUSTOMER NVARCHAR(1200) NULL,
	 O50F_ADDITIONALINFORMATION NVARCHAR(1200) NULL,
	 M50A_ORDERINGCUSTOMER NVARCHAR(1200) NULL,
	 ID_CLIENTE INT NULL,
	 M20_SENDERREF VARCHAR(16) NULL ,
	 M32A_VDATECURRENCYINTERBANK VARCHAR(24) NULL,
	 DATALOTE DATETIME NULL, 
	 DATA_LANCAMENTO_ROBO DATETIME NULL ,
	 STATUS_LANC INT NULL,
	 DATA_LANCAMENTO DATETIME NULL, 
	 EMPRESA VARCHAR(10) NULL, 
	 DATA_REGISTRO DATETIME NULL,
	 LC_AUTOMATICO BIT NULL,
	 id_lote INT NULL,
	 O57A_AccountInstitution VARCHAR(500) NULL,
	 NomeArquivoSwift VARCHAR(400) NULL,
	 DataArquivoSwift DATETIME NULL,
	 LOTE INT NULL,
	 FlagGoogle BIT NULL,
	 BENEFICIARIO VARCHAR(500) NULL,
	 ORDENANTE VARCHAR(500) NULL,
	 VALOR_USD FLOAT NULL
)

INSERT INTO #TBL_TEMP1
(
	 IDSWIFT,
	 M59_BENEFICIARYCUSTOMER ,
	 M50K_ORDERINGCUSTOMER,
	 O50F_ADDITIONALINFORMATION ,
	 M50A_ORDERINGCUSTOMER,
	 ID_CLIENTE,
	 M20_SENDERREF,
	 M32A_VDATECURRENCYINTERBANK,
	 DATALOTE, 
	 DATA_LANCAMENTO_ROBO,
	 STATUS_LANC,
	 DATA_LANCAMENTO , 
	 EMPRESA, 
	 DATA_REGISTRO ,
	 LC_AUTOMATICO,
	 id_lote,
	 O57A_AccountInstitution,
	 NomeArquivoSwift,
	 DataArquivoSwift ,
	 LOTE,
	 FlagGoogle,
	 BENEFICIARIO,
	 ORDENANTE,
	 VALOR_USD
)
SELECT 
	 IDSWIFT,
	 M59_BENEFICIARYCUSTOMER ,
	 M50K_ORDERINGCUSTOMER,
	 O50F_ADDITIONALINFORMATION,
	 M50A_ORDERINGCUSTOMER,
	 M.ID_CLIENTE,
	 M20_SENDERREF,
	 M32A_VDATECURRENCYINTERBANK,
	 DATALOTE, 
	 DATA_LANCAMENTO_ROBO,
	 STATUS_LANC,
	 DATA_LANCAMENTO , 
	 EMPRESA, 
	 DATA_REGISTRO,
	 LC_AUTOMATICO,
	 id_lote,
	 O57A_AccountInstitution,
	 NomeArquivoSwift,
	 DataArquivoSwift,
	 LOTE,
	 FlagGoogle,
	 [dbo].[MT103_FORMATA_BENEFICIARIO] (M.M59_BeneficiaryCustomer)AS BENEFICIARIO,
	 [dbo].[MT103_FORMATA_ORDENANTE] (M.M50K_OrderingCustomer,M.O50F_AdditionalInformation,M.M50A_OrderingCustomer)AS ORDENANTE,
	 ([IK_VAREJO].[dbo].[CALCULA_MOEDA](SUBSTRING(M32A_VDateCurrencyInterbank,7,3),LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(SUBSTRING(M32A_VDateCurrencyInterbank,10,15),CHAR(13),''),CHAR(10),''),',','.'))))) AS VALOR_USD
 FROM [IK_VAREJO].[dbo].[tbl_meweb_MT103] AS M WITH(NOLOCK)                        
 LEFT JOIN [IK_VAREJO].[dbo].[tbl_meweb_MT103_LOTE] AS L WITH(NOLOCK) ON M.id_Lote = L.LOTE 
 LEFT JOIN TBL_CLIENTES as C WITH(NOLOCK) ON M.id_cliente IS NOT NULL AND C.id_cliente = M.id_cliente
 WHERE ( @Arq IS NULL	OR	m.Arquivo_entrada LIKE '%'+@Arq+'%' )
	AND ISNULL(OP_N_BOLETO_SISTEMA, 'PC') = 'PC' AND
	CASE 
		WHEN @STATUSLOTE = 'TODOS' THEN 1 
		WHEN @STATUSLOTE = 'PENDENTE' AND id_Lote IS NULL AND status_lanc IS NULL THEN 1
		WHEN @STATUSLOTE = 'FECHADO' AND id_Lote IS NOT NULL AND status_lanc IS NULL THEN 1 
		WHEN @STATUSLOTE = 'DataFutura' AND status_lanc = 6 THEN 1 
		ELSE 0 
	END = 1 AND
	CASE 
		WHEN @PERIODO = 'DATACREDITO' AND CONVERT(Date,SUBSTRING(M32A_VDateCurrencyInterbank,1,6),101) BETWEEN CONVERT(Date,@DATAINICIAL,101) AND CONVERT(Date,@DATAFINAL,101) THEN 1
		WHEN @PERIODO = 'DATAREGISTRO' AND CONVERT(Date,data_registro,101) BETWEEN CONVERT(Date,@DATAINICIAL,101) AND CONVERT(Date,@DATAFINAL,101) THEN 1
		WHEN @PERIODO = 'DATALOTE' AND CONVERT(Date,l.DataLote,101) BETWEEN CONVERT(Date,@DATAINICIAL,101) AND CONVERT(Date,@DATAFINAL,101) THEN 1
		WHEN @PERIODO = 'DATAGERACAOSWIFT' AND CONVERT(Date,l.DataArquivoSwift,101) BETWEEN CONVERT(Date,@DATAINICIAL,101) AND CONVERT(Date,@DATAFINAL,101) THEN 1
		ELSE 0
	END = 1 AND
	CASE 
		WHEN ISNULL(@EMPRESA,'TODAS') = 'TODAS' THEN 1
		WHEN @EMPRESA = l.Empresa THEN 1
		ELSE 0
	END = 1 AND
	CASE 
		WHEN @ARQUIVO IS NULL THEN 1
		WHEN LEN(@ARQUIVO) = 0 THEN 1
		WHEN l.NomeArquivoSwift LIKE '%' + @ARQUIVO + '%' THEN 1
		ELSE 0
	END = 1 
	AND (
		FlagGoogle = 0
		OR 
		( FlagGoogle = 1 AND m.id_cliente IS NULL AND m.op_n_boleto IS NULL AND @FLAG_HABILITA_TELAS_CCME = 'S')
	)
	/*AND
	CASE
		WHEN ISNULL(@FLAG_HABILITA_TELAS_CCME,'N') = 'N' AND FlagGoogle = 0 THEN 1
		WHEN ISNULL(@FLAG_HABILITA_TELAS_CCME,'N') = 'S' AND FlagGoogle IN(0, 1) THEN 1
		ELSE 0
	END = 1*/
	
UPDATE M SET M.CL_OPERASOMENTEBANCO = C.cl_OperaSomenteBanco, M.ID_CLIENTE_LANCAMENTO = C.id_cliente,  M.CLIENTE_LANCAMENTO = ISNULL(C.cl_nome,C.cl_razao_social) +' - '+ C.cl_num_doc 
FROM #TBL_TEMP1 AS M 
INNER JOIN TBL_CLIENTES AS C WITH(NOLOCK) ON M.id_cliente = C.id_cliente
WHERE M.id_cliente IS NOT NULL
	
UPDATE M SET M.ID = A.ID, M.CL_OPERASOMENTEBANCO = C.cl_OperaSomenteBanco, M.id_cliente_associado = C.id_cliente,  M.cliente_associado = ISNULL(C.cl_nome,C.cl_razao_social) +' - '+ C.cl_num_doc 
FROM #TBL_TEMP1 AS M 
INNER JOIN [IK_VAREJO].[dbo].[TBL_MEWEB_ASSOCIA_CLIENTES] AS A WITH(NOLOCK) ON 
(
 REPLACE(REPLACE(REPLACE(REPLACE(BENEFICIARIO ,CHAR(9),''),CHAR(10),''),CHAR(13),''),CHAR(32),'') COLLATE SQL_Latin1_General_CP1_CI_AS = REPLACE(REPLACE(REPLACE(REPLACE(A.Beneficiario_Swift,CHAR(9),''),CHAR(10),''),CHAR(13),''),CHAR(32),'') COLLATE SQL_Latin1_General_CP1_CI_AS AND                            
 REPLACE(REPLACE(REPLACE(REPLACE(ORDENANTE,CHAR(9),''),CHAR(10),''),CHAR(13),''),CHAR(32),'') COLLATE SQL_Latin1_General_CP1_CI_AS= REPLACE(REPLACE(REPLACE(REPLACE(A.Ordenante_Swift,CHAR(9),''),CHAR(10),''),CHAR(13),''),CHAR(32),'') COLLATE SQL_Latin1_General_CP1_CI_AS 
)  
INNER JOIN TBL_CLIENTES AS C ON A.id_cliente = C.id_cliente
WHERE M.id_cliente IS NOT NULL
	
UPDATE M SET M.CL_OPERASOMENTEBANCO = C.cl_OperaSomenteBanco, M.id_cliente_sugestao = S.id_cliente, M.cliente_sugestao = ISNULL(C.cl_nome,C.cl_razao_social) +' - '+ C.cl_num_doc 
FROM #TBL_TEMP1 AS M 
INNER JOIN TBL_MEWEB_MT103_SUGEST AS S WITH(NOLOCK) ON M.idSwift = S.idSwift
INNER JOIN TBL_CLIENTES AS C WITH(NOLOCK) ON C.id_cliente = S.id_cliente
WHERE M.id_cliente IS NOT NULL
 
SELECT   
M.ID,                
m.id_Lote, 
M.CL_OPERASOMENTEBANCO,                  
M.CLIENTE_ASSOCIADO,                            
M.ID_CLIENTE_ASSOCIADO,                                
M.CLIENTE_SUGESTAO,                             
M.ID_CLIENTE_SUGESTAO,                
M.CLIENTE_LANCAMENTO,                          
M.ID_CLIENTE_LANCAMENTO,             
CONVERT(DATE,SUBSTRING(M32A_VDateCurrencyInterbank,1,6),101) AS DATACREDITO,                           
CASE WHEN PATINDEX('%'+@BICCODECOTACAO+'%',O57A_AccountInstitution) > 0 THEN 'COTACAO' ELSE 'BRSA' END AS BICCODE,
M.BENEFICIARIO,                        
M.ORDENANTE,                      
m.Empresa,m.Lote,M.DataLote,m.DataArquivoSwift,m.NomeArquivoSwift,M.idSwift,data_registro,M20_SenderRef AS REFERENCIA,                        
SUBSTRING(M32A_VDateCurrencyInterbank,10,15) +' / '+SUBSTRING(M32A_VDateCurrencyInterbank,7,3) AS VALOR_MOEDA,                        
M.VALOR_USD,                        
M.FlagGoogle
FROM #TBL_TEMP1 AS M 
ORDER BY CONVERT(Date,SUBSTRING(M32A_VDateCurrencyInterbank,1,6),101) ASC         

DROP TABLE #TBL_TEMP1
END                       
        