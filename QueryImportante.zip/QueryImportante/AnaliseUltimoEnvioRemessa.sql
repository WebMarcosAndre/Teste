--			37471		IGOR
--			344442		MARCELO CULEN
--			278340		CESAR
--			196221		NELY
--			192249		ALUISIO
 
 /*
 
 UPDATE IK_VAREJO.dbo.TBL_LOGIN_INTEGRADO SET FLAG_HABILITA_CAMBIO_COTACAO = 'S' WHERE LI_IDCLIENTE = 196221
 SELECT * FROM IK_VAREJO.dbo.TBL_LOGIN_INTEGRADO (NOLOCK) WHERE LI_DOC = '12936605822'
 */
 
 
DECLARE @IdCliente INT = 344442
SELECT * FROM IK_VAREJO.dbo.TBL_LOGIN_INTEGRADO (NOLOCK) WHERE LI_IDCLIENTE = @IdCliente

SELECT MAX(op_data_boleto) ultimo_boleto
				FROM IK_VAREJO.DBO.TBL_PRE_BOLETO (NOLOCK)
				WHERE id_cliente = ISNULL(@IdCliente,id_cliente) AND sistema_origem = 'PC'
				AND op_data_boleto >= DATEADD(YEAR, -1, GETDATE())
				
SELECT MAX(op_data_boleto) ultimo_boleto
				FROM IK_VAREJO.DBO.TBL_PRE_BOLETO (NOLOCK)
				WHERE id_cliente = ISNULL(@IdCliente,id_cliente) AND sistema_origem = 'SF'
				AND pre_boleto_status IN(		0,	1,	4,	5	)
				
SELECT 1
WHERE 
	NOT EXISTS (			
				SELECT TOP 1 1
				FROM IK_VAREJO.DBO.TBL_PRE_BOLETO (NOLOCK)
				WHERE id_cliente = @IdCliente AND sistema_origem = 'PC'
				
				)
	AND		EXISTS(
				
				SELECT TOP 1 1
				FROM IK_VAREJO.DBO.TBL_PRE_BOLETO (NOLOCK)
				WHERE id_cliente = @IdCliente AND sistema_origem = 'SF'
				AND pre_boleto_status IN(		0,	1,	4,	5	)
			)
RETURN			


SELECT A.op_data_boleto, LL.li_nome, LL.LI_DOC, LL.li_idcliente
FROM IK_VAREJO.dbo.TBL_LOGIN_INTEGRADO LL
inner join (
			SELECT 
				MAX(b.op_data_boleto) op_data_boleto,
				b.id_cliente 
			FROM TBL_PRE_BOLETO b (nolock) 
				left join TBL_LOGIN_INTEGRADO l (NOLOCK)
					ON b.id_cliente = l.LI_IDCLIENTE
			where b.sistema_origem = 'PC'
			group by  b.id_cliente
			--order by b.op_data_boleto
			) as a 
ON LL.LI_IDCLIENTE = a.id_cliente
ORDER BY LL.li_nome
--having op_data_boleto  < DATEADD(YEAR, -1, GETDATE())


select * from TBL_LOGIN_INTEGRADO where li_idcliente = 344442
select * from TBL_clientes where id_cliente = 344442


select * from TBL_LOGIN_INTEGRADO where li_nome like '%cesar mendes%'
select * from TBL_LOGIN_INTEGRADO where li_idcliente = 278340
select * from TBL_clientes where id_cliente = 278340
