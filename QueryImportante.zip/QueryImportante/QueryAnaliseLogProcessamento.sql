USE DBVAREJO
GO


IF OBJECT_ID('tempdb..#TBL_PRE_BOLETO') IS NOT NULL DROP TABLE #TBL_PRE_BOLETO
IF OBJECT_ID('tempdb..#BOLETO_ANALISE') IS NOT NULL DROP TABLE #BOLETO_ANALISE

SELECT * 
INTO #TBL_PRE_BOLETO
FROM TBL_PRE_BOLETO (NOLOCK) 
WHERE op_tipo_operacao = 'V'
AND op_data_inclusao > '20190820'  
AND op_tipo_entrega IN ('TELE', 'CREDITO')
AND sistema_origem = 'PC'
--AND pre_boleto_status = 0
ORDER BY op_n_boleto DESC


SELECT p.op_n_boleto, p.op_data_inclusao,p.op_tipo_entrega ,p.pre_boleto_status, 
	c.pre_data_fase1, c.pre_data_fase2, c.pre_data_fase3, c.pre_data_fase4, c.pre_data_fase5,
	DATEDIFF(MINUTE, c.pre_data_fase1, c.pre_data_fase5) TEMPO1X5,
	CASE WHEN p.pre_boleto_status IN (1,2,3) AND c.pre_data_fase5 IS NOT NULL THEN 'SUCESSO'
		WHEN c.pre_data_fase5 IS NULL THEN 'PENDENTE'
		WHEN p.pre_boleto_status = 0 AND c.pre_data_fase5 IS NOT NULL THEN 'FALHA' END RESULTADO
INTO #BOLETO_ANALISE
FROM #TBL_PRE_BOLETO p (NOLOCK)
	LEFT JOIN TBL_COL_PREBOLETO c 
		ON p.op_n_boleto = c.pre_n_boleto

SELECT * FROM #BOLETO_ANALISE

RETURN

DECLARE @op_n_boleto INT = 0
	
DECLARE db_cursor CURSOR FOR 
		SELECT op_n_boleto FROM #BOLETO_ANALISE
OPEN db_cursor  
FETCH NEXT FROM db_cursor INTO @op_n_boleto 
WHILE @@FETCH_STATUS = 0  
BEGIN        

	  SELECT @op_n_boleto op_n_boleto, MIN(error_date) Inicio, MAX(error_date) Fim , DATEDIFF( MINUTE, MIN(error_date) , MAX(error_date) ) Tempo
	  FROM TBL_COL_LOG_ERROS (NOLOCK) WHERE error_description LIKE '%'+CONVERT(VARCHAR(10),@op_n_boleto)+'%'

      FETCH NEXT FROM db_cursor INTO @op_n_boleto 
END 
CLOSE db_cursor  
DEALLOCATE db_cursor 

