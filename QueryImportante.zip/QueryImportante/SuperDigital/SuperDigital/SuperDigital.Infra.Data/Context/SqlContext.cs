﻿using Microsoft.EntityFrameworkCore;
using SuperDigital.Domain.Entities;

namespace SuperDigital.Infra.Context
{
    public partial class SqlContext : DbContext
    {
        public SqlContext()
        { }

        public SqlContext(DbContextOptions<SqlContext> options)
            : base(options)
        { }

        public virtual DbSet<Conta> ContaCorrente { get; set; }
        public virtual DbSet<Lancamento> Lancamento { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=test;Integrated Security=True;Pooling=False");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Conta>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ContaCorrenteId").IsRequired();
                entity.Property(e => e.Saldo).IsRequired();
            });

            modelBuilder.Entity<Lancamento>(entity =>
            {
                entity.ToTable("Lancamento", "dbo");

                entity.Property(e => e.Id).HasColumnName("Id").IsRequired();

                entity.HasOne(d => d.ContaOrigem)
                   .WithMany(p => p.Lancamentos)
                   .HasForeignKey(d => d.Id)
                   .OnDelete(DeleteBehavior.Cascade)
                  .HasConstraintName("FK_Lancamento_ContaCorrenteOrigem");

                entity.HasOne(d => d.ContaDestino)
                   .WithMany(p => p.Lancamentos)
                   .HasForeignKey(d => d.Id)
                   .OnDelete(DeleteBehavior.Cascade )
                  .HasConstraintName("FK_Lancamento_ContaCorrenteDestino");

                entity.Property(e => e.Data).IsRequired();
                entity.Property(e => e.ValorOperacao).IsRequired();
            });
        }
    }
}
