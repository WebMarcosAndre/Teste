﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using SuperDigital.Domain.Entities;
using SuperDigital.Domain.Interfaces.Repositories;
using SuperDigital.Infra.Context;


namespace SuperDigital.Infra.Repositories
{
    public class BaseRepository<TEntity> : IBaseRepository<TEntity> where TEntity : BaseEntity
    {
        protected SqlContext _context;
        protected DbSet<TEntity> dbSet;

        public BaseRepository(SqlContext context)
        {
            _context = context;
            dbSet = _context.Set<TEntity>();
        }

        public virtual TEntity Insert(TEntity obj)
        {
            return dbSet.Add(obj).Entity;
        }

        public virtual TEntity GetById(int id)
        {
            return dbSet.Find(id);
        }

        public virtual IEnumerable<TEntity> List()
        {
            return dbSet;
        }

        public virtual TEntity Update(TEntity obj)
        {
            var entry = _context.Entry(obj);
            dbSet.Attach(obj);
            entry.State = EntityState.Modified;

            return obj;
        }

        public virtual void Delete(int id)
        {
            dbSet.Remove(dbSet.Find(id));
        }

        public IEnumerable<TEntity> Find(Expression<Func<TEntity, bool>> predicate)
        {
            return dbSet.Where(predicate);
        }

        public int SaveChanges()
        {
            return _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}
