﻿using SuperDigital.Domain.Entities;
using SuperDigital.Domain.Interfaces.Repositories;
using SuperDigital.Infra.Context;

namespace ContaCorrente.Infra.Repositories
{
    public class ContaRepository : BaseEntity<Conta>, IContaRepository
    {
        public ContaRepository(SqlContext context)
            : base(context)
        { }

        public Conta ObterContaCorrente(int contaCorrenteId)
        {
            return ObterPorId(contaCorrenteId);
        }

        public void AtualizarSaldo(Conta contaCorrente)
        {
            Atualizar(contaCorrente);
        }
    }
}
