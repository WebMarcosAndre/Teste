﻿using System;

namespace SuperDigital.Infra.Data
{
    public class Class1
    {
    }
}
