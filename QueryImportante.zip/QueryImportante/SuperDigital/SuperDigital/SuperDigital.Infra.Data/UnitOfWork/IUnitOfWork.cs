﻿using Microsoft.EntityFrameworkCore.Storage;

namespace SuperDigital.Infra.Data.UnitOfWork
{
    public interface IUnitOfWork
    {
        void Commit();
        IDbContextTransaction BeginTransaction();
    }
}
