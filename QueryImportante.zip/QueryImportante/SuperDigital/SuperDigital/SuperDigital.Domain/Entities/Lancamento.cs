﻿
using System;

namespace SuperDigital.Domain.Entities
{
    public class Lancamento:BaseEntity
    {
        public int Id { get; set; }
        public Conta ContaOrigem { get; set; }
        public Conta ContaDestino { get; set; }
        public DateTime Data { get; set; }
        public decimal ValorOperacao { get; set; }

    }
}
