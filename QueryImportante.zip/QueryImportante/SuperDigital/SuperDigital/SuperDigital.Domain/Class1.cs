﻿
namespace SuperDigital.Domain
{
    public class Class1
    {
    }
}
