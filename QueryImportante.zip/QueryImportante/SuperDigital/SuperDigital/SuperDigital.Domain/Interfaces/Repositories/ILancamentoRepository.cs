﻿using SuperDigital.Domain.Entities;

namespace SuperDigital.Domain.Interfaces.Repositories
{
    public interface ILancamentoRepository : IBaseRepository<Lancamento>
    {
        Lancamento IncluirLancamento(Lancamento lancamento);
    }
}
