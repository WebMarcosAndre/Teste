﻿using SuperDigital.Domain.Entities;

namespace SuperDigital.Domain.Interfaces.Repositories
{
    public interface IContaRepository : IBaseRepository<Conta>
    {
        Conta ObterContaCorrente(int contaCorrenteId);
        void AtualizarSaldo(Conta contaCorrente);
    }
}
