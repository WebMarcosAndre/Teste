﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace SuperDigital.Domain.Interfaces.Repositories
{
    public interface IBaseRepository<TEntity> : IDisposable where TEntity : class
    {
        TEntity Insert(TEntity obj);
        TEntity GetById(int id);
        IEnumerable<TEntity> List();
        TEntity Update(TEntity obj);
        void Delete(int id);
        IEnumerable<TEntity> Find(Expression<Func<TEntity, bool>> predicate);
        int SaveChanges();
    }
}
