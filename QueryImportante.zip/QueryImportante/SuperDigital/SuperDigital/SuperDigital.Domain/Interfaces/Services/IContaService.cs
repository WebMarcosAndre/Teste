﻿
namespace SuperDigital.Domain.Interfaces.Services
{
    public interface IContaService
    {
     
    }
}
