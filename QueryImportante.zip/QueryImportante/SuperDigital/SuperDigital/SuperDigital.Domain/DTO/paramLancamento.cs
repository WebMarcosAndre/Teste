﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.Domain.DTO
{
    public class paramLancamento
    {
        public Conta ContaOrigem { get; set; }
        public Conta ContaDestino { get; set; }        
        public decimal ValorOperacao { get; set; }
    }
}
