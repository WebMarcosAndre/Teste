﻿using System;

namespace SuperDigital.Services
{
    public class Class1
    {
    }
}
