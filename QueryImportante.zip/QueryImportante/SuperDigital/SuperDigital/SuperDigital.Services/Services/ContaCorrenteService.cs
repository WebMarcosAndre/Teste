﻿using SuperDigital.Domain.Dtos;
using SuperDigital.Domain.Interfaces.Repositories;
using SuperDigital.Domain.Interfaces.Services;

namespace SuperDigital.Services.Services
{
    public class ContaCorrenteService : IContaCorrenteService
    {
        private readonly IContaCorrenteRepository _contaCorrenteRepository;

        public ContaCorrenteService(IContaCorrenteRepository contaCorrenteRepository)
        {
            _contaCorrenteRepository = contaCorrenteRepository;
        }

        public void DebitarValor(AtualizarSaldoDto dto)
        {
            var contaCorrente = _contaCorrenteRepository.ObterPorId(dto.ContaCorrenteId);
            contaCorrente.Saldo += dto.Valor;
            _contaCorrenteRepository.AtualizarSaldo(contaCorrente);
        }

        public void CreditarValor(AtualizarSaldoDto dto)
        {
            var contaCorrente = _contaCorrenteRepository.ObterPorId(dto.ContaCorrenteId);
            contaCorrente.Saldo += dto.Valor;
            _contaCorrenteRepository.AtualizarSaldo(contaCorrente);
        }
    }
}
