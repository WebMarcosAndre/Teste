﻿using System;
using SuperDigital.Domain;
using SuperDigital.Domain.Dtos;
using SuperDigital.Domain.Entities;
using SuperDigital.Domain.Interfaces.Repositories;
using SuperDigital.Domain.Interfaces.Services;
using SuperDigital.Domain.ValueObjects;
using SuperDigital.Infra.Data.UnitOfWork;

namespace SuperDigital.Services.Services
{
    public class LancamentoService : ILancamentoService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILancamentoRepository _lancamentoRepository;
        private readonly IContaCorrenteService _contaCorrenteService;

        public LancamentoService(IUnitOfWork unitOfWork,
                                 ILancamentoRepository lancamentoRepository, IContaCorrenteService contaCorrenteService)
        {
            _unitOfWork = unitOfWork;
            _lancamentoRepository = lancamentoRepository;
            _contaCorrenteService = contaCorrenteService;
        }

        public void EfetuarTransferencia(TransferenciaRequest request)
        {
            Guard.IsNotNull(request, typeof(TransferenciaRequest).Name);

            using (var transaction = _unitOfWork.BeginTransaction())
            {
                DebitarValorDaContaDeOrigem(request);
                CreditarValorNaContaDeDestino(request);
                InserirLancamento(request);

                _unitOfWork.Commit();
                transaction.Commit();
            }
        }

        public void DebitarValorDaContaDeOrigem(TransferenciaRequest request)
        {
            _contaCorrenteService.DebitarValor(new AtualizarSaldoDto()
            {
                ContaCorrenteId = request.ContaOrigem,
                Valor = request.Valor
            });
        }
        public void CreditarValorNaContaDeDestino(TransferenciaRequest request)
        {
            _contaCorrenteService.CreditarValor(new AtualizarSaldoDto()
            {
                ContaCorrenteId = request.ContaDestino,
                Valor = request.Valor
            });
        }

        public void InserirLancamento(TransferenciaRequest request)
        {
            _lancamentoRepository.IncluirLancamento(new Lancamento()
            {
                ContaCorrenteOrigemId = request.ContaOrigem,
                ContaCorrenteDestinoId = request.ContaDestino,
                DataLancamento = DateTime.Now,
                TipoTransacao = (int)TipoLancamentoEnum.Transferencia,
                TipoOperacao = (int)TipoOperacaoEnum.Debito,
                Valor = request.Valor
            });
        }
    }
}
