﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SuperDigital.Infra.Data.UnitOfWork;

namespace SuperDigital.Api.Controllers
{
    public class BaseController : ControllerBase
    {
                          
        protected IUnitOfWork _unitOfWork;

        public BaseController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        protected StatusCodeResult OkBase()
        {
            _unitOfWork.Commit();
            return StatusCode(StatusCodes.Status200OK);
        }

        protected StatusCodeResult ServerErrorBase()
        {
            return StatusCode(StatusCodes.Status500InternalServerError);
        }
    }
}
