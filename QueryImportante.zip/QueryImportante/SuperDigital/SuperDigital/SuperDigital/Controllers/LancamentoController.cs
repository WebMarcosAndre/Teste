﻿using System;

using Microsoft.AspNetCore.Mvc;

using SuperDigital.Domain.Interfaces.Services;
using SuperDigital.Infra.Data.UnitOfWork;

namespace SuperDigital.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LancamentoController : BaseController
    {
        private readonly ILancamentoService _lancamentoService;
       
        public LancamentoController(IUnitOfWork unitOfWork, ILancamentoService lancamentoService)
            : base(unitOfWork)
        {
            _lancamentoService = lancamentoService;
            _unitOfWork = unitOfWork;
        }

        [HttpPost("Transferencia")]
        [ProducesResponseType(typeof(StatusCodeResult), 200)]
        [ProducesResponseType(typeof(StatusCodeResult), 500)]
        public StatusCodeResult Transferencia(TransferenciaRequest request)
        {
            try
            {
                _lancamentoService.EfetuarTransferencia(request);
                return OkBase();
            }
            catch (Exception )
            {
                return ServerErrorBase();
            }
        }
    }
}
