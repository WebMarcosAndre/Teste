USE DBVAREJO
GO

DECLARE @li_doc VARCHAR(20) = '31294721852'
		
		
		, @id_cliente INT = 0


	SELECT @id_cliente = LI_IDCLIENTE FROM TBL_LOGIN_INTEGRADO (NOLOCK) WHERE li_doc = @li_doc
	
	--UPDATE TBL_CLI_BANCO_COMERCIO  SET 
	--		bc_cod_banco2 = 633, 
	--		bc_banco2= 'BANCO RENDIMENTO', 
	--		bc_agencia2 = '1', 
	--		bc_conta2= '01234' 
	--WHERE id_cliente = @id_cliente
	
	--UPDATE TBL_CLI_BANCO_COMERCIO  SET 
	--		bc_cod_banco3 = 633, 
	--		bc_banco3= 'BANCO RENDIMENTO', 
	--		bc_agencia3 = '1', 
	--		bc_conta3= '56789' 
	--WHERE id_cliente = @id_cliente

		
			
	UPDATE TBL_CLI_BANCO_COMERCIO  SET 
			bc_cod_banco = NULL, 
			bc_banco = NULL, 
			bc_agencia = NULL, 
			bc_conta = NULL	
	WHERE id_cliente = @id_cliente
	AND bc_cod_banco = 633

	UPDATE TBL_CLI_BANCO_COMERCIO  SET 
			bc_cod_banco2 = NULL, 
			bc_banco2= NULL, 
			bc_agencia2 = NULL, 
			bc_conta2= NULL	
	WHERE id_cliente = @id_cliente
	AND bc_cod_banco2 = 633

	UPDATE TBL_CLI_BANCO_COMERCIO  SET 
			bc_cod_banco3 = NULL, 
			bc_banco3= NULL, 
			bc_agencia3 = NULL, 
			bc_conta3= NULL	
	WHERE id_cliente = @id_cliente
	AND bc_cod_banco3 = 633