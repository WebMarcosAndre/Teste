
use IK_VAREJO

GO

DECLARE @tipo INT = NULL

SELECT @tipo = li_tipocliente FROM TBL_LOGIN_INTEGRADO (NOLOCK) where li_doc = '17659759000183'
SELECT * FROM TBL_LOGIN_INTEGRADO_TIPOCLIENTE(NOLOCK) WHERE Id = @tipo

--Se tipo for igual a 0 
IF @tipo = 0
SELECT id_natureza, portal_titulo FROM TBL_NATUREZA (NOLOCK)
WHERE portal_operar = 1 AND (portal_tipo_natureza = 'V' OR portal_tipo_natureza = 'A') AND NAT_STATUS ='A'
	AND portal_corretora = 1

--Se tipo for igual a 1 
IF @tipo = 1
SELECT id_natureza, portal_titulo FROM TBL_NATUREZA (NOLOCK)
WHERE portal_operar = 1 AND (portal_tipo_natureza = 'V' OR portal_tipo_natureza = 'A') AND NAT_STATUS ='A'
	AND portal_agencia = 1

--Se tipo for igual a 2
IF @tipo = 2
SELECT id_natureza, portal_titulo FROM TBL_NATUREZA (NOLOCK)
WHERE portal_operar = 1 AND (portal_tipo_natureza = 'V' OR portal_tipo_natureza = 'A') AND NAT_STATUS ='A'
	AND portal_intercambio = 1

--Se tipo for igual a 3
IF @tipo = 3
SELECT id_natureza, portal_titulo FROM TBL_NATUREZA (NOLOCK)
WHERE portal_operar = 1 AND (portal_tipo_natureza = 'V' OR portal_tipo_natureza = 'A') AND NAT_STATUS ='A'
	AND portal_pj_outros = 1

--Se tipo for igual a 4
IF @tipo = 4
SELECT id_natureza, portal_titulo FROM TBL_NATUREZA (NOLOCK)
WHERE portal_operar = 1 AND (portal_tipo_natureza = 'V' OR portal_tipo_natureza = 'A') AND NAT_STATUS ='A'
	AND portal_pf = 1

--CASO CONTR�RIO
ELSE
SELECT id_natureza, portal_titulo FROM TBL_NATUREZA (NOLOCK)
WHERE portal_operar = 1 AND (portal_tipo_natureza = 'V' OR portal_tipo_natureza = 'A') AND NAT_STATUS ='A'
	AND (1 > 2)





