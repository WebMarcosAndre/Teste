USE IK_VAREJO 

GO

SELECT TOP 10 --* 
c.flg_aceita_efet_auto_ordem, 
pb.op_n_boleto , 
c.id_cliente, 
c.cl_nome, 
l.li_nome, 
l.li_doc, 
l.li_senha, 
mt.OP_N_BOLETO mt_OP_N_BOLETO,
cpb.pre_n_boleto,
cpb.pre_boleto_status, 
pb.op_n_boleto_change, 
pb.op_tipo_operacao,
MTC.idSwift, 
pb.op_n_boleto_change
FROM TBL_PRE_BOLETO PB (NOLOCK)
LEFT JOIN TBL_MEWEB_MT103 MT (NOLOCK)
		ON PB.op_n_boleto = MT.OP_N_BOLETO
LEFT JOIN TBL_COL_PREBOLETO CPB (NOLOCK)
		ON pb.op_n_boleto = cpb.pre_n_boleto
INNER JOIN TBL_CLIENTES C (NOLOCK)
		ON pb.id_cliente = c.id_cliente
INNER JOIN TBL_LOGIN_INTEGRADO l (NOLOCK)
		ON c.id_cliente = l.LI_IDCLIENTE
LEFT JOIN TBL_MEWEB_MT103_CHANGE MTC (NOLOCK)
		ON mt.idSwift = MTC.idSwift	
		WHERE pb.op_n_boleto = 2629995--2629819 --2550444	--2550205

ORDER BY PB.op_n_boleto DESC

/*
SELECT * FROM TBL_LOGIN_INTEGRADO (NOLOCK) WHERE li_doc = '31294721852' --	CESAR 278340


UPDATE IK_VAREJO.dbo.TBL_CLIENTES SET flg_aceita_efet_auto_ordem = 'N' WHERE id_cliente = 278340

SELECT * FROM tbl_pre_boleto (NOLOCK) WHERE op_n_boleto = 2548995

*/
