USE DBVAREJO
GO

DECLARE @NrBoleto INT = 3384646, @IdOperacao INT 

SELECT @IDOPERACAO = ID_OPERACAO FROM TBL_PRE_BOLETO (NOLOCK) WHERE op_n_boleto = @NrBoleto
SELECT op_n_boleto, outras_especificacoes, op_natureza, op_data_inclusao FROM TBL_PRE_BOLETO (NOLOCK) WHERE op_n_boleto = @NrBoleto
SELECT pre_data_prevEmbarque,pre_cod_mod_imp,pre_disp_LI FROM TBL_COL_PREBOLETO (NOLOCK) WHERE pre_n_boleto = @NrBoleto

--SELECT TOP 10 * FROM TBL_COL_IMP_DI (NOLOCK) WHERE op_n_boleto = @NrBoleto OR id_operacao = @IdOperacao
--SELECT TOP 10 * FROM TBL_COL_IMP_LI (NOLOCK) WHERE op_n_boleto = @NrBoleto OR id_operacao = @IdOperacao
--SELECT TOP 10 * FROM TBL_COL_IMP_COEMB (NOLOCK) WHERE op_n_boleto = @NrBoleto OR id_operacao = @IdOperacao




SET @NrBoleto = 3381040-- 3380074
SELECT @IDOPERACAO = ID_OPERACAO  FROM TBL_PRE_BOLETO (NOLOCK) WHERE op_n_boleto = @NrBoleto
SELECT op_n_boleto, outras_especificacoes, op_natureza, op_data_inclusao FROM TBL_PRE_BOLETO (NOLOCK) WHERE op_n_boleto = @NrBoleto
SELECT pre_data_prevEmbarque,pre_cod_mod_imp,pre_disp_LI FROM TBL_COL_PREBOLETO (NOLOCK) WHERE pre_n_boleto = @NrBoleto

--SELECT TOP 10 * FROM TBL_COL_IMP_DI (NOLOCK) WHERE op_n_boleto = @NrBoleto OR id_operacao = @IdOperacao
--SELECT TOP 10 * FROM TBL_COL_IMP_LI (NOLOCK) WHERE op_n_boleto = @NrBoleto OR id_operacao = @IdOperacao
--SELECT TOP 10 * FROM TBL_COL_IMP_COEMB (NOLOCK) WHERE op_n_boleto = @NrBoleto OR id_operacao = @IdOperacao




SET @NrBoleto = 3278855
SELECT @IDOPERACAO = ID_OPERACAO  FROM TBL_PRE_BOLETO (NOLOCK) WHERE op_n_boleto = @NrBoleto
SELECT op_n_boleto, outras_especificacoes, op_natureza, op_data_inclusao FROM TBL_PRE_BOLETO (NOLOCK) WHERE op_n_boleto = @NrBoleto
SELECT pre_data_prevEmbarque,pre_cod_mod_imp,pre_disp_LI FROM TBL_COL_PREBOLETO (NOLOCK) WHERE pre_n_boleto = @NrBoleto

--SELECT TOP 10 * FROM TBL_COL_IMP_DI (NOLOCK) WHERE op_n_boleto = @NrBoleto OR id_operacao = @IdOperacao
--SELECT TOP 10 * FROM TBL_COL_IMP_LI (NOLOCK) WHERE op_n_boleto = @NrBoleto OR id_operacao = @IdOperacao
--SELECT TOP 10 * FROM TBL_COL_IMP_COEMB (NOLOCK) WHERE op_n_boleto = @NrBoleto OR id_operacao = @IdOperacao




return
select top 100 outras_especificacoes, op_n_boleto, * from TBL_PRE_BOLETO (nolock)
where op_natureza = 233 --(select * from TBL_NATUREZA where nat_codigo = 12012 )
and op_vend_comp = 09
and op_pag_receb = 05
and op_cod_RMMCCI = 9 --(SELECT RRMCCI_id, RRMCCI_Codigo, RRMCCI_Descricao FROM TBL_RRMCCI with(nolock) WHERE (RRMCCI_Ativo = 'S') ORDER By RRMCCI_Codigo - Recebimento/Pagamento antecipado - Importador (Exporta��o/Importa��o)) 
and sistema_origem = 'PC'
and pre_boleto_status = 2
and outras_especificacoes is not null
order by op_data_sistema desc
