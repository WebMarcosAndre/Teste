﻿using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace RND.AUTH.Service.Utils
{
    public class CriptografiaAES
    {
        public static byte[] Criptografar(string texto, string chave)
        {
            byte[] criptografado;

            using (AesManaged aes = new AesManaged())
            {
                ICryptoTransform cripto = aes.CreateEncryptor(Encoding.UTF8.GetBytes(chave), Encoding.UTF8.GetBytes("1234567890123456"));
                
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, cripto, CryptoStreamMode.Write))
                    {                        
                        using (StreamWriter sw = new StreamWriter(cs))
                            sw.Write(texto);

                        criptografado = ms.ToArray();
                    }
                }
            }

            return criptografado;
        }

        public static string DescriptografarUnicode(string texto, string chave)
        {
            byte[] textoCriptografado = Encoding.Unicode.GetBytes(texto);

            var textoDescript = string.Empty;

            using (AesManaged aes = new AesManaged())
            {
                ICryptoTransform decryptor = aes.CreateDecryptor(Encoding.UTF8.GetBytes(chave), Encoding.UTF8.GetBytes("1234567890123456"));

                using (MemoryStream ms = new MemoryStream(textoCriptografado))
                {
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader reader = new StreamReader(cs))
                            textoDescript = reader.ReadToEnd();
                    }
                }
            }
            return textoDescript;
        }

        public static string DescriptografarBigEndianUnicode(string texto, string chave)
        {
            byte[] textoCriptografado = Encoding.BigEndianUnicode.GetBytes(texto);

            var textoDescript = string.Empty;

            using (AesManaged aes = new AesManaged())
            {
                ICryptoTransform decryptor = aes.CreateDecryptor(Encoding.UTF8.GetBytes(chave), Encoding.UTF8.GetBytes("1234567890123456"));

                using (MemoryStream ms = new MemoryStream(textoCriptografado))
                {
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader reader = new StreamReader(cs))
                            textoDescript = reader.ReadToEnd();
                    }
                }
            }
            return textoDescript;
        }
    }
}
