﻿using FluentValidation;
using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Services;
using RND.CBP.Infra.Data.BaseRepository;
using System;
using System.Collections.Generic;

namespace RND.CBP.Service
{
    public class BaseService<T> : IBaseService<T> where T : BaseEntity
    {

        private BaseRepository<TEntidade, TId> repository = new BaseRepository<T>();

        public T Post<V>(T obj) where V : AbstractValidator<T>
        {
            Validate(obj, Activator.CreateInstance<V>());

            repository.Insert(obj);
            return obj;
        }

        public T Put<V>(T obj) where V : AbstractValidator<T>
        {
            Validate(obj, Activator.CreateInstance<V>());

            repository.Update(obj);
            return obj;
        }

        public void Delete(int id)
        {
            if (id == 0)
                throw new ArgumentException("Id não pode ser zero");

            repository.Delete(id);
        }

        //public IList<T> Get() => repository.Select();

        public T Get(int id)
        {
            if (id == 0)
                throw new ArgumentException("Id não pode ser zero");

            return repository.SelectById(id);
        }

        private void Validate(T obj, AbstractValidator<T> validator)
        {
            if (obj == null)
                throw new Exception("Registros não detectados!");

            validator.ValidateAndThrow(obj);
        }

        public IList<T> Get()
        {
            return repository.SelectAll();
        }


    }
}
