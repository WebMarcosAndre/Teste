﻿using RND.AUTH.Domain.DTOs;
using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Interfaces.Repositories;
using RND.AUTH.Domain.Interfaces.Services;
using RND.AUTH.Service.Base;
using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Net;

namespace RND.AUTH.Service.Services
{
    public class UsuarioService : BaseService<Usuario>, IUsuarioService
    {
        private readonly IUsuarioRepository _usuarioRepository;
        private readonly IPerfilRepository _perfilRepository;
        private readonly IFuncionalidadeRepository _funcionalidadeRepository;
        private readonly IUsuarioPerfilRepository _usuarioPerfilRepository;
        private readonly IUsuarioFuncionalidadeRepository _usuarioFuncionalidadeRepository;

        public UsuarioService(IUsuarioRepository usuarioRepository,
            IPerfilRepository perfilRepository,
            IFuncionalidadeRepository funcionalidadeRepository,
            IUsuarioPerfilRepository usuarioPerfilRepository,
            IUsuarioFuncionalidadeRepository usuarioFuncionalidadeRepository)
        {
            _usuarioRepository = usuarioRepository;
            _perfilRepository = perfilRepository;
            _funcionalidadeRepository = funcionalidadeRepository;
            _usuarioPerfilRepository = usuarioPerfilRepository;
            _usuarioFuncionalidadeRepository = usuarioFuncionalidadeRepository;
        }

        public object ObterUsuarioPorUsuarioAD(string usuarioAD)
        {
            return _usuarioRepository.BuscarUsuario(usuarioAD);
        }

        public List<Usuario> ObterUsuarioPorFiltro(string nome, string usuarioAD)
        {
            nome = nome ?? string.Empty;
            usuarioAD = usuarioAD ?? string.Empty;

            var retorno = _usuarioRepository.ListBy(x => x.Nome.Contains(nome) && x.UsuarioAd.Contains(usuarioAD)
                                                    , y => y.UsuarioFuncionalidade
                                                    , z => z.UsuarioPerfil);

            return retorno.ToList();
        }

        public List<Usuario> ObterUsuarioADPorFiltro(string nome, string usuarioAD, string dominio)
        {
            try
            {
                nome = nome ?? string.Empty;
                usuarioAD = usuarioAD ?? string.Empty;

                var usuariosBaseAuth = ObterUsuarioPorFiltro(nome, usuarioAD);

                var usuarios = new List<Usuario>();

                using (var searcher = new PrincipalSearcher(new UserPrincipal(new PrincipalContext(ContextType.Domain, dominio))))
                {
                    List<UserPrincipal> users = searcher.FindAll().Select(u => (UserPrincipal)u)
                        .ToList();

                    var listaUsers = users.Where(u => !u.SamAccountName.Contains("tivit")
                    && u.UserPrincipalName != null
                    && u.LastLogon >= DateTime.Now.AddMonths(-2)
                    && u.SamAccountName.Contains(usuarioAD)
                    && u.Name.ToUpper().Contains(nome.ToUpper())
                    && !usuariosBaseAuth.Where(x => x.UsuarioAd.Contains(u.SamAccountName)).Any()
                    ).ToList();

                    foreach (var u in listaUsers)
                    {
                        usuarios.Add(new Usuario()
                        {
                            UsuarioAd = u.SamAccountName,
                            Nome = u.Name,
                            Ativo = true
                        });
                    }
                }

                return usuarios.Union(usuariosBaseAuth).ToList();
            }
            catch (System.Exception)
            {
                throw;
            }
        }

        public bool SalvarUsuarioPerfil(UsuarioPerfilRequest usuarioPerfilRequest)
        {
            var usuario = _usuarioRepository.GetById(usuarioPerfilRequest.IdUsuario, x => x.UsuarioPerfil, x => x.UsuarioFuncionalidade);
            var usuarioPerfil = _usuarioPerfilRepository.ListBy(x => x.UsuarioId == usuario.Id).ToList();

            var perfis = new List<Perfil>();
            var listaUsuarioPerfil = new List<UsuarioPerfil>();

            foreach (var userPerfil in usuarioPerfil)
            {
                _usuarioPerfilRepository.Delete(userPerfil.Id);
            }

            usuario.UsuarioPerfil.Clear();
            _usuarioRepository.Update(usuario);

            foreach (var idPerfil in usuarioPerfilRequest.Perfis)
            {
                var perfil = _perfilRepository.GetById(idPerfil);

                perfis.Add(perfil);

                listaUsuarioPerfil.Add(new UsuarioPerfil
                {
                    UsuarioId = usuario.Id,
                    PerfilId = idPerfil,
                    Usuario = usuario,
                    Perfil = perfil
                });
            }

            if (listaUsuarioPerfil.Count() > 0)
            {
                usuario.UsuarioPerfil = listaUsuarioPerfil;

                _usuarioRepository.Update(usuario);
            }

            return true;
        }

        public object SalvarUsuarioFuncionalidade(UsuarioFuncionalidadeRequest usuarioFuncionalidadeRequest)
        {
            try
            {
                if (usuarioFuncionalidadeRequest.IdUsuario > 0)
                {
                    var usuario = _usuarioRepository.GetById(usuarioFuncionalidadeRequest.IdUsuario, x => x.UsuarioPerfil, x => x.UsuarioFuncionalidade);
                    var usuarioFuncionalidade = _usuarioFuncionalidadeRepository.ListBy(x => x.UsuarioId == usuario.Id).ToList();

                    var funcionalidades = new List<Funcionalidade>();
                    var listaUsuarioFuncionalidade = new List<UsuarioFuncionalidade>();

                    foreach (var userFuncionalidade in usuarioFuncionalidade)
                    {
                        _usuarioFuncionalidadeRepository.Delete(userFuncionalidade.Id);
                    }

                    usuario.UsuarioFuncionalidade.Clear();
                    _usuarioRepository.Update(usuario);

                    foreach (var idFuncionalidade in usuarioFuncionalidadeRequest.Funcionalidades.Distinct())
                    {
                        var funcionalidade = _funcionalidadeRepository.GetById(idFuncionalidade);

                        funcionalidades.Add(funcionalidade);

                        listaUsuarioFuncionalidade.Add(new UsuarioFuncionalidade
                        {
                            UsuarioId = usuario.Id,
                            FuncionalidadeId = idFuncionalidade,
                            Usuario = usuario,
                            Funcionalidade = funcionalidade
                        });
                    }

                    if (listaUsuarioFuncionalidade.Count() > 0)
                    {
                        usuario.UsuarioFuncionalidade = listaUsuarioFuncionalidade;

                        _usuarioRepository.Update(usuario);
                    }
                }
                else
                {
                    var usuario = new Usuario()
                    {
                        Nome = usuarioFuncionalidadeRequest.Nome,
                        UsuarioAd = usuarioFuncionalidadeRequest.UsuarioAD,
                        Ativo = true
                    };

                    _usuarioRepository.Insert(usuario);

                    usuario = _usuarioRepository.GetBy(x => x.UsuarioAd == usuarioFuncionalidadeRequest.UsuarioAD);

                    var funcionalidades = new List<Funcionalidade>();
                    var listaUsuarioFuncionalidade = new List<UsuarioFuncionalidade>();

                    foreach (var idFuncionalidade in usuarioFuncionalidadeRequest.Funcionalidades.Distinct())
                    {
                        var funcionalidade = _funcionalidadeRepository.GetById(idFuncionalidade);

                        funcionalidades.Add(funcionalidade);

                        listaUsuarioFuncionalidade.Add(new UsuarioFuncionalidade
                        {
                            UsuarioId = usuario.Id,
                            FuncionalidadeId = idFuncionalidade,
                            Usuario = usuario,
                            Funcionalidade = funcionalidade
                        });
                    }

                    if (listaUsuarioFuncionalidade.Count() > 0)
                    {
                        usuario.UsuarioFuncionalidade = listaUsuarioFuncionalidade;

                        _usuarioRepository.Update(usuario);
                    }
                }

                return new { Status = HttpStatusCode.OK, Result = "Salvo com sucesso" }; 
            }
            catch (System.Exception ex)
            {
                throw;
            }
        }
    }
}