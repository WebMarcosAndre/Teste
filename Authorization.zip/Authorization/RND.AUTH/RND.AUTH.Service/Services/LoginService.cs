﻿using RND.AUTH.Domain.DTOs;
using RND.AUTH.Domain.Interfaces.Services;
using RND.AUTH.Service.Utils;
using RND.AUTH.Service.Validators;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Net;
using System.Text;

namespace RND.AUTH.Service.Services
{
    public class LoginService : ILoginService
    {
        public object AutenticarUsuarioAD(Acesso usuario)
        {
            var validator = new AcessoValidator();
            var resultValidator = validator.Validate(usuario);

            if (resultValidator.IsValid)
            {
                bool autenticado = false;

                using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, usuario.Dominio))
                {
                    if(usuario.TipoEncodeSenha == "Unicode")
                        autenticado = pc.ValidateCredentials(usuario.Login, CriptografiaAES.DescriptografarUnicode(usuario.Senha, usuario.Chave));
                    else
                        autenticado = pc.ValidateCredentials(usuario.Login, CriptografiaAES.DescriptografarBigEndianUnicode(usuario.Senha, usuario.Chave));
                }

                if (!autenticado) return new { Status = HttpStatusCode.BadRequest, Result = "Usuário ou senha inválido" };
                else return new { Status = HttpStatusCode.OK, Result = "Autenticado com sucesso" };
            }
            else
                return new { Status = HttpStatusCode.BadRequest, Result = resultValidator.Errors.FirstOrDefault().ErrorMessage };
        }
    }
}
