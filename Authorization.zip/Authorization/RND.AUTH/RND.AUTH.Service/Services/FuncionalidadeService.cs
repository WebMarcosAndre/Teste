﻿using System.Collections.Generic;
using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Interfaces.Repositories;
using RND.AUTH.Domain.Interfaces.Services;
using RND.AUTH.Service.Base;
using System.Linq;
using RND.AUTH.Infra.Data.Transactions;

namespace RND.AUTH.Service.Services
{
    public class FuncionalidadeService : BaseService<Funcionalidade>, IFuncionalidadeService
    {
        private readonly IFuncionalidadeRepository _funcionalidadeRepository;
        private readonly IMenuFuncionalidadeRepository _menuFuncionalidadeRepository;
        private readonly IMenuRepository _menuRepository;
        private readonly IUnitOfWork _unitOfWork;

        public FuncionalidadeService(IUnitOfWork unitOfWork, 
                                     IFuncionalidadeRepository funcionalidadeRepository, 
                                     IMenuFuncionalidadeRepository menuFuncionalidadeRepository,
                                     IMenuRepository menuRepository)
        {
            _unitOfWork = unitOfWork;
            _funcionalidadeRepository = funcionalidadeRepository;
            _menuFuncionalidadeRepository = menuFuncionalidadeRepository;
            _menuRepository = menuRepository;
        }

        public IEnumerable<Funcionalidade> ListarPorSistema(int sistemaId)
        {
           return _funcionalidadeRepository.ListBy(x=>x.SistemaId == sistemaId).ToList();
        }

        public IEnumerable<Menu> ListarMenuPorSistema(int sistemaId)
        {
            var listaMenu = _menuRepository.ListarMenuHierarquia(sistemaId);

            return listaMenu;
        }
    }
}