﻿using System;
using FluentValidation;
using RND.AUTH.Domain.DTOs;

namespace RND.AUTH.Service.Validators
{
    public class AcessoValidator : AbstractValidator<Acesso>
    {
        public AcessoValidator()
        {
            PreenchimentoValidator();
        }

        public void PreenchimentoValidator()
        {
            RuleFor(c => c)
                .NotNull()
                .OnAnyFailure(x =>
                {
                    throw new ArgumentNullException("Não é possível encontrar o objeto!");
                });

            RuleFor(c => c.Login)
                .NotEmpty().WithMessage("Informar o login")
                .NotNull().WithMessage("Informar o login");

            RuleFor(c => c.Senha)
                .NotEmpty().WithMessage("Informar a senha")
                .NotNull().WithMessage("Informar a senha");

            RuleFor(c => c.Chave)
                .NotEmpty().WithMessage("Informar a chave")
                .NotNull().WithMessage("Informar a chave");

            RuleFor(c => c.Dominio)
                .NotEmpty().WithMessage("Informar o domínio")
                .NotNull().WithMessage("Informar o domínio");

        }
    }
}
