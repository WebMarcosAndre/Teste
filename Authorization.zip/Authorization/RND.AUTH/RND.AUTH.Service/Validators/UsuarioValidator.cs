﻿using FluentValidation;
using RND.AUTH.Domain.Entities;
using System;

namespace RND.AUTH.Service.Validators
{
    public class UsuarioValidator : AbstractValidator<Usuario>
    {
        public UsuarioValidator() {
            PreenchimentoValidator();
        }

        public void PreenchimentoValidator()
        {
            RuleFor(c => c)
                    .NotNull()
                    .OnAnyFailure(x =>
                    {
                        throw new ArgumentNullException("Não é possível encontrar o objeto!");
                    });

            RuleFor(c => c.UsuarioAd)
                .NotEmpty().WithMessage("Informar UsuarioAD")
                .NotNull().WithMessage("Informar UsuarioAD.");
        }
    }
}