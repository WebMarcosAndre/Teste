﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Entities.Elmah_Error;
using System.Linq;


namespace RND.AUTH.Infra.Data.Context
{
    public class SqlContext : DbContext
    {
        public SqlContext()
        {
        }

        public SqlContext(DbContextOptions<SqlContext> options) : base(options)
        {
        }

        public DbSet<Area> Area { get; set; }

        public DbSet<Auditoria> Auditoria { get; set; }

        public DbSet<Funcionalidade> Funcionalidade { get; set; }

        public virtual DbSet<Menu> Menu { get; set; }

        public virtual DbSet<MenuFuncionalidade> MenuFuncionalidade { get; set; }

        public DbSet<Perfil> Perfil { get; set; }

        public DbSet<PerfilFuncionalidade> PerfilFuncionalidade { get; set; }

        public DbSet<Sistema> Sistema { get; set; }

        public DbSet<Usuario> Usuario { get; set; }

        public DbSet<UsuarioFuncionalidade> UsuarioFuncionalidade { get; set; }

        public DbSet<UsuarioPerfil> UsuarioPerfil { get; set; }

        public DbSet<ELMAH_Error> Elmah_Error { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder().Build();
                optionsBuilder.UseSqlServer("Server=REND-SRVDSQL-01; Database=dbCorpAuthorization; Trusted_Connection=True; MultipleActiveResultSets=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Area>(entity =>
            {
                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(70)
                    .IsUnicode(false);

                entity.HasOne(d => d.Coordenador)
                    .WithMany(p => p.Area)
                    .HasForeignKey(d => d.CoordenadorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_area_usuario");
            });

            modelBuilder.Entity<Auditoria>(entity =>
            {
                entity.Property(e => e.Acao)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Data).HasColumnType("datetime");

                entity.Property(e => e.De)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Entidade)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EntidadeDescricao)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Para)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UsuarioAd)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Funcionalidade>(entity =>
            {
                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.Sistema)
                    .WithMany(p => p.Funcionalidade)
                    .HasForeignKey(d => d.SistemaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_sistema_funcionalidade");
            });

            modelBuilder.Entity<Menu>(entity =>
            {
                entity.Property(e => e.CaminhoMenu)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PaginaAcesso)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<MenuFuncionalidade>(entity =>
            {
                entity.HasOne(d => d.Funcionalidade)
                    .WithMany(p => p.MenuFuncionalidade)
                    .HasForeignKey(d => d.FuncionalidadeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_funcionalidade_menu");

                entity.HasOne(d => d.Menu)
                    .WithMany(p => p.MenuFuncionalidade)
                    .HasForeignKey(d => d.MenuId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_menufuncionalidade_menuId");
            });

            modelBuilder.Entity<Perfil>(entity =>
            {
                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PerfilFuncionalidade>(entity =>
            {
                entity.HasOne(d => d.Funcionalidade)
                    .WithMany(p => p.PerfilFuncionalidade)
                    .HasForeignKey(d => d.FuncionalidadeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_funcionalidade_perfil");

                entity.HasOne(d => d.Perfil)
                    .WithMany(p => p.PerfilFuncionalidade)
                    .HasForeignKey(d => d.PerfilId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_perfil_funcionalidade");
            });

            modelBuilder.Entity<Sistema>(entity =>
            {
                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(70)
                    .IsUnicode(false);

                entity.Property(e => e.Versao)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(70)
                    .IsUnicode(false);

                entity.Property(e => e.UsuarioAd)
                    .IsRequired()
                    .HasColumnName("UsuarioAD")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<UsuarioFuncionalidade>(entity =>
            {
                entity.HasOne(d => d.Funcionalidade)
                    .WithMany(p => p.UsuarioFuncionalidade)
                    .HasForeignKey(d => d.FuncionalidadeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_funcionalidade_usuario");

                entity.HasOne(d => d.Usuario)
                    .WithMany(p => p.UsuarioFuncionalidade)
                    .HasForeignKey(d => d.UsuarioId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_usuario_funcionalidade");
            });

            modelBuilder.Entity<UsuarioPerfil>(entity =>
            {
                entity.HasOne(d => d.Perfil)
                    .WithMany(p => p.UsuarioPerfil)
                    .HasForeignKey(d => d.PerfilId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_perfil_usuario");

                entity.HasOne(d => d.Usuario)
                    .WithMany(p => p.UsuarioPerfil)
                    .HasForeignKey(d => d.UsuarioId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_usuario_perfil");
            });
        }

        public void DetachLocal<T>(T t, int entryId) where T : BaseEntity
        {
            var local = this.Set<T>().Local.FirstOrDefault(entry => entry.Id == entryId);

            if (local != null)
            {
                this.Entry(local).State = EntityState.Detached;
            }
            this.Entry(t).State = EntityState.Modified;
        }
    }
}