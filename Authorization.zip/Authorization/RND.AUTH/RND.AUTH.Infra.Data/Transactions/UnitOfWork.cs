﻿using RND.AUTH.Infra.Data.Context;


namespace RND.AUTH.Infra.Data.Transactions
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly SqlContext _sqlContext;

        public UnitOfWork(SqlContext sqlContext)
        {
            _sqlContext = sqlContext;
        }

        public void Commit()
        {
            _sqlContext.SaveChanges();
        }

        public void Dispose()
        {
            _sqlContext.Dispose();
        }
    }
}