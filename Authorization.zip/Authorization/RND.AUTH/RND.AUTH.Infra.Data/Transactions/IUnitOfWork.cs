﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.AUTH.Infra.Data.Transactions
{
    public interface IUnitOfWork : IDisposable
    {
        void Commit();
    }
}
