﻿using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Interfaces.Repositories;
using RND.AUTH.Infra.Data.Context;

namespace RND.AUTH.Infra.Data.Repository
{
    public class PerfilRepository : BaseRepository<Perfil, int>, IPerfilRepository
    {
        protected readonly SqlContext _sqlContext;

        public PerfilRepository(SqlContext sqlContext) : base(sqlContext)
        {
            _sqlContext = sqlContext;
        }
    }
}
