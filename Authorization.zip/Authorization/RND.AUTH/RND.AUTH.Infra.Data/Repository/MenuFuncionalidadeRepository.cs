﻿using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Interfaces.Repositories;
using RND.AUTH.Infra.Data.Context;

namespace RND.AUTH.Infra.Data.Repository
{
    public class MenuFuncionalidadeRepository : BaseRepository<MenuFuncionalidade, int>, IMenuFuncionalidadeRepository
    {
        protected readonly SqlContext _sqlContext;

        public MenuFuncionalidadeRepository(SqlContext sqlContext) : base(sqlContext)
        {
            _sqlContext = sqlContext;
        }
    }
}
