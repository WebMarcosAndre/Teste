﻿using RND.AUTH.Domain.DTOs;
using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Interfaces.Repositories;
using RND.AUTH.Infra.Data.Context;
using System.Collections.Generic;
using System.Linq;

namespace RND.AUTH.Infra.Data.Repository
{
    public class FuncionalidadeRepository : BaseRepository<Funcionalidade, int>, IFuncionalidadeRepository
    {
        protected readonly SqlContext _sqlContext;

        public FuncionalidadeRepository(SqlContext sqlContext) : base(sqlContext)
        {
            _sqlContext = sqlContext;
        }

        public IEnumerable<object> BuscarFuncionalidadesPerfil(int sistemaId)
        {
            var listaRetorno = (from t1 in _sqlContext.Perfil
                                       join t2 in _sqlContext.PerfilFuncionalidade on t1.Id equals t2.PerfilId
                                       join t3 in _sqlContext.Funcionalidade on t2.FuncionalidadeId equals t3.Id
                                       where t3.SistemaId == sistemaId && t1.Ativo
                                       select new PerfilFuncionalidadeResponse
                                       {
                                           IdPerfil = t1.Id,
                                           NomePerfil = t1.Nome
                                       }).Distinct().ToList();

            for (int i = 0; i < listaRetorno.Count(); i++)
            {
                listaRetorno[i].Funcionalidades = (from tb1 in _sqlContext.Funcionalidade
                                                   join tb2 in _sqlContext.PerfilFuncionalidade on tb1.Id equals tb2.FuncionalidadeId
                                                   join tb3 in _sqlContext.Perfil on tb2.PerfilId equals tb3.Id
                                                   where tb3.Id == listaRetorno[i].IdPerfil
                                                   select new Funcionalidade
                                                   {
                                                       Id = tb1.Id,
                                                       Nome = tb1.Nome
                                                   }).ToList();
            }
            
            return listaRetorno;
        }
    }
}
