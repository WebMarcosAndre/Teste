﻿using Microsoft.EntityFrameworkCore;
using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Interfaces.Repositories;
using RND.AUTH.Infra.Data.Context;
using System.Collections.Generic;
using System.Linq;

namespace RND.AUTH.Infra.Data.Repository
{
    public class MenuRepository : BaseRepository<Menu, int>, IMenuRepository
    {
        protected readonly SqlContext _sqlContext;

        public MenuRepository(SqlContext sqlContext) : base(sqlContext)
        {
            _sqlContext = sqlContext;
        }

        public List<Menu> ListarMenuHierarquia(int idSistema)
        {
            var listaMenus = (from t1 in _sqlContext.Menu.Include("MenuFuncionalidade").Include("MenuFuncionalidade.Funcionalidade")
                              join t2 in _sqlContext.MenuFuncionalidade on t1.Id equals t2.MenuId
                              join t3 in _sqlContext.Funcionalidade on t2.FuncionalidadeId equals t3.Id
                              where t3.SistemaId == idSistema
                              select t1).Distinct().ToList();

            return listaMenus;
        }
    }
}
