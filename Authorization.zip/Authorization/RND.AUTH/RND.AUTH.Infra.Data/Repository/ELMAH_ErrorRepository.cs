﻿using RND.AUTH.Domain.Entities.Elmah_Error;
using RND.AUTH.Domain.Interfaces.Repositories;

using RND.AUTH.Infra.Data.Context;

namespace RND.AUTH.Infra.Data.Repository
{
    public class ELMAH_ErrorRepository : BaseRepository<ELMAH_Error, int>, IELMAH_ErrorRepository
    {
        protected readonly SqlContext _context;

        #region Construtor

        public ELMAH_ErrorRepository(SqlContext context) : base(context)
        {
            _context = context;
        }

        #endregion

    }
}
