﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Interfaces.Repositories;
using RND.AUTH.Infra.Data.Context;

namespace RND.AUTH.Infra.Data.Repository
{
    public class UsuarioRepository : BaseRepository<Usuario, int>, IUsuarioRepository
    {
        protected readonly SqlContext _context;

        public UsuarioRepository(SqlContext context) : base(context)
        {
            _context = context;
        }

        public Usuario BuscarUsuario(string usuarioAD)
        {
            var usuario = _context.Usuario
                .Include("UsuarioFuncionalidade.Funcionalidade")
                .Include("UsuarioPerfil.Perfil")
                .FirstOrDefault(x => x.UsuarioAd == usuarioAD);

            return usuario;
        }
    }
}
