﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace RND.AUTH.Domain.Entities
{
    public class Menu : BaseEntity
    {
        public Menu()
        {
            MenuFuncionalidade = new HashSet<MenuFuncionalidade>();
        }

        public string Nome { get; set; }
        public string CaminhoMenu { get; set; }
        public string PaginaAcesso { get; set; }
                
        public ICollection<MenuFuncionalidade> MenuFuncionalidade { get; set; }
    }
}
