﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace RND.AUTH.Domain.Entities
{
    public class Funcionalidade : BaseEntity
    {
        public Funcionalidade()
        {
            MenuFuncionalidade = new HashSet<MenuFuncionalidade>();
            PerfilFuncionalidade = new HashSet<PerfilFuncionalidade>();
            UsuarioFuncionalidade = new HashSet<UsuarioFuncionalidade>();
        }

        public int SistemaId { get; set; }
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public bool Ativo { get; set; }

        public Sistema Sistema { get; set; }

        [JsonIgnore]
        public ICollection<MenuFuncionalidade> MenuFuncionalidade { get; set; }
        [JsonIgnore]
        public ICollection<PerfilFuncionalidade> PerfilFuncionalidade { get; set; }
        [JsonIgnore]
        public ICollection<UsuarioFuncionalidade> UsuarioFuncionalidade { get; set; }
    }
}
