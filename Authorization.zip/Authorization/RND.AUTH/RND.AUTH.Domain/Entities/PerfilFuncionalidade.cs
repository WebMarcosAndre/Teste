﻿

using Newtonsoft.Json;

namespace RND.AUTH.Domain.Entities
{
    public class PerfilFuncionalidade : BaseEntity
    {
        public int PerfilId { get; set; }
        public int FuncionalidadeId { get; set; }

        [JsonIgnore]
        public Funcionalidade Funcionalidade { get; set; }

        public Perfil Perfil { get; set; }
    }
}
