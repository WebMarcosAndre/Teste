﻿using Newtonsoft.Json;

namespace RND.AUTH.Domain.Entities
{
    public class MenuFuncionalidade : BaseEntity
    {
        public int MenuId { get; set; }
        public int FuncionalidadeId { get; set; }

        public Funcionalidade Funcionalidade { get; set; }

        [JsonIgnore]
        public Menu Menu { get; set; }
    }
}
