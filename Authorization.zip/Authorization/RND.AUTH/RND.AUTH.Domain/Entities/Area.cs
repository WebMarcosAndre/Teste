﻿
using Newtonsoft.Json;

namespace RND.AUTH.Domain.Entities
{
    public class Area : BaseEntity
    {
        public string Nome { get; set; }
        public int CoordenadorId { get; set; }
        public bool Ativo { get; set; }

        [JsonIgnore]
        public Usuario Coordenador { get; set; }    
    }
}
