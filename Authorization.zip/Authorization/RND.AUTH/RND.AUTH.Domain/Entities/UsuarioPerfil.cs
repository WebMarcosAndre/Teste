﻿
using Newtonsoft.Json;

namespace RND.AUTH.Domain.Entities
{
    public class UsuarioPerfil : BaseEntity
    {
        public int UsuarioId { get; set; }
        public int PerfilId { get; set; }

        public Perfil Perfil { get; set; }

        [JsonIgnore]
        public Usuario Usuario { get; set; }
    }
}
