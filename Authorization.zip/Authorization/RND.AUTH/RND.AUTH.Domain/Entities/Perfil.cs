﻿
using Newtonsoft.Json;
using System.Collections.Generic;

namespace RND.AUTH.Domain.Entities
{
    public class Perfil : BaseEntity
    {
        public Perfil()
        {
            PerfilFuncionalidade = new HashSet<PerfilFuncionalidade>();
            UsuarioPerfil = new HashSet<UsuarioPerfil>();
        }

        public string Nome { get; set; }
        public bool Ativo { get; set; }

        [JsonIgnore]
        public ICollection<PerfilFuncionalidade> PerfilFuncionalidade { get; set; }
        [JsonIgnore]
        public ICollection<UsuarioPerfil> UsuarioPerfil { get; set; }
    }
}
