﻿
namespace RND.AUTH.Domain.Entities
{
    public class Acesso : BaseEntity
    {
        public string Dominio { get; set; }
        public string Login { get; set; }
        public string Senha { get; set; }
        public string Chave { get; set; }
    }
}
