﻿using System.Collections.Generic;

namespace RND.AUTH.Domain.Entities
{
    public class Sistema : BaseEntity
    {
        public Sistema()
        {
            Funcionalidade = new HashSet<Funcionalidade>();
        }

        public string Nome { get; set; }
        public string Descricao { get; set; }
        public string Versao { get; set; }
        public bool Ativo { get; set; }

        public ICollection<Funcionalidade> Funcionalidade { get; set; }
    }
}

