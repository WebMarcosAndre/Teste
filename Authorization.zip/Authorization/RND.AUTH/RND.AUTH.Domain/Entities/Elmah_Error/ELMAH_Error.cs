﻿using System;

using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using RND.AUTH.Domain.Arguments.Elmah_Error;


namespace RND.AUTH.Domain.Entities.Elmah_Error
{
    public class ELMAH_Error : BaseEntity
    {
        #region Construtor

        public ELMAH_Error()
        {

        }

        #endregion

        #region Métodos

        public static explicit operator ELMAH_Error(ELMAH_ErrorResponse v)
        {
            return new ELMAH_Error()
            {
                ErrorId = v.ErrorId,
                Application = v.Application,
                Host = v.Host,
                Type = v.Type,
                Source = v.Source,
                Message = v.Message,
                User = v.User,
                StatusCode = v.StatusCode,
                TimeUtc = v.TimeUtc,
                Id = v.Sequence,
                AllXml = v.AllXml
            };
        }


        #endregion

        #region Propriedades
        public Guid ErrorId { get; private set; }

        public string Application { get; private set; }

        public string Host { get; private set; }

        public string Type { get; private set; }

        public string Source { get; private set; }

        public string Message { get; private set; }

        public string User { get; private set; }

        public int StatusCode { get; private set; }

        public DateTime TimeUtc { get; private set; }
        [Column("Sequence")]
        public int Id { get; set; }

        public string AllXml { get; private set; }
        #endregion

    }
}
