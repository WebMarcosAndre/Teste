﻿
using Newtonsoft.Json;

namespace RND.AUTH.Domain.Entities
{
    public class UsuarioFuncionalidade : BaseEntity
    {
        public int UsuarioId { get; set; }
        public int FuncionalidadeId { get; set; }

        public virtual Funcionalidade Funcionalidade { get; set; }

        [JsonIgnore]
        public virtual Usuario Usuario { get; set; }
    }
}
