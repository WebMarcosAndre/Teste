﻿using System;

namespace RND.AUTH.Domain.Entities
{
    public class Auditoria : BaseEntity
    {
        public string UsuarioAd { get; set; }
        public DateTime Data { get; set; }
        public string Entidade { get; set; }
        public int EntidadeId { get; set; }
        public string EntidadeDescricao { get; set; }
        public string Acao { get; set; }
        public string De { get; set; }
        public string Para { get; set; }
        public string Descricao { get; set; }
    }
}
