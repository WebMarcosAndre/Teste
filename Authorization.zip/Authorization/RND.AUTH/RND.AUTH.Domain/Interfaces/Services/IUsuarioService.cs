﻿using RND.AUTH.Domain.DTOs;
using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Services;
using System.Collections.Generic;

namespace RND.AUTH.Domain.Interfaces.Services
{
    public interface IUsuarioService : IBaseService<Usuario>
    {
        object ObterUsuarioPorUsuarioAD(string usuarioAD);

        List<Usuario> ObterUsuarioPorFiltro(string nome, string usuarioAD);

        List<Usuario> ObterUsuarioADPorFiltro(string nome, string usuarioAD, string dominio);

        bool SalvarUsuarioPerfil(UsuarioPerfilRequest usuarioPerfilFuncionalidade);

        object SalvarUsuarioFuncionalidade(UsuarioFuncionalidadeRequest usuarioFuncionalidadeRequest);
    }
}