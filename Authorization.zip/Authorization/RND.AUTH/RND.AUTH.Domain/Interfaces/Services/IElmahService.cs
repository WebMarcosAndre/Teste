﻿using RND.AUTH.Domain.Arguments.Elmah_Error;
using System;
using System.Collections.Generic;


namespace RND.AUTH.Domain.Interfaces.Services
{
    public interface IElmahService
    {
        void ResponseExceptionAsync(Exception ex);
        IEnumerable<ELMAH_ErrorRequest> ListarTodos();
        Result<ELMAH_ErrorRequest> ObterLog(DateTime dataDe, DateTime dataAte, int pagina, int itensPorPagina, int draw);
        ELMAH_ErrorRequest ObterPor(int id);
    }
}
