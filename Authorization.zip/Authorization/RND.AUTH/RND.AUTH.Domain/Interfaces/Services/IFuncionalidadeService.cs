﻿using System.Collections.Generic;
using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Services;

namespace RND.AUTH.Domain.Interfaces.Services
{
    public interface IFuncionalidadeService : IBaseService<Funcionalidade>
    {
        IEnumerable<Funcionalidade> ListarPorSistema(int sistemaId);

        IEnumerable<Menu> ListarMenuPorSistema(int sistemaId);
    }
}
