﻿using RND.AUTH.Domain.DTOs;

namespace RND.AUTH.Domain.Interfaces.Services
{
    public interface ILoginService
    {
        object AutenticarUsuarioAD(Acesso usuario);
    }
}
