﻿namespace RND.AUTH.Domain.Interfaces.Validator
{
    public interface IValidate<TRequest>
    {
        TRequest Validacao(TRequest request);
    }
}
