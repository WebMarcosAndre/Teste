﻿using RND.AUTH.Domain.Entities.Elmah_Error;
using RND.AUTH.Domain.Interfaces.Repositories.Base;


namespace RND.AUTH.Domain.Interfaces.Repositories
{
    public interface IELMAH_ErrorRepository : IBaseRepository<ELMAH_Error, int>
    {
        
    }
}
