﻿using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Interfaces.Repositories.Base;
using System.Collections.Generic;

namespace RND.AUTH.Domain.Interfaces.Repositories
{
    public interface IFuncionalidadeRepository : IBaseRepository<Funcionalidade, int>
    {
        IEnumerable<object> BuscarFuncionalidadesPerfil(int sistemaId);
    }
}