﻿using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Interfaces.Repositories.Base;

namespace RND.AUTH.Domain.Interfaces.Repositories
{
    public interface IMenuFuncionalidadeRepository : IBaseRepository<MenuFuncionalidade, int>
    {
    }
}