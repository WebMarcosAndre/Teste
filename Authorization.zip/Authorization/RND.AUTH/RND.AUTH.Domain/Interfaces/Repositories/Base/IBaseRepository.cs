﻿using System;

using System.Linq;
using System.Linq.Expressions;

namespace RND.AUTH.Domain.Interfaces.Repositories.Base
{
    public interface IBaseRepository<TEntidade, TId> where TEntidade : class where TId : struct
    {
        IQueryable<TEntidade> ListBy(Expression<Func<TEntidade, bool>> where, params Expression<Func<TEntidade, object>>[] includeProperties);
        IQueryable<TEntidade> List(params Expression<Func<TEntidade, object>>[] includeProperties);
        TEntidade GetBy(Func<TEntidade, bool> where, params Expression<Func<TEntidade, object>>[] includeProperties);
        TEntidade GetById(TId id, params Expression<Func<TEntidade, object>>[] includeProperties);
        void Update(TEntidade entidade);
        void Insert(TEntidade entidade);
        void Delete(int id);
    }
}