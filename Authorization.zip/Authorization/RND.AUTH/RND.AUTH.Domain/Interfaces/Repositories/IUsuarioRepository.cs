﻿using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Interfaces.Repositories.Base;

namespace RND.AUTH.Domain.Interfaces.Repositories
{
    public interface IUsuarioRepository : IBaseRepository<Usuario, int>
    {
        Usuario BuscarUsuario(string usuarioAD);
    }
}
