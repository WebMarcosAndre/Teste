﻿using RND.AUTH.Domain.Entities;
using RND.AUTH.Domain.Interfaces.Repositories.Base;
using System.Collections.Generic;

namespace RND.AUTH.Domain.Interfaces.Repositories
{
    public interface IMenuRepository : IBaseRepository<Menu, int>
    {
        List<Menu> ListarMenuHierarquia(int idSistema);
    }
}