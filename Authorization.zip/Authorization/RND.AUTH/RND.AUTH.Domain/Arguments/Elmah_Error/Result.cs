﻿using System.Collections.Generic;

namespace RND.AUTH.Domain.Arguments.Elmah_Error
{
    public class Result<T>
    {
        public int Draw { get; set; }
        public int RecordsTotal { get; set; }
        public int RecordsFiltered { get; set; }
        public List<T> data { get; set; }
    }
}
