﻿using System;
using RND.AUTH.Domain.Entities.Elmah_Error;

namespace RND.AUTH.Domain.Arguments.Elmah_Error
{
    public class ELMAH_ErrorResponse
    {
        #region Propriedades

        public Guid ErrorId { get; set; }
        public string Application { get; set; }
        public string Host { get; set; }
        public string Type { get; set; }
        public string Source { get; set; }
        public string Message { get; set; }
        public string User { get; set; }
        public int StatusCode { get; set; }
        public DateTime TimeUtc { get; set; }
        public int Sequence { get; set; }
        public string AllXml { get; set; }

        #endregion

        #region Métodos

        public static explicit operator ELMAH_ErrorResponse(ELMAH_Error v)
        {
            return new ELMAH_ErrorResponse()
            {
                ErrorId = v.ErrorId,
                Application = v.Application,
                Host = v.Host,
                Type = v.Type,
                Source = v.Source,
                Message = v.Message,
                User = v.User,
                StatusCode  = v.StatusCode,
                TimeUtc = v.TimeUtc,
                Sequence = v.Id,
                AllXml = v.AllXml
            };
        }

        #endregion
    }
}
