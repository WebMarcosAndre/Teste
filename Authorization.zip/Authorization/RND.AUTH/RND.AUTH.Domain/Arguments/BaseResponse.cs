﻿
using System.Collections.Generic;


namespace RND.AUTH.Domain.Arguments
{
    public abstract class BaseResponse
    {
        public BaseResponse()
        {
            Errors = new List<string>();
            IsValid = true;
        }
        public IList<string> Errors { get; set; }

        public bool IsValid { get; set; }


        public void AddIsValid(bool isValid)
        {
            IsValid = isValid;
        }

        public void AddError(string errorMessage)
        {
            Errors.Add(errorMessage);
        }
    }
}
