﻿

namespace RND.AUTH.Domain.Arguments.Login
{
    public class AcessoRequest
    {
        public string Dominio { get; set; }
        public string Login { get; set; }
        public string Senha { get; set; }
        public string Chave { get; set; }

        public static explicit operator AcessoRequest(AcessoResponse v)
        {
            return new AcessoRequest()
            {
                Dominio = v.Dominio,
                Login = v.Login,
                Senha = v.Senha,
                Chave = v.Chave
            };
        }
    }
}
