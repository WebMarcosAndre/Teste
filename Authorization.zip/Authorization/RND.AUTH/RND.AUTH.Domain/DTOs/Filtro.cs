﻿namespace RND.AUTH.Domain.DTOs
{
    public class Filtro
    {
        public string Nome { get; set; }

        public string UsuarioAD { get; set; }
    }
}
