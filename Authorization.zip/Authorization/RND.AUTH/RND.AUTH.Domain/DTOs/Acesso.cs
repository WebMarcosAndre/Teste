﻿using RND.AUTH.Domain.Entities;

namespace RND.AUTH.Domain.DTOs
{
    public class Acesso : BaseEntity
    {
        public string Dominio { get; set; }
        public string Login { get; set; }
        public string Senha { get; set; }
        public string TipoEncodeSenha { get; set; }
        public string Chave { get; set; }
    }
}
