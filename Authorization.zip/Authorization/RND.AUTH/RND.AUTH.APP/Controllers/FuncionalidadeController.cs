﻿
using System.Net;
using Microsoft.AspNetCore.Mvc;
using RND.AUTH.APP.Filters;
using RND.AUTH.Domain.Interfaces.Services;
using RND.AUTH.Infra.Data.Transactions;

namespace RND.AUTH.APP.Controllers
{
    [Route("api/[controller]")]
    public class FuncionalidadeController : Controller
    {
        private readonly IFuncionalidadeService _funcionalidadeService;
        private readonly IElmahService _elmahService;
        protected readonly IUnitOfWork _unitOfWork;
        public FuncionalidadeController(IUnitOfWork unitOfWork, IFuncionalidadeService funcionalidadeService, IElmahService elmahService)
        {
            _funcionalidadeService = funcionalidadeService;
            _elmahService = elmahService;
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ServiceFilter(typeof(AuthorizationActionFilter))]
        [Route("Listar")]
        public ActionResult Listar(int idSistema)
        {
            try
            {
                return Ok(_funcionalidadeService.ListarPorSistema(idSistema));
            }
            catch (System.Exception ex)
            {
                _elmahService.ResponseExceptionAsync(ex);
                return BadRequest(new { Status = HttpStatusCode.InternalServerError, Result = $"{ex.Message}" });
            }
        }

        [HttpGet]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ServiceFilter(typeof(AuthorizationActionFilter))]
        [Route("ListarHierarquia")]
        public ActionResult ListarHierarquia(int idSistema)
        {
            try
            {
                var lista = _funcionalidadeService.ListarMenuPorSistema(idSistema);

                return Ok(lista);
            }
            catch (System.Exception ex)
            {
                _elmahService.ResponseExceptionAsync(ex);
                return BadRequest(new { Status = HttpStatusCode.InternalServerError, Result = $"{ex.Message}" });
            }
        }
    }
}