﻿using Microsoft.AspNetCore.Mvc;
using RND.AUTH.APP.Filters;
using RND.AUTH.Domain.DTOs;
using RND.AUTH.Domain.Interfaces.Services;
using System;
using System.Net;


namespace RND.AUTH.APP.Controllers
{
    [Route("api/[controller]")]
    public class LoginController : Controller
    {
        private readonly ILoginService _loginService;
        private readonly IElmahService _elmahService;

        public LoginController(ILoginService loginService, IElmahService elmahService)
        {
            _loginService = loginService;
            _elmahService = elmahService;
        }

        // GET api/login
        [HttpPost] 
        [Route("Autenticar")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ServiceFilter(typeof(AuthorizationActionFilter))]
        public ActionResult Autenticar([FromBody]Acesso usuarioAcesso)
        {
            try
            {
                return Ok(_loginService.AutenticarUsuarioAD(usuarioAcesso));
            }

            catch (System.Security.Cryptography.CryptographicException ex)
            {
                return BadRequest(new { Status = HttpStatusCode.UnsupportedMediaType, Result = $"{ex.Message}" });
            }

            catch (System.DirectoryServices.AccountManagement.PrincipalServerDownException ex)
            {
                _elmahService.ResponseExceptionAsync(ex);
                return BadRequest(new { Status = HttpStatusCode.BadRequest, Result = $"Ocorreu um erro ao conectar na rede: {usuarioAcesso.Dominio}. Favor, entre em contato com o administrador." });
            }
            catch (Exception ex)
            {
                _elmahService.ResponseExceptionAsync(ex);
                return BadRequest(new { Status = HttpStatusCode.InternalServerError, Result = $"{ex.Message}" });
            }            
        }
    }
}
