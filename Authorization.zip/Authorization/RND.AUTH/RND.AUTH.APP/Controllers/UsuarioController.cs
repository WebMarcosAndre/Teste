﻿using Microsoft.AspNetCore.Mvc;
using RND.AUTH.APP.Filters;
using RND.AUTH.Domain.DTOs;
using RND.AUTH.Domain.Interfaces.Services;
using System.Net;

namespace RND.AUTH.APP.Controllers
{
    [Route("api/[controller]")]
    public class UsuarioController : Controller
    {
        private readonly IUsuarioService _usuarioService;
        private readonly IElmahService _elmahService;

        public UsuarioController(IUsuarioService usuarioService, IElmahService elmahService)
        {
            _usuarioService = usuarioService;
            _elmahService = elmahService;
        }

        [HttpGet]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ServiceFilter(typeof(AuthorizationActionFilter))]
        [Route("Buscar")]
        public ActionResult Buscar(string usuarioAD)
        {
            try
            {
                return Ok(_usuarioService.ObterUsuarioPorUsuarioAD(usuarioAD));
            }
            catch (System.Exception ex)
            {
                _elmahService.ResponseExceptionAsync(ex);
                return BadRequest( new { Status = HttpStatusCode.InternalServerError, Result = $"{ex.Message}"});
            }            
        }

        [HttpGet]
        [Route("Filtrar")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ServiceFilter(typeof(AuthorizationActionFilter))]
        public ActionResult Filtrar(string nome, string usuarioAD, string dominio)
        {
            try
            {
                var retornoFiltroUsuarios = _usuarioService.ObterUsuarioADPorFiltro(nome, usuarioAD, dominio);

                return Ok(retornoFiltroUsuarios);
            }
            catch (System.Exception ex)
            {
                _elmahService.ResponseExceptionAsync(ex);
                return BadRequest(new { Status = HttpStatusCode.InternalServerError, Result = $"{ex.Message}" });
            }
        }

        [HttpPost]
        [Route("SalvarPerfil")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ServiceFilter(typeof(AuthorizationActionFilter))]
        public ActionResult SalvarPerfil([FromBody]UsuarioPerfilRequest request)
        {
            try
            {
                var dadosSalvos = _usuarioService.SalvarUsuarioPerfil(request);

                return Ok(dadosSalvos);
            }
            catch (System.Exception ex)
            {
                _elmahService.ResponseExceptionAsync(ex);
                return BadRequest(new { Status = HttpStatusCode.InternalServerError, Result = $"{ex.Message}" });
            }
        }

        [HttpPost]
        [Route("SalvarFuncionalidade")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ServiceFilter(typeof(AuthorizationActionFilter))]
        public ActionResult SalvarFuncionalidade([FromBody]UsuarioFuncionalidadeRequest request)
        {
            try
            {
                var dadosSalvos = _usuarioService.SalvarUsuarioFuncionalidade(request);

                return Ok(dadosSalvos);
            }
            catch (System.Exception ex)
            {
                _elmahService.ResponseExceptionAsync(ex);
                return BadRequest(new { Status = HttpStatusCode.InternalServerError, Result = $"Ocorreu um erro inesperado. Favor, tente novamente mais tarde!" });
            }
        }
    }
}
