﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RND.AUTH.APP.Filters;
using RND.AUTH.Domain.Interfaces.Repositories;
using RND.AUTH.Domain.Interfaces.Services;
using RND.AUTH.Infra.Data.Repository;
using RND.AUTH.Infra.Data.Context;
using RND.AUTH.Service.Services;
using Swashbuckle.AspNetCore.Swagger;
using ElmahCore.Mvc;
using ElmahCore.Sql;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Linq;
using RND.AUTH.Infra.Data.Transactions;

namespace RND.AUTH.APP
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();

            #region Injeção de dependência

            #region UnitOfWork
            services.AddScoped<IUnitOfWork, UnitOfWork>();
            #endregion

            #region Login

            services.AddScoped<ILoginService, LoginService>();

            #endregion

            services.AddScoped<IUsuarioService, UsuarioService>();
            services.AddScoped<IUsuarioRepository, UsuarioRepository>();

            services.AddScoped<IFuncionalidadeService, FuncionalidadeService>();
            services.AddScoped<IFuncionalidadeRepository, FuncionalidadeRepository>();

            services.AddScoped<IMenuFuncionalidadeRepository, MenuFuncionalidadeRepository>();
            services.AddScoped<IMenuRepository, MenuRepository>();

            services.AddScoped<IPerfilRepository, PerfilRepository>();
            services.AddScoped<IUsuarioPerfilRepository, UsuarioPerfilRepository>();
            services.AddScoped<IUsuarioFuncionalidadeRepository, UsuarioFuncionalidadeRepository>();

            #region Elmah
            services.AddScoped<IElmahService, ElmahService>();
            services.AddScoped<IELMAH_ErrorRepository, ELMAH_ErrorRepository>();
            #endregion

            #endregion

            #region Swagger
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    Title = "AUTH API",
                    Description = "Description AUTH API",
                    TermsOfService = "None",

                    Contact = new Contact() { Name = "Authorization", Email = "jefferson.paulo.ext@cotacao.com.br", Url = "www.rendimento.com" }

                });
                c.AddSecurityDefinition("Token",
                     new ApiKeyScheme
                     {
                         In = "header",
                         Description = "Please enter into field the word 'Token' following by space and JWT",
                         Name = "Token",
                         Type = "apiKey"
                     });
                    c.AddSecurityRequirement(new Dictionary<string, IEnumerable<string>> {
                    { "Token", Enumerable.Empty<string>() }
                });
            });
            #endregion

            #region ElmahCore

            services.AddElmah<SqlErrorLog>(options =>
            {
                options.Path = new PathString("/elm");
                options.ConnectionString = options.ConnectionString = Configuration.GetConnectionString("APIAuth");
            });
            #endregion

            #region Filters

            services.AddScoped<AuthorizationActionFilter>();

            #endregion

            services.AddDbContext<SqlContext>(option => option.UseSqlServer(Configuration.GetConnectionString("APIAuth"), opt => opt.UseRowNumberForPaging()));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseMvc();

            #region Swagger

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Authorization API V 1.0");
            });

            #endregion

            #region ElmahCore

            app.UseElmah();

            #endregion
        }
    }

}
