﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rendimento.Portal.CambioOnline.DAO
{
   public class MoedaDAO
    {
        //public TMOEDAS Get() {

        //}
    }
}
