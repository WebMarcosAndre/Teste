﻿using System.Data;
using System.Linq;
using Dapper;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;

namespace Rendimento.Portal.CambioOnline.DAO
{
    public class ClienteDAO : BaseDAO
    {
        public TBL_CLIENTES Get(int idCliente)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<TBL_CLIENTES>(
                $@"SELECT * FROM TBL_CLIENTES (NOLOCK) 
                    WHERE id_cliente = @idCliente
                ", param: new
                {
                    idCliente
                }, commandType: CommandType.Text).FirstOrDefault();

            }
        }

        public void Update_Valuta(string login, int valutaRecebimentoMN, int valutaRecebimentoME, int valutaEnvioMN, int valutaEnvioME)
        {
            string query = $@"
                UPDATE IK_VAREJO.dbo.TBL_COL_PARAMCLI SET      
                    PARAM_DIASLIQ_COMPRAS = {valutaRecebimentoMN},
                    PARAM_DIASLIQ_COMPRASME = {valutaRecebimentoME},
                    PARAM_DIASLIQ_VENDAS = {valutaEnvioMN},
                    PARAM_DIASLIQ_VENDASME = {valutaEnvioME}
                WHERE li_doc = '{login}'
            ";

            SqlHelper.ExecuteNonQuery(strConexao, CommandType.Text, query);
        }
        public void Insert_Valuta(string login, int valutaRecebimentoMN, int valutaRecebimentoME, int valutaEnvioMN, int valutaEnvioME)
        {
            string query = $@"
                INSERT IK_VAREJO.dbo.TBL_COL_PARAMCLI (
                        LI_DOC                  ,
                        PARAM_DIASLIQ_COMPRAS   ,
                        PARAM_DIASLIQ_COMPRASME ,
                        PARAM_DIASLIQ_VENDAS    ,
                        PARAM_DIASLIQ_VENDASME 
                ) VALUES(
                        '{login}'     ,
                        {valutaRecebimentoMN}   ,
                        {valutaRecebimentoME}   ,
                        {valutaEnvioMN}         ,
                        {valutaEnvioME}
                )";
            SqlHelper.ExecuteNonQuery(strConexao, CommandType.Text, query);
        }
        public TBL_COL_PARAMCLI Get_ParametrosCliente(string login)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<TBL_COL_PARAMCLI>(
                $@"SELECT * FROM TBL_COL_PARAMCLI (NOLOCK) 
                    WHERE li_doc = @login
                ", param: new
                {
                    login
                }, commandType: CommandType.Text).FirstOrDefault();

            }
        }

        public bool Exist_ParametrosCliente(string login)
        {
            TBL_COL_PARAMCLI param = new TBL_COL_PARAMCLI();
            param = Get_ParametrosCliente(login);
            return param != null && !string.IsNullOrEmpty(param.LI_DOC);
        }
    }
}
