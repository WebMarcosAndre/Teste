﻿using System.Data;
using System.Linq;
using Dapper;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;

namespace Rendimento.Portal.CambioOnline.DAO
{
    public class TipoClienteDAO:BaseDAO
    {
        public TBL_LOGIN_INTEGRADO_TIPOCLIENTE Get(int id)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<TBL_LOGIN_INTEGRADO_TIPOCLIENTE>(
                $@"SELECT * FROM TBL_LOGIN_INTEGRADO_TIPOCLIENTE (NOLOCK)   WHERE   Id = @id
                ", param: new
                {
                    id
                }, commandType: CommandType.Text).FirstOrDefault();

            }
        }
    }
}
