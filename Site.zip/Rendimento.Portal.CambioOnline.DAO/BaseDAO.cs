﻿using Dapper;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;


namespace Rendimento.Portal.CambioOnline.DAO
{
    public class BaseDAO
    {
        internal static string strConexao = Executar.obterStringConexao("Rendimento.Portal.CambioOnline.Modelos.ModelosCambio.*");

        public static IDbConnection Connection
        {
            get { return new SqlConnection(strConexao); }
        }
       
    }
}
