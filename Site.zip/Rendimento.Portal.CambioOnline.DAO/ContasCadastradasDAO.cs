﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;

namespace Rendimento.Portal.CambioOnline.DAO
{
    public class ContasCadastradasDAO : BaseDAO
    {
        public TBL_MEWEB_CONTAS_CADASTRADAS SelecionarFavorecido(int idConta, int idCliente)
        {
            TBL_MEWEB_CONTAS_CADASTRADAS retorno = null;
            using (IDbConnection cn = Connection)
            {
                retorno = cn.Query<TBL_MEWEB_CONTAS_CADASTRADAS>(
                    $@"SELECT C50K_NOME, C50K_NUM_DOC, C50K_CEP, C50K_ENDERECO, C50K_BAIRRO, C50K_CIDADE, C50K_ESTADO, 
                            C50K_COD_BANCO, C50K_AGENCIA, C50K_CONTA_CORRENTE,
                            C59_NOME, C59_NUM_CONTA, REPLACE(REPLACE(C59_ENDERECO, CHAR(13),' '), CHAR(10), '\n') AS C59_ENDERECO, 
                            C59_PAIS, TIPO_IDENTIFICACAO, C57_SWIFT_CODE,
                            C57_ABA, C57_CONTA, C57_NOME, REPLACE(REPLACE(C57_ENDERECO, CHAR(13),' '), CHAR(10), '\n') AS C57_ENDERECO, 
                            TIPO_IDENT_CORRESP, C56_SWIFT_CODE, C56_ABA,
                            C56_CONTA, C56_NOME, C56_ENDERECO, C56_CONTA_RECEBEDOR, 
                            r.Pais AS PAIS_RECEBEDOR, id_conta, id_cliente
                    FROM TBL_MEWEB_CONTAS_CADASTRADAS cc (NOLOCK)
                    LEFT JOIN TBL_BANCOS_REMESSA r (NOLOCK)
                            ON cc.C57_SWIFT_CODE = r.Swift_Code
                    WHERE ID_CONTA = @IdConta
                          AND ID_CLIENTE = @IdCliente
                    ", param: new
                    {
                        IdConta = idConta,
                        IdCliente = idCliente
                    }, commandType: CommandType.Text).FirstOrDefault();
            }
            return retorno;
        }

        public void Inserir(TBL_MEWEB_CONTAS_CADASTRADAS conta)
        {
            string query = @"
                INSERT INTO TBL_MEWEB_CONTAS_CADASTRADAS
                (
                    ID_CLIENTE, C50K_NOME, C50K_NUM_DOC, C50K_ENDERECO, C50K_BAIRRO, C50K_CIDADE, C50K_ESTADO, 
                    C50K_CEP, C50K_COD_BANCO, C50K_AGENCIA, C50K_CONTA_CORRENTE, C59_NUM_CONTA, C59_NOME, C59_ENDERECO, 
                    C59_PAIS, TIPO_IDENTIFICACAO, C57_SWIFT_CODE, C57_ABA, C57_CONTA, C57_NOME, C57_ENDERECO,
                    TIPO_IDENT_CORRESP, C56_SWIFT_CODE, C56_ABA, C56_CONTA, C56_NOME, C56_ENDERECO, C56_CONTA_RECEBEDOR
                )
                VALUES
                (
                    @ID_CLIENTE, @C50K_NOME, @C50K_NUM_DOC, @C50K_ENDERECO, @C50K_BAIRRO, @C50K_CIDADE, @C50K_ESTADO, 
                    @C50K_CEP, @C50K_COD_BANCO, @C50K_AGENCIA, @C50K_CONTA_CORRENTE, @C59_NUM_CONTA, @C59_NOME, @C59_ENDERECO, 
                    @C59_PAIS, @TIPO_IDENTIFICACAO, @C57_SWIFT_CODE, @C57_ABA, @C57_CONTA, @C57_NOME, @C57_ENDERECO,
                    @TIPO_IDENT_CORRESP, @C56_SWIFT_CODE, @C56_ABA, @C56_CONTA, @C56_NOME, @C56_ENDERECO, @C56_CONTA_RECEBEDOR
                )";
            SqlHelper.ExecuteNonQuery(strConexao, CommandType.Text, query, CarregarParametros(conta));
        }

        public void Atualizar(TBL_MEWEB_CONTAS_CADASTRADAS conta)
        {

            string query = @"
                UPDATE TBL_MEWEB_CONTAS_CADASTRADAS
                        SET C50K_NOME = @C50K_NOME, C50K_NUM_DOC = @C50K_NUM_DOC,
                        C50K_ENDERECO = @C50K_ENDERECO, C50K_CIDADE = @C50K_CIDADE,
                        C50K_ESTADO = @C50K_ESTADO, C50K_CEP = @C50K_CEP,
                        C50K_COD_BANCO = @C50K_COD_BANCO, C50K_AGENCIA = @C50K_AGENCIA,
                        C50K_CONTA_CORRENTE = @C50K_CONTA_CORRENTE, C59_NUM_CONTA = @C59_NUM_CONTA,
                        C59_NOME = @C59_NOME, C59_ENDERECO = @C59_ENDERECO,
                        C59_PAIS = @C59_PAIS, TIPO_IDENTIFICACAO = @TIPO_IDENTIFICACAO,
                        C57_SWIFT_CODE = @C57_SWIFT_CODE, C57_ABA = @C57_ABA,
                        C57_CONTA = @C57_CONTA, C57_NOME = @C57_NOME,
                        C57_ENDERECO = @C57_ENDERECO, TIPO_IDENT_CORRESP = @TIPO_IDENT_CORRESP,
                        C56_SWIFT_CODE = @C56_SWIFT_CODE, C56_ABA = @C56_ABA,
                        C56_CONTA = @C56_CONTA, C56_NOME = @C56_NOME,
                        C56_ENDERECO = @C56_ENDERECO, C56_CONTA_RECEBEDOR = @C56_CONTA_RECEBEDOR,
                        C50K_BAIRRO = @C50K_BAIRRO
                WHERE id_conta = @ID_CONTA AND id_cliente = @ID_CLIENTE ";

            SqlHelper.ExecuteNonQuery(strConexao, CommandType.Text, query, CarregarParametros(conta));

        }

        private SqlParameter[] CarregarParametros(TBL_MEWEB_CONTAS_CADASTRADAS conta)
        {

            SqlParameter[] strParametros = new SqlParameter[29];
            strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[0].Value = conta.id_cliente; //SessaoLogin.li_idcliente;

            strParametros[1] = new SqlParameter("@ID_CONTA", SqlDbType.VarChar, 25);
            strParametros[1].Value = conta.id_conta;

            strParametros[2] = new SqlParameter("@C50K_BAIRRO", SqlDbType.VarChar, 34);
            strParametros[2].Value = conta.C50K_BAIRRO;

            strParametros[3] = new SqlParameter("@C50K_NOME", SqlDbType.VarChar, 200);
            strParametros[3].Value = conta.C50K_NOME;

            strParametros[4] = new SqlParameter("@C50K_NUM_DOC", SqlDbType.VarChar, 50);
            strParametros[4].Value = conta.C50K_NUM_DOC;

            strParametros[5] = new SqlParameter("@C50K_ENDERECO", SqlDbType.VarChar, 500);
            strParametros[5].Value = conta.C50K_ENDERECO;

            strParametros[6] = new SqlParameter("@C50K_CIDADE", SqlDbType.VarChar, 34);
            strParametros[6].Value = conta.C50K_CIDADE;

            strParametros[7] = new SqlParameter("@C50K_ESTADO", SqlDbType.VarChar, 2);
            strParametros[7].Value = conta.C50K_ESTADO;

            strParametros[8] = new SqlParameter("@C50K_CEP", SqlDbType.VarChar, 8);
            strParametros[8].Value = conta.C50K_CEP;

            strParametros[9] = new SqlParameter("@C50K_COD_BANCO", SqlDbType.VarChar, 25);
            strParametros[9].Value = string.IsNullOrEmpty(conta.C50K_COD_BANCO) ? string.Empty : conta.C50K_COD_BANCO;

            strParametros[10] = new SqlParameter("@C50K_AGENCIA", SqlDbType.VarChar, 4);
            strParametros[10].Value = string.IsNullOrEmpty(conta.C50K_AGENCIA) ? string.Empty : conta.C50K_AGENCIA;

            strParametros[11] = new SqlParameter("@C50K_CONTA_CORRENTE", SqlDbType.VarChar, 15);
            strParametros[11].Value = string.IsNullOrEmpty(conta.C50K_CONTA_CORRENTE) ? string.Empty : conta.C50K_CONTA_CORRENTE; 

            strParametros[12] = new SqlParameter("@C59_NUM_CONTA", SqlDbType.NVarChar, 34);
            strParametros[12].Value = string.IsNullOrEmpty(conta.C59_NUM_CONTA) ? string.Empty : conta.C59_NUM_CONTA;

            strParametros[13] = new SqlParameter("@C59_NOME", SqlDbType.VarChar, 50);
            strParametros[13].Value = string.IsNullOrEmpty(conta.C59_NOME) ? string.Empty : conta.C59_NOME;

            strParametros[14] = new SqlParameter("@C59_ENDERECO", SqlDbType.VarChar, 68);
            strParametros[14].Value = string.IsNullOrEmpty(conta.C59_ENDERECO) ? string.Empty : conta.C59_ENDERECO;

            strParametros[15] = new SqlParameter("@C59_PAIS", SqlDbType.VarChar, 10);
            strParametros[15].Value = string.IsNullOrEmpty(conta.C59_PAIS) ? string.Empty : conta.C59_PAIS;

            strParametros[16] = new SqlParameter("@TIPO_IDENTIFICACAO", SqlDbType.VarChar, 10);
            strParametros[16].Value = conta.TIPO_IDENTIFICACAO.Trim().ToUpper();

            strParametros[17] = new SqlParameter("@C57_SWIFT_CODE", SqlDbType.VarChar, 25);

            conta.TIPO_IDENTIFICACAO = string.IsNullOrEmpty(conta.TIPO_IDENTIFICACAO) ? string.Empty : conta.TIPO_IDENTIFICACAO.Trim().ToUpper();
            if (
                conta.TIPO_IDENTIFICACAO.Equals("SWIFT")
                || conta.TIPO_IDENTIFICACAO.Equals("MANUAL")
            )
                strParametros[17].Value = conta.C57_SWIFT_CODE.Trim().ToUpper();
            else
                strParametros[17].Value = string.Empty;

            strParametros[18] = new SqlParameter("@C57_ABA", SqlDbType.VarChar, 25);
            if (
                conta.TIPO_IDENTIFICACAO.Equals("ABA")
                || conta.TIPO_IDENTIFICACAO.Equals("SORTCODE")
                || conta.TIPO_IDENTIFICACAO.Equals("BLZ")
            )
                strParametros[18].Value = conta.C57_SWIFT_CODE.Trim().ToUpper();
            else
                strParametros[18].Value = string.Empty;


            strParametros[19] = new SqlParameter("@C57_CONTA", SqlDbType.VarChar, 25);
            strParametros[19].Value = string.Empty;

            strParametros[20] = new SqlParameter("@C57_NOME", SqlDbType.VarChar, 200);
            strParametros[20].Value = conta.C57_NOME.Trim().ToUpper();

            strParametros[21] = new SqlParameter("@C57_ENDERECO", SqlDbType.VarChar, 500);
            strParametros[21].Value = conta.C57_ENDERECO.Trim().ToUpper();

            conta.TIPO_IDENT_CORRESP = string.IsNullOrEmpty(conta.TIPO_IDENT_CORRESP) ? string.Empty : conta.TIPO_IDENT_CORRESP.Trim().ToString().ToUpper();

            strParametros[22] = new SqlParameter("@TIPO_IDENT_CORRESP", SqlDbType.VarChar, 10);
            strParametros[22].Value = conta.TIPO_IDENT_CORRESP.Trim().ToString().ToUpper();

            strParametros[23] = new SqlParameter("@C56_SWIFT_CODE", SqlDbType.VarChar, 25);

            if (
                conta.TIPO_IDENT_CORRESP.Equals("SWIFT")
                || conta.TIPO_IDENT_CORRESP.Equals("MANUAL")
            )
                strParametros[23].Value = conta.C56_SWIFT_CODE.Trim().ToUpper();
            else
                strParametros[23].Value = string.Empty;

            strParametros[24] = new SqlParameter("@C56_ABA", SqlDbType.VarChar, 25);

            if (
                conta.TIPO_IDENT_CORRESP.Trim().ToString().ToUpper().Equals("ABA")
                || conta.TIPO_IDENT_CORRESP.Trim().ToString().ToUpper().Equals("SORTCODE")
                || conta.TIPO_IDENT_CORRESP.Trim().ToString().ToUpper().Equals("BLZ")
            )
                strParametros[24].Value = conta.C56_SWIFT_CODE.Trim().ToUpper();
            else
                strParametros[24].Value = string.Empty;


            strParametros[25] = new SqlParameter("@C56_CONTA", SqlDbType.VarChar, 25);
            strParametros[25].Value = string.Empty;

            strParametros[26] = new SqlParameter("@C56_NOME", SqlDbType.VarChar, 200);
            strParametros[26].Value = conta.C56_NOME;

            strParametros[27] = new SqlParameter("@C56_ENDERECO", SqlDbType.VarChar, 500);
            strParametros[27].Value = string.IsNullOrEmpty(conta.C56_ENDERECO) ? string.Empty : conta.C56_ENDERECO.Trim().ToUpper();

            strParametros[28] = new SqlParameter("@C56_CONTA_RECEBEDOR", SqlDbType.VarChar, 25);
            strParametros[28].Value = conta.C56_CONTA_RECEBEDOR.Trim().ToUpper();


            return strParametros;
        }
    }
}
