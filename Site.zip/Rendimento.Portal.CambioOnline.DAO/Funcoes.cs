﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;
using Rendimento.Portal.Infra.Core;

namespace Rendimento.Portal.CambioOnline.DAO
{
    public class Funcoes
    {
        private static string strConexaoDecode = Executar.obterStringConexao("Rendimento.Portal.CambioOnline.Modelos.ModelosCambio.*");

        public static DataTable RetornaBoxCotacao(string strIdeCliente)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[2];
            strParametros[0] = new SqlParameter("@ACAO", SqlDbType.Char)
            {
                Value = "LISTAR"
            };
            strParametros[1] = new SqlParameter("@LI_DOC", SqlDbType.VarChar);
            strParametros[1].Value = strIdeCliente;
            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_BOX_COTACAO_CAMBIOONLINE", strParametros);
            return objDts.Tables[0];
        }

        public static Boolean RetornaAlterarSenha(string Li_Doc, string nova_senha, string sessionId)
        {

            Boolean booRet = true;
            try
            {
                SqlParameter[] strParametrosSenha = new SqlParameter[3];
                strParametrosSenha[0] = new SqlParameter("@NUM_DOC", SqlDbType.VarChar, 25);
                strParametrosSenha[0].Value = Li_Doc;
                strParametrosSenha[1] = new SqlParameter("@LI_SENHA", SqlDbType.VarChar);
                strParametrosSenha[1].Value = nova_senha;
                strParametrosSenha[2] = new SqlParameter("@LI_ID_USER_SENDPWD", SqlDbType.Int);
                strParametrosSenha[2].Value = (string.IsNullOrEmpty(sessionId)) ? 0 : Convert.ToInt32(sessionId);

                SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Admin_Atualiza_Senha", strParametrosSenha);
            }
            catch
            {
                booRet = false;
            }
            return booRet;

        }

        public static Boolean RetornaEsqueciSenha(string strNumDoc, string strEmail, string strNovaSenha)
        {
            Boolean booRet = true;
            try
            {

                SqlParameter[] strParametros = new SqlParameter[3];
                strParametros[0] = new SqlParameter("@NUM_DOC", SqlDbType.VarChar, 25);
                strParametros[0].Value = strNumDoc;
                strParametros[1] = new SqlParameter("@LI_SENHA", SqlDbType.VarChar, 8);
                strParametros[1].Value = strNovaSenha;
                strParametros[2] = new SqlParameter("@EMAIL_ORIGEM", SqlDbType.VarChar, 50);
                strParametros[2].Value = strEmail;
                SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Admin_Enviar_Senha", strParametros);
            }
            catch
            {
                booRet = false;
            }
            return booRet;
        }

        public static DataTable RetornaAcessoMenu(int opcao, int id_acesso, string li_doc_master, string li_doc_usuario, int mn_ope_comprar, int mn_ope_vender, int mn_ope_operacoes, int mn_ope_acompanhamento, int mn_ope_ordens, int mn_ope_usuarios, int mn_ope_senha, char li_acesso_econtratos)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[12];
            strParametros[0] = new SqlParameter("@OPCAO", SqlDbType.Int);
            strParametros[0].Value = opcao;
            strParametros[1] = new SqlParameter("@ID_ACESSO", SqlDbType.Int);
            strParametros[1].Value = id_acesso;
            strParametros[2] = new SqlParameter("@LI_DOC_MASTER", SqlDbType.VarChar);
            strParametros[2].Value = li_doc_master;
            strParametros[3] = new SqlParameter("@LI_DOC_USUARIO", SqlDbType.VarChar);
            strParametros[3].Value = li_doc_usuario;
            strParametros[4] = new SqlParameter("@MN_OPE_COMPRAR", SqlDbType.Int);
            strParametros[4].Value = mn_ope_comprar;
            strParametros[5] = new SqlParameter("@MN_OPE_VENDER", SqlDbType.Int);
            strParametros[5].Value = mn_ope_vender;
            strParametros[6] = new SqlParameter("@MN_OPE_OPERACOES", SqlDbType.Int);
            strParametros[6].Value = mn_ope_operacoes;
            strParametros[7] = new SqlParameter("@MN_OPE_ACOMPANHAMENTO", SqlDbType.Int);
            strParametros[7].Value = mn_ope_acompanhamento;
            strParametros[8] = new SqlParameter("@MN_OPE_ORDENS", SqlDbType.Int);
            strParametros[8].Value = mn_ope_ordens;
            strParametros[9] = new SqlParameter("@MN_OPE_USUARIOS", SqlDbType.Int);
            strParametros[9].Value = mn_ope_usuarios;
            strParametros[10] = new SqlParameter("@MN_OPE_SENHA", SqlDbType.Int);
            strParametros[10].Value = mn_ope_senha;
            strParametros[11] = new SqlParameter("@LI_ACESSO_ECONTRATOS", SqlDbType.Char);
            strParametros[11].Value = li_acesso_econtratos;
            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_MENU_PORTAL_CAMBIO", strParametros);
            return objDts.Tables[0];
        }

        public static DataTable RetornaBoxSaldo(string strIdeCliente)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[1];
            strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[0].Value = Convert.ToInt32(strIdeCliente);
            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Saldos_SaldoConsolidado", strParametros);
            return objDts.Tables[0];
        }

        public static string TrocaSenhaUsuario(string strDoc, string strSenha)
        {
            string strRet = "";
            try
            {
                SqlParameter[] strParametros = new SqlParameter[2];
                strParametros[0] = new SqlParameter("@LI_DOC", SqlDbType.VarChar);
                strParametros[0].Value = strDoc;
                strParametros[1] = new SqlParameter("@LI_SENHA", SqlDbType.VarChar);
                strParametros[1].Value = strSenha;
                SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Update_Senha_Usuarios_Sistema", strParametros);
            }
            catch (Exception ex)
            {
                strRet = ex.Message.ToString();
            }
            return strRet;
        }

        public static DataTable RetornaTermoUso(int intOpcao, string strIdeCliente, string strAutorizaEmail)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[3];
            strParametros[0] = new SqlParameter("@LI_OPCAO", SqlDbType.Int);
            strParametros[0].Value = intOpcao;
            strParametros[1] = new SqlParameter("@LI_USUARIO", SqlDbType.VarChar);
            strParametros[1].Value = strIdeCliente;
            strParametros[2] = new SqlParameter("@LI_AUTORIZAEMAIL", SqlDbType.Char);
            strParametros[2].Value = strAutorizaEmail;
            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Verifica_TermoUso_PortalCambio", strParametros);
            return objDts.Tables[0];
        }

        public static DataTable RetornarAutenticacao(string strProcesso, string strUsuario, string strSenha, string strSistema, string strPesquisa)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[5];
            strParametros[0] = new SqlParameter("@PROCESSO", SqlDbType.Char, 1);
            strParametros[0].Value = strProcesso;
            strParametros[1] = new SqlParameter("@USUARIO", SqlDbType.VarChar, 25);
            strParametros[1].Value = strUsuario;
            strParametros[2] = new SqlParameter("@SENHA", SqlDbType.VarChar, 45);
            strParametros[2].Value = strSenha;
            strParametros[3] = new SqlParameter("@SISTEMA", SqlDbType.VarChar, 1);
            strParametros[3].Value = strSistema;
            strParametros[4] = new SqlParameter("@PESQUISA", SqlDbType.VarChar, 1);
            strParametros[4].Value = strPesquisa;
            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBVOL_LOGIN", strParametros);
            return objDts.Tables[0];
        }

        public static string EnviarEmail(string assunto, string corpo, string email_destino)
        {
            SqlDataReader dr = null;
            try
            {
                SqlParameter[] strParametros = new SqlParameter[4];
                strParametros[0] = new SqlParameter("@ASSUNTO", SqlDbType.VarChar, 250);
                strParametros[0].Value = assunto;
                strParametros[1] = new SqlParameter("@CORPO", SqlDbType.NVarChar);
                strParametros[1].Value = corpo;
                strParametros[2] = new SqlParameter("@EMAIL_ORIGEM", SqlDbType.VarChar, 500);
                strParametros[2].Value = GetConfigCambioOnline("EMAIL_SISTEMA");
                strParametros[3] = new SqlParameter("@EMAIL_DESTINO", SqlDbType.VarChar, 500);
                strParametros[3].Value = email_destino;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Enviar_Email", strParametros);
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: EnviarEmail()", "Arquivo: funcoes.cs <br> Parâmetros: EnviarEmail(" + assunto + "," + corpo + "," + email_destino + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return null;
        }

        public static string VerificaLogin(string login)
        {
            DataSet dr = null;
            string retorno = "";
            SqlParameter[] strParametros = new SqlParameter[1];
            strParametros[0] = new SqlParameter("@CPF", SqlDbType.VarChar, 20);
            strParametros[0].Value = login;

            try
            {
                var sqlInit = @"SELECT	case when (B.CL_STATUS <> 'A' or A.LI_STATUS <> 'A' Or FLAG_HABILITA_CAMBIO_COTACAO <> 'S') then 
		                        'I'
		                        else
		                        'A'
		                        end 
                        FROM	TBL_LOGIN_INTEGRADO A WITH (NOLOCK)
                        JOIN	TBL_CLIENTES B WITH (NOLOCK)
                        ON		A.LI_IDCLIENTE = B.ID_CLIENTE ";

                var sql = string.Format("{0} WHERE	CL_NUM_DOC = '{1}' AND LI_TIPO = 'M'", sqlInit, login);


                dr = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, sql);
                if (dr.Tables[0].Rows.Count > 0)
                {
                    retorno = dr.Tables[0].Rows[0].ItemArray[0].ToString();
                }
                else
                {
                    retorno = "N";
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: VerificaLogin()", "Arquivo: funcoes.cs <br> Parâmetros: VerificaLogin(" + login + ")");
            }

            return retorno;
        }

        public static string Atualiza_LoginIntegrado(string strID, string strNome, string strEmail, string strStatus, DateTime dtValidade)
        {
            string strRet = "";
            try
            {
                SqlParameter[] strParametros = new SqlParameter[8];
                strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
                strParametros[0].Value = "ATUALIZAR";

                strParametros[1] = new SqlParameter("@LI_ID", SqlDbType.Int);
                strParametros[1].Value = Convert.ToInt32(strID);

                strParametros[2] = new SqlParameter("@LI_NOME", SqlDbType.VarChar, 300);
                strParametros[2].Value = strNome;

                strParametros[3] = new SqlParameter("@LI_EMAIL", SqlDbType.VarChar, 300);
                strParametros[3].Value = strEmail;

                strParametros[4] = new SqlParameter("@LI_STATUS", SqlDbType.Char, 1);
                strParametros[4].Value = strStatus;

                strParametros[5] = new SqlParameter("@LI_OPERA_VOL", SqlDbType.Char, 1);
                strParametros[5].Value = "N";

                strParametros[6] = new SqlParameter("@LI_VALIDADE", SqlDbType.DateTime);
                strParametros[6].Value = dtValidade;

                strParametros[7] = new SqlParameter("@LI_CORRETORA", SqlDbType.Char, 1);
                strParametros[7].Value = "N";

                SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Usuarios", strParametros);
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: Atualiza_LoginIntegrado()", "Arquivo: funcoes.cs <br> Parâmetros: Atualiza_LoginIntegrado(" + ex.Message.ToString() + ")");
                strRet = ex.Message.ToString();
            }
            return strRet;
        }

        public static string[] Grava_Novo_LoginIntegradoUsuarios(string num_doc, string nome, string email, DateTime datValidade, int intIdCliente, string strAcessaCCME, string strAcessaCOL, string strAcessaECO, string corretora, string tipoCliente, string cpf)
        {
            SqlDataReader dr = null;
            try
            {
                SqlParameter[] strParametros = new SqlParameter[16];
                strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
                strParametros[0].Value = "INSERIR";

                strParametros[1] = new SqlParameter("@LI_DOC", SqlDbType.NVarChar, 25);
                strParametros[1].Value = num_doc;

                string senha = GeraSenha(8);
                strParametros[2] = new SqlParameter("@LI_SENHA", SqlDbType.NVarChar, 8);
                strParametros[2].Value = senha;

                strParametros[3] = new SqlParameter("@LI_STATUS", SqlDbType.Char, 1);
                strParametros[3].Value = "A";

                strParametros[4] = new SqlParameter("@LI_NOME", SqlDbType.VarChar, 300);
                strParametros[4].Value = nome;

                strParametros[5] = new SqlParameter("@LI_EMAIL", SqlDbType.VarChar, 200);
                strParametros[5].Value = email;

                strParametros[6] = new SqlParameter("@LI_OPERA_VOL", SqlDbType.Char, 1);
                strParametros[6].Value = "N";

                strParametros[7] = new SqlParameter("@LI_VALIDADE", SqlDbType.DateTime, 8);
                strParametros[7].Value = String.Format("{0:yyyy-MM-dd}", datValidade);

                strParametros[8] = new SqlParameter("@LI_SISTEMA", SqlDbType.Int);
                strParametros[8].Value = 5; // ccme + cambio_online + portal + e-contratos

                strParametros[9] = new SqlParameter("@LI_IDCLIENTE", SqlDbType.Int);
                strParametros[9].Value = intIdCliente;

                strParametros[10] = new SqlParameter("@LI_ACESSO_CCMEWEB", SqlDbType.Char);
                strParametros[10].Value = strAcessaCCME;

                strParametros[11] = new SqlParameter("@LI_ACESSO_CAMBIOONLINE", SqlDbType.Char);
                strParametros[11].Value = strAcessaCOL;

                strParametros[12] = new SqlParameter("@LI_ACESSO_ECONTRATOS", SqlDbType.Char);
                strParametros[12].Value = strAcessaECO;

                strParametros[13] = new SqlParameter("@LI_CORRETORA", SqlDbType.Char);
                strParametros[13].Value = corretora;

                strParametros[14] = new SqlParameter("@LI_TIPOCLIENTE", SqlDbType.Char);
                strParametros[14].Value = tipoCliente;

                strParametros[15] = new SqlParameter("@LI_CPF", SqlDbType.VarChar);
                strParametros[15].Value = cpf;


                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Usuarios", strParametros);

                if (dr != null)
                {
                    if (dr.HasRows)
                    {
                        dr.Read();
                        return (new string[] { dr[0].ToString(), senha }); // ID_USUARIO
                    }
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: Grava_LoginIntegradoUsuarios()", "Arquivo: funcoes.cs <br> Parâmetros: Grava_LoginIntegradoUsuarios(" + num_doc + "," + nome + "," + email + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return null;
        }

        public static int GravarCliente(SqlParameter[] parameter)
        {
          
            try
            {

                var retorno = SqlHelper.ExecuteReaderRetorno(strConexaoDecode, CommandType.StoredProcedure, "PR_TBL_CLIENTES_Inserir", 135, parameter);
                return retorno;
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: Grava_LoginIntegradoUsuarios()", "Arquivo: funcoes.cs <br> Parâmetros: Grava_LoginIntegradoUsuarios()");
            }

            return 0;
        }

        public static string[] Grava_LoginIntegradoUsuarios(string num_doc, string nome, string email, DateTime datValidade, int idCliente, string tipo)
        {
            SqlDataReader dr = null;
            try
            {

                SqlParameter[] strParametros = new SqlParameter[24];
                strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
                strParametros[0].Value = "INSERIR";

                strParametros[1] = new SqlParameter("@LI_DOC", SqlDbType.NVarChar, 25);
                strParametros[1].Value = num_doc;

                string senha = GeraSenha(8);
                strParametros[2] = new SqlParameter("@LI_SENHA", SqlDbType.NVarChar, 8);
                strParametros[2].Value = senha;

                strParametros[3] = new SqlParameter("@LI_STATUS", SqlDbType.Char, 1);
                strParametros[3].Value = "A";

                strParametros[4] = new SqlParameter("@LI_NOME", SqlDbType.VarChar, 300);
                strParametros[4].Value = nome;

                strParametros[5] = new SqlParameter("@LI_EMAIL", SqlDbType.VarChar, 200);
                strParametros[5].Value = email;

                strParametros[6] = new SqlParameter("@LI_OPERA_VOL", SqlDbType.Char, 1);
                strParametros[6].Value = "N";

                strParametros[7] = new SqlParameter("@LI_VALIDADE", SqlDbType.DateTime, 8);
                strParametros[7].Value = String.Format("{0:yyyy-MM-dd}", datValidade);

                strParametros[8] = new SqlParameter("@LI_SISTEMA", SqlDbType.Int);
                strParametros[8].Value = 1; // ccme + cambio_online + portal + e-contratos

                strParametros[9] = new SqlParameter("@LI_IDCLIENTE", SqlDbType.Int);
                strParametros[9].Value = idCliente;

                strParametros[10] = new SqlParameter("@LI_TIPO", SqlDbType.Char, 1);
                strParametros[10].Value = tipo;

                strParametros[11] = new SqlParameter("@LI_ACESSO_CAMBIOONLINE", SqlDbType.Char, 1);
                strParametros[11].Value = "S";

                strParametros[12] = new SqlParameter("@FLAG_HABILITA_CAMBIO_COTACAO", SqlDbType.Char, 1);
                strParametros[12].Value = "S";

                strParametros[13] = new SqlParameter("@LI_TERMO_ASSINADO_COTA", SqlDbType.Char, 1);
                strParametros[13].Value = "S";

                strParametros[14] = new SqlParameter("@LI_TERMO_ASS_ELETR_COTA", SqlDbType.Char, 1);
                strParametros[14].Value = "S";

                strParametros[15] = new SqlParameter("@LI_DATA_ASS_TERMO_COTA", SqlDbType.DateTime);
                strParametros[15].Value = DateTime.Now;

                strParametros[16] = new SqlParameter("@li_pesquisa", SqlDbType.Char, 1);
                strParametros[16].Value = "C";

                strParametros[17] = new SqlParameter("@li_corretora", SqlDbType.Char, 1);
                strParametros[17].Value = "0";

                strParametros[18] = new SqlParameter("@LI_TERMO_ASSINADO", SqlDbType.Char, 1);
                strParametros[18].Value = "S";

                strParametros[19] = new SqlParameter("@LI_TERMO_ASS_ELETR", SqlDbType.Char, 1);
                strParametros[19].Value = "S";

                strParametros[20] = new SqlParameter("@LI_TipoCliente", SqlDbType.Char, 1);
                strParametros[20].Value = "4";

                strParametros[21] = new SqlParameter("@LI_Cpf", SqlDbType.Char, 11);
                strParametros[21].Value = num_doc;

                strParametros[22] = new SqlParameter("@Li_Aprova_Op", SqlDbType.Char, 1);
                strParametros[22].Value = "S";

                strParametros[23] = new SqlParameter("@Li_Opera_Importacao", SqlDbType.Char, 1);
                strParametros[23].Value = "N";

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Usuarios", strParametros);

                if (dr != null)
                {
                    if (dr.HasRows)
                    {
                        dr.Read();
                        return (new string[] { dr[0].ToString(), senha }); // ID_USUARIO
                    }
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: Grava_LoginIntegradoUsuarios()", "Arquivo: funcoes.cs <br> Parâmetros: Grava_LoginIntegradoUsuarios(" + num_doc + "," + nome + "," + email + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return null;
        }

        /* Rotina de creditar na CCME */
        public static int CreditarCCME(int id_cliente, string cod_moeda, string tipo, string tipo_operacao, decimal valor_operacao, int historico, int id_lancamento, string flag_disp, string flag_bloq, string obs, int quant_cheques, DateTime data_disp)
        {
            SqlDataReader dr = null;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[15];
                strParametros[0] = new SqlParameter("@MOV_CLIENTE", SqlDbType.Int);
                strParametros[0].Value = id_cliente;

                strParametros[1] = new SqlParameter("@MOV_MOEDA", SqlDbType.VarChar, 10);
                strParametros[1].Value = cod_moeda;

                strParametros[2] = new SqlParameter("@MOV_TIPO", SqlDbType.VarChar, 1);
                strParametros[2].Value = tipo;

                strParametros[3] = new SqlParameter("@MOV_TIPO_OP", SqlDbType.VarChar, 50);
                strParametros[3].Value = tipo_operacao;

                strParametros[4] = new SqlParameter("@MOV_VALOR", SqlDbType.Money);
                strParametros[4].Value = valor_operacao;

                strParametros[5] = new SqlParameter("@MOV_PARIDADE", SqlDbType.Money);
                strParametros[5].Value = 0;

                strParametros[6] = new SqlParameter("@MOV_HISTORICO", SqlDbType.Int);
                strParametros[6].Value = historico;

                strParametros[7] = new SqlParameter("@MOV_FLAG_DISP", SqlDbType.Char, 1);
                strParametros[7].Value = flag_disp;

                strParametros[8] = new SqlParameter("@MOV_FLAG_BLOQ", SqlDbType.Char, 2);
                strParametros[8].Value = flag_bloq;

                strParametros[9] = new SqlParameter("@MOV_OBS", SqlDbType.VarChar, 2000);
                strParametros[9].Value = obs;

                strParametros[10] = new SqlParameter("@MOV_QTDE_CHEQUES", SqlDbType.Int);
                strParametros[10].Value = quant_cheques;

                strParametros[11] = new SqlParameter("@MOV_DATA_DISP", SqlDbType.DateTime);
                strParametros[11].Value = String.Format("{0:yyyy-MM-dd}", data_disp);

                strParametros[12] = new SqlParameter("@ID_LANCAMENTO", SqlDbType.Int);
                strParametros[12].Value = id_lancamento;

                strParametros[13] = new SqlParameter("@SISTEMA", SqlDbType.Int);
                strParametros[13].Value = 1;


                // CCME WEB Admin........................M
                // Automatico Varejo.....................J
                // Automatico Cambio Boletagem...........B
                // CCME WEB Cliente......................W
                // Cambio Online.........................C


                string origem = "C";
                strParametros[14] = new SqlParameter("@TIPO_USUARIO", SqlDbType.Char);
                strParametros[14].Value = origem;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Inserir_Lancamento", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    id_lancamento = Convert.ToInt32(dr["ID_LANCAMENTO"]);
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: CreditarCCME()", "Arquivo: funcoes.cs <br> CreditarCCME()");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return id_lancamento;
        }

        /* Parametros do Cambio Online */
        public static string GetConfigCambioOnline(string config_type)
        {
            SqlDataReader dr = null;
            string config_parameter = null;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[2];
                strParametros[0] = new SqlParameter("@ID_CONFIG", SqlDbType.Int);
                strParametros[0].Value = 1;
                strParametros[1] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
                strParametros[1].Value = "LISTAR";

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Admin_Config", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    config_parameter = Convert.ToString(dr[config_type]);
                }
            }
            catch
            {
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return config_parameter;
        }

        public static string GetConfigCambioOnline(string config_type, SqlTransaction transaction)
        {
            SqlDataReader dr = null;
            string config_parameter = null;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[2];
                strParametros[0] = new SqlParameter("@ID_CONFIG", SqlDbType.Int);
                strParametros[0].Value = 1;
                strParametros[1] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
                strParametros[1].Value = "LISTAR";

                dr = SqlHelper.ExecuteReader(transaction, CommandType.StoredProcedure, "SPCOL_Admin_Config", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    config_parameter = Convert.ToString(dr[config_type]);
                }
            }
            catch
            {
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return config_parameter;
        }

        /// <summary>
        /// Parâmetros do Cliente Câmbio Online. Procedure SPCOL_ParametrosCliente, acao LISTAR
        /// </summary>
        /// <param name="li_doc"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        public static string GetConfigParamCli(string li_doc, string param)
        {
            SqlDataReader dr = null;
            string retParam = string.Empty;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[2];
                strParametros[0] = new SqlParameter("@LI_DOC", SqlDbType.VarChar);
                strParametros[0].Value = li_doc.Trim();
                strParametros[1] = new SqlParameter("@acao", SqlDbType.VarChar);
                strParametros[1].Value = "LISTAR";

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_ParametrosCliente", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    if (dr[param] != null)
                        retParam = dr[param].ToString();
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: SPCOL_ParametrosCliente()", "Arquivo: funcoes.cs <br> SPCOL_ParametrosCliente(" + li_doc + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return retParam;
        }

        /* Retorna Spread do dia */
        public static decimal GetSpreadDia(DateTime dt_inicio, DateTime dt_fim, int id_cliente, int id_grupo)
        {
            SqlDataReader dr = null;
            decimal retParam = 0;

            try
            {
                SqlParameter[] strParametrosSpread = new SqlParameter[5];
                strParametrosSpread[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 10);
                strParametrosSpread[0].Value = "LISTAR";
                strParametrosSpread[1] = new SqlParameter("@SPD_VALIDADE_INICIO", SqlDbType.DateTime);
                strParametrosSpread[1].Value = dt_inicio;
                strParametrosSpread[2] = new SqlParameter("@SPD_VALIDADE_FIM", SqlDbType.DateTime);
                strParametrosSpread[2].Value = dt_fim;
                strParametrosSpread[3] = new SqlParameter("@SPD_CLIENTE_ESPECIFICO", SqlDbType.Int);
                if (id_cliente > 0)
                    strParametrosSpread[3].Value = id_cliente;
                strParametrosSpread[4] = new SqlParameter("@SPD_GRUPO_ESPECIFICO", SqlDbType.VarChar, 3);
                if (id_grupo > 0)
                    strParametrosSpread[4].Value = id_grupo;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_SPREAD_DIA", strParametrosSpread);

                if (dr.HasRows)
                {
                    dr.Read();
                    if (dr["SPD_TX_SPREAD"] != null)
                        retParam = Convert.ToDecimal(dr["SPD_TX_SPREAD"]);
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetSpreadDia()", "Arquivo: funcoes.cs <br> GetSpreadDia(" + dt_inicio + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return retParam;
        }

        /// <summary>
        /// Verifica se o cliente tem Ordem Google Manual em Aberto.
        /// </summary>
        /// <param name="id_cliente"></param>
        /// <returns></returns>
        public static bool OrdemGoogleManualEmAberto(int id_cliente)
        {
            try
            {
                var sqlquery = new StringBuilder();
                sqlquery.Append("SELECT P.Pre_boleto_status ");
                sqlquery.Append("FROM tbl_meweb_mt103 M WITH (NOLOCK) ");
                sqlquery.Append("INNER JOIN TBL_PRE_BOLETO P WITH(NOLOCK) ON P.id_cliente = M.id_cliente ");
                sqlquery.Append("AND M.OP_N_BOLETO = P.OP_N_BOLETO ");
                sqlquery.Append("WHERE M.ID_CLIENTE = @ID_CLIENTE ");
                sqlquery.Append("AND M.FLAGGOOGLE = 1 ");
                sqlquery.Append("AND P.Pre_boleto_status <> 2 ");

                SqlParameter[] strParametros = new SqlParameter[1];

                strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                strParametros[0].Value = id_cliente;

                var ds = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, sqlquery.ToString(), strParametros);

                return (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0) ? true : false;

            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: OrdemGoogleManualEmAberto()", "Arquivo: funcoes.cs");

                return false;
            }
        }

        /// <summary>
        /// Parâmetros de Produtos. Procedure SPCOL_Parametros_PortalProdutos, ACAO LISTAR
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public static string GetConfigParamProdutos(string param)
        {
            SqlDataReader dr = null;
            string retParam = string.Empty;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar);
                strParametros[0].Value = "LISTAR";

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Parametros_PortalProdutos", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    if (dr[param] != null)
                        retParam = dr[param].ToString();
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetConfigParamProdutos()", "Arquivo: funcoes.cs <br> GetConfigParamProdutos(" + param + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return retParam.Trim();
        }

        public static string GetConfigParamProdutos(string param, SqlTransaction transacao)
        {
            SqlDataReader dr = null;
            string retParam = string.Empty;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar);
                strParametros[0].Value = "LISTAR";

                dr = SqlHelper.ExecuteReader(transacao, CommandType.StoredProcedure, "SPCOL_Parametros_PortalProdutos", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    if (dr[param] != null)
                        retParam = dr[param].ToString();
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetConfigParamProdutos()", "Arquivo: funcoes.cs <br> GetConfigParamProdutos(" + param + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return retParam;
        }

        /*
         
         * Código das mensagens na tabela TBL_COL_MENSAGENS 
         * ----------------------------------------------------------
         * As Msgs de parametros são do tipo 1 ( IDTipoMensagem = 1 )
         * 1- FAQ
         * 2- Mensagem Principal
         * 3- Mensagem Geral
         * 4- Normas - Vender - Recebimento de Op
         * 5- Normas - Vender - Cheque em Moeda Estrangeira
         * 6- Normas - Compra - Enviar DOC/TED
         * 7- Normas - Termo de Uso
         * 8- Normas - Procuração
         * 9- Normas - Compra ME
     
         */


        public static string GetConfigParamMensagens(int idMsg)
        {
            SqlDataReader dr = null;
            string retParam = string.Empty;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[3];
                strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 10);
                strParametros[0].Value = "LISTAR";
                strParametros[1] = new SqlParameter("@ID_TIPOMSG", SqlDbType.Int);
                strParametros[1].Value = 1;
                strParametros[2] = new SqlParameter("@ID_MSG", SqlDbType.Int);
                strParametros[2].Value = idMsg;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Parametros_Mensagens", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    if (dr["TextoMensagem"] != null)
                        retParam = dr["TextoMensagem"].ToString();
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetConfigParamMensagens()", "Arquivo: funcoes.cs <br> GetConfigParamMensagens(" + idMsg.ToString() + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return retParam;
        }

        public static string GetClienteOperaSomenteBanco(string LI_DOC)
        {
            string strRet = null;
            DataTable objDts = null;
            try
            {
                Modelos.ModelosCambio.TBL_CLIENTES objTabClientes = new Modelos.ModelosCambio.TBL_CLIENTES();
                objDts = objTabClientes.obterDataTable("id_cliente = (select li_idcliente from tbl_login_integrado where li_doc= '" + LI_DOC + "')", "", null);

                if (objDts.Rows.Count != 0)
                {
                    strRet = objDts.Rows[0]["cl_operasomentebanco"].ToString();
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetClienteOperaSomenteBanco()", "Arquivo: funcoes.cs <br> GetClienteOperaSomenteBanco(" + LI_DOC + ")");
            }
            finally
            {
                if (objDts != null)
                {
                    if (objDts.Rows.Count > 0)
                    {
                        objDts.Dispose();
                    }
                }
            }
            return strRet;

        }

        public static DataSet GetCliente(string LI_DOC)
        {
            DataSet dr = null;
            string retParam = string.Empty;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@NUM_DOC", SqlDbType.VarChar, 200);
                strParametros[0].Value = LI_DOC;
                dr = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Admin_Selecionar_Cliente", strParametros);
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetCliente()", "Arquivo: funcoes.cs <br> GetCliente(" + LI_DOC + ")");
            }
            finally
            {
                //if (dr != null)
                //{
                //    if (!dr.IsClosed)
                //    {
                //        dr.Close();
                //        dr.Dispose();
                //    }
                //}
            }
            return dr;
        }


        public static string GetFLAG_Habilita_Cambio_Cotacao(string LI_DOC)
        {
            SqlDataReader dr = null;
            string retParam = string.Empty;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@NUM_DOC", SqlDbType.VarChar, 200);
                strParametros[0].Value = LI_DOC;
                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Admin_Selecionar_Cliente", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    retParam = Convert.ToString(dr["FLAG_HABILITA_CAMBIO_COTACAO"]);
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetFLAG_Habilita_Cambio_Cotacao()", "Arquivo: funcoes.cs <br> GetFLAG_Habilita_Cambio_Cotacao(" + LI_DOC + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }
            return retParam;
        }


        public static string GetParamEmpresas(string Parametro, int id_empresa)
        {
            SqlDataReader dr = null;
            string retParam = string.Empty;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[2];
                strParametros[0] = new SqlParameter("@PARAMETRO", SqlDbType.VarChar, 200);
                strParametros[0].Value = Parametro;
                strParametros[1] = new SqlParameter("@IDEMPRESA", SqlDbType.Int);
                strParametros[1].Value = id_empresa;
                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBR_BuscarParamEmpresaValue", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    if (dr[0] != null)
                        retParam = dr[0].ToString();
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetParamEmpresas()", "Arquivo: funcoes.cs <br> GetParamEmpresas(" + Parametro + "," + id_empresa + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }
            return retParam;
        }


        public static decimal GetTaxaMoeda(string codMoeda)
        {
            return 0;
        }

        public static string GravarErro(Exception ex, string referencia, string info_adicional)
        {
            try
            {
                if (!string.IsNullOrEmpty(ex.Source) && ex.Source.ToLower().Trim() != "mscorlib")
                {
                    SqlParameter[] strParametros = new SqlParameter[4];
                    strParametros[0] = new SqlParameter("@ERROR_SUBJECT", SqlDbType.VarChar, 250);
                    strParametros[0].Value = referencia + " " + ex.ToString();
                    strParametros[1] = new SqlParameter("@ERROR_DESCRIPTION", SqlDbType.NVarChar);
                    strParametros[1].Value = "<html><body>Origem do Erro: " + ex.Source + "<br>Modulo: " + info_adicional + "<br>Trace " + ex.StackTrace + "</body></html>";
                    strParametros[2] = new SqlParameter("@EMAIL_ORIGEM", SqlDbType.VarChar, 500);
                    strParametros[2].Value = GetConfigCambioOnline("EMAIL_SISTEMA");
                    strParametros[3] = new SqlParameter("@EMAIL_DESTINO", SqlDbType.VarChar, 500);
                    strParametros[3].Value = GetConfigCambioOnline("EMAIL_ERRO_SISTEMA");

                    SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Enviar_Erros", strParametros);
                }
                else
                {
                    SqlParameter[] strParametros = new SqlParameter[4];
                    strParametros[0] = new SqlParameter("@ERROR_SUBJECT", SqlDbType.VarChar, 250);
                    strParametros[0].Value = referencia + ex.ToString();
                    strParametros[1] = new SqlParameter("@ERROR_DESCRIPTION", SqlDbType.NVarChar);
                    strParametros[1].Value = "<html><body>Origem do Erro: " + ex.ToString() + "<br>Modulo: " + info_adicional + "<br>Trace " + ex.StackTrace + "</body></html>";
                    strParametros[2] = new SqlParameter("@EMAIL_ORIGEM", SqlDbType.VarChar, 500);
                    strParametros[2].Value = GetConfigCambioOnline("EMAIL_SISTEMA");
                    strParametros[3] = new SqlParameter("@EMAIL_DESTINO", SqlDbType.VarChar, 500);
                    strParametros[3].Value = GetConfigCambioOnline("EMAIL_ERRO_SISTEMA");

                    SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Enviar_Erros", strParametros);
                }
            }
            catch (Exception exGravar)
            {
                return exGravar.StackTrace;
            }

            return null;
        }

        private const string SenhaCaracteresValidos = "abcdefghijklmnopqrstuvwxyz1234567890";

        public static string GeraSenha(int tamanho)
        {
            int valormaximo = SenhaCaracteresValidos.Length;

            Random random = new Random(DateTime.Now.Millisecond);

            StringBuilder senha = new StringBuilder(tamanho);

            for (int indice = 0; indice < tamanho; indice++)
                senha.Append(SenhaCaracteresValidos[random.Next(0, valormaximo)]);

            return senha.ToString();
        }

        public static DataSet ListarTarifasCliente(int id_cliente, string cl_tarifa)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[2];
            strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[0].Value = Convert.ToInt32(id_cliente);
            strParametros[1] = new SqlParameter("@CL_TARIFA", SqlDbType.Char, 5);
            strParametros[1].Value = cl_tarifa;

            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Listar_Tarifas_Cliente", strParametros);
            return objDts;
        }

        public static DataSet MostraMsgCliente(int id_cliente)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[1];
            strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[0].Value = Convert.ToInt32(id_cliente);

            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SP_Lista_Msg_Cliente", strParametros);
            return objDts;
        }

        //TODO: Metodo para conseguir as mensagens
        public static DataSet MostrarMensagemCliente(int id_cliente, string tipo_cliente)
        {
            SqlParameter[] parametros = new SqlParameter[5];
            parametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 50);
            parametros[0].Value = "LISTAR_MENSAGENS_TIPO_CLIENTE";
            parametros[1] = new SqlParameter("@DATA_INICIO", SqlDbType.DateTime);
            parametros[1].Value = DateTime.Now;
            parametros[2] = new SqlParameter("@DATA_FIM", SqlDbType.DateTime);
            parametros[2].Value = DateTime.Now;
            parametros[3] = new SqlParameter("@LISTA_TIPO_CLIENTE", SqlDbType.VarChar, 100);
            parametros[3].Value = tipo_cliente;
            parametros[4] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            parametros[4].Value = id_cliente;

            return Rendimento.Portal.CambioOnline.DAO.SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_MSG_CLIENTES", parametros);
        }

        public static int DesativarMensagemCliente(string idTipoMensagem, int idcliente)
        {
            SqlParameter[] parametros = new SqlParameter[3];
            parametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 50);
            parametros[0].Value = "DESATIVAR_EXIBICAO_MENSAGEM";
            parametros[1] = new SqlParameter("@ID_MSG_TIPO_CLIENTE", SqlDbType.Int);
            parametros[1].Value = idTipoMensagem;
            parametros[2] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            parametros[2].Value = idcliente;

            return SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_MSG_CLIENTES", parametros);
        }

        public static DataSet ListarOrdensPagamento(string acao, int id_cliente, string status, string data_inicial, string data_final)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[5];
            strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
            strParametros[0].Value = acao;
            strParametros[1] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[1].Value = Convert.ToInt32(id_cliente);
            strParametros[2] = new SqlParameter("@STATUS", SqlDbType.Char, 1);
            strParametros[2].Value = status;
            strParametros[3] = new SqlParameter("@DATA_INICIAL", SqlDbType.DateTime);
            strParametros[3].Value = String.Format("{0:yyyy-MM-dd}", Convert.ToDateTime(data_inicial));
            strParametros[4] = new SqlParameter("@DATA_FINAL", SqlDbType.DateTime);
            strParametros[4].Value = String.Format("{0:yyyy-MM-dd}", Convert.ToDateTime(data_final));

            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Ordem_Pagamento", strParametros);
            return objDts;
        }

        public static DataSet EmitirComprovanteSwift(string nr_boleto, string acao, int empresa)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[3];
            strParametros[0] = new SqlParameter("@NR_BOLETO", SqlDbType.Int);
            strParametros[0].Value = int.Parse(nr_boleto);
            strParametros[1] = new SqlParameter("@ACAO", SqlDbType.VarChar, 10);
            strParametros[1].Value = acao;
            strParametros[2] = new SqlParameter("@EMPRESA", SqlDbType.Int);
            strParametros[2].Value = empresa;

            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Comprovante_Swift", strParametros);
            return objDts;
        }

        public static DataSet ListarUsuarios(string strIdentificacao)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[2];
            strParametros[0] = new SqlParameter("@OPCAO", SqlDbType.Int);
            strParametros[0].Value = 0;
            strParametros[1] = new SqlParameter("@LI_DOC_USUARIO", SqlDbType.VarChar);
            strParametros[1].Value = strIdentificacao;
            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_LISTA_USUARIOS_PORTAL", strParametros);
            return objDts;
        }

        public static DataSet ValidarSwift(string SwiftCode)
        {
            string SqlSwift = "SELECT  B.Id, B.Nome, B.ENDERECO, ";
            SqlSwift += " case when B.Tipo = 'S' then 'SWIFT' ";
            SqlSwift += " 	 when B.Tipo = 'A' then 'ABA' ";
            SqlSwift += " 	 When B.Tipo = 'C' then 'SORTCODE' ";
            SqlSwift += " 	 When B.Tipo = 'B' then 'BLZ' ELSE B.Tipo END AS Tipo ";
            SqlSwift += " , B.Swift_Code, B.Status, P.Pais, B.Pais as Cod_Pais ";
            SqlSwift += " FROM TBL_BANCOS_REMESSA B (NOLOCK) INNER JOIN TBL_PAISES P with(nolock) ";
            SqlSwift += " ON B.Pais = P.Codigo ";
            SqlSwift += " WHERE B.Status IN ('A')";
            SqlSwift += " and B.Swift_Code = @SWIFT_CODE";
            SqlSwift += " ORDER BY B.Nome ASC";

            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[1];
            strParametros[0] = new SqlParameter("@SWIFT_CODE", SqlDbType.VarChar, 50);
            strParametros[0].Value = SwiftCode;
            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, SqlSwift, strParametros);
            return objDts;

        }
        public static DataSet ValidarSwiftIntermediario(string SwiftRecebedor, string SwiftIntermediario)
        {


            string SqlSwift = "SELECT TBL_BANCOS_REMESSA_1.id, TBL_BANCOS_REMESSA_1.ENDERECO, ";
            SqlSwift += "  case when TBL_BANCOS_REMESSA_1.Tipo = 'S' then 'SWIFT' ";
            SqlSwift += "       when TBL_BANCOS_REMESSA_1.Tipo = 'A' then 'ABA' ";
            SqlSwift += "       When TBL_BANCOS_REMESSA_1.Tipo = 'C' then 'SORTCODE' ";
            SqlSwift += "       When TBL_BANCOS_REMESSA_1.Tipo = 'B' then 'BLZ' ELSE TBL_BANCOS_REMESSA_1.Tipo END AS Tipo, ";
            SqlSwift += " 		TBL_BANCOS_REMESSA_1.Status, TBL_BANCOS_REMESSA_1.Pais, TBL_BANCOS_REMESSA_1.Pais as Cod_Pais,";
            SqlSwift += " TBL_BANCOS_REMESSA_1.Nome AS Nome, ";
            SqlSwift += " TBL_BANCOS_REMESSA_1.Swift_Code AS Swift_Code  ";
            SqlSwift += " FROM TBL_ASSOC_BANCOS ";
            SqlSwift += " INNER JOIN TBL_BANCOS_REMESSA ";
            SqlSwift += "         ON TBL_ASSOC_BANCOS.id_remessa = TBL_BANCOS_REMESSA.id ";
            SqlSwift += " INNER JOIN TBL_BANCOS_REMESSA TBL_BANCOS_REMESSA_1 ";
            SqlSwift += "         ON TBL_ASSOC_BANCOS.id_corresp = TBL_BANCOS_REMESSA_1.id ";
            SqlSwift += " INNER JOIN TBL_PAISES P with(nolock) ";
            SqlSwift += "         ON TBL_BANCOS_REMESSA_1.Pais = P.Codigo";
            SqlSwift += " WHERE (TBL_BANCOS_REMESSA.Swift_Code = @SWIFT_RECEBEDOR";
            SqlSwift += "    AND TBL_BANCOS_REMESSA_1.Status = 'A'";
            SqlSwift += "    and TBL_BANCOS_REMESSA_1.Swift_Code = @SWIFT_INTERMEDIARIO)";


            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[2];
            strParametros[0] = new SqlParameter("@SWIFT_RECEBEDOR", SqlDbType.VarChar, 50);
            strParametros[0].Value = SwiftRecebedor;
            strParametros[1] = new SqlParameter("@SWIFT_INTERMEDIARIO", SqlDbType.VarChar, 50);
            strParametros[1].Value = SwiftIntermediario;
            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, SqlSwift, strParametros);
            return objDts;

        }

        public static DataSet GetPaisMoedaOperacao(string simb_Moeda, string codPais)
        {

            string SqlPaisMoeda = "SELECT A.codigo, A.pais, B.* ";
            SqlPaisMoeda += " FROM tbl_paises A, TBL_MOEDAS B with(nolock)";
            SqlPaisMoeda += " WHERE A.MOE_CODIGO = B.MOE_CODIGO ";
            SqlPaisMoeda += "   AND B.moe_swift = @moe_codigo ";
            SqlPaisMoeda += "   AND A.CODIGO = @codPais";

            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[2];
            strParametros[0] = new SqlParameter("@moe_codigo", SqlDbType.VarChar, 50);
            strParametros[0].Value = simb_Moeda;
            strParametros[1] = new SqlParameter("@codPais", SqlDbType.VarChar, 50);
            strParametros[1].Value = codPais;

            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, SqlPaisMoeda, strParametros);
            return objDts;

        }
        public static DataSet ListarAcompanhamento(int nr_boleto)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[1];
            strParametros[0] = new SqlParameter("@NR_BOLETO", SqlDbType.Int);
            strParametros[0].Value = nr_boleto;

            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Acompanhamento", strParametros);
            return objDts;
        }

        public static DataSet ListarAcompanhamento(int id_cliente, string status, string data_inicial, string data_final)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[4];
            strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[0].Value = Convert.ToInt32(id_cliente);
            strParametros[1] = new SqlParameter("@STATUS", SqlDbType.Char, 1);
            strParametros[1].Value = status;
            strParametros[2] = new SqlParameter("@DATA_INICIAL", SqlDbType.DateTime);
            strParametros[2].Value = String.Format("{0:yyyy-MM-dd}", Convert.ToDateTime(data_inicial));
            strParametros[3] = new SqlParameter("@DATA_FINAL", SqlDbType.DateTime);
            strParametros[3].Value = String.Format("{0:yyyy-MM-dd}", Convert.ToDateTime(data_final));

            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Acompanhamento", strParametros);
            return objDts;
        }

        public static SqlDataReader GetInfoPreBoleto(int op_n_boleto, int id_cliente)
        {
            SqlDataReader objDtr = null;

            SqlParameter[] strParametros = new SqlParameter[2];
            strParametros[0] = new SqlParameter("@OP_N_BOLETO", SqlDbType.Int);
            strParametros[0].Value = op_n_boleto;
            strParametros[1] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[1].Value = id_cliente;

            objDtr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_GetInfoPreBoleto", strParametros);
            return objDtr;
        }

        public static string TratarAcentos(string texto)
        {
            string texto_novo = null;

            char[] strLetra = new char[] { '~', '@', '#', '$', '^', '&', '*', '`', '<', '>', 'Á', 'É', 'Í', 'Ó', 'Ú', 'Ã', 'Õ', 'À', 'È', 'Ì', 'Ò', 'Ù', 'Ñ', '|', 'Ç', 'Â', 'Ê', 'Î', 'Ô', 'Û', '!', '?', '²', '³', '¤', '€', '¼', '½', '¾', '‘', '’', '×', ' ' };
            char[] strLetraNew = new char[] { ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'A', 'E', 'I', 'O', 'U', 'A', 'O', 'A', 'E', 'I', 'O', 'U', 'N', ' ', 'C', 'A', 'E', 'I', 'O', 'U', ' ', ' ', '2', '3', ' ', 'E', ' ', ' ', ' ', ' ', ' ', 'X', ' ' };

            texto_novo = texto.ToUpper();
            texto_novo = texto_novo.Replace("'", " ");

            try
            {

                for (int i = 0; i < texto.Length; i++)
                {
                    char ch = texto[i];
                    int p = strLetra.ToList().FindIndex(c => c == ch);
                    if (p > -1)
                        texto_novo = texto_novo.Replace(ch, strLetraNew[p]);
                }

                /*if (texto.Length > 2000)
                {
                    Exception ex = new Exception();
                    GravarErro(ex, "Erro: TratarAcentos()", "Arquivo: Funcoes.cs <br> Não foi possível tratar o texto, pois o seu tamanho é superior a 2000 caracteres.");
                }
                else
                {
                    SqlParameter[] strParametros = new SqlParameter[2];
                    strParametros[0] = new SqlParameter("@TEXTO", SqlDbType.VarChar, 2000);
                    strParametros[0].Value = texto.ToUpper();

                    strParametros[1] = new SqlParameter("@TEXTO_NOVO", SqlDbType.VarChar, 2000);
                    strParametros[1].Direction = ParameterDirection.Output;

                    SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Tratar_Acentos", strParametros);

                    texto_novo = strParametros[1].Value.ToString();
                }*/

            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: TratarAcentos()", "Arquivo: Funcoes.cs <br> Parâmetros: TratarAcentos(" + texto + ")");
            }

            return texto_novo;
        }

        public static string MoedaTarifa(string cod_moeda, int id_cliente)
        {
            SqlDataReader dr = null;

            string moeda_tarifa = "D";

            try
            {
                SqlParameter[] strParametros = new SqlParameter[2];
                strParametros[0] = new SqlParameter("@COD_MOEDA", SqlDbType.VarChar, 10);
                strParametros[0].Value = cod_moeda;

                strParametros[1] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                strParametros[1].Value = id_cliente;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Get_Moeda_Tarifa", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    moeda_tarifa = Convert.ToString(dr["SUB_MOEDA_TARIFA"]);
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: MoedaTarifa()", "Arquivo: Funcoes.cs");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return moeda_tarifa;
        }

        public static decimal CalcularTarifa(int id_cliente, string cod_moeda_operacao, string cod_moeda_tarifa, decimal valor_operacao, string tipo_tarifa)
        {
            decimal valor_tarifa = 0;
            SqlDataReader dr = null;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[5];
                strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                strParametros[0].Value = id_cliente;

                strParametros[1] = new SqlParameter("@VALOR_OPERACAO", SqlDbType.Money);
                strParametros[1].Value = valor_operacao;

                strParametros[2] = new SqlParameter("@COD_MOEDA", SqlDbType.VarChar, 10);
                strParametros[2].Value = cod_moeda_operacao;

                strParametros[3] = new SqlParameter("@TIPO_TARIFA", SqlDbType.VarChar, 50);
                strParametros[3].Value = tipo_tarifa;

                strParametros[4] = new SqlParameter("@MOEDA_TARIFA", SqlDbType.VarChar, 10);
                strParametros[4].Value = cod_moeda_tarifa;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Calcular_Tarifa", strParametros);

                if (dr.HasRows == true)
                {
                    dr.Read();
                    valor_tarifa = Convert.ToDecimal(dr["VALOR_TARIFA"]);
                }

            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: AtualizarSaldo()", "Arquivo: funcoes.cs<br>Parâmetros: CalcularTarifa(" + id_cliente + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return valor_tarifa;

        }

        public static string GetConfigParameterCCME(string config_type)
        {
            SqlDataReader dr = null;
            string config_parameter = null;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@ID_CONFIG", SqlDbType.Int);
                strParametros[0].Value = 1;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Get_Config", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    config_parameter = Convert.ToString(dr[config_type]);
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetConfigParameter()", "Arquivo: Funcoes.cs <br> GetConfigParameter(" + config_type + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return config_parameter;
        }

        public static int getCodigoMoeda(string moe_simbolo)
        {
            SqlDataReader dr = null;

            int codigo_moeda = 0;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@MOE_SIMBOLO", SqlDbType.VarChar, 10);
                strParametros[0].Value = moe_simbolo;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Get_CodigoMoeda", strParametros);

                while (dr.Read())
                {
                    codigo_moeda = Convert.ToInt32(dr["MOE_CODIGO"]);
                }

                return codigo_moeda;

            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: getCodigoMoeda()", "Arquivo: funcoes.cs <br> Parâmetros: getCodigoMoeda(" + moe_simbolo + ")");
                return 0;
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }
        }

        public static string GetReceiver(string cod_moeda, double valor)
        {
            SqlDataReader dr = null;

            string receiver_swift = null;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[3];

                strParametros[0] = new SqlParameter("@C32A_MOEDA", SqlDbType.VarChar, 10);
                strParametros[0].Value = cod_moeda;

                strParametros[1] = new SqlParameter("@C32A_VALOR", SqlDbType.Money);
                strParametros[1].Value = valor;

                strParametros[2] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
                strParametros[2].Value = "GET_RECEIVER";

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Ordem_Pagamento", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    receiver_swift = Convert.ToString(dr["RECEIVER_SWIFT"]).Trim().ToUpper();
                }

                return receiver_swift;
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetReceiver()", "Arquivo: /transferencias/transferencias_ordem.aspx <br /> Parametros: GetReceiver(" + cod_moeda + "," + valor.ToString() + ")");
                return string.Empty;
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }
        }

        public static void SalvarConta(SqlParameter[] parametros)
        {
            try
            {
                SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Contas_Cadastradas", parametros);
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: SalvarConta()", "Arquivo: funcoes.cs");
            }
        }

        /// <summary>
        /// Pega o próximo dia útil, procedure DbFeriado..SPBR_Verifica_Proxima_Data_Vigente 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="hora_corte"></param>
        /// <param name="minuto_corte"></param>
        /// <param name="praca"></param>
        /// <param name="moeda"></param>
        /// <param name="diasMN"></param>
        /// <param name="diasME"></param>
        /// <param name="IdOperacao"></param>
        /// <param name="DESPREZAHORARIOCORTE"></param>
        /// <returns></returns>
        public static string[] Get_Proximo_Dia_Util(DateTime data, int hora_corte, int minuto_corte, string praca, string moeda, int diasMN, int diasME, string IdOperacao, string DESPREZAHORARIOCORTE)
        {
            SqlDataReader dr = null;

            string[] data_util = new string[3] { "", "", "" };

            try
            {
                SqlParameter[] strParametros = new SqlParameter[10];

                strParametros[0] = new SqlParameter("@DataBase", SqlDbType.SmallDateTime);
                strParametros[0].Value = Convert.ToDateTime(String.Format("{0:dd/MM/yyyy}", data));
                strParametros[1] = new SqlParameter("@QtdDiasME", SqlDbType.Int);
                strParametros[1].Value = diasME;
                strParametros[2] = new SqlParameter("@QtdDiasMN", SqlDbType.Int);
                strParametros[2].Value = diasMN;
                strParametros[3] = new SqlParameter("@Praca", SqlDbType.VarChar, 2);
                strParametros[3].Value = praca;
                strParametros[4] = new SqlParameter("@Moeda", SqlDbType.VarChar, 4);
                strParametros[4].Value = moeda;
                strParametros[5] = new SqlParameter("@IdSistema", SqlDbType.Int);
                strParametros[5].Value = 2;
                strParametros[6] = new SqlParameter("@IdOperacao", SqlDbType.VarChar, 2);
                strParametros[6].Value = IdOperacao; //31-08-2012 - Alterado parametro para V:Compra e C: Venda//  strParametros[6].Value = "CV";
                strParametros[7] = new SqlParameter("@HoraCorte", SqlDbType.Int);
                strParametros[7].Value = hora_corte;
                strParametros[8] = new SqlParameter("@MinutoCorte", SqlDbType.Int);
                strParametros[8].Value = minuto_corte;
                strParametros[9] = new SqlParameter("@DESPREZAHORARIOCORTE", SqlDbType.Char);
                strParametros[9].Value = DESPREZAHORARIOCORTE;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "DbFeriado..SPBR_Verifica_Proxima_Data_Vigente", strParametros);
                //dr = SqlHelper.ExecuteReader(strConexaoDecodeFeriado, CommandType.StoredProcedure, "SPBR_Verifica_Proxima_Data_Vigente", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    data_util[0] = dr[0].ToString();
                    data_util[1] = dr[1].ToString();
                    data_util[2] = dr[2].ToString();
                }

                return data_util;
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: Get_Proximo_Dia_Util()", "Arquivo: /DAO.Funcoes.cs <br /> Parametros: Get_Proximo_Dia_Util(" + data + ")");
                return data_util;
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }
        }

        public static DataSet VerificaDataFeriado(DateTime dataAtual)
        {
            SqlParameter[] strParametros = new SqlParameter[10];

            strParametros[0] = new SqlParameter("@DataBase", SqlDbType.SmallDateTime);
            strParametros[0].Value = Convert.ToDateTime(String.Format("{0:dd/MM/yyyy}", dataAtual));
            strParametros[1] = new SqlParameter("@QtdDiasME", SqlDbType.Int);
            strParametros[1].Value = 0;
            strParametros[2] = new SqlParameter("@QtdDiasMN", SqlDbType.Int);
            strParametros[2].Value = 0;
            strParametros[3] = new SqlParameter("@Praca", SqlDbType.VarChar, 2);
            strParametros[3].Value = DBNull.Value;
            strParametros[4] = new SqlParameter("@Moeda", SqlDbType.VarChar, 4);
            strParametros[4].Value = "USD";
            strParametros[5] = new SqlParameter("@IdSistema", SqlDbType.Int);
            strParametros[5].Value = 2;
            strParametros[6] = new SqlParameter("@IdOperacao", SqlDbType.VarChar, 2);
            strParametros[6].Value = "V";
            strParametros[7] = new SqlParameter("@HoraCorte", SqlDbType.Int);
            strParametros[7].Value = DBNull.Value;
            strParametros[8] = new SqlParameter("@MinutoCorte", SqlDbType.Int);
            strParametros[8].Value = DBNull.Value;
            strParametros[9] = new SqlParameter("@DESPREZAHORARIOCORTE", SqlDbType.Char);
            strParametros[9].Value = DBNull.Value;

            DataSet ds = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "DbFeriado..SPBR_Verifica_Proxima_Data_Vigente", strParametros);

            return ds;
        }

        //public static string[] Get_Proximo_Dia_Util(DateTime data, int hora_corte, int minuto_corte, string praca, string moeda, int diasMN, int diasME)
        //{
        //    SqlDataReader dr = null;

        //    string[] data_util = new string[3] { "", "", "" };

        //    try
        //    {
        //        SqlParameter[] strParametros = new SqlParameter[7];

        //        strParametros[0] = new SqlParameter("@DATA_SISTEMA", SqlDbType.DateTime);
        //        strParametros[0].Value = data;
        //        strParametros[1] = new SqlParameter("@HORA_CORTE", SqlDbType.Int);
        //        strParametros[1].Value = hora_corte;
        //        strParametros[2] = new SqlParameter("@MINUTO_CORTE", SqlDbType.Int);
        //        strParametros[2].Value = minuto_corte;
        //        strParametros[3] = new SqlParameter("@PRACA", SqlDbType.VarChar, 3);
        //        strParametros[3].Value = praca;
        //        strParametros[4] = new SqlParameter("@MOEDAME", SqlDbType.VarChar, 3);
        //        strParametros[4].Value = moeda;
        //        strParametros[5] = new SqlParameter("@DIASMN", SqlDbType.Int);
        //        strParametros[5].Value = diasMN;
        //        strParametros[6] = new SqlParameter("@DIASME", SqlDbType.Int);
        //        strParametros[6].Value = diasME;

        //        // chamada antiga da proc do CCME
        //        //dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Get_Proximo_Dia_Util", strParametros);

        //        dr = SqlHelper.ExecuteReader(strConexaoDecodeVarejo, CommandType.StoredProcedure, "PR_PROXIMO_DIA_UTIL", strParametros);

        //        if (dr.HasRows)
        //        {
        //            dr.Read();
        //            data_util[0] = dr[0].ToString();
        //            data_util[1] = dr[1].ToString();
        //            data_util[2] = dr[2].ToString();
        //        }

        //        return data_util;
        //    }
        //    catch (Exception ex)
        //    {
        //        GravarErro(ex, "Erro: Get_Proximo_Dia_Util()", "Arquivo: /DAO.Funcoes.cs <br /> Parametros: Get_Proximo_Dia_Util(" + data + ")");
        //        return data_util;
        //    }
        //    finally
        //    {
        //        if (dr != null)
        //        {
        //            if (!dr.IsClosed)
        //            {
        //                dr.Close();
        //                dr.Dispose();
        //            }
        //        }
        //    }
        //}

        public static SqlDataReader GetLimites(string acao, int id_cliente, string tipo, string comp_nivel, string cr_nivel)
        {
            SqlDataReader objDtr = null;

            SqlParameter[] strParametros = new SqlParameter[5];
            strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 50);
            strParametros[0].Value = acao;
            strParametros[1] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[1].Value = id_cliente;
            strParametros[2] = new SqlParameter("@TIPO", SqlDbType.Char, 1);
            strParametros[2].Value = tipo;
            strParametros[3] = new SqlParameter("@COMP_NIVEL", SqlDbType.VarChar, 8);
            strParametros[3].Value = comp_nivel;
            strParametros[4] = new SqlParameter("@CR_NIVEL", SqlDbType.Char, 1);
            strParametros[4].Value = cr_nivel;

            objDtr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Limites", strParametros);
            return objDtr;
        }

        public static DataSet GetLimitesNatureza(string acao)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[1];
            strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 50);
            strParametros[0].Value = acao;

            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Limites", strParametros);
            return objDts;
        }

        public static bool IntegracaoSwift()
        {

            bool integrado = false;

            string diretorio_xml = GetConfigCambioOnline("DIRETORIO_XML");

            DataSet ds_bancos_remessa = new DataSet("TBL_BANCOS_REMESSA");
            DataSet ds_assoc_bancos = new DataSet("TBL_BANCOS_CORRESPONDENTES");

            try
            {

                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);

                //-----------------------------------------
                //-- Listar os Swifts cadastrados no varejo
                //-----------------------------------------
                strParametros[0].Value = "LISTAR_REMESSA";
                ds_bancos_remessa = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Importar_Swifts", strParametros);
                ds_bancos_remessa.WriteXml(diretorio_xml + "TBL_BANCOS_REMESSA.xml");

                //------------------------
                //-- Listar as Associacoes
                //------------------------
                strParametros[0].Value = "LISTAR_CORRESP";
                ds_assoc_bancos = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Importar_Swifts", strParametros);
                ds_assoc_bancos.WriteXml(diretorio_xml + "TBL_BANCOS_CORRESPONDENTES.xml");

                //Exception ex1 = new Exception();
                //Funcoes_CCME.ccme.GravarErro(ex1, "Alerta: IntegracaoSwift()", "A integração do XML Swifts Bancos Remessa foi realizada com sucesso.");

                integrado = true;
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: IntegracaoSwift()", "Arquivo: DAO.Funcoes.cs");
            }
            finally
            {
                ds_assoc_bancos.Clear();
                ds_assoc_bancos = null;
                ds_bancos_remessa.Clear();
                ds_bancos_remessa = null;
            }

            return integrado;

        }

        public static SqlDataReader GetAjuda(int? id_ajuda)
        {
            SqlDataReader objDtr = null;

            SqlParameter[] strParametros = new SqlParameter[1];
            strParametros[0] = new SqlParameter("@ID_AJUDA", SqlDbType.Int);
            strParametros[0].Value = id_ajuda;

            objDtr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Ajuda", strParametros);
            return objDtr;
        }

        public static decimal[] CalculaTaxaPronto(string moeda, string tipoOp)
        {
            decimal taxa_d = 0;
            decimal taxaPronto_d = 0;
            decimal taxaPronto = 0;
            decimal paridade_d = 0;
            decimal paridade = 0;
            try
            {
                Modelos.ModelosVarejo.TMOEDAS tMoedas = new Modelos.ModelosVarejo.TMOEDAS();
                DataTable dt_d = tMoedas.obterDataTable("cod_moeda = 'USD'");

                if (dt_d.Rows.Count > 0)
                {
                    if (tipoOp == "V")
                        taxa_d = Convert.ToDecimal("0" + dt_d.Rows[0]["tx_venda"].ToString());
                    else
                        taxa_d = Convert.ToDecimal("0" + dt_d.Rows[0]["tx_compra"].ToString());

                    paridade_d = Convert.ToDecimal("0" + dt_d.Rows[0]["paridade"].ToString());
                }

                taxaPronto_d = Math.Round(taxa_d * paridade_d, 8);

                /* Taxas na moeda */
                Modelos.ModelosCambio.TBL_MOEDAS tblMoedas = new Modelos.ModelosCambio.TBL_MOEDAS();
                DataTable dt_m = tblMoedas.obterDataTable("moe_simbolo = '" + moeda + "'");

                string moeda_tipo = "A";
                if (dt_m.Rows.Count > 0)
                {
                    moeda_tipo = dt_m.Rows[0]["moe_tipo"].ToString();
                }

                DataTable dt = tMoedas.obterDataTable("cod_moeda = '" + moeda + "'");
                if (dt.Rows.Count > 0)
                {
                    paridade = Convert.ToDecimal("0" + dt.Rows[0]["paridade"].ToString());
                }

                if (paridade > 0)
                {
                    if (moeda_tipo == "A")
                        taxaPronto = Math.Round(taxa_d / paridade, 8);
                    else
                        taxaPronto = Math.Round(taxa_d * paridade, 8);
                }
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "CalculaTaxaPronto", "");
            }
            return (new decimal[] { taxaPronto, taxaPronto_d, paridade });

        }

        public static decimal CalculaTarifaOperacao(string id_cliente, string moeda, string tipoOp, string tipoEntrega, decimal valor)
        {
            decimal tarifa_op = 0;

            Modelos.ModelosCambio.TBL_CLIENTES cliente = new Modelos.ModelosCambio.TBL_CLIENTES();
            cliente = (Modelos.ModelosCambio.TBL_CLIENTES)cliente.obter("id_cliente = " + id_cliente)[0];

            // - Atualizar cl_tarifa com valor padrão caso o cliente não tiver

            cliente.cl_tarifa = cliente.cl_tarifa.TrimIfNotNull();

            if (string.IsNullOrEmpty(cliente.cl_tarifa))
            {
                string TARIFA_PADRAO = string.Empty;

                using (DataSet dsParam = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, "SELECT TARIFA_PADRAO FROM TBL_COL_PARAM_PRODUTOS WITH(NOLOCK)"))
                {
                    TARIFA_PADRAO = dsParam.Tables[0].Rows[0][0].ToString();
                }

                if (!string.IsNullOrEmpty(TARIFA_PADRAO))
                {
                    string sql = string.Format("UPDATE TBL_CLIENTES SET cl_tarifa = '{0}' WHERE id_cliente = {1}", TARIFA_PADRAO, id_cliente);
                    SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.Text, sql);

                    cliente = new Modelos.ModelosCambio.TBL_CLIENTES();
                    cliente = (Modelos.ModelosCambio.TBL_CLIENTES)cliente.obter("id_cliente = " + id_cliente)[0];
                }
            }

            if (cliente.cl_tarifa != "E")
            {
                Modelos.ModelosCambio.TBL_TARIFAS_PADRAO objTarifa = new Modelos.ModelosCambio.TBL_TARIFAS_PADRAO();
                string condicao = "tp_operacao = '" + tipoOp + "' and tp_tipo = '" + tipoEntrega + "'";
                if (cliente.cl_tarifa != null && cliente.cl_tarifa != "")
                    condicao += " and tp_indice = '" + cliente.cl_tarifa + "' ";
                condicao += " and (tp_val_minimo <= " + valor.ToString().Replace(',', '.') + " and tp_val_maximo >= " + valor.ToString().Replace(',', '.') + ")";

                ArrayList arrT = objTarifa.obter(condicao);
                List<Modelos.ModelosCambio.TBL_TARIFAS_PADRAO> lista_tarifa =
                    arrT.Cast<Modelos.ModelosCambio.TBL_TARIFAS_PADRAO>().ToList<Modelos.ModelosCambio.TBL_TARIFAS_PADRAO>();

                if (arrT.Count > 0)
                {
                    //Validação alterada para simplificar a busca
                    // CHAMADO: 91521
                    // Alterado por: Flávio Silva

                    #region Trecho de código Antigo
                    // Procura pela moeda
                    var vLista = from tarifa in lista_tarifa
                                 where (tarifa.tp_moeda.Trim() == moeda)
                                 select tarifa;

                    if (vLista.Count() == 0)
                    {
                        // Procura por Outras
                        var vLista2 = from tarifa in lista_tarifa
                                      where ((!("USD;EURO;ATD").Contains(tarifa.tp_moeda.Trim())) && tarifa.tp_moeda.Trim() != "TODAS")
                                      select tarifa;

                        if (vLista2.Count() == 0)
                        {
                            // Procura por Todas
                            var vLista3 = from tarifa in lista_tarifa
                                          where (tarifa.tp_moeda.Trim() == "TODAS")
                                          select tarifa;

                            if (vLista3.Count() > 0)
                            {
                                tarifa_op = vLista3.SingleOrDefault().tp_val_tarifa;
                            }

                        }
                        else
                        {
                            tarifa_op = vLista2.SingleOrDefault().tp_val_tarifa;
                        }

                    }
                    else
                    {
                        tarifa_op = vLista.SingleOrDefault().tp_val_tarifa;
                    }
                    #endregion

                    #region Trecho de código Novo
                    // Filtro para procura por TARIFA tipo MOEDA SELECIONADA NA TELA DE BOLETAGEM
                    var vListaMoeda = from tarifa in lista_tarifa
                                      where (tarifa.tp_moeda.Trim() == moeda)
                                      select tarifa;

                    // Filtro para procura por TARIFA tipo OUTROS
                    var vListaOutras = from tarifa in lista_tarifa
                                       where (tarifa.tp_moeda.Trim() == "OUTRAS")
                                       select tarifa;

                    // Filtro para procura por TARIFA tipo TODAS
                    var vListaTodas = from tarifa in lista_tarifa
                                      where (tarifa.tp_moeda.Trim() == "TODAS")
                                      select tarifa;

                    // Valida o tipo de tarifa que será utilizado.
                    if (vListaMoeda.Count() > 0)
                    {
                        tarifa_op = vListaMoeda.FirstOrDefault().tp_val_tarifa;
                    }
                    else if (vListaOutras.Count() > 0)
                    {
                        tarifa_op = vListaOutras.FirstOrDefault().tp_val_tarifa;
                    }
                    else if (vListaTodas.Count() > 0)
                    {
                        tarifa_op = vListaTodas.FirstOrDefault().tp_val_tarifa;
                    }
                    else
                    {
                        tarifa_op = 0;
                    }
                    #endregion
                }
            }
            else
            {
                Modelos.ModelosCambio.TBL_REGRAS_TARIFAS_CLI objTarifa = new Modelos.ModelosCambio.TBL_REGRAS_TARIFAS_CLI();
                string condicao = "id_cliente = " + id_cliente + " and rc_operacao = '" + tipoOp + "' and rc_tipo = '" + tipoEntrega + "'";
                condicao += " and (rc_val_minimo <= " + valor.ToString().Replace(',', '.') + " and rc_val_maximo >= " + valor.ToString().Replace(',', '.') + ")";
                ArrayList arrT = objTarifa.obter(condicao);

                List<Modelos.ModelosCambio.TBL_REGRAS_TARIFAS_CLI> lista_tarifa =
                    arrT.Cast<Modelos.ModelosCambio.TBL_REGRAS_TARIFAS_CLI>().ToList<Modelos.ModelosCambio.TBL_REGRAS_TARIFAS_CLI>();

                if (arrT.Count > 0)
                {
                    // Procura pela moeda
                    var vLista = from tarifa in lista_tarifa
                                 where (tarifa.rc_moeda.Trim() == moeda)
                                 select tarifa;

                    if (vLista.Count() == 0)
                    {
                        // Procura por Outras
                        var vLista2 = from tarifa in lista_tarifa
                                      where ((!("USD;EURO;ATD").Contains(tarifa.rc_moeda.Trim())) && tarifa.rc_moeda.Trim() != "TODAS")
                                      select tarifa;

                        if (vLista2.Count() == 0)
                        {
                            // Procura por Todas
                            var vLista3 = from tarifa in lista_tarifa
                                          where (tarifa.rc_moeda.Trim() == "TODAS")
                                          select tarifa;

                            if (vLista3.Count() > 0)
                            {
                                tarifa_op = vLista3.SingleOrDefault().rc_val_tarifa;
                            }

                        }
                        else
                        {
                            tarifa_op = vLista2.SingleOrDefault().rc_val_tarifa;
                        }

                    }
                    else
                    {
                        tarifa_op = vLista.SingleOrDefault().rc_val_tarifa;
                    }
                }
            }

            return tarifa_op;
        }

        public static decimal CalculaTarifaBanco(string moeda, string tipoOp, string tipoEntrega, decimal valor)
        {
            decimal tarifa_banco = 0;
            Modelos.ModelosCambio.TBL_REGRAS_TARIFAS tarifabanco = new Modelos.ModelosCambio.TBL_REGRAS_TARIFAS();
            ArrayList arrTB = tarifabanco.obter("rt_operacao = '" + tipoOp + "' and rt_tipo = '" + tipoEntrega + "'");
            //ArrayList arrTB = tarifabanco.obter("rt_val_minimo <= " + valor.ToString() + " and rt_val_maximo >= " + valor.ToString() + " and rt_operacao = 'C' and rt_tipo = 'ORDEM'");
            if (arrTB.Count > 0)
            {
                foreach (Modelos.ModelosCambio.TBL_REGRAS_TARIFAS item in arrTB)
                {
                    if (item.rt_moeda.Trim() == "US$")
                    {
                        if (moeda.Trim() == "USD")
                        {
                            tarifa_banco = item.rt_val_tarifa;
                            break;
                        }
                    }
                    else if (item.rt_moeda.Trim() == "EURO")
                    {
                        if (moeda.Trim() == "EURO")
                        {
                            tarifa_banco = item.rt_val_tarifa;
                            break;
                        }
                    }
                    else if (item.rt_moeda.Trim() == "ATD")
                    {
                        if (moeda.Trim() == "ATD")
                        {
                            tarifa_banco = item.rt_val_tarifa;
                            break;
                        }
                    }
                    else if (item.rt_moeda.Trim() == "OUTRAS")
                    {
                        if (moeda.Trim() != "USD" && moeda.Trim() != "EURO" && moeda.Trim() != "ATD")
                        {
                            tarifa_banco = item.rt_val_tarifa;
                            break;
                        }
                    }
                    else if (item.rt_moeda.Trim() == "TODAS")
                    {
                        tarifa_banco = item.rt_val_tarifa;
                        break;
                    }
                }
            }
            return tarifa_banco;
        }

        public static string GetAprovAuto(string Tipo, decimal ValorEmDolar)
        {
            decimal valorDisp = 0;

            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[2];

            strParametros[0] = new SqlParameter("@CONFIG_TIPO", SqlDbType.VarChar, 20);
            strParametros[0].Value = "ASSINATURA";

            strParametros[1] = new SqlParameter("@CONFIG_OP", SqlDbType.Char, 1);
            strParametros[1].Value = DBNull.Value;


            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_GETTBL_CONFIGURACOES", strParametros);

            if (objDts.Tables.Count > 0 && objDts.Tables[0].Rows.Count > 0)
            {
                if (objDts.Tables[0].Rows[0]["config_valor"] != DBNull.Value)
                {
                    valorDisp = Convert.ToDecimal(objDts.Tables[0].Rows[0]["config_valor"]);
                }
            }

            string retorno = "N";

            if (ValorEmDolar <= valorDisp)
            {
                if (Tipo == "D") //Doc Venda
                    retorno = "S";
                else if (Tipo == "C") //Doc Compra
                    retorno = "S";
                else if (Tipo == "A")//Assinatura
                    retorno = "D";
                else if (Tipo == "V") //Verificação de Dispensa de Assinatura
                    retorno = "D";
            }
            else
            {
                retorno = "N";
            }

            return retorno;
        }

        /// <summary>
        /// Retorna o parâmetro. Tabela tbl_varejo_parametros 
        /// </summary>
        /// <param name="NM_CAMPO"></param>
        /// <returns></returns>
        public static string Retorna_Varejo_Parametros(string NM_CAMPO)
        {

            SqlDataReader dr = null;
            string valorRetorno = "";
            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@NM_CAMPO", SqlDbType.VarChar, 50);
                strParametros[0].Value = NM_CAMPO;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.Text, "Select VL_CAMPO From tbl_varejo_parametros WHERE NM_CAMPO = @NM_CAMPO", strParametros);
                if (dr.HasRows)
                {
                    dr.Read();
                    valorRetorno = dr["VL_CAMPO"].ToString();
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: Retorna_Varejo_Paramentros()", "Arquivo: Funcoes.cs");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }
            return valorRetorno;
        }

        public static string ConsultaDOC(string idCliente)
        {
            string situacao = "NOK";
            Modelos.ModelosCambio.TBL_CLIENTES cli = new Modelos.ModelosCambio.TBL_CLIENTES();
            DataTable dtCli = cli.obterDataTable("id_cliente = " + idCliente.ToString());
            if (dtCli.Rows.Count > 0)
            {
                DataTable dt_cpfs;
                Modelos.ModelosCambio.TBL_CPFS cpfs = new Modelos.ModelosCambio.TBL_CPFS();
                if (dtCli.Rows[0]["cl_residente"].ToString() == "N")
                {
                    dt_cpfs = cpfs.obterDataTable("cpf_num = '" + dtCli.Rows[0]["cl_num_doc"].ToString() + "' and " +
                                                            "cl_passaporte = '" + dtCli.Rows[0]["cl_passaporte"].ToString() + "'");
                }
                else
                {
                    dt_cpfs = cpfs.obterDataTable("cpf_num = '" + dtCli.Rows[0]["cl_num_doc"].ToString() + "'");
                }

                if (dt_cpfs.Rows.Count > 0)
                {
                    if ((dt_cpfs.Rows[0]["cpf_st_receita"].ToString() == "0" && dtCli.Rows[0]["cl_tip_doc"].ToString().Trim() == "CPF") ||
                        (dt_cpfs.Rows[0]["cpf_st_receita"].ToString() == "2" && dtCli.Rows[0]["cl_tip_doc"].ToString().Trim() == "CNPJ"))
                    {
                        situacao = "OK";
                    }
                }
            }

            return situacao;
        }

        public static void FaleConosco(string assunto, string num_doc, string nome, string telefone, string email, string comentario)
        {
            try
            {
                SqlParameter[] strParametros = new SqlParameter[7];

                strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
                strParametros[0].Value = "INSERIR";
                strParametros[1] = new SqlParameter("@ASSUNTO", SqlDbType.Char, 2);
                strParametros[1].Value = assunto;
                strParametros[2] = new SqlParameter("@NUM_DOC", SqlDbType.VarChar, 15);
                strParametros[2].Value = num_doc;
                strParametros[3] = new SqlParameter("@NOME", SqlDbType.VarChar, 200);
                strParametros[3].Value = nome;
                strParametros[4] = new SqlParameter("@TELEFONE", SqlDbType.VarChar, 100);
                strParametros[4].Value = telefone;
                strParametros[5] = new SqlParameter("@EMAIL", SqlDbType.VarChar, 200);
                strParametros[5].Value = email;
                strParametros[6] = new SqlParameter("@COMENTARIO", SqlDbType.VarChar, 1000);
                strParametros[6].Value = comentario;

                SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Fale_Conosco", strParametros);
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: FaleConosco()", "Arquivo: funcoes.cs");
            }
        }


        public static decimal[] CalculaTaxaOperacao(string moeda, string num_doc, string tipo_operacao, string tipo_entrega, string tipo_cliente_col, decimal valor, decimal valorOverSpread)
        {
            decimal[] taxa = new decimal[2] { 0, 0 };
            try
            {
                DataSet objDts = new DataSet();
                SqlParameter[] strParametros = new SqlParameter[8];

                strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 10);
                strParametros[0].Value = "LISTAR";

                strParametros[1] = new SqlParameter("@LI_DOC", SqlDbType.VarChar, 25);
                strParametros[1].Value = num_doc;

                strParametros[2] = new SqlParameter("@MOE_SIMBOLO", SqlDbType.Char, 5);
                strParametros[2].Value = moeda;

                strParametros[3] = new SqlParameter("@VALOR", SqlDbType.Money);
                strParametros[3].Value = valor;

                strParametros[4] = new SqlParameter("@TIPO_OP", SqlDbType.VarChar, 1);
                strParametros[4].Value = tipo_operacao;

                strParametros[5] = new SqlParameter("@TIPO_ENTREGA", SqlDbType.VarChar, 7);
                strParametros[5].Value = tipo_entrega;

                strParametros[6] = new SqlParameter("@TIPO_CLIENTE_COL", SqlDbType.VarChar, 1);
                strParametros[6].Value = tipo_cliente_col;

                strParametros[7] = new SqlParameter("@VALORSPREAD_OVER", SqlDbType.Money);
                strParametros[7].Value = valorOverSpread;


                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_BOX_COTACAO_CAMBIOONLINE", strParametros);

                if (objDts.Tables[0].Rows.Count > 0)
                {
                    if (tipo_operacao == "V")
                    {
                        taxa[0] = Convert.ToDecimal(objDts.Tables[0].Rows[0]["VL_VENDA"]);
                        taxa[1] = Convert.ToDecimal(objDts.Tables[0].Rows[0]["VALORSPREAD"]);
                    }
                    else
                    {
                        taxa[0] = Convert.ToDecimal(objDts.Tables[0].Rows[0]["VL_COMPRA"]);
                        taxa[1] = Convert.ToDecimal(objDts.Tables[0].Rows[0]["VALORSPREAD"]);
                    }
                }

                return taxa;
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: CalculaTaxaOperacao()", "Arquivo: funcoes.cs");
                return taxa;
            }
        }

        public static Tuple<string, decimal> SpreadGoogle()
        {
            SqlParameter[] strParametros = new SqlParameter[1];
            strParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 10);
            strParametros[0].Value = "LISTAR";

            var ds = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_PARAMETROS_PORTALPRODUTOS", strParametros);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                if (!string.IsNullOrWhiteSpace(ds.Tables[0].Rows[0]["TIPO_DESCONTO_GOOGLE"].ToString()) &&
                    !string.IsNullOrWhiteSpace(ds.Tables[0].Rows[0]["DESCONTO_GOOGLE_MANUAL"].ToString()))
                {
                    return new Tuple<string, decimal>(ds.Tables[0].Rows[0]["TIPO_DESCONTO_GOOGLE"].ToString().Trim(), Convert.ToDecimal(ds.Tables[0].Rows[0]["DESCONTO_GOOGLE_MANUAL"]));
                }
            }

            return null;
        }

        public static decimal TaxaGoogleAutomatico()
        {
            var ds = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, "SELECT Tx_Compra FROM Varejo..TMOEDAS WHERE cod_moeda='USD'");

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return Convert.ToDecimal(ds.Tables[0].Rows[0]["Tx_Compra"]);
            }
            else
            {
                return 0;
            }
        }

        public static int[] IncluirPreBoleto(TBL_PRE_BOLETO preboleto)
        {
            SqlDataReader dr = null;
            int[] retorno = new int[] { 0, 0 };
            try
            {
                SqlParameter[] strParametros = getParametersFromObject(preboleto);
                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "PR_INSERIR_ORDEM_UNIFICADA", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    retorno[0] = Convert.ToInt32(dr["ID_OPERACAO"]);
                    retorno[1] = Convert.ToInt32(dr["ID_PRE_BOLETO"]);
                }
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: IncluirPreBoleto()", "Arquivo: Funcoes.cs");
                throw;
            }
            finally
            {
                if (dr != null && !dr.IsClosed)
                    dr.Close();
            }

            return retorno;
        }

        public static int[] IncluirPreBoleto(TBL_PRE_BOLETO preboleto, SqlTransaction transaction)
        {
            SqlDataReader dr = null;

            int[] retorno = new int[] { 0, 0 };
            try
            {
                SqlParameter[] strParametros = getParametersFromObject(preboleto);
                dr = SqlHelper.ExecuteReader(transaction, CommandType.StoredProcedure, "PR_INSERIR_ORDEM_UNIFICADA", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    retorno[0] = Convert.ToInt32(dr["ID_OPERACAO"]);
                    retorno[1] = Convert.ToInt32(dr["ID_PRE_BOLETO"]);
                }

            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: IncluirPreBoleto()", "Arquivo: Funcoes.cs");
                throw;
            }
            finally
            {
                if (dr != null && !dr.IsClosed)
                    dr.Close();
            }

            return retorno;
        }

        public static SqlParameter[] getParametersFromObject(object obj)
        {
            List<SqlParameter> list = new List<SqlParameter>();
            foreach (FieldInfo info in obj.GetType().GetFields(BindingFlags.Public | BindingFlags.Instance))
            {
                string nomeIdent = ((Modelos.ModelosCambio.TBL_PRE_BOLETO)obj).nomeIdentificador;
                if (info.Name.ToUpper() != nomeIdent.ToUpper() && info.GetValue(obj) != null)
                {
                    SqlParameter item = new SqlParameter();
                    item.ParameterName = info.Name.ToUpper();
                    if (info.FieldType.Name.ToLower().Contains("int"))
                        item.SqlDbType = SqlDbType.Int;
                    else if (info.FieldType.Name.ToLower().Contains("string"))
                        item.SqlDbType = SqlDbType.VarChar;
                    else if (info.FieldType.Name.ToLower().Contains("decimal"))
                        item.SqlDbType = SqlDbType.Decimal;
                    else if (info.FieldType.Name.ToLower().Contains("datetime"))
                        item.SqlDbType = SqlDbType.DateTime;
                    else if (info.FieldType.Name.ToLower().Contains("bool"))
                        item.SqlDbType = SqlDbType.Bit;

                    if (info.FieldType.Name.ToLower().Contains("datetime"))
                    {
                        DateTime campoData = Convert.ToDateTime(info.GetValue(obj));
                        // Data valida
                        if (campoData.Year > 1900)
                        {
                            item.Value = campoData;
                            list.Add(item);
                        }
                    }
                    else
                    {
                        item.Value = info.GetValue(obj);
                        list.Add(item);
                    }
                }
            }
            // Parametro de Sistema Origem
            list.Add(new SqlParameter("OP_SistemaOrigem", "PC"));

            return list.ToArray();
        }
        public static String FormataC59Nome_Endereco(string c59Nome, string c59Endereco)
        {
            // strRetorno = "" quando tamanho excedido 
            int iTotalRow = 35;
            decimal iRowsNome = 0;
            decimal iRowsEnd = 0;
            string strPadNome = "";
            string strPadEnd = "";
            string strRetorno = "";
            int iPadRight = 0;

            if (c59Nome.Length > 0)
            {
                iRowsNome = Math.Ceiling((Convert.ToDecimal((Convert.ToDecimal(c59Nome.Length) / iTotalRow))));
                iPadRight = (Convert.ToInt16(iRowsNome) * iTotalRow - c59Nome.Length);
                strPadNome = c59Nome + strRetorno.PadRight(iPadRight, ' ');
            }

            if (c59Endereco.Length > 0)
            {
                iRowsEnd = Math.Ceiling((Convert.ToDecimal((Convert.ToDecimal(c59Endereco.Length) / iTotalRow))));
                iPadRight = (Convert.ToInt16(iRowsEnd) * iTotalRow - c59Endereco.Length);
                strPadEnd = c59Endereco + strRetorno.PadRight(iPadRight, ' ');
            }
            if ((iRowsNome + iRowsEnd) <= 4)
            {
                if (strPadNome.Length > 0)
                {
                    strRetorno = strPadNome;
                }
                if (strPadEnd.Length > 0)
                {
                    strRetorno += strPadEnd;
                }
            }

            return strRetorno;
        }
        public static Decimal RetornaLimiteDispensaDadosBancarios()
        {

            SqlDataReader dr = null;
            Decimal valorRetorno = 1;
            try
            {
                SqlParameter[] strParametros = new SqlParameter[2];
                strParametros[0] = new SqlParameter("@CONFIG_TIPO", SqlDbType.VarChar, 20);
                strParametros[0].Value = "DADOSBANCARIOSCOL";
                strParametros[1] = new SqlParameter("@CONFIG_OP", SqlDbType.Char, 1);
                strParametros[1].Value = "V";

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_GETTBL_CONFIGURACOES", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    valorRetorno = Convert.ToDecimal(dr["CONFIG_VALOR"]);
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: RetornaLimiteDispensaDadosBancarios()", "Arquivo: funcoes.cs <br> Parâmetros: RetornaLimiteDispensaDadosBancarios()");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return valorRetorno;
        }

        public static Decimal RetornaLimiteDispensaDadosBancarios(SqlTransaction transacao)
        {

            SqlDataReader dr = null;
            Decimal valorRetorno = 1;
            try
            {
                SqlParameter[] strParametros = new SqlParameter[2];
                strParametros[0] = new SqlParameter("@CONFIG_TIPO", SqlDbType.VarChar, 20);
                strParametros[0].Value = "DADOSBANCARIOSCOL";
                strParametros[1] = new SqlParameter("@CONFIG_OP", SqlDbType.Char, 1);
                strParametros[1].Value = "V";

                dr = SqlHelper.ExecuteReader(transacao, CommandType.StoredProcedure, "SPCOL_GETTBL_CONFIGURACOES", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    valorRetorno = Convert.ToDecimal(dr["CONFIG_VALOR"]);
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: RetornaLimiteDispensaDadosBancarios()", "Arquivo: funcoes.cs <br> Parâmetros: RetornaLimiteDispensaDadosBancarios()");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return valorRetorno;
        }

        public static Decimal RetornaValorMoeda(decimal valor, string moeda)
        {
            SqlDataReader dr = null;
            Decimal valorRetorno = 1;
            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@MOEDA", SqlDbType.VarChar, 10);
                strParametros[0].Value = moeda;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Paridades", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    if (dr["MOE_TIPO"].ToString() == "A")
                    {
                        if (Convert.ToDecimal(dr["PARIDADE"]) > 1)
                        {
                            valorRetorno = (valor / Convert.ToDecimal(dr["PARIDADE"]));
                        }
                        else
                        {
                            valorRetorno = (valor * Convert.ToDecimal(dr["PARIDADE"]));
                        }
                    }
                    else
                    {
                        valorRetorno = (valor * Convert.ToDecimal(dr["PARIDADE"]));
                    }
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: RetornaValorMoeda()", "Arquivo: funcoes.cs <br> Parâmetros: RetornaValorMoeda(" + valor.ToString() + "," + moeda + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return valorRetorno;
        }

        public static Decimal RetornaValorMoeda(decimal valor, string moeda, SqlTransaction transacao)
        {
            SqlDataReader dr = null;
            Decimal valorRetorno = 1;
            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@MOEDA", SqlDbType.VarChar, 10);
                strParametros[0].Value = moeda;

                dr = SqlHelper.ExecuteReader(transacao, CommandType.StoredProcedure, "SPBCCME_Paridades", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    if (dr["MOE_TIPO"].ToString() == "A")
                    {
                        if (Convert.ToDecimal(dr["PARIDADE"]) > 1)
                        {
                            valorRetorno = (valor / Convert.ToDecimal(dr["PARIDADE"]));
                        }
                        else
                        {
                            valorRetorno = (valor * Convert.ToDecimal(dr["PARIDADE"]));
                        }
                    }
                    else
                    {
                        valorRetorno = (valor * Convert.ToDecimal(dr["PARIDADE"]));
                    }
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: RetornaValorMoeda()", "Arquivo: funcoes.cs <br> Parâmetros: RetornaValorMoeda(" + valor.ToString() + "," + moeda + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return valorRetorno;
        }

        public static void Envia_Email_Automatico(int idSistema, int nrBoleto, string acaoBackOffice, string acaoEMail)
        {
            try
            {
                SqlParameter[] strParametros = new SqlParameter[4];
                strParametros[0] = new SqlParameter("@ID_SISTEMA", SqlDbType.Int);
                strParametros[0].Value = idSistema;
                strParametros[1] = new SqlParameter("@NR_BOLETO", SqlDbType.Int);
                strParametros[1].Value = nrBoleto;
                strParametros[2] = new SqlParameter("@ACAO_BACKOFFICE", SqlDbType.VarChar, 50);
                strParametros[2].Value = acaoBackOffice.Trim().ToUpper();
                strParametros[3] = new SqlParameter("@ACAO_EMAIL", SqlDbType.VarChar, 50);
                strParametros[3].Value = acaoEMail.Trim().ToUpper();

                SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Envia_Email_Automatico", strParametros);
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: Envia_Email_Automatico()", "Arquivo: Funcoes.cs <br> Envia_Email_Automatico(" + idSistema.ToString() + "," + nrBoleto.ToString() + "," + acaoBackOffice + "," + acaoEMail + ")");
            }
        }

        public static Decimal Nivel_Compliance(string tipo, string nivel)
        {
            SqlDataReader dr = null;
            decimal valorRetorno = 0;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@NIVEL", SqlDbType.VarChar, 1);
                strParametros[0].Value = nivel;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.Text, "SELECT comp_mes, comp_ano FROM tbl_aprovacao_compliance (NOLOCK) WHERE comp_nivel = @NIVEL", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    if (tipo.ToUpper().Trim() == "M" && dr["comp_mes"] != DBNull.Value)
                        valorRetorno = Convert.ToDecimal("0" + dr["comp_mes"].ToString());
                    if (tipo.ToUpper().Trim() == "A" && dr["comp_ano"] != DBNull.Value)
                        valorRetorno = Convert.ToDecimal("0" + dr["comp_ano"].ToString());
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: Nivel_Compliance()", "Arquivo: Funcoes.cs <br> Nivel_Compliance(" + tipo + "," + nivel + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return valorRetorno;
        }

        public static Decimal Valor_Operado_Compliance(string tipo, int idCliente, int idOperacao)
        {
            SqlDataReader dr = null;
            Decimal valorRetorno = 0;
            try
            {
                SqlParameter[] strParametros = new SqlParameter[3];
                strParametros[0] = new SqlParameter("@TIPO", SqlDbType.VarChar, 1);
                strParametros[0].Value = tipo;
                strParametros[1] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                strParametros[1].Value = idCliente;
                strParametros[2] = new SqlParameter("@ID_OPERACAO", SqlDbType.Int);
                strParametros[2].Value = idOperacao;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBVAR_Valor_Operado_Compliance", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    if (dr["SOMA"] != DBNull.Value)
                        valorRetorno = Convert.ToDecimal(dr["SOMA"]);
                    else
                        valorRetorno = 0;
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: Valor_Operado_Compliance()", "Arquivo: funcoes.cs <br> Parâmetros: Valor_Operado_Compliance(" + tipo + "," + idCliente.ToString() + "," + idOperacao.ToString() + ")");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return valorRetorno;
        }

        public static SqlDataReader GetInstrucao_Pagamento(string moeda, string acao)
        {
            SqlDataReader objDtr = null;

            SqlParameter[] strParametros = new SqlParameter[2];
            strParametros[0] = new SqlParameter("@COD_MOEDA", SqlDbType.VarChar, 10);
            strParametros[0].Value = moeda;
            strParametros[1] = new SqlParameter("@ACAO", SqlDbType.VarChar, 50);
            strParametros[1].Value = acao;

            objDtr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Admin_Instrucao_Pagamento", strParametros);
            return objDtr;
        }

        public static string GravarAcesso(string login_user_id, string login_ip, string login_session_id)
        {
            SqlDataReader dr = null;
            try
            {
                SqlParameter[] strParametros = new SqlParameter[4];
                strParametros[0] = new SqlParameter("@LOGIN_USER_ID", SqlDbType.Int);
                strParametros[0].Value = login_user_id;

                strParametros[1] = new SqlParameter("@LOGIN_IP", SqlDbType.VarChar, 50);
                strParametros[1].Value = login_ip;

                strParametros[2] = new SqlParameter("@LOGIN_SESSION_ID", SqlDbType.VarChar, 50);
                strParametros[2].Value = login_session_id;

                strParametros[3] = new SqlParameter("@LOGIN_LI_TIPO", SqlDbType.Char, 1);
                strParametros[3].Value = 'E'; // Via Portal de Cambio considerado acesso externo

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Criar_Sessao", strParametros);
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: CriarSessao()", "Arquivo: Funcoes.cs <br> Parâmetros: CriarSessao(" + login_user_id + "," + login_ip + "," + login_session_id + ")");
            }
            return null;
        }

        public static int GetUserPortalCrm(string user_crm)
        {
            SqlDataReader dr = null;
            int ret = 0;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@UR_USERNAME", SqlDbType.VarChar, 16);
                strParametros[0].Value = user_crm;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_Retorna_Usuario_Log", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    if (dr["ID_USER"] != DBNull.Value)
                    {
                        ret = Convert.ToInt32(dr["ID_USER"]);
                    }
                    else
                    {
                        ret = 0;
                    }
                }

            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetUserPortalCrm()", "Arquivo: Funcoes.cs");
            }
            finally
            {
                if (dr != null && !dr.IsClosed)
                    dr.Close();
            }

            return ret;
        }

        public static int GetUserPortalCrm(string user_crm, SqlTransaction transacao)
        {
            SqlDataReader dr = null;
            int ret = 0;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@UR_USERNAME", SqlDbType.VarChar, 16);
                strParametros[0].Value = user_crm;

                dr = SqlHelper.ExecuteReader(transacao, CommandType.StoredProcedure, "SPCOL_Retorna_Usuario_Log", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();
                    if (dr["ID_USER"] != DBNull.Value)
                    {
                        ret = Convert.ToInt32(dr["ID_USER"]);
                    }
                    else
                    {
                        ret = 0;
                    }
                }

            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetUserPortalCrm()", "Arquivo: Funcoes.cs");
            }
            finally
            {
                if (dr != null && !dr.IsClosed)
                    dr.Close();
            }

            return ret;
        }

        /// <summary>
        /// Seleciona a quantidade de registros na TBL_COL_DIAS_ME_PADRAO para o tipo de moeda (COD_MOEDA)
        /// </summary>
        /// <param name="Cod_moeda"></param>
        /// <returns></returns>
        public static int GetDIAS_ME_PADRAO(string Cod_moeda)
        {
            SqlDataReader dr = null;
            int valorRetorno = 0;
            try
            {
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@Cod_moeda", SqlDbType.NVarChar, 1);
                strParametros[0].Value = Cod_moeda;

                dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.Text, "Select count(*) as qtd From TBL_COL_DIAS_ME_PADRAO WHERE COD_MOEDA = '" + Cod_moeda + "'");
                if (dr.HasRows)
                {
                    dr.Read();
                    valorRetorno = Convert.ToInt32(dr["qtd"]);
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetDIAS_ME_PADRAO()", "Arquivo: Funcoes.cs");
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return valorRetorno;
        }
        public static bool PossuiListaFavorecido(int id_cliente)
        {

            DataSet objDts = new DataSet();
            try
            {
                string sql = "select UPPER(c59_nome) as  'nome do favorecido', ";
                sql += " C59_NUM_CONTA as 'Numero Conta' ";
                sql += " from TBL_MEWEB_CONTAS_CADASTRADAS with(nolock)";
                sql += " where id_cliente = @id_cliente";
                sql += " order by id_conta desc";

                //DataSet objDts = new DataSet();
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@id_cliente", SqlDbType.Int);
                strParametros[0].Value = id_cliente;
                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, sql, strParametros);

            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: CarregarListaFavorecido()", "Arquivo: Funcoes.cs");
            }
            return objDts.Tables[0].Rows.Count > 0;
        }

        public static DataTable CarregarListaFavorecido(int id_cliente)
        {
            DataSet objDts = new DataSet();
            try
            {
                string sql = "select distinct top 10 UPPER(c59_nome) as  'nome do favorecido', ";
                sql += " C59_NUM_CONTA as 'Numero Conta', ";
                sql += " (CASE WHEN C57_SWIFT_CODE is null THEN C57_ABA ELSE c57_swift_code END) as 'Codigo_Bco', ";
                sql += " C57_NOME as 'Nome Banco',   ";
                sql += " id_conta, UPPER(c59_nome + ' - ' + C59_NUM_CONTA) as NomeConta ";
                sql += " from TBL_MEWEB_CONTAS_CADASTRADAS (NOLOCK)";
                sql += " where id_cliente = @id_cliente";
                sql += " order by id_conta desc";

                //DataSet objDts = new DataSet();
                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@id_cliente", SqlDbType.Int);
                strParametros[0].Value = id_cliente;
                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, sql, strParametros);

            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: CarregarListaFavorecido()", "Arquivo: Funcoes.cs");
            }
            return objDts.Tables[0];
        }

        /// <summary>
        /// Filtra por cliente e nome do favorecido
        /// </summary>
        /// <param name="id_cliente"></param>
        /// <param name="nomeFavorecido"></param>
        /// <param name="iban"></param>
        /// <returns></returns>
        public static DataTable CarregarListaFavorecido(int id_cliente, string nomeFavorecido, string iban)
        {
            DataSet objDts = new DataSet();
            try
            {
                string sql = "select distinct top 10 c59_nome as  'nome do favorecido', ";
                sql += " C59_NUM_CONTA as 'Numero Conta', ";
                sql += " (CASE WHEN C57_SWIFT_CODE is null THEN C57_ABA ELSE c57_swift_code END) as 'Codigo_Bco', ";
                sql += " C57_NOME as 'Nome Banco',   ";
                sql += " id_conta, c59_nome + ' - ' + C59_NUM_CONTA as NomeConta ";
                sql += " from TBL_MEWEB_CONTAS_CADASTRADAS ";
                sql += " where id_cliente = @id_cliente";
                sql += " AND(C50K_NOME LIKE('%' + @C50K_NOME + '%') OR C59_NOME LIKE('%' + @C50K_NOME + '%'))";
                sql += " AND(C59_NUM_CONTA LIKE('%' + @C59_NUM_CONTA + '%') )";
                sql += " order by id_conta desc";

                //DataSet objDts = new DataSet();
                SqlParameter[] strParametros = new SqlParameter[3];
                strParametros[0] = new SqlParameter("@id_cliente", SqlDbType.Int);
                strParametros[0].Value = id_cliente;
                strParametros[1] = new SqlParameter("@C50K_NOME", SqlDbType.VarChar);
                strParametros[1].Value = nomeFavorecido;
                strParametros[2] = new SqlParameter("@C59_NUM_CONTA", SqlDbType.VarChar);
                strParametros[2].Value = iban;

                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, sql, strParametros);

            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: CarregarListaFavorecido()", "Arquivo: Funcoes.cs");
            }
            return objDts.Tables[0];
        }


        public static DataTable SelecionarFavorecido(int id_conta, int id_cliente)
        {
            DataSet objDts = null;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[3];
                strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                strParametros[0].Value = id_cliente;

                strParametros[1] = new SqlParameter("@ACTION", SqlDbType.VarChar, 25);
                strParametros[1].Value = "SELECIONARCONTA";

                strParametros[2] = new SqlParameter("@ID_CONTA", SqlDbType.Int);
                strParametros[2].Value = id_conta;
                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Contas_Cadastradas", strParametros);

                return objDts.Tables[0];
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: SelecionarFavorecido()", "Arquivo: Funcoes.cs");
            }

            return null;
        }


        public static DataTable validarOperacao(string Moeda, decimal ValMoeda, DateTime op_data_boleto, string usuario, string Id_Natureza, string TipoEntrega, string op_n_boleto, int id_cliente)
        {
            //SqlDataReader dr = null;
            //string strRetorno = "";

            DataSet objDts = new DataSet();
            try
            {


                String strsSQL = " Select pre_boleto_status, op_n_boleto, id_corretora, id_user_criacao, id_cliente,* ";
                strsSQL += " from tbl_pre_boleto with(nolock) ";
                strsSQL += " where sistema_origem = 'PC'";
                strsSQL += "   and op_data_boleto >= @op_data_boleto";
                strsSQL += "   and op_val_moeda = @ValMoeda";
                strsSQL += "   and op_tipo_moeda = @Moeda";
                strsSQL += "   and op_tipo_operacao = 'V'";
                strsSQL += "   and id_user_criacao = @usuario ";
                strsSQL += "   and op_tipo_entrega = @TipoEntrega";
                strsSQL += "   and op_natureza = @Natureza ";
                strsSQL += "   and pre_boleto_status <> '3'"; // diferente de status 3: Cancelado
                strsSQL += "   and  op_n_boleto <> @op_n_boleto";
                strsSQL += "   and  id_cliente = @id_cliente";

                //DataSet objDts = new DataSet();
                SqlParameter[] strParametros = new SqlParameter[8];
                strParametros[0] = new SqlParameter("@op_data_boleto", SqlDbType.Date);
                strParametros[0].Value = op_data_boleto;
                strParametros[1] = new SqlParameter("@ValMoeda", SqlDbType.Decimal);
                strParametros[1].Value = ValMoeda;
                strParametros[2] = new SqlParameter("@Moeda", SqlDbType.VarChar, 50);
                strParametros[2].Value = Moeda.Trim();
                strParametros[3] = new SqlParameter("@usuario", SqlDbType.VarChar, 50);
                strParametros[3].Value = usuario;
                strParametros[4] = new SqlParameter("@TipoEntrega", SqlDbType.VarChar, 50);
                strParametros[4].Value = TipoEntrega.Trim();
                strParametros[5] = new SqlParameter("@Natureza", SqlDbType.VarChar, 50);
                strParametros[5].Value = Id_Natureza.Trim();
                strParametros[6] = new SqlParameter("@op_n_boleto", SqlDbType.VarChar, 50);
                strParametros[6].Value = op_n_boleto.Trim();
                strParametros[7] = new SqlParameter("@id_cliente", SqlDbType.Int);
                strParametros[7].Value = id_cliente;
                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, strsSQL, strParametros);
                //return objDts;            
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: validarOperacao()", "Arquivo: Funcoes.cs");
            }
            return objDts.Tables[0];

        }

        /// <summary>
        /// Validar Isenção de Imposto de Renda por cliente. Chamado: 94422 - Incorporar rotina DARF - 29/06/2012 - Sequenza: Steeves
        /// </summary>
        /// <param name="id_Cliente"></param>
        /// <returns></returns>
        public static DataTable ValidarIsencaoIR(int id_Cliente)
        {
            DataSet objDts = new DataSet();

            try
            {
                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, String.Format("SELECT ISNULL(IR_Isento,'N') AS IR_Isento, ISNULL(IOF_Isento,'N') AS IOF_Isento, ISNULL(IR_SAIDA,'N') AS IR_SAIDA FROM TBL_CLIENTES With(nolock) WHERE id_Cliente={0}", id_Cliente));
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: ValidarIsencaoIR()", "Arquivo: Funcoes.cs");
            }
            return objDts.Tables[0];
        }

        public static DataTable GetPermissaoImportacao(int CodModalidade, string li_doc)
        {
            StringBuilder strQuery = new StringBuilder();
            DataSet objDts = new DataSet();

            try
            {
                strQuery.Append("SELECT B.LI_OPERA_IMPORTACAO, A.CODMODIMP ");
                strQuery.Append(" From TBL_LOGIN_MOD_IMP A, TBL_LOGIN_INTEGRADO B");
                strQuery.Append(" WHERE A.LI_ID = B.LI_ID");
                strQuery.Append(" AND A.LI_DOC = '" + li_doc + "'");
                strQuery.Append(" AND B.LI_OPERA_IMPORTACAO = 'S'");

                if (CodModalidade != 0) { strQuery.Append(" AND (A.CODMODIMP = " + CodModalidade + ")"); }

                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, strQuery.ToString());
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetPermissaoImportacao()", "Arquivo: Funcoes.cs");
            }

            return objDts.Tables[0];
        }
        // Retorna permissão para importação S/N TBL_LOGIN_INTEGRADO
        public static DataTable GetPermissaoImportacao(string li_doc)
        {
            StringBuilder strQuery = new StringBuilder();
            DataSet objDts = new DataSet();

            try
            {
                strQuery.Append("SELECT LI_OPERA_IMPORTACAO ");
                strQuery.Append(" From TBL_LOGIN_INTEGRADO ");
                strQuery.Append(" WHERE LI_DOC = '" + li_doc + "'");


                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, strQuery.ToString());
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetPermissaoImportacao()", "Arquivo: Funcoes.cs");
            }

            return objDts.Tables[0];
        }
        public static DataTable GetAliquotaIR(int id_natureza)
        /* Pesquisar Aliquota de Imposto de Renda por cliente
         * Chamado: 94422 - Incorporar rotina DARF
         * 29/06/2012 - Sequenza: Steeves
         */
        {
            StringBuilder strQuery = new StringBuilder();
            DataSet objDts = new DataSet();

            try
            {
                strQuery.Append("SELECT TBL_ALIQUOTAS_IR.Tarifa, Cod_darf, TBL_Paises.Codigo ");
                strQuery.Append(" FROM TBL_ALIQUOTAS_IR WITH(NOLOCK) INNER JOIN TBL_Paises WITH(NOLOCK) ");
                strQuery.Append(" ON TBL_ALIQUOTAS_IR.ID_Pais = TBL_Paises.id_pais ");
                strQuery.Append(" WHERE 0=0 ");

                if (id_natureza != 0) { strQuery.Append(" AND (TBL_ALIQUOTAS_IR.ID_Natureza in (" + id_natureza + "))"); }

                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, strQuery.ToString());
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetAliquotaIR()", "Arquivo: Funcoes.cs");
            }

            return objDts.Tables[0];
        }

        public static DataTable GetAliquotaIR(int id_natureza, int codigo_pais)
        /* Pesquisar Aliquota de Imposto de Renda por cliente
         * Chamado: 94422 - Incorporar rotina DARF
         * 29/06/2012 - Sequenza: Steeves
         */
        {
            StringBuilder strQuery = new StringBuilder();
            DataSet objDts = new DataSet();

            try
            {
                strQuery.Append("SELECT TBL_ALIQUOTAS_IR.Tarifa, Cod_darf ");
                strQuery.Append(" FROM TBL_ALIQUOTAS_IR WITH(NOLOCK) INNER JOIN TBL_Paises WITH(NOLOCK)  ");
                strQuery.Append(" ON TBL_ALIQUOTAS_IR.ID_Pais = TBL_Paises.id_pais ");
                strQuery.Append(" WHERE 0=0 ");

                if (codigo_pais != 0) { strQuery.Append(" AND TBL_Paises.Codigo =" + codigo_pais); }
                if (id_natureza != 0) { strQuery.Append(" AND (TBL_ALIQUOTAS_IR.ID_Natureza in (" + id_natureza + "))"); }
                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, strQuery.ToString());
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetAliquotaIR()", "Arquivo: Funcoes.cs");
            }

            return objDts.Tables[0];
        }

        public static DataTable GetAllBancoComplete(string name)
        {

            DataSet objDts = new DataSet();
            try
            {

                string StrSql = string.Format(@" select cod_banco, REPLICATE('0', 3 - LEN(cod_banco)) + RTrim(cod_banco) +' - '+ nome_banco as NmBanco
               from tbl_cod_bancos 
               where 
               REPLICATE('0', 3 - LEN(cod_banco)) + RTrim(cod_banco) like '{0}%'
               or dbo.sf_RemoveExtraChars(nome_banco) like '%{0}%'
               or dbo.sf_RemoveExtraChars(REPLICATE('0', 3 - LEN(cod_banco)) + RTrim(cod_banco) + ' - ' + nome_banco) like dbo.sf_RemoveExtraChars('%{0}%')
               order by 1,2 asc", name.Trim());

                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@SEARCH", SqlDbType.VarChar, 80);
                strParametros[0].Value = name;

                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, StrSql);//, strParametros );
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetBancoComplete()", "Arquivo: funcoes.cs");
            }
            return objDts.Tables[0];

        }

        public static DataTable GetBancoComplete(string name)
        {

            DataSet objDts = new DataSet();
            try
            {

                string StrSql = string.Format(@" select top 10 cod_banco, REPLICATE('0', 3 - LEN(cod_banco)) + RTrim(cod_banco) +' - '+ nome_banco as NmBanco
               from tbl_cod_bancos 
               where 
               REPLICATE('0', 3 - LEN(cod_banco)) + RTrim(cod_banco) like '{0}%'
               or dbo.sf_RemoveExtraChars(nome_banco) like '%{0}%'
               or dbo.sf_RemoveExtraChars(REPLICATE('0', 3 - LEN(cod_banco)) + RTrim(cod_banco) + ' - ' + nome_banco) like dbo.sf_RemoveExtraChars('%{0}%')
               order by 1,2 asc", name.Trim());

                SqlParameter[] strParametros = new SqlParameter[1];
                strParametros[0] = new SqlParameter("@SEARCH", SqlDbType.VarChar, 80);
                strParametros[0].Value = name;

                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, StrSql);//, strParametros );
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetBancoComplete()", "Arquivo: funcoes.cs");
            }
            return objDts.Tables[0];

        }
        public static DataTable GetCalculoIR(string UtilizaAliquota, decimal ValMoeda, decimal ValReais, decimal TaxaOperacao, string Moeda, decimal TaxaIR)
        {
            DataSet objDts = new DataSet();
            try
            {
                SqlParameter[] strParametros = new SqlParameter[6];
                strParametros[0] = new SqlParameter("@UT_ALIQUOTA", SqlDbType.VarChar);
                strParametros[0].Value = UtilizaAliquota;
                strParametros[1] = new SqlParameter("@OP_VAL_MOEDA", SqlDbType.Money);
                strParametros[1].Value = ValMoeda;
                strParametros[2] = new SqlParameter("@OP_VAL_REAIS", SqlDbType.Money);
                strParametros[2].Value = ValReais;
                strParametros[3] = new SqlParameter("@OP_TX_OPERACAO", SqlDbType.Decimal);
                strParametros[3].Value = TaxaOperacao;
                strParametros[4] = new SqlParameter("@MOEDA", SqlDbType.VarChar);
                strParametros[4].Value = Moeda;
                strParametros[5] = new SqlParameter("@TAXA_IR", SqlDbType.Decimal);
                strParametros[5].Value = TaxaIR;


                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPBR_Varejo_Calcula_Darf", strParametros);
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetCalculoIR()", "Arquivo: funcoes.cs");
            }
            DataTable dt = new DataTable();

            if (objDts.Tables.Count > 0)
                dt = objDts.Tables[0];

            return dt;

        }

        public static DataTable GetDadosClienteDARF(int id_Cliente)
        {
            DataSet objDts = new DataSet();
            //SqlDataReader dr = null;
            //string strRetorno = "";
            try
            {
                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, "SELECT case when cl_nome is null then cl_razao_social else cl_nome end  as Nome, cl_razao_social, cl_tel_res, cl_num_doc, cl_tip_doc FROM TBL_CLIENTES With(nolock) WHERE id_Cliente=" + id_Cliente);
                //                objDts = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.Text, );
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetDadosClienteDARF()", "Arquivo: Funcoes.cs");
            }

            return objDts.Tables[0];

        }

        public static DataTable GetListaPaises()
        {
            return GetListaPaises(null);
        }

        public static DataTable GetListaPaises(string codigo_iso)
        {
            DataSet objdts = new DataSet();
            try
            {

                SqlParameter parameterCodigoIso = new SqlParameter("@codigo_iso", SqlDbType.VarChar, 3);
                if (string.IsNullOrEmpty(codigo_iso))
                    parameterCodigoIso.Value = DBNull.Value;
                else parameterCodigoIso.Value = codigo_iso;

                objdts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, $@"
                        SELECT codigo, pais FROM TBL_PAISES (NOLOCK) 
                        WHERE codigo NOT IN (6959,7900,1996) AND codigo_iso = ISNULL( @codigo_iso  , codigo_iso )
                        ORDER BY ordem, pais ASC ",
                        parameterCodigoIso);

            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetListaPaises()", "Arquivo: Funcoes.cs");
            }

            if (objdts.Tables.Count == 0)
                return new DataTable();
            else
                return objdts.Tables[0];

        }

        public static DataTable getListaModalidadeImportacao()
        {
            DataSet objDts = new DataSet();
            try
            {
                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, "SELECT CodModImp, DescModImp FROM TBL_COL_MODALIDADE_IMP ORDER BY 1 ASC");
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: getListaModalidadeImportacao()", "Arquivo: Funcoes.cs");
            }
            return objDts.Tables[0];
        }
        public static DataTable getLI_DI_COEMB(string item, string op_n_boleto)
        {
            DataSet objDts = new DataSet();

            try
            {
                String strSQL = "";
                if (item == "DI")
                {
                    strSQL = "select * from TBL_COL_IMP_DI where op_n_boleto = " + op_n_boleto;
                }
                else if (item == "LI")
                {
                    strSQL = "select * from TBL_COL_IMP_LI where op_n_boleto = " + op_n_boleto;
                }
                else if (item == "COEMB")
                {
                    strSQL = "select * from TBL_COL_IMP_COEMB where op_n_boleto = " + op_n_boleto;
                }

                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, strSQL);
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: getLI_DI_COEMB()", "Arquivo: Funcoes.cs");
            }
            return objDts.Tables[0];
        }

        public static DataTable getLI_DI_COEMB(string item, string op_n_boleto, SqlTransaction transacao)
        {
            DataSet objDts = new DataSet();

            try
            {
                String strSQL = "";
                if (item == "DI")
                {
                    strSQL = "select * from TBL_COL_IMP_DI where op_n_boleto = " + op_n_boleto;
                }
                else if (item == "LI")
                {
                    strSQL = "select * from TBL_COL_IMP_LI where op_n_boleto = " + op_n_boleto;
                }
                else if (item == "COEMB")
                {
                    strSQL = "select * from TBL_COL_IMP_COEMB where op_n_boleto = " + op_n_boleto;
                }

                objDts = SqlHelper.ExecuteDataset(transacao, CommandType.Text, strSQL);
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: getLI_DI_COEMB()", "Arquivo: Funcoes.cs");
            }
            return objDts.Tables[0];
        }

        public static DataTable getVinculoBeneficiarios(string cl_tipo, int id_motivo_envio)
        {
            DataSet objDts = new DataSet();

            try
            {

                String strSQL = "Select  ltrim(rtrim(ME.cod_pagador)) as cod_pagador, ME.tipo_envio_portal, ME.tipo_envio_varejo, ME.habilita_pf, ME.habilita_pj, ME.vinculo ";
                strSQL += " From tbl_natureza N, tbl_natureza_motivo_envio NM, tbl_motivo_envio ME ";
                strSQL += " Where N.id_natureza = NM.id_natureza ";
                strSQL += " and NM.id_motivo_envio = ME.id_motivo_envio ";
                strSQL += " and ME.cod_pagador = " + id_motivo_envio;
                if (cl_tipo == "J") { strSQL += " and ME.habilita_pj= 1 "; }
                if (cl_tipo == "F") { strSQL += " and ME.habilita_pf= 1 "; }
                strSQL += " ORDER BY ME.tipo_envio_varejo asc ";

                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, strSQL);
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: getVinculoBeneficiarios()", "Arquivo: Funcoes.cs");
            }
            return objDts.Tables[0];
        }

        public static DataTable getListaBeneficiarios(string cl_tipo, int id_natureza)
        {
            DataSet objDts = new DataSet();

            try
            {

                String strSQL = "Select distinct ltrim(rtrim(ME.cod_pagador)) as cod_pagador, ME.tipo_envio_portal, ME.tipo_envio_varejo, ME.habilita_pf, ME.habilita_pj, ME.vinculo ";
                strSQL += " From tbl_natureza N, tbl_natureza_motivo_envio NM, tbl_motivo_envio ME ";
                strSQL += " Where N.id_natureza = NM.id_natureza ";
                strSQL += " and NM.id_motivo_envio = ME.id_motivo_envio and ME.tipo_operacao = 'V' ";
                strSQL += " and N.id_natureza = " + id_natureza;
                if (cl_tipo == "J") { strSQL += " and ME.habilita_pj= 1 "; }
                if (cl_tipo == "F") { strSQL += " and ME.habilita_pf= 1 "; }
                strSQL += " ORDER BY ME.tipo_envio_varejo asc ";

                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, strSQL);
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: getListaBeneficiarios()", "Arquivo: Funcoes.cs");
            }
            return objDts.Tables[0];
        }
        public static bool ExcluirDarf(int Id_Darf)
        {
            int Retorno = SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.Text, "DELETE FROM DARF..TBL_DARF where id_darf = " + Id_Darf);
            return (Retorno > 0);
        }
        public static int VarejoGerarDARF(string Nome_DARF, string Telefone_DARF, string CPF_CNPJ_DARF, int Cod_Receita_DARF, int Cod_Unidade_DARF, decimal Valor_Principal_DARF, decimal Vlr_Multa_DARF, decimal Vlr_Juros_DARF, string Observacoes_DARF)
        {
            DataSet objDts = new DataSet();
            int ID_DARF = 0;
            try
            {
                SqlParameter[] strParametros = new SqlParameter[12];
                strParametros[0] = new SqlParameter("@NOME_DARF", SqlDbType.VarChar);
                strParametros[0].Value = Nome_DARF;
                strParametros[1] = new SqlParameter("@TELEFONE_DARF", SqlDbType.VarChar);
                strParametros[1].Value = Telefone_DARF;
                strParametros[2] = new SqlParameter("@DATA_PERIODO_DARF", SqlDbType.DateTime);
                strParametros[2].Value = DateTime.Now;
                strParametros[3] = new SqlParameter("@CPF_CNPJ_DARF", SqlDbType.VarChar);
                strParametros[3].Value = CPF_CNPJ_DARF;
                strParametros[4] = new SqlParameter("@COD_RECEITA_DARF", SqlDbType.Int);
                strParametros[4].Value = Cod_Receita_DARF;
                strParametros[5] = new SqlParameter("@COD_UNIDADE_DARF", SqlDbType.Int);
                strParametros[5].Value = Cod_Unidade_DARF;
                strParametros[6] = new SqlParameter("@DATA_VENCIMENTO_DARF", SqlDbType.DateTime);
                strParametros[6].Value = DateTime.Now;
                strParametros[7] = new SqlParameter("@VLR_PRINCIPAL_DARF", SqlDbType.Decimal);
                strParametros[7].Value = Valor_Principal_DARF;
                strParametros[8] = new SqlParameter("@VLR_MULTA_DARF", SqlDbType.Decimal);
                strParametros[8].Value = Vlr_Multa_DARF;
                strParametros[9] = new SqlParameter("@VLR_JUROS_DARF", SqlDbType.Decimal);
                strParametros[9].Value = Vlr_Juros_DARF;
                strParametros[10] = new SqlParameter("@DATA_INCLUSAO_DARF", SqlDbType.DateTime);
                strParametros[10].Value = DateTime.Now;
                strParametros[11] = new SqlParameter("@OBSERVACOES_DARF", SqlDbType.VarChar);
                strParametros[11].Value = Observacoes_DARF;

                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SP_VAREJO_GERAR_DARF", strParametros);
                ID_DARF = Convert.ToInt32(objDts.Tables[0].Rows[0]["ID_DARF"]);

            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: VarejoGerarDARF()", "Arquivo: funcoes.cs");
            }
            return ID_DARF;
        }

        public static int VarejoGerarDARF(string Nome_DARF, string Telefone_DARF, string CPF_CNPJ_DARF, int Cod_Receita_DARF, int Cod_Unidade_DARF, decimal Valor_Principal_DARF, decimal Vlr_Multa_DARF, decimal Vlr_Juros_DARF, string Observacoes_DARF, SqlTransaction transacao)
        {
            DataSet objDts = new DataSet();
            int ID_DARF = 0;
            try
            {
                SqlParameter[] strParametros = new SqlParameter[12];
                strParametros[0] = new SqlParameter("@NOME_DARF", SqlDbType.VarChar);
                strParametros[0].Value = Nome_DARF;
                strParametros[1] = new SqlParameter("@TELEFONE_DARF", SqlDbType.VarChar);
                strParametros[1].Value = Telefone_DARF;
                strParametros[2] = new SqlParameter("@DATA_PERIODO_DARF", SqlDbType.DateTime);
                strParametros[2].Value = DateTime.Now;
                strParametros[3] = new SqlParameter("@CPF_CNPJ_DARF", SqlDbType.VarChar);
                strParametros[3].Value = CPF_CNPJ_DARF;
                strParametros[4] = new SqlParameter("@COD_RECEITA_DARF", SqlDbType.Int);
                strParametros[4].Value = Cod_Receita_DARF;
                strParametros[5] = new SqlParameter("@COD_UNIDADE_DARF", SqlDbType.Int);
                strParametros[5].Value = Cod_Unidade_DARF;
                strParametros[6] = new SqlParameter("@DATA_VENCIMENTO_DARF", SqlDbType.DateTime);
                strParametros[6].Value = DateTime.Now;
                strParametros[7] = new SqlParameter("@VLR_PRINCIPAL_DARF", SqlDbType.Decimal);
                strParametros[7].Value = Valor_Principal_DARF;
                strParametros[8] = new SqlParameter("@VLR_MULTA_DARF", SqlDbType.Decimal);
                strParametros[8].Value = Vlr_Multa_DARF;
                strParametros[9] = new SqlParameter("@VLR_JUROS_DARF", SqlDbType.Decimal);
                strParametros[9].Value = Vlr_Juros_DARF;
                strParametros[10] = new SqlParameter("@DATA_INCLUSAO_DARF", SqlDbType.DateTime);
                strParametros[10].Value = DateTime.Now;
                strParametros[11] = new SqlParameter("@OBSERVACOES_DARF", SqlDbType.VarChar);
                strParametros[11].Value = Observacoes_DARF;

                objDts = SqlHelper.ExecuteDataset(transacao, CommandType.StoredProcedure, "SP_VAREJO_GERAR_DARF", strParametros);
                ID_DARF = Convert.ToInt32(objDts.Tables[0].Rows[0]["ID_DARF"]);

            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: VarejoGerarDARF()", "Arquivo: funcoes.cs");
            }
            return ID_DARF;
        }
        //método para cadastrar usuario na TBL_LOGIN_INTEGRADO
        //Chamado 124128 - Rotina de pré-cadastro
        public static string[] MigrarCliente(string num_doc, string nome, string email, string tipoCliente, DateTime dtValidade)
        {
            string senha = GeraSenha(8);

            try
            {
                SqlParameter[] strParametros = new SqlParameter[7];
                strParametros[0] = new SqlParameter("@US_NUM_DOC", SqlDbType.NVarChar, 25);
                strParametros[0].Value = num_doc;

                strParametros[1] = new SqlParameter("@US_NOME", SqlDbType.NVarChar, 300);
                strParametros[1].Value = nome;

                strParametros[2] = new SqlParameter("@US_VALIDADE", SqlDbType.DateTime, 8);
                strParametros[2].Value = String.Format("{0:yyyy-MM-dd}", dtValidade);

                strParametros[3] = new SqlParameter("@US_EMAIL", SqlDbType.VarChar, 100);
                strParametros[3].Value = email;

                strParametros[4] = new SqlParameter("@ID_USUARIO", SqlDbType.VarChar, 25);
                strParametros[4].Value = "1812"; //DEFINIR QUAL O USUARIO PADRÃO

                strParametros[5] = new SqlParameter("@US_TIPOCLIENTE", SqlDbType.Char, 1);
                strParametros[5].Value = tipoCliente;

                strParametros[6] = new SqlParameter("@LI_SENHA", SqlDbType.NVarChar, 8);
                strParametros[6].Value = senha;

                SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Migrar_cliente", strParametros);

            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: MigrarCliente()", "Arquivo: precadastro.aspx");
            }

            // Recuperando ID do cliente da Login Integrado
            SqlDataReader dr_li = null;
            try
            {
                SqlParameter[] strParametros_li = new SqlParameter[1];
                strParametros_li[0] = new SqlParameter("@LI_DOC", SqlDbType.VarChar, 25);
                strParametros_li[0].Value = num_doc;

                dr_li = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBCCME_Ler_Usuario", strParametros_li);

                if (dr_li != null)
                {
                    if (dr_li.HasRows)
                    {
                        dr_li.Read();
                        return (new string[] { dr_li[8].ToString(), senha }); // ID_USUARIO
                    }
                }
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: MigrarCliente()", "Arquivo: precadastro.aspx");
            }
            finally
            {
                if (dr_li != null)
                {
                    if (!dr_li.IsClosed)
                    {
                        dr_li.Close();
                        dr_li.Dispose();
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// Consulta Lista de Parametros para cadastro na tabela TBL_COL_PARAM_CLI
        /// </summary>
        /// <returns>DataTable com o resultado da pesquisa</returns>
        public static DataTable GetListaParametrosCOLPF()
        {
            DataSet objdts = new DataSet();
            try
            {
                objdts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, "SELECT nm_campo, nm_descricao, vl_campo FROM TBL_COL_PARAM_PF WHERE fg_ativo = 1 and id_sistema = 10 and cl_tabela = 'TBL_COL_PARAMCLI'");
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetListaParametrosCOLPF()", "Arquivo: Funcoes.cs");
            }

            return objdts.Tables[0];
        }

        /// <summary>
        /// Retorna lista de parametros para cadastro de clientes na TBL_CLIENTES
        /// </summary>
        /// <returns>DataTable com o resultado da pesquisa</returns>
        public static DataTable GetListaParametrosTBLCLIENTES(int Ativo)
        {
            DataSet objDts = new DataSet();
            try
            {
                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, "SELECT nm_campo, nm_descricao, vl_campo FROM TBL_COL_PARAM_PF WHERE fg_ativo = " + Ativo + " and id_sistema = 10 and cl_tabela = 'TBL_CLIENTES'");
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetListaParametrosTBLCLIENTES()", "Arquivo: Funcoes.cs");
            }

            return objDts.Tables[0];
        }

        public static DataTable GetTarifa()
        {
            DataSet objDts = new DataSet();
            try
            {
                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, "SELECT nm_campo, nm_descricao, vl_campo FROM TBL_COL_PARAM_PF WHERE id_sistema = 10 and cl_tabela = 'TBL_CLIENTES' and nm_campo='CL_TARIFA'");
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetTarifa()", "Arquivo: Funcoes.cs");
            }

            return objDts.Tables[0];
        }

        public static DataTable GetTarifaGoogle()
        {
            DataSet objDts = new DataSet();
            try
            {
                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, "SELECT nm_campo, nm_descricao, vl_campo FROM TBL_COL_PARAM_PF WHERE id_sistema = 10 and cl_tabela = 'TBL_CLIENTES' and nm_campo='CL_TARIFA_GOOGLE'");
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetListaParametrosTBLCLIENTES()", "Arquivo: Funcoes.cs");
            }

            return objDts.Tables[0];
        }

        /// <summary>
        /// Grava parametros do cliente na TBL_CLIENTES
        /// </summary>
        /// <param name="strParametros">Array com os parametros a serem gravados</param>
        public static void GravaParametrosTBLClientes(SqlParameter[] strParametros)
        {
            try
            {
                SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "PR_TBL_CLIENTES_Atualizar", strParametros);
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: GravaParametrosTBLCLientes()", "Arquivo: Funcoes.cs");
            }
        }

        /// <summary>
        /// Insere na tabela TBL_CPFS
        /// </summary>
        /// <param name="cl_num_doc">Número do documento (CPF/CNPJ)</param>
        /// <param name="cl_passaporte">Número do passaporte</param>
        public static void GravaParametrosTBLCPFS(string cl_num_doc, string cl_passaporte)
        {
            try
            {
                SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.Text, "insert into tbl_cpfs (cpf_num, cpf_status, id_nivel, cpf_st_receita, cpf_dt_inclusao, cl_passaporte) values ('" + cl_num_doc + "' , 'L', 1, 0, getdate(),  '" + cl_passaporte + "')");
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: GravaParametrosTBLCPFS()", "Arquivo: Funcoes.cs");
            }
        }

        /// <summary>
        /// Grava parametros do cliente na TBL_COL_PARAM_CLI
        /// </summary>
        /// <param name="strParametros">Array com os parametros a serem gravados</param>
        public static void GravaParametrosCliente(SqlParameter[] strParametros)
        {
            try
            {
                SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_ParametrosCliente", strParametros);
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: GravaParametrosCliente()", "Arquivo: Funcoes.cs");
            }
        }

        /// <summary>
        /// Consulta e-mails para envio
        /// </summary>
        /// <param name="strParametros">Parametros da pesquisa</param>
        public static DataTable ConsultaEmailAcessoSenha(SqlParameter[] strParametros)
        {
            DataSet objDts = new DataSet();

            try
            {
                objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_ADMIN_CONFIG", strParametros);
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: ConsultaEmailAcessoSenha()", "Arquivo: Funcoes.cs");
            }

            return objDts.Tables[0];
        }

        //método para inserir um pré-cadastro na TBL_PRE_CADASTRO
        //Chamado 124128 - Rotina de pré-cadastro
        public static int GravaPreCadastro(string tipoDoc, string numDoc, string nome, string sobrenome, string email, string contato, string telefone, string faseAtual, bool status, string flg_google)
        {
            int ret = 0;
            try
            {
                SqlParameter[] strParametros = new SqlParameter[11];

                strParametros[0] = new SqlParameter("@cl_tipo_doc", SqlDbType.VarChar, 25);
                strParametros[0].Value = tipoDoc;

                strParametros[1] = new SqlParameter("@cl_num_doc", SqlDbType.VarChar, 25);
                strParametros[1].Value = numDoc;

                strParametros[2] = new SqlParameter("@cl_nome_razaosocial", SqlDbType.VarChar, 150);
                strParametros[2].Value = nome;

                strParametros[3] = new SqlParameter("@cl_sobrenome_nomefantasia", SqlDbType.VarChar, 150);
                strParametros[3].Value = sobrenome;

                strParametros[4] = new SqlParameter("@cl_email", SqlDbType.VarChar, 140);
                strParametros[4].Value = email;

                strParametros[5] = new SqlParameter("@cl_nome_contato", SqlDbType.VarChar, 150);
                strParametros[5].Value = contato;

                strParametros[6] = new SqlParameter("@cl_telefone", SqlDbType.VarChar, 23);
                strParametros[6].Value = telefone;

                strParametros[7] = new SqlParameter("@fase_atual", SqlDbType.VarChar, 1);
                strParametros[7].Value = faseAtual;

                strParametros[8] = new SqlParameter("@status_cadastro", SqlDbType.Bit);
                strParametros[8].Value = status;

                strParametros[9] = new SqlParameter("@flg_google", SqlDbType.Char, 1);
                strParametros[9].Value = flg_google;

                strParametros[10] = new SqlParameter("@IdRetorno", SqlDbType.BigInt);
                strParametros[10].Direction = ParameterDirection.Output;

                SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "PR_TBL_PRE_CADASTRO_Inserir", strParametros);

                ret = Convert.ToInt32(strParametros[10].Value);
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetUserPortalCrm()", "Arquivo: Funcoes.cs");
            }

            return ret;
        }

        public static DataTable PesquisarPreCadastro(string numDoc)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[1];

            strParametros[0] = new SqlParameter("@cl_num_doc", SqlDbType.VarChar);
            strParametros[0].Value = numDoc;

            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "PR_TBL_PRE_CADASTRO_Selecionar", strParametros);

            return objDts.Tables[0];
        }

        public static void AtualizaPreCadastro(SqlParameter[] parametros)
        {
            try
            {
                SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "PR_TBL_PRE_CADASTRO_Atualizar", parametros);
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: AtualizaPreCadastro()", "Arquivo: funcoes.cs");
            }
        }
        public static void ExcluirPreCadastroCompAcionario(int id_ca, int id_precadastro)
        {
            try
            {
                SqlParameter[] strParametros = new SqlParameter[2];

                strParametros[0] = new SqlParameter("@id_ca", SqlDbType.VarChar);
                strParametros[0].Value = id_ca;
                strParametros[1] = new SqlParameter("@id_precadastro", SqlDbType.VarChar);
                strParametros[1].Value = id_precadastro;

                SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "PR_TBL_PRE_CADASTRO_CLI_COMP_ACIONARIO_Excluir", strParametros);
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: ExcluirPreCadastroCompAcionario()", "Arquivo: funcoes.cs");
            }
        }
        public static void AtualizaPreCadastroComposicaoAcionaria(SqlParameter[] parametros)
        {
            try
            {
                SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "PR_TBL_PRE_CADASTRO_CLI_COMP_ACIONARIO_Atualizar", parametros);
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: AtualizaPreCadastroComposicaoAcionaria()", "Arquivo: funcoes.cs");
            }
        }

        public static int MigrarPreCadastroCompAcionario(int id_pre_cadastro, int id_cliente)
        {
            int objInt = 0;
            //DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[2];

            strParametros[0] = new SqlParameter("@id_pre_cadastro", SqlDbType.VarChar);
            strParametros[0].Value = id_pre_cadastro;
            strParametros[1] = new SqlParameter("@id_cliente", SqlDbType.VarChar);
            strParametros[1].Value = id_cliente;

            objInt = SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "PR_TBL_PRE_CADASTRO_CLI_COMP_ACIONARIO_Migrar", strParametros);

            return objInt;


        }

        public static DataTable PesquisarPreCadastroComposicaoAcionaria(int id_pre_cadastro)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[1];

            strParametros[0] = new SqlParameter("@id_pre_cadastro", SqlDbType.VarChar);
            strParametros[0].Value = id_pre_cadastro;

            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "PR_TBL_PRE_CADASTRO_CLI_COMP_ACIONARIA_Selecionar", strParametros);

            return objDts.Tables[0];
        }

        public static DataTable ListarContasCliente(int id_cliente, string tipo)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[2];

            strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[0].Value = id_cliente;

            strParametros[1] = new SqlParameter("@TIPO", SqlDbType.Char);
            strParametros[1].Value = tipo;

            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_LISTAR_CONTAS_CLIENTE", strParametros);

            return objDts.Tables[0];
        }

        public static DataTable SelecionarContaCliente(int id_cliente, int id_banco, string tipo)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[3];

            strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[0].Value = id_cliente;

            strParametros[1] = new SqlParameter("@ID_BANCO", SqlDbType.Int);
            strParametros[1].Value = id_banco;

            strParametros[2] = new SqlParameter("@TIPO", SqlDbType.Char);
            strParametros[2].Value = tipo;

            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_SELECIONAR_CONTA_CLIENTE", strParametros);

            return objDts.Tables[0];
        }

        /// <summary>
        /// Seleciona os dados da conta bancária do cliente através da SPCOL_SELECIONAR_CONTA_CLIENTE_GOOGLE
        /// </summary>
        /// <param name="id_cliente"></param>
        /// <param name="id_banco"></param>
        /// <param name="tipo"></param>
        /// <param name="nome_banco"></param>
        /// <returns></returns>
        public static DataTable SelecionarContaCliente(int id_cliente, int id_banco, string tipo, string nome_banco)
        {
            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[4];

            strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[0].Value = id_cliente;

            strParametros[1] = new SqlParameter("@ID_BANCO", SqlDbType.Int);
            strParametros[1].Value = id_banco;

            strParametros[2] = new SqlParameter("@TIPO", SqlDbType.Char);
            strParametros[2].Value = tipo;

            strParametros[3] = new SqlParameter("@NOME", SqlDbType.Char);
            strParametros[3].Value = nome_banco;

            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_SELECIONAR_CONTA_CLIENTE_GOOGLE", strParametros);

            return objDts.Tables[0];
        }

        public static decimal ObterValorParametrosConfiguracoes(string tipo, string operacao)
        {
            decimal retorno = 0;

            DataSet objDts = new DataSet();
            SqlParameter[] strParametros = new SqlParameter[2];

            strParametros[0] = new SqlParameter("@CONFIG_TIPO", SqlDbType.VarChar, 20);
            strParametros[0].Value = tipo;

            strParametros[1] = new SqlParameter("@CONFIG_OP", SqlDbType.Char, 1);
            strParametros[1].Value = operacao;


            objDts = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "SPCOL_GETTBL_CONFIGURACOES", strParametros);

            if (objDts.Tables.Count > 0 && objDts.Tables[0].Rows.Count > 0)
            {
                if (objDts.Tables[0].Rows[0]["config_valor"] != DBNull.Value)
                {
                    retorno = Convert.ToDecimal(objDts.Tables[0].Rows[0]["config_valor"]);
                }
            }

            return retorno;
        }

        public static string ObtemCodigoIban(string documento, string empresa)
        {
            SqlParameter[] parametros = new SqlParameter[2];
            parametros[0] = new SqlParameter("@DOCUMENTO", SqlDbType.VarChar, 40);
            parametros[0].Value = documento;
            parametros[1] = new SqlParameter("@EMPRESA", SqlDbType.VarChar, 10);
            parametros[1].Value = empresa;

            var dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "PR_GERADOR_IBAN", parametros);

            if (dr.HasRows)
            {
                dr.Read();
                return dr.GetString(dr.GetOrdinal("IBAN"));
            }

            return string.Empty;
        }

        public static bool ObterValorParametrosConfiguracoes(int idCliente)
        {
            SqlDataReader dr = null;

            SqlParameter[] strParametros = new SqlParameter[1];

            strParametros[0] = new SqlParameter("@id_cliente", SqlDbType.Int);
            strParametros[0].Value = idCliente;

            dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SP_VerificaClienteComContaReendimento", strParametros);

            if (dr != null)
            {
                if (dr.HasRows)
                {
                    dr.Read();
                    return (int.Parse(dr[0].ToString()) > 0 ? true : false);
                }
            }
            return false;
        }

        public static bool BoletoTipoGoogle(int numBoleto)
        {
            var sqlquery = new StringBuilder();
            sqlquery.Append("SELECT TOP 1 M.FlagGoogle ");
            sqlquery.Append("FROM IK_VAREJO.dbo.TBL_MEWEB_MT103 AS M WITH(NOLOCK) ");
            sqlquery.Append("INNER JOIN TBL_PRE_BOLETO AS B WITH(NOLOCK) ON M.OP_N_BOLETO = B.OP_N_BOLETO ");
            sqlquery.Append("WHERE B.OP_N_BOLETO = @OP_N_BOLETO ");

            SqlParameter[] strParametros = new SqlParameter[1];

            strParametros[0] = new SqlParameter("@OP_N_BOLETO", SqlDbType.Int);
            strParametros[0].Value = numBoleto;

            var ds = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, sqlquery.ToString(), strParametros);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return Convert.ToBoolean(ds.Tables[0].Rows[0]["FlagGoogle"]);
            }

            return false;
        }

        public static bool NotificaProcuracaoPendente(int idCliente, int quantidadeOperacoes, int quantidadeDias, decimal limiteAssinatura)
        {
            try
            {
                StringBuilder sqlquery = new StringBuilder();
                sqlquery.Append("SELECT CASE WHEN COUNT(*) % @QTDE_OPS = 0 THEN 1 ELSE 0 END AS NOTIFICACAO ");
                sqlquery.Append("FROM  TBL_PRE_BOLETO TPB WITH (NOLOCK) ");
                sqlquery.Append("WHERE (TPB.OP_TAXA_BANCO/TPB.OP_TAXA_PRONTO_D)*TPB.OP_VAL_MOEDA >= @VALOR_LIMITE_BOLETO  ");
                sqlquery.Append("AND TPB.OP_DATA_BOLETO >= DATEADD(DAY,-@QTDE_DIAS,GETDATE()) ");
                sqlquery.Append("AND PRE_BOLETO_STATUS = 2 ");
                sqlquery.Append("AND SISTEMA_ORIGEM IN ('SF','PC') ");
                sqlquery.Append("AND TPB.ID_CLIENTE = @ID_CLIENTE ");

                SqlParameter[] parametros = new SqlParameter[4];
                parametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                parametros[0].Value = idCliente;
                parametros[1] = new SqlParameter("@QTDE_DIAS", SqlDbType.Int);
                parametros[1].Value = quantidadeDias;
                parametros[2] = new SqlParameter("@QTDE_OPS", SqlDbType.Int);
                parametros[2].Value = quantidadeOperacoes;
                parametros[3] = new SqlParameter("@VALOR_LIMITE_BOLETO", SqlDbType.Decimal);
                parametros[3].Value = limiteAssinatura;

                var ds = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.Text, sqlquery.ToString(), parametros);

                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    return Convert.ToBoolean(ds.Tables[0].Rows[0]["NOTIFICACAO"]);
                }
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: NotificaProcuracaoPendente()", "Arquivo: funcoes.cs");
            }

            return false;
        }

        public static bool StatusBoletoZero(int pre_n_boleto)
        {
            SqlDataReader dr = null;

            SqlParameter[] strParametros = new SqlParameter[1];

            strParametros[0] = new SqlParameter("@pre_n_boleto", SqlDbType.Int);
            strParametros[0].Value = pre_n_boleto;

            dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SP_VerificaStatusBoleto", strParametros);

            if (dr != null)
            {
                if (dr.HasRows)
                {
                    dr.Read();
                    return (int.Parse(dr[0].ToString()) == 0 ? true : false);
                }
            }

            return false;
        }

        public static void AtualizaStatusBoleto(int pre_n_boleto, int status)
        {
            SqlDataReader dr = null;

            SqlParameter[] strParametros = new SqlParameter[2];

            strParametros[0] = new SqlParameter("@pre_n_boleto", SqlDbType.Int);
            strParametros[0].Value = pre_n_boleto;

            strParametros[1] = new SqlParameter("@Status", SqlDbType.Int);
            strParametros[1].Value = status;

            dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SP_AtualizaStatusBoleto", strParametros);
        }

        /// <summary>
        /// Atenção: O @ID_USER_CLIENTE é como se fosse @ID_USUARIO
        /// </summary>
        /// <param name="idupload"></param>
        /// <param name="nboleto"></param>
        /// <param name="hash"></param>
        /// <param name="li_id">id do usuário logado</param>
        /// <param name="ip"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public static int AssinaEletronicamenteBoleto(int idupload, int nboleto, string hash, int li_id, string ip, SqlTransaction transaction)
        {
            SqlParameter[] sqlParametros = new SqlParameter[7];
            sqlParametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 20);
            sqlParametros[0].Value = "ASSINATURA_CLIENTE";
            sqlParametros[1] = new SqlParameter("@STATUS", SqlDbType.Char, 1);
            sqlParametros[1].Value = "C";
            sqlParametros[2] = new SqlParameter("@ID_ARQUIVO_UPLOAD", SqlDbType.Int);
            sqlParametros[2].Value = idupload;
            sqlParametros[3] = new SqlParameter("@OP_N_BOLETO", SqlDbType.Int);
            sqlParametros[3].Value = nboleto;
            sqlParametros[4] = new SqlParameter("@HASH_DOCUMENTO", SqlDbType.NVarChar);
            sqlParametros[4].Value = hash;
            sqlParametros[5] = new SqlParameter("@ID_USER_CLIENTE", SqlDbType.Int);
            sqlParametros[5].Value = li_id;
            sqlParametros[6] = new SqlParameter("@IP_CLIENTE", SqlDbType.VarChar, 50);
            sqlParametros[6].Value = ip;

            return SqlHelper.ExecuteNonQuery(transaction, CommandType.StoredProcedure, "PR_BOLETO_ASSINADO_DIGITALMENTE", sqlParametros);
        }

        public static void Atualiza_LoginIntegradoUsuarios_LU(string login)
        {
            try
            {
                SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.Text, "UPDATE TBL_LOGIN_INTEGRADO SET LI_ACESSO_ECONTRATOS = 'N', LI_EDITA_OP = 'S', LI_CANCELA_OP = 'S' WHERE LI_DOC = '" + login + "'");
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: Atualiza_LoginIntegradoUsuarios_LU()", "Arquivo: Funcoes.cs");
            }

            try
            {
                SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.Text, "UPDATE TBL_CLIENTES SET CL_COD_VENDEDOR = '00' WHERE cl_num_doc = '" + login + "'");
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: Atualiza_LoginIntegradoUsuarios_LU()", "Arquivo: Funcoes.cs");
            }

            try
            {
                SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.Text, "INSERT INTO TBL_CPFS (CPF_NUM, cpf_status, id_nivel, cpf_st_receita, cpf_dt_inclusao, CL_PASSAPORTE) " +
                                                                              "VALUES('" + login + "','L',1,0,GETDATE(),'')");
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: Atualiza_LoginIntegradoUsuarios_LU()", "Arquivo: Funcoes.cs");
            }
        }

        public static Tuple<decimal, string, string> RetornaTaxaOperacao(decimal valMoeda, decimal valReais, decimal taxaOperacao, string moeda, decimal taxaIr, bool tipoClienteAgencia, bool irSaida)
        {
            DataTable dr = new DataTable();

            dr = GetCalculoIR("D", valMoeda, valReais, taxaOperacao, moeda, taxaIr);

            if (dr.Rows.Count > 0)
            {
                decimal decPTax;
                string valIr = "0,00";
                string val_reais = string.Empty;

                //calcula o valor independente do IR_SAIDA
                decPTax = Convert.ToDecimal(dr.Rows[0]["VALOR_PTAX"].ToString());

                //VALOR_LIQ_REAIS é calculado caso IR_SAIDA = N 
                //OBSERVAÇÃO: VALOR_LIQ_MOEDA só é calculado se o UtilizaAliquota = C, e está sendo utilizado o valor D de forma fixa.
                if (!irSaida)
                {
                    val_reais = Math.Round(Convert.ToDecimal(dr.Rows[0]["VALOR_LIQ_REAIS"].ToString()), 2, MidpointRounding.AwayFromZero).ToString("N");
                }
                else
                {
                    val_reais = valReais.ToString("N");
                }

                //ValorIR é calculado com IR_SAIDA = N, ou IR_SAIDA ‘SIM’ e clientes Agência de Turismo.
                //Ajustado para IR_SAIDA = N ou clientes Agência de Turismo.
                if ((!irSaida) || (tipoClienteAgencia))
                {
                    if (Convert.ToDecimal(dr.Rows[0]["VALOR_IR_REAIS"].ToString()) >= 10)
                    {
                        valIr = Math.Round(Convert.ToDecimal(dr.Rows[0]["VALOR_IR_REAIS"].ToString()), 2, MidpointRounding.AwayFromZero).ToString("N");
                    }
                }

                return new Tuple<decimal, string, string>(decPTax, val_reais, valIr);

            }

            return null;
        }

        public static bool GetClienteTemMeSubConta(string idCliente)
        {
            DataTable objDts = null;
            bool retorno = false;
            string sub_status = "A";

            try
            {
                TBL_ME_SUBCONTA objTblMeSubConta = new TBL_ME_SUBCONTA();

                objDts = objTblMeSubConta.obterDataTable("id_cliente = '" + idCliente + "' and sub_status = '" + sub_status + "'  ", "", null);

                if (objDts.Rows.Count > 0)
                {
                    retorno = true;
                }
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Erro: GetClienteTemMeSubConta()", "Arquivo: funcoes.cs <br> GetClienteTemMeSubConta(" + idCliente + ")");
            }
            finally
            {
                if (objDts != null)
                {
                    if (objDts.Rows.Count > 0)
                    {
                        objDts.Dispose();
                    }
                }
            }

            return retorno;

        }

        //public static decimal LimiteOperacao(string idCliente, string natureza)
        //{
        //    try
        //    {
        //        decimal limiteNatureza = 0;

        //        // Verifica parametro no cad. da natureza
        //        TBL_NATUREZA objNatureza = new TBL_NATUREZA();
        //        ArrayList arrNat = objNatureza.obter("id_natureza = " + natureza);
        //        if (arrNat.Count > 0)
        //        {
        //            limiteNatureza = ((TBL_NATUREZA)arrNat[0]).portal_valor;
        //        }

        //        // Verifica parametro no cad. de cliente
        //        decimal valorCliente = 0;
        //        TBL_CLIENTES objCliente = new TBL_CLIENTES();
        //        ArrayList arrCli = objCliente.Obter ("id_cliente = " + idCliente);
        //        string pValor = GetConfigParamCli(((TBL_CLIENTES)arrCli[0]).cl_num_doc, "param_limite_operacao");
        //        if (pValor != "")
        //        {
        //            valorCliente = Convert.ToDecimal(pValor);
        //        }

        //        if (valorCliente > 0)
        //        {
        //            if (valorCliente < limiteNatureza)
        //            {
        //                return valorCliente;
        //            }
        //            else
        //            {
        //                return limiteNatureza;
        //            }
        //        }
        //        else
        //        {
        //            return limiteNatureza;
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        GravarErro(ex, "Erro: LimiteOperacao()", string.Format("idCliente:{0} , natureza:{1}", idCliente, natureza));                
        //    }

        //    return 0;
        //}
    }
}
