﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rendimento.Portal.CambioOnline.DAO
{
    public class ProcuracoesClienteDAO
    {
        private static string strConexaoDecode = Executar.obterStringConexao("Rendimento.Portal.CambioOnline.Modelos.ModelosCambio.*");

        public static string ObterStringConexao()
        {
            return strConexaoDecode;
        }

        public static DataTable BuscarProcuracoesAtivas(Nullable<int> idprocuracao, Nullable<int> idcliente, string tipo, Nullable<int> status)
        {
            SqlParameter[] parametros = new SqlParameter[5];
            parametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 100);
            parametros[1] = new SqlParameter("@ID", SqlDbType.Int);
            parametros[2] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            parametros[3] = new SqlParameter("@TIPO_PROCURACAO", SqlDbType.Char, 1);
            parametros[4] = new SqlParameter("@STATUS", SqlDbType.Char, 1);

            parametros[0].Value = "SELECT";
            if (idprocuracao.HasValue)
                parametros[1].Value = idprocuracao.Value;
            else
                parametros[1].Value = DBNull.Value;
            if (idcliente.HasValue)
                parametros[2].Value = idcliente.Value;
            else
                parametros[2].Value = DBNull.Value;
            if (!string.IsNullOrWhiteSpace(tipo))
                parametros[3].Value = tipo.Trim();
            else
                parametros[3].Value = DBNull.Value;

            if (status.HasValue)
                parametros[4].Value = status.Value;
            else
                parametros[4].Value = DBNull.Value;

            var dt = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "PR_PROCURACAO_CLIENTE", parametros);

            if (dt != null && dt.Tables.Count > 0 && dt.Tables[0].Rows.Count > 0)
                return dt.Tables[0];

            return null;
        }

        public static DataTable BuscarProcuracoesAtivas(Nullable<int> idprocuracao, Nullable<int> idcliente, string tipo, Nullable<int> status, SqlTransaction transacao)
        {
            SqlParameter[] parametros = new SqlParameter[5];
            parametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 100);
            parametros[1] = new SqlParameter("@ID", SqlDbType.Int);
            parametros[2] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            parametros[3] = new SqlParameter("@TIPO_PROCURACAO", SqlDbType.Char, 1);
            parametros[4] = new SqlParameter("@STATUS", SqlDbType.Char, 1);

            parametros[0].Value = "SELECT";
            if (idprocuracao.HasValue)
                parametros[1].Value = idprocuracao.Value;
            else
                parametros[1].Value = DBNull.Value;
            if (idcliente.HasValue)
                parametros[2].Value = idcliente.Value;
            else
                parametros[2].Value = DBNull.Value;
            if (!string.IsNullOrWhiteSpace(tipo))
                parametros[3].Value = tipo.Trim();
            else
                parametros[3].Value = DBNull.Value;

            if (status.HasValue)
                parametros[4].Value = status.Value;
            else
                parametros[4].Value = DBNull.Value;

            var dt = SqlHelper.ExecuteDataset(transacao, CommandType.StoredProcedure, "PR_PROCURACAO_CLIENTE", parametros);

            if (dt != null && dt.Tables.Count > 0 && dt.Tables[0].Rows.Count > 0)
                return dt.Tables[0];

            return null;
        }

        public static DataTable BuscarModeloProcuracao(int idcliente)
        {
            SqlParameter[] parametros = new SqlParameter[2];
            parametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 100);
            parametros[0].Value = "RETORNA_TEXTO";
            parametros[1] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            parametros[1].Value = idcliente;

            var dt = SqlHelper.ExecuteDataset(strConexaoDecode, CommandType.StoredProcedure, "PR_MODELO_PROCURACAO", parametros);

            if (dt != null && dt.Tables.Count > 0 && dt.Tables[0].Rows.Count > 0)
                return dt.Tables[0];

            return null;
        }

        public static Nullable<int> IncluirProcuracao(int idCliente, int idUpload, string enderecoIP, string tipo, int status, string hash)
        {
            SqlParameter[] parametros = new SqlParameter[8];
            parametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 100);
            parametros[0].Value = "INSERT";
            parametros[1] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            parametros[1].Value = idCliente;
            parametros[2] = new SqlParameter("@ID_ARQUIVO_UPLOAD", SqlDbType.Int);
            parametros[2].Value = idUpload;
            parametros[3] = new SqlParameter("@TIPO_PROCURACAO", SqlDbType.Char, 1);
            parametros[3].Value = tipo;
            parametros[4] = new SqlParameter("@STATUS", SqlDbType.Int);
            parametros[4].Value = status;
            parametros[5] = new SqlParameter("@IP_ACEITE_PROCURACAO", SqlDbType.VarChar, 50);
            parametros[5].Value = enderecoIP;
            parametros[6] = new SqlParameter("@HASH_PROCURACAO", SqlDbType.NVarChar);
            if (!string.IsNullOrWhiteSpace(hash))
                parametros[6].Value = hash;
            else
                parametros[6].Value = DBNull.Value;
            parametros[7] = new SqlParameter("DT_ATIVACAO", SqlDbType.DateTime);
            parametros[7].Value = DateTime.Now;

            var dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "PR_PROCURACAO_CLIENTE", parametros);

            if (dr != null && dr.HasRows)
            {
                dr.Read();

                return (int)dr.GetDecimal(dr.GetOrdinal("ID"));
            }

            return null;
        }

        public static int AtualizaProcuracaoDigital(int idprocuracao, int idcliente, int idupload, string enderecoip, int status)
        {
            SqlParameter[] parametros = new SqlParameter[8];
            parametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 100);
            parametros[0].Value = "UPDATE";
            parametros[1] = new SqlParameter("@ID", SqlDbType.Int);
            parametros[1].Value = idprocuracao;
            parametros[2] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            parametros[2].Value = idcliente;
            parametros[3] = new SqlParameter("@ID_ARQUIVO_UPLOAD", SqlDbType.Int);
            parametros[3].Value = idupload;
            parametros[4] = new SqlParameter("@IP_ACEITE_PROCURACAO", SqlDbType.VarChar, 50);
            parametros[4].Value = enderecoip;
            parametros[5] = new SqlParameter("@HASH_PROCURACAO", SqlDbType.NVarChar);
            parametros[5].Value = DBNull.Value;
            parametros[6] = new SqlParameter("DT_ATIVACAO", SqlDbType.DateTime);
            parametros[6].Value = DateTime.Now;
            parametros[7] = new SqlParameter("@STATUS", SqlDbType.Int);
            parametros[7].Value = status;

            return SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "PR_PROCURACAO_CLIENTE", parametros);
        }

        public static int DesativarProcuracoesDigitais(int idcliente, string tipo)
        {
            SqlParameter[] parametros = new SqlParameter[3];
            parametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 100);
            parametros[0].Value = "DISABLE";
            parametros[1] = new SqlParameter("@TIPO_PROCURACAO", SqlDbType.Char, 1);
            parametros[1].Value = tipo;
            parametros[2] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            parametros[2].Value = idcliente;

            return SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "PR_PROCURACAO_CLIENTE", parametros);
        }

        public static int AtualizaStatusProcuracaoPorId(int idprocuracao, int status)
        {
            SqlParameter[] parametros = new SqlParameter[3];
            parametros[0] = new SqlParameter("@ACAO", SqlDbType.VarChar, 100);
            parametros[0].Value = "UPDATE";
            parametros[1] = new SqlParameter("@STATUS", SqlDbType.Int);
            parametros[1].Value = status;
            parametros[2] = new SqlParameter("@id", SqlDbType.Int);
            parametros[2].Value = idprocuracao;

            return SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.StoredProcedure, "PR_PROCURACAO_CLIENTE", parametros);
        }

        public static decimal BuscarValorProcuracaoAntiga(int id_cliente)
        {
            decimal retorno = 0;

            var parametros = new SqlParameter[2];
            parametros[0] = new SqlParameter("@acao", SqlDbType.Char);
            parametros[0].Value = "1";     //   AÇÃO SELECIONAR VALOR
            parametros[1] = new SqlParameter("@cliente", SqlDbType.Int);
            parametros[1].Value = id_cliente;

            var dr = SqlHelper.ExecuteReader(strConexaoDecode, CommandType.StoredProcedure, "SPBVAR_VALOR_DOC_GOOGLE", parametros);

            if (dr != null && dr.HasRows)
            {
                dr.Read();
                Decimal.TryParse(dr["valor"].ToString().Replace(',', '.'), out retorno);
                    //retorno = Convert.ToDecimal(dr["valor"].ToString());                
            }

            return retorno;
        }

        public static int GravarLogCRM(int idcliente, Nullable<int> idusuario, Nullable<int> idcorretora, string ocorrencia, Nullable<int> numeroboleto, string passaporte, string campos, Nullable<int> idfilial, Nullable<int> idoperacao)
        {
            var sb = new StringBuilder();
            sb.Append("INSERT INTO TBL_CRM (ID_USUARIO,ID_CORRETORA,CRM_CPF_CNPJ,CRM_OCORRENCIA,CRM_NBOLETO,CRM_DATA,CRM_PASSAPORTE,CRM_CAMPOS,ID_FILIAL,CRM_ID_OPERACAO,CRM_AP) ");
            sb.Append("SELECT TOP 1 @ID_USUARIO,@ID_CORRETORA,CL_NUM_DOC,@CRM_OCORRENCIA,@CRM_NBOLETO,GETDATE(),@CRM_PASSAPORTE,@CRM_CAMPOS,@ID_FILIAL,@CRM_ID_OPERACAO,@CRM_AP FROM TBL_CLIENTES WITH(NOLOCK) WHERE ID_CLIENTE = @ID_CLIENTE");

            var parametros = new SqlParameter[10];
            parametros[0] = new SqlParameter("@ID_USUARIO", SqlDbType.Int);
            parametros[1] = new SqlParameter("@ID_CORRETORA", SqlDbType.Int);
            parametros[2] = new SqlParameter("@CRM_OCORRENCIA", SqlDbType.VarChar, 2048);
            parametros[3] = new SqlParameter("@CRM_NBOLETO", SqlDbType.Int);
            parametros[4] = new SqlParameter("@CRM_PASSAPORTE", SqlDbType.VarChar, 20);
            parametros[5] = new SqlParameter("@CRM_CAMPOS", SqlDbType.VarChar, 256);
            parametros[6] = new SqlParameter("@ID_FILIAL", SqlDbType.Int);
            parametros[7] = new SqlParameter("@CRM_ID_OPERACAO", SqlDbType.Decimal);
            parametros[7].Precision = 18;
            parametros[7].Scale = 0;
            parametros[8] = new SqlParameter("@CRM_AP", SqlDbType.Char, 1);
            parametros[9] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);

            if (idusuario.HasValue)
                parametros[0].Value = idusuario.Value;
            else
                parametros[0].Value = DBNull.Value;

            if (idcorretora.HasValue)
                parametros[1].Value = idcorretora.Value;
            else
                parametros[1].Value = DBNull.Value;

            if (!string.IsNullOrWhiteSpace(ocorrencia))
                parametros[2].Value = ocorrencia;
            else
                parametros[2].Value = DBNull.Value;

            if (numeroboleto.HasValue)
                parametros[3].Value = numeroboleto.Value;
            else
                parametros[3].Value = DBNull.Value;

            if (!string.IsNullOrWhiteSpace(passaporte))
                parametros[4].Value = passaporte;
            else
                parametros[4].Value = DBNull.Value;

            if (!string.IsNullOrWhiteSpace(campos))
                parametros[5].Value = campos;
            else
                parametros[5].Value = DBNull.Value;

            if (idfilial.HasValue)
                parametros[6].Value = idfilial.Value;
            else
                parametros[6].Value = DBNull.Value;

            if (idoperacao.HasValue)
                parametros[7].Value = idoperacao.Value;
            else
                parametros[7].Value = DBNull.Value;

            parametros[8].Value = DBNull.Value;
            parametros[9].Value = idcliente;

            return SqlHelper.ExecuteNonQuery(strConexaoDecode, CommandType.Text, sb.ToString(), parametros);
        }
    }
}
