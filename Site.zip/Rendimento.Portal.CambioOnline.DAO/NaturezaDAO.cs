﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using Dapper;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;

namespace Rendimento.Portal.CambioOnline.DAO
{
    public class NaturezaDAO : BaseDAO
    {
        public TBL_NATUREZA Get(int idNatureza)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<TBL_NATUREZA>(
                $@"SELECT * FROM TBL_NATUREZA (NOLOCK) 
                    WHERE id_natureza = @idNatureza
                ", param: new
                {
                    idNatureza = idNatureza
                }, commandType: CommandType.Text).FirstOrDefault();

            }
        }
    }
}
