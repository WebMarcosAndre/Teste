﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;
using Rendimento.Framework.Nucleo.Master.entAgentes.Servico;
using System.Configuration;
using System.Collections.Specialized;

namespace Rendimento.Portal.CambioOnline.DAO
{
    public class Executar
    {
        public static int Inserir(Object obj)
        {
            return ((BaseModelo)obj).inserir(null);
        }

        public static int Inserir(Object obj, Transacao objTrans)
        {
            return ((BaseModelo)obj).inserir(objTrans);
        }

        public static Int64 InserirRetornaMaxId(Object obj, string condicao)
        {
            if (condicao == "") condicao = "1=1";
            ((BaseModelo)obj).inserir(null);
            return ((BaseModelo)obj).obterMAX((BaseModelo)obj, ((BaseModelo)obj).nomeIdentificador, condicao);
        }

        public static ArrayList Obter(Object obj, string strCondicao)
        {
            return ((BaseModelo)obj).obter(strCondicao);
        }

        public static ArrayList Obter(Object obj, string strCondicao, Transacao objTrans)
        {
            return ((BaseModelo)obj).obter(strCondicao, objTrans);
        }

        public static DataTable ObterDataTable(Object obj, string strCondicao, string strOrdem, Transacao objTrans)
        {
            return ((BaseModelo)obj).obterDataTable(strCondicao, strOrdem, objTrans);
        }

        public static string obterStringConexao(string contexto)
        {
            Rendimento.Framework.Nucleo.Master.entAgentes.Modelo.Conexao conn = (Rendimento.Framework.Nucleo.Master.entAgentes.Modelo.Conexao)Rendimento.Framework.Nucleo.Master.entAgentes.Servico.Configuracao.obterTodosConexao(contexto)[0];
            string lStrStringConexao = "user id=" + conn.UsuarioBD + ";password=" + conn.SenhaBD + ";initial catalog=" + conn.NomeBD + ";data source=" + conn.ServidorBD + ";Connect Timeout=" + conn.TimeOutBD;
            if (conn.HabilitarPool)
            {
                if (conn.MinPool.ToString() == "") conn.MinPool = 0;
                if (conn.MaxPool.ToString() == "") conn.MaxPool = 50;
                lStrStringConexao += ";Pooling=true;Min Pool Size=" + conn.MinPool.ToString() + ";Max Pool Size=" + conn.MaxPool.ToString();
            }
            else
            {
                lStrStringConexao += ";Pooling=false";
            }

            return lStrStringConexao;
        }

        public static int Atualizar(Object obj, string condicao, string[] arrCampos, Transacao objTrans)
        {
            return ((BaseModelo)obj).atualizar(condicao, arrCampos, objTrans);
        }


        public static int Excluir(object obj, string condicao)
        {
            return ((BaseModelo)obj).remover(condicao, null);
        }

        public static int Excluir(object obj, string condicao, Transacao objTrans)
        {
            return ((BaseModelo)obj).remover(condicao, objTrans);
        }
    }
}
