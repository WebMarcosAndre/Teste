﻿using Dapper;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;


namespace Rendimento.Portal.CambioOnline.DAO
{
    public class CommonDAO
    {
        internal static string strConexao = Executar.obterStringConexao("Rendimento.Portal.CambioOnline.Modelos.ModelosCambio.*");

        public static IDbConnection Connection
        {
            get { return new SqlConnection(strConexao); }
        }               

        public static TEntity Get<TEntity>(string query, CommandType type)
        {
            return Get<TEntity>(query, null, type);
        }
        public static TEntity Get<TEntity>(string query, object param, CommandType type)
        {
            TEntity objeto = default(TEntity);
            using (IDbConnection cn = Connection)
            {
                objeto = cn.Query<TEntity>(query, param: param, commandType: type).FirstOrDefault();
            }
            return objeto;
        }
        public static dynamic Get(string query, object param, CommandType type)
        {
            dynamic objeto;
            using (IDbConnection cn = Connection)
            {
                objeto = cn.Query(query, param: param, commandType: type).FirstOrDefault();

            }
            return objeto;
        }
        public static void Insert(string query)
        {
            SqlHelper.ExecuteNonQuery(strConexao, CommandType.Text, query);
        }
        public static void Insert(string query, params SqlParameter[] commandParameters)
        {
            SqlHelper.ExecuteNonQuery(strConexao, CommandType.Text, query, commandParameters);
        }


        public static void Update(string query)
        {
            SqlHelper.ExecuteNonQuery(strConexao, CommandType.Text, query);
        }
    }
}
