﻿
using System.Collections.Generic;
using System.Data;
using Dapper;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;
using System.Linq;
using System;

namespace Rendimento.Portal.CambioOnline.DAO
{
    public class BoletoDAO : BaseDAO
    {
        public List<TBL_PRE_BOLETO> ListByClienteId(int idCliente)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<TBL_PRE_BOLETO>(
                $@"SELECT * FROM TBL_PRE_BOLETO (NOLOCK) 
                    WHERE id_cliente = @idCliente
                    AND CONVERT(DATE,op_data_inclusao) = CONVERT(DATE, GETDATE() )
                    AND pre_boleto_status IN (0,1) ", param: new
                {
                    idCliente = idCliente
                }, commandType: CommandType.Text).ToList();

            }
        }

        public List<TBL_PRE_BOLETO> ListByOver(int idCliente, string tipoOperacao, DateTime dataInicio, DateTime dataFim)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<TBL_PRE_BOLETO>(
                $@"
					SELECT b.* 
					FROM TBL_PRE_BOLETO b					
					INNER JOIN TBL_COL_PREBOLETO c (NOLOCK) 
							ON b.op_n_boleto = c.pre_n_boleto
                    WHERE b.id_cliente = @idCliente
                    AND c.pre_data_fase1 BETWEEN @dataInicio AND @dataFim
                    AND b.pre_boleto_status IN ( 0, 1, 2 ) 
                    AND b.op_tipo_operacao = @tipoOperacao                   
                    ", param: new
                {
                    idCliente = idCliente,
                    tipoOperacao = tipoOperacao,
                    dataInicio = dataInicio,
                    dataFim = dataFim
                }, commandType: CommandType.Text).ToList();

            }
        }

        public TBL_PRE_BOLETO Get(int numeroBoleto) {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<TBL_PRE_BOLETO>(
                $@"SELECT * FROM TBL_PRE_BOLETO (NOLOCK) 
                    WHERE op_n_boleto = @numeroBoleto
                     ", param: new
                {
                    numeroBoleto = numeroBoleto
                }, commandType: CommandType.Text).FirstOrDefault();

            }
        }
    }
}
