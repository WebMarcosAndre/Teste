﻿using System.Data;
using System.Linq;
using Dapper;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;

namespace Rendimento.Portal.CambioOnline.DAO
{
    public class CrmDAO:BaseDAO
    {
        public TBL_CRM Get_LogConfirmacaoFamiliaNoExterior( int numeroBoleto,string documentoCliente )
        {
            using (IDbConnection cn = Connection)
            {                
                return cn.Query<TBL_CRM>(
                    $@" SELECT * 
                        FROM TBL_CRM (NOLOCK) 
                        WHERE 
                                crm_ocorrencia = 'Cliente confirmou que o beneficiário é seu dependente'
                                AND crm_cpf_cnpj = @DocumentoCliente
                                AND crm_nboleto = @NumeroBoleto                           
                      ", param: new
                {
                    DocumentoCliente = documentoCliente,
                    NumeroBoleto = numeroBoleto                 
                    }, commandType: CommandType.Text).FirstOrDefault();

            }
        }
       

    }
}
