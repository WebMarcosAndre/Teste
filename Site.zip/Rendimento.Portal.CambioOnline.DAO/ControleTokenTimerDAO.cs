﻿

using System;
using System.Data;
using System.Data.SqlClient;
using Rendimento.Portal.CambioOnline.Modelos;

namespace Rendimento.Portal.CambioOnline.DAO
{
    public class ControleTokenTimerDAO
    {

        public TokenTimerConfig Get(int enumTokenTimer)
        {

            TokenTimerConfig tokenTimerConfig =
                CommonDAO.Get<TokenTimerConfig>(
                    $@"SELECT  Id, TipoClienteID, Descricao, CONVERT(DATETIME, Valor) Valor, DataCriacao
                    FROM ControleTokenTimerCambioOnlineConfig (NOLOCK) 
                    WHERE Id = {enumTokenTimer}"
                    , CommandType.Text);

            return tokenTimerConfig;

        }

        public void Insert(TokenTimer tokenTimer)
        {                    

            CommonDAO.Insert(
           
                    $@"INSERT INTO ControleTokenTimerCambioOnline (
                        Token, LiId, TokenConfigId, 
                        SimboloMoeda, QuantidadeMoeda, 
                        TaxaMoeda, IOF, Utilizado, DataCriacao
                    ) VALUES (
                        '{tokenTimer.Token}', 
                        {tokenTimer.LoginIntegrado.li_id}, 
                        {tokenTimer.TokenTimerConfig.ID}, 
                        '{tokenTimer.Moeda.moe_simbolo}',
                        '{tokenTimer.Quantidade.ToString().Replace(',','.')}', 
                        '{tokenTimer.Taxa.ToString().Replace(',','.')}', 
                        '{tokenTimer.IOF.ToString().Replace(',', '.')}',
                        {Convert.ToInt32(tokenTimer.Utilizado)}, 
                        '{tokenTimer.DataCriacao.ToString("yyyy-MM-dd hh:mm:ss")}'
                    )"
                    
                );
        }
        public void SetTokenAsUsed(TokenTimer tokenTimer)
        {
            CommonDAO.Update(
                  $@"UPDATE ControleTokenTimerCambioOnline SET                    
                        Utilizado = {Convert.ToInt32(tokenTimer.Utilizado)},
                        PreBoletoID = {tokenTimer.PreBoleto.op_n_boleto}
                   WHERE Token = '{tokenTimer.Token}'
                   "
              );
        }
    }
}
