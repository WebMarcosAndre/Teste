﻿using Rendimento.Portal.CambioOnline.DAO;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class ContasCadastradas
    {
        public TBL_MEWEB_CONTAS_CADASTRADAS SelecionarFavorecido(int idConta, int idCliente)
        {
            ContasCadastradasDAO contaDAO = new ContasCadastradasDAO();
            return contaDAO.SelecionarFavorecido(idConta, idCliente);
        }

        public void Salvar(TBL_MEWEB_CONTAS_CADASTRADAS conta)
        {
            ContasCadastradasDAO contaDAO = new ContasCadastradasDAO();
            if (conta.id_conta == 0)
                contaDAO.Inserir(conta);
            else contaDAO.Atualizar(conta);

        }
    }
}
