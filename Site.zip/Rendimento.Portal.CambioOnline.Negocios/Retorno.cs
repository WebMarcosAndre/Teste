﻿using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;
using Rendimento.Portal.CambioOnline.Negocios.Enum;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class Retorno
    {
        public static int GetUserPortalCrm(string param)
        {
            return DAO.Funcoes.GetUserPortalCrm(param);
        }

        public static string GetConfigCambioOnline(string param)
        {
            return DAO.Funcoes.GetConfigCambioOnline(param);
        }

        /// <summary>
        /// Parâmetros do Cliente Câmbio Online
        /// </summary>
        /// <param name="li_doc"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        public static string GetConfigParamCli(string li_doc, string param)
        {
            return DAO.Funcoes.GetConfigParamCli(li_doc, param);
        }

        /// <summary>
        /// Parâmetros de Produtos
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public static string GetConfigParamProdutos(string param)
        {
            return DAO.Funcoes.GetConfigParamProdutos(param);
        }

        public static string GetConfigParamProdutos(string param, SqlTransaction transacao)
        {
            return DAO.Funcoes.GetConfigParamProdutos(param, transacao);
        }

        public static decimal GetSpreadDia(DateTime dt_inicio, DateTime dt_fim, int id_cliente, int id_grupo)
        {
            return DAO.Funcoes.GetSpreadDia(dt_inicio, dt_fim, id_cliente, id_grupo);
        }

        public static int CreditarCCME(int id_cliente, string cod_moeda, string tipo, string tipo_operacao, decimal valor_operacao, int historico, int id_lancamento, string flag_disp, string flag_bloq, string obs, int quant_cheques, DateTime data_disp)
        {
            return DAO.Funcoes.CreditarCCME(id_cliente, cod_moeda, tipo, tipo_operacao, valor_operacao, historico, id_lancamento, flag_disp, flag_bloq, obs, quant_cheques, data_disp);
        }


        public static decimal LimiteOperacao(string idCliente)
        {
            decimal valorCliente = 0;
            Modelos.ModelosCambio.TBL_CLIENTES cli = new Modelos.ModelosCambio.TBL_CLIENTES();
            ArrayList arrCli = Operacoes.Obter(cli, "id_cliente = " + idCliente);
            string pValor = GetConfigParamCli(((Modelos.ModelosCambio.TBL_CLIENTES)arrCli[0]).cl_num_doc, "param_limite_operacao");
            if (pValor != "")
            {
                valorCliente = Convert.ToDecimal(pValor);
            }
            return valorCliente;

        }
        public static decimal LimiteOperacao(string idCliente, string natureza)
        {
            try
            {
                decimal limiteNatureza = 0;


                // Verifica parametro no cad. da natureza
                Modelos.ModelosCambio.TBL_NATUREZA obj = new Modelos.ModelosCambio.TBL_NATUREZA();
                ArrayList arrNat = Operacoes.Obter(obj, "id_natureza = " + natureza);
                if (arrNat.Count > 0)
                {
                    limiteNatureza = ((Modelos.ModelosCambio.TBL_NATUREZA)arrNat[0]).portal_valor;
                }

                // Verifica parametro no cad. de cliente
                decimal valorCliente = LimiteOperacao(idCliente);

                if (valorCliente > 0)
                {
                    if (valorCliente < limiteNatureza)
                    {
                        return valorCliente;
                    }
                    else
                    {
                        return limiteNatureza;
                    }
                }
                else
                {
                    return limiteNatureza;
                }

            }
            catch (Exception ex)
            {
                Retorno.GravarErro(ex, "Retorno.cs", string.Format("LimiteOperacao(idCliente:{0} , natureza:{1})", idCliente, natureza));
            }

            return 0;
        }

        public static decimal CalculaTaxaOperacao(string moeda, string num_doc, string tipo_operacao, string tipo_entrega, string tipo_cliente_col, decimal valor, string tipoRetorno, decimal valorOverSpread)
        {
            //decimal fator = new System.Decimal(.98);
            decimal taxaOp = 0;

            if (tipoRetorno.ToLower().Trim() == "taxa")
                taxaOp = DAO.Funcoes.CalculaTaxaOperacao(moeda, num_doc, tipo_operacao, tipo_entrega, tipo_cliente_col, valor, valorOverSpread)[0]; // taxa
            else
                taxaOp = DAO.Funcoes.CalculaTaxaOperacao(moeda, num_doc, tipo_operacao, tipo_entrega, tipo_cliente_col, valor, valorOverSpread)[1]; // spread

            return taxaOp;
        }

        public static Tuple<string, decimal> SpreadGoogle()
        {
            return DAO.Funcoes.SpreadGoogle();
        }

        public static decimal TaxaGoogleAutomatico()
        {
            return DAO.Funcoes.TaxaGoogleAutomatico();
        }

        public static string[] Grava_LoginIntegradoUsuarios(string num_doc, string nome, string email, DateTime dtValidade, int idCliente, string tipo)
        {
            return DAO.Funcoes.Grava_LoginIntegradoUsuarios(num_doc, nome, email, dtValidade, idCliente, tipo);
        }

        public static DataSet ListarTarifasCliente(int id_cliente, string cl_tarifa)
        {
            return DAO.Funcoes.ListarTarifasCliente(id_cliente, cl_tarifa);
        }

        public static DataSet ListarOrdensPagamento(string acao, int id_cliente, string status, string data_inicial, string data_final)
        {
            return DAO.Funcoes.ListarOrdensPagamento(acao, id_cliente, status, data_inicial, data_final);
        }

        public static DataSet EmitirComprovanteSwift(string n_boleto, string acao, int empresa)
        {
            return DAO.Funcoes.EmitirComprovanteSwift(n_boleto, acao, empresa);
        }

        public static DataSet ListarAcompanhamento(int nr_boleto)
        {
            return DAO.Funcoes.ListarAcompanhamento(nr_boleto);
        }

        public static DataSet ListarAcompanhamento(int id_cliente, string status, string data_inicial, string data_final)
        {
            return DAO.Funcoes.ListarAcompanhamento(id_cliente, status, data_inicial, data_final);
        }

        public static DataSet ListarUsuarios(string strDocumento)
        {
            return DAO.Funcoes.ListarUsuarios(strDocumento);
        }

        public static DataSet ValidarSwift(string SwiftCode)
        {
            return DAO.Funcoes.ValidarSwift(SwiftCode);
        }

        public static DataSet ValidarSwiftIntermediario(string SwiftRecebedor, string SwiftIntermediario)
        {
            return DAO.Funcoes.ValidarSwiftIntermediario(SwiftRecebedor, SwiftIntermediario);
        }

        public static DataSet GetPaisMoedaOperacao(string simb_Moeda, string codPais)
        {
            return DAO.Funcoes.GetPaisMoedaOperacao(simb_Moeda, codPais);
        }

        public static SqlDataReader GetInfoPreBoleto(int op_n_boleto, int id_cliente)
        {
            return DAO.Funcoes.GetInfoPreBoleto(op_n_boleto, id_cliente);
        }

        /// <summary>
        /// Pega o próximo dia útil vigente 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="hora_corte"></param>
        /// <param name="minuto_corte"></param>
        /// <param name="praca"></param>
        /// <param name="moeda"></param>
        /// <param name="diasMN"></param>
        /// <param name="diasME"></param>
        /// <param name="IdOperacao"></param>
        /// <param name="DESPREZAHORARIOCORTE"></param>
        /// <returns></returns>
        public static string[] Get_Proximo_Dia_Util(DateTime data, int hora_corte, int minuto_corte, string praca, string moeda, int diasMN, int diasME, string IdOperacao, string DESPREZAHORARIOCORTE)
        {
            return DAO.Funcoes.Get_Proximo_Dia_Util(data, hora_corte, minuto_corte, praca, moeda, diasMN, diasME, IdOperacao, DESPREZAHORARIOCORTE);
        }

        public static DataSet VerificaDataFeriado(DateTime dataAtual)
        {
            return DAO.Funcoes.VerificaDataFeriado(dataAtual);
        }

        public static string GetConfigParamMensagens(int idMsg)
        {
            return DAO.Funcoes.GetConfigParamMensagens(idMsg);
        }

        public static string GetParamEmpresas(string Parametro, int id_empresa)
        {
            return DAO.Funcoes.GetParamEmpresas(Parametro, id_empresa);
        }

        public static string GetClienteOperaSomenteBanco(string LI_doc)
        {
            return DAO.Funcoes.GetClienteOperaSomenteBanco(LI_doc);
        }

        public static DataSet GetCliente(string LI_DOC)
        {
            return DAO.Funcoes.GetCliente(LI_DOC);
        }

        public static string GetFLAG_Habilita_Cambio_Cotacao(string LI_DOC)
        {

            return DAO.Funcoes.GetFLAG_Habilita_Cambio_Cotacao(LI_DOC);
        }

        /// <summary>
        /// Inserir CRM
        /// </summary>
        /// <param name="idUsuario"></param>
        /// <param name="docto"></param>
        /// <param name="preboleto"></param>
        /// <param name="msg"></param>
        public static void GravaCRM(int idUsuario, string docto, Modelos.ModelosCambio.TBL_PRE_BOLETO preboleto, string msg)
        {
            Modelos.ModelosCambio.TBL_CRM crm = new Modelos.ModelosCambio.TBL_CRM();
            crm.id_usuario = idUsuario;
            crm.id_corretora = Convert.ToInt32("0" + Negocios.Retorno.GetConfigParamProdutos("ID_CORRETORA"));
            crm.crm_cpf_cnpj = docto;
            crm.crm_ocorrencia = msg;
            crm.crm_nboleto = Convert.ToInt32("0" + preboleto.op_n_boleto);
            crm.crm_data = DateTime.Now;
            crm.ID_FILIAL = preboleto.id_filial;
            Negocios.Operacoes.Inserir(crm);
        }

        /// <summary>
        /// Inserir CRM
        /// </summary>
        /// <param name="idUsuario"></param>
        /// <param name="docto"></param>
        /// <param name="preboleto"></param>
        /// <param name="msg"></param>
        /// <param name="transacao"></param>
        public static void GravaCRM(int idUsuario, string docto, Modelos.ModelosCambio.TBL_PRE_BOLETO preboleto, string msg, Transacao transacao)
        {
            Modelos.ModelosCambio.TBL_CRM crm = new Modelos.ModelosCambio.TBL_CRM();
            crm.id_usuario = idUsuario;
            crm.id_corretora = Convert.ToInt32("0" + Negocios.Retorno.GetConfigParamProdutos("ID_CORRETORA"));
            crm.crm_cpf_cnpj = docto;
            crm.crm_ocorrencia = msg;
            crm.crm_nboleto = Convert.ToInt32("0" + preboleto.op_n_boleto);
            crm.crm_data = DateTime.Now;
            crm.ID_FILIAL = preboleto.id_filial;
            Negocios.Operacoes.Inserir(crm, transacao);
        }

        public static void GravaCRM(int idUsuario, string docto, string msg)
        {
            GravaCRM(idUsuario, docto, new Modelos.ModelosCambio.TBL_PRE_BOLETO(), msg);
        }

        public static DataTable GetDadosBancarios(int idCliente, string tipoCliente)
        {
            // Cria DataTable
            DataTable dtDadosBancarios = new DataTable();
            dtDadosBancarios.Columns.Add("codigo", typeof(string));
            dtDadosBancarios.Columns.Add("banco", typeof(string));
            dtDadosBancarios.Columns.Add("cod_banco", typeof(string));
            dtDadosBancarios.Columns.Add("nome_banco", typeof(string));
            dtDadosBancarios.Columns.Add("agencia", typeof(string));
            dtDadosBancarios.Columns.Add("conta", typeof(string));
            dtDadosBancarios.Columns.Add("data_abertura", typeof(string));

            if (tipoCliente == "F")
            {
                Modelos.ModelosCambio.TBL_CLI_BANCO_COMERCIO dados_banco = new Modelos.ModelosCambio.TBL_CLI_BANCO_COMERCIO();
                DataTable dt = ((DataTable)Negocios.Operacoes.ObterDataTable(dados_banco, "id_cliente = " + idCliente, "id_cliente", null));

                if (dt.Rows.Count > 0)
                {
                    string banco = string.Empty;
                    string nome_banco = string.Empty;

                    /*###########################################
                    Alterada regra para consulta de dados bancarios do usuário  
                    - Antes: Validação de código banco = 633 (só popular objeto de retorno com dados bancarios caso usuario tenha conta no Banco Rendimento)
                    - Atual: Consulta os dados da conta principal do usuário e popula o objeto de retorno com os dados bancarios.
                    ###########################################*/
                    if (dt.Rows[0]["bc_banco"].ToString() != string.Empty)
                        nome_banco = dt.Rows[0]["bc_banco"].ToString();
                    else
                    {
                        Modelos.ModelosCambio.TBL_COD_BANCOS cd_banco = new Modelos.ModelosCambio.TBL_COD_BANCOS();
                        ArrayList arrBanco = cd_banco.obter("cod_banco = '" + dt.Rows[0]["bc_cod_banco"].ToString().Trim() + "'");
                        if (arrBanco.Count > 0)
                            nome_banco = ((Modelos.ModelosCambio.TBL_COD_BANCOS)arrBanco[0]).abrev_banco.Trim();
                        else
                            nome_banco = string.Empty;
                    }

                    DataRow dr = dtDadosBancarios.NewRow();
                    dr["cod_banco"] = dt.Rows[0]["bc_cod_banco"].ToString();
                    dr["nome_banco"] = nome_banco;
                    dr["agencia"] = dt.Rows[0]["bc_agencia"].ToString();
                    dr["conta"] = dt.Rows[0]["bc_conta"].ToString();

                    dtDadosBancarios.Rows.Add(dr);
                }
            }
            else
            {
                Modelos.ModelosCambio.TBL_CLIENTES dados_banco = new Modelos.ModelosCambio.TBL_CLIENTES();
                DataTable dt = ((DataTable)Negocios.Operacoes.ObterDataTable(dados_banco, "id_cliente = " + idCliente, "id_cliente", null));

                if (dt.Rows.Count > 0)
                {
                    string banco = string.Empty;
                    string nome_banco = string.Empty;

                    /*###########################################
                    Alterada regra para consulta de dados bancarios do usuário  
                    - Antes: Validação de código banco = 633 (só popular objeto de retorno com dados bancarios caso usuario tenha conta no Banco Rendimento)
                    - Atual: Consulta os dados da conta principal do usuário e popula o objeto de retorno com os dados bancarios.
                    ###########################################*/
                    if (dt.Rows[0]["cl_banco"].ToString() != string.Empty)
                        nome_banco = dt.Rows[0]["cl_banco"].ToString();
                    else
                    {
                        Modelos.ModelosCambio.TBL_COD_BANCOS cd_banco = new Modelos.ModelosCambio.TBL_COD_BANCOS();
                        ArrayList arrBanco = cd_banco.obter("cod_banco = '" + dt.Rows[0]["cl_cod_banco"].ToString().Trim() + "'");
                        if (arrBanco.Count > 0)
                            nome_banco = ((Modelos.ModelosCambio.TBL_COD_BANCOS)arrBanco[0]).abrev_banco.Trim();
                        else
                            nome_banco = string.Empty;
                    }

                    DataRow dr = dtDadosBancarios.NewRow();
                    dr["cod_banco"] = dt.Rows[0]["cl_cod_banco"].ToString();
                    dr["nome_banco"] = nome_banco;
                    dr["agencia"] = dt.Rows[0]["cl_agencia"].ToString();
                    dr["conta"] = dt.Rows[0]["cl_conta"].ToString();

                    dtDadosBancarios.Rows.Add(dr);
                }
            }
            return dtDadosBancarios;
        }

        public static DataTable GetContasCliente(int idCliente, string tipoCliente)
        {
            DataTable dt;

            if (tipoCliente == "F")
            {
                Modelos.ModelosCambio.TBL_CLI_BANCO_COMERCIO dados_banco = new Modelos.ModelosCambio.TBL_CLI_BANCO_COMERCIO();
                dt = ((DataTable)Negocios.Operacoes.ObterDataTable(dados_banco, "id_cliente = " + idCliente, "id_cliente", null));
            }
            else
            {
                Modelos.ModelosCambio.TBL_CLIENTES dados_banco = new Modelos.ModelosCambio.TBL_CLIENTES();
                dt = ((DataTable)Negocios.Operacoes.ObterDataTable(dados_banco, "id_cliente = " + idCliente, "id_cliente", null));
            }

            return dt;
        }

        public static DataTable GetContaPagto(DataTable dtContasCliente, string tipoCliente)
        {
            DataTable dtContaPagto = new DataTable();
            string seq;
            string banco = string.Empty;
            string nome_banco = string.Empty;

            //cria as colunas do datatable
            dtContaPagto.Columns.Add("codigo", typeof(string));
            dtContaPagto.Columns.Add("banco", typeof(string));



            if (tipoCliente == "F")
            {
                for (int i = 1; i < 4; i++)
                {
                    seq = (i > 1) ? i.ToString() : "";
                    if (dtContasCliente.Rows[0]["bc_banco" + seq].ToString() != string.Empty)
                        nome_banco = dtContasCliente.Rows[0]["bc_banco" + seq].ToString();
                    else
                    {
                        Modelos.ModelosCambio.TBL_COD_BANCOS cd_banco = new Modelos.ModelosCambio.TBL_COD_BANCOS();
                        ArrayList arrBanco = cd_banco.obter("cod_banco = '" + dtContasCliente.Rows[0]["bc_cod_banco" + seq].ToString().Trim() + "'");
                        if (arrBanco.Count > 0)
                            nome_banco = ((Modelos.ModelosCambio.TBL_COD_BANCOS)arrBanco[0]).abrev_banco.Trim();
                        else
                            nome_banco = string.Empty;
                    }

                    if (dtContasCliente.Rows[0]["bc_cod_banco" + seq].ToString().Trim() == "633")
                    {
                        banco = nome_banco + " - " + dtContasCliente.Rows[0]["bc_agencia" + seq].ToString() + " - " +
                                 dtContasCliente.Rows[0]["bc_conta" + seq].ToString();

                        DataRow dr = dtContaPagto.NewRow();
                        dr["codigo"] = i.ToString();
                        dr["banco"] = banco;

                        dtContaPagto.Rows.Add(dr);
                    }
                }
            }
            else
            {
                for (int i = 1; i < 4; i++)
                {
                    seq = (i > 1) ? i.ToString() : "";
                    if (dtContasCliente.Rows[0]["cl_banco" + seq].ToString() != string.Empty)
                        nome_banco = dtContasCliente.Rows[0]["cl_banco" + seq].ToString();
                    else
                    {
                        Modelos.ModelosCambio.TBL_COD_BANCOS cd_banco = new Modelos.ModelosCambio.TBL_COD_BANCOS();
                        ArrayList arrBanco = cd_banco.obter("cod_banco = '" + dtContasCliente.Rows[0]["cl_cod_banco" + seq].ToString().Trim() + "'");
                        if (arrBanco.Count > 0)
                            nome_banco = ((Modelos.ModelosCambio.TBL_COD_BANCOS)arrBanco[0]).abrev_banco.Trim();
                        else
                            nome_banco = string.Empty;
                    }

                    if (dtContasCliente.Rows[0]["cl_cod_banco" + seq].ToString().Trim() == "633")
                    {
                        banco = nome_banco + " - " + dtContasCliente.Rows[0]["cl_agencia" + seq].ToString() + " - " +
                                dtContasCliente.Rows[0]["cl_conta" + seq].ToString();

                        DataRow dr = dtContaPagto.NewRow();
                        dr["codigo"] = i.ToString();
                        dr["banco"] = banco;

                        dtContaPagto.Rows.Add(dr);
                    }
                }
            }

            return dtContaPagto;
        }

        public static bool ValidaFormaPagto(DataTable DtDadosBancarios, string tipoCliente)
        {
            bool retorno = false;

            if (DtDadosBancarios.Rows.Count > 0)
            {
                if (tipoCliente == "F")
                {
                    string seq;
                    for (int i = 1; i < 4; i++)
                    {
                        seq = (i > 1) ? i.ToString() : "";
                        if (DtDadosBancarios.Rows[0]["bc_cod_banco" + seq].ToString().Trim() == "633")
                            retorno = true;
                    }
                }
                else
                {
                    string seq;
                    for (int i = 1; i < 4; i++)
                    {
                        seq = (i > 1) ? i.ToString() : "";
                        if (DtDadosBancarios.Rows[0]["cl_cod_banco" + seq].ToString().Trim() == "633")
                            retorno = true;
                    }
                }

            }
            return retorno;
        }

        public static SqlDataReader GetLimites(string acao, int id_cliente, string tipo, string comp_nivel, string cr_nivel)
        {
            return DAO.Funcoes.GetLimites(acao, id_cliente, tipo, comp_nivel, cr_nivel);
        }

        public static DataSet GetLimitesNatureza(string acao)
        {
            return DAO.Funcoes.GetLimitesNatureza(acao);
        }

        public static void IntegracaoSwift()
        {
            DAO.Funcoes.IntegracaoSwift();
        }

        public static SqlDataReader GetAjuda(int? id_ajuda)
        {
            return DAO.Funcoes.GetAjuda(id_ajuda);
        }

        public static string GravarErro(Exception ex, string referencia, string info_adicional)
        {
            return DAO.Funcoes.GravarErro(ex, referencia, info_adicional);
        }

        public static decimal[] CalculaTaxaPronto(string moeda, string tipoOp)
        {
            return DAO.Funcoes.CalculaTaxaPronto(moeda, tipoOp);
        }

        public static decimal CalculaTarifaOperacao(string id_cliente, string moeda, string tipoOp, string tipoEntrega, decimal valor)
        {
            return DAO.Funcoes.CalculaTarifaOperacao(id_cliente, moeda, tipoOp, tipoEntrega, valor);
        }

        public static decimal CalculaTarifaBanco(string moeda, string tipoOp, string tipoEntrega, decimal valor)
        {
            return DAO.Funcoes.CalculaTarifaBanco(moeda, tipoOp, tipoEntrega, valor);
        }

        public static string GetAprovAuto(string Tipo, decimal ValorEmDolar)
        {
            return DAO.Funcoes.GetAprovAuto(Tipo, ValorEmDolar);
        }

        /// <summary>
        /// Retorna o parâmetro 
        /// </summary>
        /// <param name="NM_CAMPO"></param>
        /// <returns></returns>
        public static string Retorna_Varejo_Parametros(string NM_CAMPO)
        {
            return DAO.Funcoes.Retorna_Varejo_Parametros(NM_CAMPO);
        }

        public static string ConsultaDOC(string idCliente)
        {
            return DAO.Funcoes.ConsultaDOC(idCliente);
        }

        public static string EnviarEmail(string assunto, string corpo, string email_destino)
        {
            return DAO.Funcoes.EnviarEmail(assunto, corpo, email_destino);
        }

        public static void FaleConosco(string assunto, string num_doc, string nome, string telefone, string email, string comentario)
        {
            DAO.Funcoes.FaleConosco(assunto, num_doc, nome, telefone, email, comentario);
        }

        public static int[] IncluirPreBoleto(Modelos.ModelosCambio.TBL_PRE_BOLETO preboleto)
        {
            return DAO.Funcoes.IncluirPreBoleto(preboleto);
        }

        public static int[] IncluirPreBoleto(Modelos.ModelosCambio.TBL_PRE_BOLETO preboleto, SqlTransaction transaction)
        {
            return DAO.Funcoes.IncluirPreBoleto(preboleto, transaction);
        }

        public static decimal RetornaValorMoeda(decimal valor, string moeda)
        {
            return DAO.Funcoes.RetornaValorMoeda(valor, moeda);
        }

        public static decimal RetornaValorMoeda(decimal valor, string moeda, SqlTransaction transacao)
        {
            return DAO.Funcoes.RetornaValorMoeda(valor, moeda, transacao);
        }

        public static decimal RetornaLimiteDispensaDadosBancarios()
        {
            return DAO.Funcoes.RetornaLimiteDispensaDadosBancarios();
        }

        public static decimal RetornaLimiteDispensaDadosBancarios(SqlTransaction transacao)
        {

            return DAO.Funcoes.RetornaLimiteDispensaDadosBancarios(transacao);
        }

        public static void Envia_Email_Automatico(string li_doc, int idSistema, int nrBoleto, string acaoBackOffice, string acaoEMail)
        {
            if (GetConfigParamCli(li_doc, "PARAM_EMAIL_AUTOMATICO") == "S")
                DAO.Funcoes.Envia_Email_Automatico(idSistema, nrBoleto, acaoBackOffice, acaoEMail);
        }

        /// <summary>
        /// Pega a quantidade de dias para Moeda Extrangeira de acordo com o tipo de moeda 
        /// </summary>
        /// <param name="Cod_moeda"></param>
        /// <returns></returns>
        public static int GetDias_ME_Moeda(string Cod_moeda)
        {
            return DAO.Funcoes.GetDIAS_ME_PADRAO(Cod_moeda);
        }

        public static Decimal Nivel_Compliance(string tipo, string nivel)
        {
            return DAO.Funcoes.Nivel_Compliance(tipo, nivel);
        }

        public static Decimal Valor_Operado_Compliance(string tipo, int idCliente, int idOperacao)
        {
            return DAO.Funcoes.Valor_Operado_Compliance(tipo, idCliente, idOperacao);
        }

        public static DataTable GetPermissaoImportacao(int CodModalidade, string li_doc)
        {
            //95269 - Adequação COL operar qualquer Natureza
            return DAO.Funcoes.GetPermissaoImportacao(CodModalidade, li_doc);
        }

        public static DataTable GetPermissaoImportacao(string li_doc)
        {
            //95269 - Adequação COL operar qualquer Natureza
            return DAO.Funcoes.GetPermissaoImportacao(li_doc);
        }

        /// <summary>
        /// chamado 94422 - Incorporar rotina DARF - 29/06/2012 - Sequenza: Steeves
        /// </summary>
        /// <param name="id_Cliente"></param>
        /// <returns></returns>
        public static DataTable ValidarIsencaoIR(int id_Cliente)
        {
            return DAO.Funcoes.ValidarIsencaoIR(id_Cliente);
        }

        public static DataTable ValidarOperacao(string Moeda, decimal ValMoeda, DateTime op_data_boleto, string usuario, string Natureza, string TipoEntrega, string op_n_boleto, int id_cliente)
        {
            return DAO.Funcoes.validarOperacao(Moeda, ValMoeda, op_data_boleto, usuario, Natureza, TipoEntrega, op_n_boleto, id_cliente);
        }

        public static bool PossuiListaFavorecido(int id_cliente)
        {
            return DAO.Funcoes.PossuiListaFavorecido(id_cliente);
        }

        public static DataTable CarregarListaFavorecido(int id_cliente)
        {
            return DAO.Funcoes.CarregarListaFavorecido(id_cliente);
        }

        /// <summary>
        /// Filtra por cliente e nome do favorecido
        /// </summary>
        /// <param name="id_cliente"></param>
        /// <param name="nomeFavorecido"></param>
        /// <param name="iban"></param>
        /// <returns></returns>
        public static DataTable CarregarListaFavorecido(int id_cliente, string nomeFavorecido, string iban)
        {
            return DAO.Funcoes.CarregarListaFavorecido(id_cliente, nomeFavorecido, iban);
        }

        public static DataTable SelecionarFavorecido(int id_conta, int id_cliente)
        {
            return DAO.Funcoes.SelecionarFavorecido(id_conta, id_cliente);
        }

        public static DataTable GetAliquotaIR(int id_natureza)
        {
            return DAO.Funcoes.GetAliquotaIR(id_natureza);
        }

        public static DataTable GetAliquotaIR(int id_natureza, int codigo_pais)
        {
            return DAO.Funcoes.GetAliquotaIR(id_natureza, codigo_pais);
        }

        public static DataTable GetBancoComplete(string name)
        {
            return DAO.Funcoes.GetBancoComplete(name);
        }

        public static DataTable GetAllBancoComplete(string name)
        {
            return DAO.Funcoes.GetAllBancoComplete(name);
        }

        public static DataTable GetCalculoIR(string UtilizaAliquota, decimal ValMoeda, decimal ValReais, decimal TaxaOperacao, string Moeda, decimal TaxaIR)
        {
            return DAO.Funcoes.GetCalculoIR(UtilizaAliquota, ValMoeda, ValReais, TaxaOperacao, Moeda, TaxaIR);

        }

        public static DataTable GetDadosClienteDARF(int id_Cliente)
        {
            return DAO.Funcoes.GetDadosClienteDARF(id_Cliente);
        }

        public static int VarejoGerarDARF(string Nome_DARF, string Telefone_DARF, string CPF_CNPJ_DARF, int Cod_Receita_DARF, int Cod_Unidade_DARF, decimal Valor_Principal_DARF, decimal Vlr_Multa_DARF, decimal Vlr_Juros_DARF, string Observacoes_DARF)
        {
            return DAO.Funcoes.VarejoGerarDARF(Nome_DARF, Telefone_DARF, CPF_CNPJ_DARF, Cod_Receita_DARF, Cod_Unidade_DARF, Valor_Principal_DARF, Vlr_Multa_DARF, Vlr_Juros_DARF, Observacoes_DARF);
        }

        public static int VarejoGerarDARF(string Nome_DARF, string Telefone_DARF, string CPF_CNPJ_DARF, int Cod_Receita_DARF, int Cod_Unidade_DARF, decimal Valor_Principal_DARF, decimal Vlr_Multa_DARF, decimal Vlr_Juros_DARF, string Observacoes_DARF, SqlTransaction transacao)
        {
            return DAO.Funcoes.VarejoGerarDARF(Nome_DARF, Telefone_DARF, CPF_CNPJ_DARF, Cod_Receita_DARF, Cod_Unidade_DARF, Valor_Principal_DARF, Vlr_Multa_DARF, Vlr_Juros_DARF, Observacoes_DARF, transacao);
        }

        public static bool ExcluirDarf(int ID_Darf)
        {
            return DAO.Funcoes.ExcluirDarf(ID_Darf);
        }

        public static DataTable GetListaPaises()
        {
            return DAO.Funcoes.GetListaPaises();
        }

        public static DataTable GetListaPaises(string codigo_iso)
        {
            return DAO.Funcoes.GetListaPaises(codigo_iso);
        }
        /* Fim chamado 94422 - Incorporar rotina DARF*/

        // Inicio - chamado 95269 - Adequação COL para operar com qualquer Natureza de operação
        //Sequenza - 31-07-2012
        public static DataTable getListaModalidadeImportacao()
        {
            return DAO.Funcoes.getListaModalidadeImportacao();
        }

        public static DataTable getListaBeneficiarios(string cl_tipo, int id_natureza)
        {
            return DAO.Funcoes.getListaBeneficiarios(cl_tipo, id_natureza);
        }

        public static DataTable getVinculoBeneficiarios(string cl_tipo, int id_motivo_envio)
        {
            return DAO.Funcoes.getVinculoBeneficiarios(cl_tipo, id_motivo_envio);
        }

        public static DataTable getLI_DI_COEMB(string Item, string op_n_boleto)
        {
            return DAO.Funcoes.getLI_DI_COEMB(Item, op_n_boleto);

        }

        public static DataTable getLI_DI_COEMB(string Item, string op_n_boleto, SqlTransaction transacao)
        {
            return DAO.Funcoes.getLI_DI_COEMB(Item, op_n_boleto, transacao);

        }

        /// <summary>
        /// método para cadastrar usuario na TBL_LOGIN_INTEGRADO
        /// Chamado 124128 - Rotina de pré-cadastro
        /// </summary>
        /// <param name="num_doc">Numero do documento</param>
        /// <param name="nome">Nome completo</param>
        /// <param name="email">Email</param>
        /// <param name="tipoCliente">Tipo de Cliente (PF ou PJ)</param>
        /// <param name="dtValidade">Data de Validade</param>
        /// <returns>Array contendo ID e Senha criados para o usuário</returns>
        public static string[] MigrarCliente(string num_doc, string nome, string email, string tipoCliente, DateTime dtValidade)
        {
            return DAO.Funcoes.MigrarCliente(num_doc, nome, email, tipoCliente, dtValidade);
        }

        /// <summary>
        /// Consulta Lista de Parametros para cadastro na tabela TBL_COL_PARAM_CLI
        /// </summary>
        /// <returns>DataTable com o resultado da pesquisa</returns>
        public static DataTable GetListaParametrosCOLPF()
        {
            return DAO.Funcoes.GetListaParametrosCOLPF();
        }

        /// <summary>
        /// Retorna lista de parametros para cadastro de clientes na TBL_CLIENTES
        /// </summary>
        /// <returns>DataTable com o resultado da pesquisa</returns>
        public static DataTable GetListaParametrosTBLCLIENTES(int Ativo)
        {
            return DAO.Funcoes.GetListaParametrosTBLCLIENTES(Ativo);
        }

        public static DataTable GetTarifaGoogle()
        {
            return DAO.Funcoes.GetTarifaGoogle();
        }

        public static DataTable GetTarifa()
        {
            return DAO.Funcoes.GetTarifa();
        }

        /// <summary>
        /// Grava parametros na TBL_CLIENTES
        /// </summary>
        /// <param name="strParametros">Array contendo os parametros e valores dos mesmos.</param>
        public static void GravaParametrosTBLClientes(SqlParameter[] strParametros)
        {
            DAO.Funcoes.GravaParametrosTBLClientes(strParametros);
        }

        /// <summary>
        /// Grava parametros na TBL_COL_PARAM_CLI
        /// </summary>
        /// <param name="strParametros">Array contendo os parametros e valores dos mesmos.</param>
        public static void GravaParametrosCliente(SqlParameter[] strParametros)
        {
            DAO.Funcoes.GravaParametrosCliente(strParametros);
        }

        /// <summary>
        /// Insere na tabela TBL_CPFS
        /// </summary>
        /// <param name="cl_num_doc">Número do documento (CPF/CNPJ)</param>
        /// <param name="cl_passaporte">Número do passaporte</param>
        public static void GravaParametrosTBLCPFS(string cl_num_doc, string cl_passaporte)
        {
            DAO.Funcoes.GravaParametrosTBLCPFS(cl_num_doc, cl_passaporte);
        }

        /// <summary>
        /// método para cadastrar usuario na TBL_PRE_CADASTRO
        /// Chamado 124128 - Rotina de pré-cadastro
        /// </summary>
        /// <param name="tipoDoc">Tipo de documento (CPF ou CNPJ)</param>
        /// <param name="numDoc">Numero do Documento</param>
        /// <param name="nome">Nome completo</param>
        /// <param name="sobrenome">Nome fantasia quando tipoDoc = CNPJ</param>
        /// <param name="email">Email</param>
        /// <param name="contato">Contato (tipoDoc = CNPJ)</param>
        /// <param name="telefone">Telefone</param>
        /// <param name="faseAtual">Indica em qual passo do pré-cadastro o cadasro está</param>
        /// <param name="status">Status</param>
        /// <returns>Id do pré-cadastro</returns>
        public static int GravaPreCadastro(string tipoDoc, string numDoc, string nome, string sobrenome, string email, string contato, string telefone, string faseAtual, bool status, string flg_google)
        {
            return DAO.Funcoes.GravaPreCadastro(tipoDoc, numDoc, nome, sobrenome, email, contato, telefone, faseAtual, status, flg_google);
        }

        /// <summary>
        /// Consulta e-mails para envio
        /// </summary>
        /// <param name="strParametros">Parametros da pesquisa</param>
        public static DataTable ConsultaEmailAcessoSenha(SqlParameter[] strParametros)
        {
            return DAO.Funcoes.ConsultaEmailAcessoSenha(strParametros);
        }

        public static DataTable PesquisarPreCadastro(string numDoc)
        {
            return DAO.Funcoes.PesquisarPreCadastro(numDoc);
        }

        public static void AtualizaPreCadastro(SqlParameter[] parametros)
        {
            DAO.Funcoes.AtualizaPreCadastro(parametros);
        }

        public static int MigrarPreCadastroCompAcionario(int id_pre_cadstro, int id_cliente)
        {
            return DAO.Funcoes.MigrarPreCadastroCompAcionario(id_pre_cadstro, id_cliente);
        }

        public static DataTable PesquisarPreCadastroCompAcionario(int id_pre_cadstro)
        {
            return DAO.Funcoes.PesquisarPreCadastroComposicaoAcionaria(id_pre_cadstro);
        }

        public static void AtualizaPreCadastroCompAcionario(SqlParameter[] parametros)
        {
            DAO.Funcoes.AtualizaPreCadastroComposicaoAcionaria(parametros);
        }

        public static void ExcluirPreCadastroCompAcionario(int id_ca, int id_precadastro)
        {

            DAO.Funcoes.ExcluirPreCadastroCompAcionario(id_ca, id_precadastro);
        }

        public static void GravaCRMPreCadastro(int idUsuario, string docto, string msg)
        {
            Modelos.ModelosCambio.TBL_CRM crm = new Modelos.ModelosCambio.TBL_CRM();
            crm.id_usuario = idUsuario;
            crm.id_corretora = Convert.ToInt32("0" + Negocios.Retorno.GetConfigParamProdutos("ID_CORRETORA"));
            crm.crm_cpf_cnpj = docto;
            crm.crm_ocorrencia = msg;
            crm.crm_data = DateTime.Now;
            Negocios.Operacoes.Inserir(crm);
        }

        public static DataTable ListarContasCliente(int id_cliente, string tipo)
        {
            return DAO.Funcoes.ListarContasCliente(id_cliente, tipo);
        }

        public static DataTable SelecionarContaCliente(int id_cliente, int id_banco, string tipo)
        {
            return DAO.Funcoes.SelecionarContaCliente(id_cliente, id_banco, tipo);
        }

        /// <summary>
        /// Seleciona os dados da conta bancária do cliente
        /// </summary>
        /// <param name="id_cliente"></param>
        /// <param name="id_banco"></param>
        /// <param name="tipo"></param>
        /// <param name="nome_banco"></param>
        /// <returns></returns>
        public static DataTable SelecionarContaCliente(int id_cliente, int id_banco, string tipo, string nome_banco)
        {
            return DAO.Funcoes.SelecionarContaCliente(id_cliente, id_banco, tipo, nome_banco);
        }

        public static decimal ObterLimiteBoleto(string operacao)
        {
            return DAO.Funcoes.ObterValorParametrosConfiguracoes("BOLETO", operacao);
        }

        public static decimal ObterLimiteAssinatura()
        {
            return DAO.Funcoes.ObterValorParametrosConfiguracoes("ASSINATURA", null);
        }

        public static bool ExisteContaDoClienteNoBancoRendimento(int idCliente)
        {
            return DAO.Funcoes.ObterValorParametrosConfiguracoes(idCliente);
        }

        public static bool BoletoTipoGoogle(int numBoleto)
        {
            return DAO.Funcoes.BoletoTipoGoogle(numBoleto);
        }

        public static bool NotificaProcuracaoPendente(int idCliente, int quantidadeOperacoes, int quantidadeDias, decimal limiteAssinatura)
        {
            return DAO.Funcoes.NotificaProcuracaoPendente(idCliente, quantidadeOperacoes, quantidadeDias, limiteAssinatura);
        }

        public static string TratarAcentos(string texto)
        {
            return DAO.Funcoes.TratarAcentos(texto);
        }

        public static void AtualizaStatusBoleto(int pre_n_boleto, int status)
        {
            DAO.Funcoes.AtualizaStatusBoleto(pre_n_boleto, status);
        }

        public static bool StatusBoletoZero(int pre_n_boleto)
        {
            return DAO.Funcoes.StatusBoletoZero(pre_n_boleto);
        }

        public static int GetUserPortalCrm(string user_crm, SqlTransaction transacao)
        {
            return DAO.Funcoes.GetUserPortalCrm(user_crm, transacao);
        }

        /// <summary>
        /// Retornar o tempo de expiração da taxa para o tipo de cliente específico
        /// </summary>
        /// <remarks>
        /// 0 - Corretora/Distribuidora
        /// 1 - Agência de Turismo
        /// 2 - Intercâmbio
        /// 3 - PJ/Outros
        /// 4 - PF
        /// 5 - Embaixada/Consulado
        /// 6 - Diplomatas
        /// 7 - Organismos
        /// </remarks>
        public static string ObterTempoExpirarTaxa(string tipoCliente)
        {
            switch (tipoCliente)
            {
                case "0":
                    return GetConfigParamProdutos("TEMPO_EXPIRACAO_TAXA_CORRETORA");
                case "1":
                    return GetConfigParamProdutos("TEMPO_EXPIRACAO_TAXA_AGENCIA");
                case "2":
                    return GetConfigParamProdutos("TEMPO_EXPIRACAO_TAXA_INTERCAMBIO");
                case "3":
                    return GetConfigParamProdutos("TEMPO_EXPIRACAO_TAXA_PJ");
                case "4":
                    return GetConfigParamProdutos("TEMPO_EXPIRACAO_TAXA_PF");
                case "5":
                    return GetConfigParamProdutos("TEMPO_EXPIRACAO_TAXA_EMBAIXADA");
                case "6":
                    return GetConfigParamProdutos("TEMPO_EXPIRACAO_TAXA_DIPLOMATA");
                case "7":
                    return GetConfigParamProdutos("TEMPO_EXPIRACAO_TAXA_ORGANISMOS");
                default:
                    return string.Empty;
            }

        }

        /// <summary>
        /// Verifica se está ativo o Cliente e a moeda na TBL_ME_SUBCONTA
        /// </summary>
        /// <param name="moeda"></param>
        /// <param name="idCliente"></param>
        /// <returns></returns>
        public static bool ExisteContaCCMEAtiva(string moeda, int idCliente)
        {
            Modelos.ModelosCambio.TBL_ME_SUBCONTA subconta = new Modelos.ModelosCambio.TBL_ME_SUBCONTA();
            ArrayList arrSub = Negocios.Operacoes.Obter(subconta, "id_cliente = '" + Convert.ToString(idCliente) + "' and cod_moeda = '" + moeda + "' and sub_status = 'A'");
            return (arrSub.Count > 0);
        }

        /// <summary>
        /// Formata o documento
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="tipoCliente"></param>
        /// <returns></returns>
        public static string FormatarCPFCNPJ(string doc, string tipoCliente)
        {
            if (tipoCliente.Equals("F") && doc.Length.Equals(11))
                doc = string.Format("{0}.{1}.{2}-{3}", doc.Substring(0, 3), doc.Substring(3, 3), doc.Substring(6, 3), doc.Substring(9, 2));
            else if (tipoCliente.Equals("J") && doc.Length.Equals(14))
                doc = string.Format("{0}.{1}.{2}/{3}-{4}", doc.Substring(0, 2), doc.Substring(2, 3), doc.Substring(5, 3), doc.Substring(8, 4), doc.Substring(12, 2));

            return doc;
        }

        /// <summary>
        /// Inclusão ou atualização de registros das contas, proceudre SPBCCME_Contas_Cadastradas
        /// </summary>
        /// <param name="parametros"></param>
        public static void SalvarConta(SqlParameter[] parametros)
        {
            DAO.Funcoes.SalvarConta(parametros);
        }

        /// <summary>
        /// Inclusão ou atualização de registros das contas, proceudre SPBCCME_Contas_Cadastradas
        /// </summary>
        /// <param name="parametros"></param>
        public static void SalvarConta(int idCliente, string c50kNome, string c50kNumDoc, string c50kEndereco, string c50kCidade, string c50kEstado,
                                        string c50kCep, string c50kCodBanco, string c50kAgencia, string c50kContaCorrente, string c59NumConta,
                                        string c59Nome, string c59Endereco, string c59Pais, string tipoIdentificacao, string c57SwiftCode,
                                        string c57Conta, string c57Nome, string c57Endereco, string tipoIdentCorresp, string c56SwiftCode,
                                        string c56Aba, string c56Conta, string c56Nome, string c56Endereco, string c56ContaRecebedor, string c50kBairro)
        {
            SqlParameter[] strParametros = new SqlParameter[30];
            strParametros[0] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
            strParametros[0].Value = idCliente;

            strParametros[1] = new SqlParameter("@ACTION", SqlDbType.VarChar, 25);
            strParametros[1].Value = "Atualizar";

            strParametros[2] = new SqlParameter("@FMT_SWIFT", SqlDbType.Char, 5);
            strParametros[2].Value = "103";

            strParametros[3] = new SqlParameter("@C50K_NOME", SqlDbType.VarChar, 200);
            strParametros[3].Value = c50kNome;

            strParametros[4] = new SqlParameter("@C50K_NUM_DOC", SqlDbType.VarChar, 50);
            strParametros[4].Value = c50kNumDoc;

            strParametros[5] = new SqlParameter("@C50K_ENDERECO", SqlDbType.VarChar, 500);
            strParametros[5].Value = c50kEndereco;

            strParametros[6] = new SqlParameter("@C50K_CIDADE", SqlDbType.VarChar, 34);
            strParametros[6].Value = c50kCidade;

            strParametros[7] = new SqlParameter("@C50K_ESTADO", SqlDbType.VarChar, 2);
            strParametros[7].Value = c50kEstado;

            strParametros[8] = new SqlParameter("@C50K_CEP", SqlDbType.VarChar, 8);
            strParametros[8].Value = c50kCep;

            strParametros[9] = new SqlParameter("@C50K_COD_BANCO", SqlDbType.VarChar, 25);
            strParametros[9].Value = c50kCodBanco;

            strParametros[10] = new SqlParameter("@C50K_AGENCIA", SqlDbType.VarChar, 4);
            strParametros[10].Value = c50kAgencia;

            strParametros[11] = new SqlParameter("@C50K_CONTA_CORRENTE", SqlDbType.VarChar, 15);
            strParametros[11].Value = c50kContaCorrente;

            strParametros[12] = new SqlParameter("@C59_NUM_CONTA", SqlDbType.NVarChar, 34);
            strParametros[12].Value = c59NumConta;

            strParametros[13] = new SqlParameter("@C59_NOME", SqlDbType.VarChar, 50);
            strParametros[13].Value = c59Nome;

            strParametros[14] = new SqlParameter("@C59_ENDERECO", SqlDbType.VarChar, 68);
            strParametros[14].Value = c59Endereco;

            strParametros[15] = new SqlParameter("@C59_PAIS", SqlDbType.VarChar, 10);
            strParametros[15].Value = c59Pais;

            string tipoId = tipoIdentificacao.Trim().ToUpper();
            string tipoIdAux = string.Empty;

            strParametros[16] = new SqlParameter("@TIPO_IDENTIFICACAO", SqlDbType.VarChar, 10);
            strParametros[16].Value = tipoId;

            switch (tipoId)
            {
                case "SWIFT":
                case "MANUAL":
                    tipoIdAux = tipoId;
                    break;
                default:
                    tipoIdAux = null;
                    break;
            }

            strParametros[17] = new SqlParameter("@C57_SWIFT_CODE", SqlDbType.VarChar, 25);
            strParametros[17].Value = tipoIdAux;


            switch (tipoId)
            {
                case "ABA":
                case "SORTCODE":
                case "BLZ":
                    tipoIdAux = c57SwiftCode.Trim().ToUpper();
                    break;
                default:
                    tipoIdAux = null;
                    break;
            }

            strParametros[18] = new SqlParameter("@C57_ABA", SqlDbType.VarChar, 25);
            strParametros[18].Value = tipoIdAux;

            strParametros[19] = new SqlParameter("@C57_CONTA", SqlDbType.VarChar, 25);
            strParametros[19].Value = null;

            strParametros[20] = new SqlParameter("@C57_NOME", SqlDbType.VarChar, 200);
            strParametros[20].Value = c57Nome.Trim().ToUpper();

            strParametros[21] = new SqlParameter("@C57_ENDERECO", SqlDbType.VarChar, 500);
            strParametros[21].Value = c57Endereco.Trim().ToUpper();

            string tipoIdCorresp = tipoIdentCorresp.Trim().ToString().ToUpper();

            strParametros[22] = new SqlParameter("@TIPO_IDENT_CORRESP", SqlDbType.VarChar, 10);
            strParametros[22].Value = tipoIdCorresp;

            string tipoIdentCorrespAux = string.Empty;

            switch (tipoIdCorresp)
            {
                case "SWIFT":
                case "MANUAL":
                    tipoIdentCorrespAux = tipoIdCorresp;
                    break;
                default:
                    tipoIdentCorrespAux = null;
                    break;
            }

            strParametros[23] = new SqlParameter("@C56_SWIFT_CODE", SqlDbType.VarChar, 25);
            strParametros[23].Value = tipoIdentCorrespAux;

            switch (tipoId)
            {
                case "ABA":
                case "SORTCODE":
                case "BLZ":
                    tipoIdAux = c56SwiftCode.Trim().ToUpper();
                    break;
                default:
                    tipoIdAux = null;
                    break;
            }

            strParametros[24] = new SqlParameter("@C56_ABA", SqlDbType.VarChar, 25);
            strParametros[24].Value = tipoIdAux;

            strParametros[25] = new SqlParameter("@C56_CONTA", SqlDbType.VarChar, 25);
            strParametros[25].Value = null;

            strParametros[26] = new SqlParameter("@C56_NOME", SqlDbType.VarChar, 200);
            strParametros[26].Value = c56Nome.Trim().ToUpper();

            strParametros[27] = new SqlParameter("@C56_ENDERECO", SqlDbType.VarChar, 500);
            strParametros[27].Value = c56Endereco.Trim().ToUpper();

            strParametros[28] = new SqlParameter("@C56_CONTA_RECEBEDOR", SqlDbType.VarChar, 25);
            strParametros[28].Value = c56ContaRecebedor.Trim().ToUpper();

            strParametros[29] = new SqlParameter("@C50K_BAIRRO", SqlDbType.VarChar, 34);
            strParametros[29].Value = c50kBairro;

            DAO.Funcoes.SalvarConta(strParametros);
        }

        /// <summary>
        /// Retorna a data de corte
        /// </summary>
        /// <returns></returns>
        public static DateTime dataDeCorte()
        {
            // Horario de corte
            return Convert.ToDateTime(DateTime.Today.ToString("dd/MM/yyyy ") + GetConfigParamProdutos("HORARIO_CORTE"));
        }

        /// <summary>
        /// Seta parametros para dias de liquidação Moeda Nacional
        /// </summary>
        /// <param name="documento"></param>
        /// <param name="tipoMoeda"></param>
        /// <returns></returns>
        public static string ParametrosDiasLiqCompraMN(string documento, string tipoMoeda)
        {
            string diasLiqCompraMN = "";

            try
            {
                diasLiqCompraMN = GetConfigParamCli(documento, "PARAM_DIASLIQ_VENDAS");

                if (string.IsNullOrEmpty(diasLiqCompraMN.Trim()))
                    diasLiqCompraMN = GetConfigParamProdutos("DIASLIQ_VENDAS");

            }
            catch (Exception ex)
            {
                diasLiqCompraMN = "0";
                GravarErro(ex, "Retorno.cs", string.Format("diasLiqCompraMN = 00 no ParametrosDiasLiqCompraMN(documento{0}, tipoMoeda{1})", documento, tipoMoeda));
            }

            return diasLiqCompraMN;
        }

        /// <summary>
        /// Seta parametros para dias de liquidação Moeda Extrangeira
        /// </summary>
        /// <param name="documento"></param>
        /// <param name="tipoMoeda"></param>
        /// <returns></returns>
        public static string ParametrosDiasLiqCompraME(string documento, string tipoMoeda)
        {
            string diasLiqCompraME = "";

            try
            {
                diasLiqCompraME = GetConfigParamCli(documento, "PARAM_DIASLIQ_VENDASME");
                int Moeda_Padrao = GetDias_ME_Moeda(tipoMoeda);
                //chamado 93342 - Não permitir operações D0 para moedas que necessitam de Arbitragem
                //Steeves - Sequenza
                if (Moeda_Padrao != 0)
                {
                    if (string.IsNullOrEmpty(diasLiqCompraME.Trim()))
                        diasLiqCompraME = GetConfigParamProdutos("DIASLIQ_VENDASME");
                }
                else
                {
                    diasLiqCompraME = "2";
                }
            }
            catch (Exception ex)
            {
                diasLiqCompraME = "0";
                GravarErro(ex, "Retorno.cs", string.Format("diasLiqCompraME = 00 no ParametrosDiasLiqCompraME(documento{0}, tipoMoeda{1})", documento, tipoMoeda));
            }

            return diasLiqCompraME;
        }

        /// <summary>
        /// Retorna o próximo dia útil
        /// </summary>
        /// <param name="horarioCorte"></param>
        /// <param name="tipoMoeda"></param>
        /// <param name="documento"></param>
        /// <param name="dt"></param>
        /// <param name="somenteValidar"></param>
        /// <returns></returns>
        public static string[] RetornaProximoDiaUtil(string horarioCorte, string tipoMoeda, string documento, DateTime dt, bool somenteValidar)
        {
            string[] retorno = new string[3] { "", "", "" };

            try
            {
                /*   if (TimeSpan.Parse(DateTime.Now.ToShortTimeString()) > TimeSpan.Parse(horarioCorte))
                      dt= dt.AddDays(1);*/
                // Seta parametros para dias de liquidacao
                string diasLiqCompraMN = (somenteValidar) ? "0" : ParametrosDiasLiqCompraMN(documento, tipoMoeda);
                string diasLiqCompraME = (somenteValidar) ? "0" : ParametrosDiasLiqCompraME(documento, tipoMoeda);
                Int32 hora_corte = (somenteValidar) ? 23 : (string.IsNullOrEmpty(horarioCorte) ? 0 : Convert.ToInt32(horarioCorte.Split(':')[0]));
                Int32 min_corte = (somenteValidar) ? 59 : (string.IsNullOrEmpty(horarioCorte) ? 0 : Convert.ToInt32(horarioCorte.Split(':')[1]));

                // Codigo da moeda
                Modelos.ModelosVarejo.TMOEDAS moeda_varejo = new Modelos.ModelosVarejo.TMOEDAS();
                moeda_varejo = (Modelos.ModelosVarejo.TMOEDAS)Negocios.Operacoes.Obter(moeda_varejo, "Cod_moeda = '" + tipoMoeda.Trim() + "'")[0];

                retorno = Get_Proximo_Dia_Util(dt,
                                                hora_corte,
                                                min_corte,
                                                "SP",
                                                moeda_varejo.cod_moeda,
                                                Convert.ToInt32(diasLiqCompraMN),
                                                Convert.ToInt32(diasLiqCompraME),
                                                "V",
                                                Retorna_Varejo_Parametros("HorarioDeCorteMudaDataValuta").ToString());
            }
            catch (Exception ex)
            {
                GravarErro(ex, "Retorno.cs", string.Format("RetornaProximoDiaUtil() - Erro:{0}", ex.Message));
            }

            return retorno;
        }

        /// <summary>
        /// Calcula a taxa de operação retornando o Valor PTAX, Valor Liq Reais, Valor IR Reais
        /// </summary>
        /// <param name="valMoeda"></param>
        /// <param name="valReais"></param>
        /// <param name="taxaOperacao"></param>
        /// <param name="moeda"></param>
        /// <param name="taxaIr"></param>
        /// <param name="tipoCliente"></param>
        /// <param name="irSaida"></param>
        /// <returns></returns>
        public static Tuple<decimal, string, string> RetornaTaxaOperacao(decimal valMoeda, decimal valReais, decimal taxaOperacao, string moeda, decimal taxaIr, string tipoCliente, bool irSaida)
        {
            EnumTipoCliente enumTipoCliente = (EnumTipoCliente)Convert.ToInt32(tipoCliente);

            return DAO.Funcoes.RetornaTaxaOperacao(valMoeda, valReais, taxaOperacao, moeda, taxaIr, (enumTipoCliente.Equals(EnumTipoCliente.AGENCIA)), irSaida);
        }

        /// <summary>
        /// Verifica se o cliente tem conta na Me SubConta
        /// </summary>
        /// <param name="idCliente"></param>
        /// <returns></returns>
        public static bool GetClienteTemMeSubConta(string idCliente)
        {
            return DAO.Funcoes.GetClienteTemMeSubConta(idCliente);
        }
    }
}
