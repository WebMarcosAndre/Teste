﻿

using System.Collections.Generic;
using Rendimento.Portal.CambioOnline.DAO;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class CrmService
    {
        public bool TemLogConfirmacaoFamiliaNoExterior(int numeroBoleto, string documentoCliente)
        {
            CrmDAO crmDAO = new CrmDAO();
            TBL_CRM crm = crmDAO.Get_LogConfirmacaoFamiliaNoExterior(numeroBoleto, documentoCliente);
            return crm != null && crm.crm_nboleto > 0;
        }

        public TBL_CRM Get_LogConfirmacaoFamiliaNoExterior(int numeroBoleto, string documentoCliente)
        {
            CrmDAO crmDAO = new CrmDAO();
            TBL_CRM crm = crmDAO.Get_LogConfirmacaoFamiliaNoExterior(numeroBoleto, documentoCliente);
            return crm;
        }


    }
}
