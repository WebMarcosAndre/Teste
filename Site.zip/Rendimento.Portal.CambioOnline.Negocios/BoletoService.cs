﻿
using System;
using System.Collections.Generic;
using Rendimento.Portal.CambioOnline.DAO;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;
using System.Linq;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class BoletoService
    {

        public static string Definir_op_assinado(TBL_CLIENTES ObjCliente, TBL_NATUREZA natureza, TBL_COL_PREBOLETO COL_PreBoleto, decimal valorEmDolar, bool AceitaProcuracao, bool AceitaAssinatura, decimal limiteAssinatura)
        {
            string op_assinado = "N";
            if (natureza.nat_obriga_bol_assinado)
                COL_PreBoleto.pre_assinado = "D";
            else if (valorEmDolar < limiteAssinatura)
                op_assinado = "D";
            else if (
                            (
                            !string.IsNullOrEmpty(COL_PreBoleto.pre_tipo_procuracao)
                            && COL_PreBoleto.pre_tipo_procuracao != "N" // Tiver procuração
                            )
                            || AceitaProcuracao // Aceitou procuração na tela
                    )
                op_assinado = "P";
            else if (ObjCliente.flg_valor_diferenciado != null &&
                        ObjCliente.flg_valor_diferenciado.Equals("S") &&
                        valorEmDolar <= ProcuracoesClienteDAO.BuscarValorProcuracaoAntiga(ObjCliente.id_cliente)) //Procuração antiga
                op_assinado = "D";
            else if (AceitaAssinatura)
                op_assinado = "A";
            else if (ObjCliente.flg_assina_digitalmente.Equals("S"))
                op_assinado = "N"; //caso mudem de ideia, achei melhor manter essa duplicidade de definição de op_assinado = "N"

            return op_assinado;
        }


        /// <summary>
        /// Indica se o cliente tem procuração ativa, no modelo novo (op_assinado == "P") ou modelo antigo (op_assinado == "D" mais condições)
        /// </summary>
        /// <param name="objCliente"></param>
        /// <param name="objPreBoleto"></param>
        /// <param name="valorEmDolar"></param>
        /// <returns></returns>
        public static bool ExisteProcuracaoAtiva(TBL_CLIENTES objCliente, TBL_PRE_BOLETO objPreBoleto, decimal valorEmDolar)
        {
            //return  ((!string.IsNullOrEmpty(COL_PreBoleto.pre_tipo_procuracao) && COL_PreBoleto.pre_tipo_procuracao != "N") || AceitaProcuracao )
            //        ||
            //        (ObjCliente.flg_valor_diferenciado != null 
            //        && ObjCliente.flg_valor_diferenciado.Equals("S") 
            //        && valorEmDolar <= ProcuracoesClienteDAO.BuscarValorProcuracaoAntiga(ObjCliente.id_cliente)) ? true:false;

            return (objPreBoleto.op_assinado == "P")
                    || ((objPreBoleto.op_assinado == "D")
                        && (objCliente.flg_valor_diferenciado != null
                            && objCliente.flg_valor_diferenciado.Equals("S")
                            && valorEmDolar <= ProcuracoesClienteDAO.BuscarValorProcuracaoAntiga(objCliente.id_cliente))) ? true : false;
        }

        public static bool ValidarPermissaoOperacaoParametrosCBP(ParametroRemessa parametroRemessa, decimal valorOperacao, string tipoMoeda, int idCliente, string tela, out string mensagemErro)
        {

            bool retorno = true;
            mensagemErro = "";
            string mensagemLogar = string.Empty;
            if (parametroRemessa == null || parametroRemessa.tipoPeriodoId == 0)
            {
                retorno = false;
                mensagemErro = "Serviço temporariamente indisponível. Tente novamente em alguns instantes.";
                mensagemLogar = $"Não foi possível obter informações de parametrização de remessa do CBP - Cliente: {idCliente}";
            }
            else if (parametroRemessa.numeroOperacaoCliente <= 0
                    || parametroRemessa.valorLimiteOperacao <= 0
                    || parametroRemessa.valorLimitePeriodo <= 0
                )
            {
                retorno = false;
                mensagemErro = "Operação não permitida para a data e horário atual.";
                mensagemLogar = $@"Limites zerados para operação - Cliente: {idCliente} | Parametrizado - 
                                    ParametrizacaoId: {parametroRemessa.id} -
                                    NumeroOperacaoCliente: {parametroRemessa.numeroOperacaoCliente} -
                                    ValorLimiteOperacao: {parametroRemessa.valorLimiteOperacao} -
                                    ValorLimitePeriodo: {parametroRemessa.valorLimitePeriodo} ";
            }
            else
            {
                BoletoDAO boletoDao = new BoletoDAO();
                DateTime.TryParse(DateTime.Now.ToString("yyyy-MM-dd") + " " + parametroRemessa.horaInicioPeriodo, out DateTime dataInicio);
                DateTime.TryParse(DateTime.Now.ToString("yyyy-MM-dd") + " " + parametroRemessa.horaFimPeriodo, out DateTime dataFim);

                //parametroRemessa.numeroOperacaoCliente = 2;
                //parametroRemessa.valorLimiteOperacao = 5000;
                //parametroRemessa.valorLimitePeriodo = 25000;

                string tipoOperacao = parametroRemessa.codigoTipoRemessa == "E" ? "V" : "C";

                List<TBL_PRE_BOLETO> preBoletoList = boletoDao.ListByOver(idCliente, tipoOperacao, dataInicio, dataFim);

                decimal[] taxas = Retorno.CalculaTaxaPronto("BRL", tipoOperacao);               
                decimal taxaDolar = taxas[1];    
                decimal valorOperacaoEmDolar =  valorOperacao / taxaDolar;
                decimal valorOperadoPeriodoEmDolar = preBoletoList.Sum(i => i.op_val_reais + i.Vlr_IOF + i.Vlr_IR + i.op_tarifa_operacao) / taxaDolar;

                if (preBoletoList.Count >= parametroRemessa.numeroOperacaoCliente)
                {
                    retorno = false;
                    mensagemErro = "Quantidade de operações excedidas no período.";
                    mensagemLogar = $@"Cliente ultrapassou o limite de quantidade de boletos | Quantidade limite de operação:                                         
                                        {parametroRemessa.numeroOperacaoCliente} x Boletos Gerados: {preBoletoList.Count }";

                }
                else if (valorOperacaoEmDolar >= parametroRemessa.valorLimiteOperacao)
                {
                    retorno = false;
                    mensagemErro = "Valor da operação não permitido para a data e horário atual.";
                    mensagemLogar = $@"Valor operado ultrapassou o limite por operação | Valor limite parametrizado por operação: {parametroRemessa.valorLimiteOperacao} x Valor Operacao EM DOLAR: {valorOperacaoEmDolar }";
                }
                else if (valorOperadoPeriodoEmDolar >= parametroRemessa.valorLimitePeriodo)
                {
                    retorno = false;
                    mensagemErro = "O valor total das operações excede o limite dentro do período.";
                    mensagemLogar = $@"Valor operado total ultrapassou o limite por periodo | Valor limite parametrizado por periodo: {parametroRemessa.valorLimitePeriodo} x Valor Periodo EM DOLAR: {valorOperadoPeriodoEmDolar}";
                }

                if (!retorno) {
                    mensagemLogar += $" - Tipo Operacao: {parametroRemessa.codigoTipoRemessa} - Cliente: {idCliente} - Parametrizado - ParametrizacaoId: {parametroRemessa.id} - Hora Inicio: {parametroRemessa.horaInicioPeriodo} - Hora Fim: {parametroRemessa.horaFimPeriodo}";
                    Retorno.GravarErro(new Exception(mensagemLogar), tela, mensagemLogar);
                }

            }

            return retorno;
        }




        public TBL_PRE_BOLETO Get(int numeroBoleto)
        {
            BoletoDAO boletoDao = new BoletoDAO();
            return boletoDao.Get(numeroBoleto);
        }
    }
}
