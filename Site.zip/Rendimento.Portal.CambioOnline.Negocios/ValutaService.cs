﻿using System;
using Rendimento.Portal.CambioOnline.DAO;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;
using Rendimento.Portal.CambioOnline.Negocios.DTO;
using Rendimento.Portal.CambioOnline.Negocios.Enum;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class ValutaService
    {
        ValutaDAO valutaDAO = new ValutaDAO();
        public void SalvarParametrosValuta(string login, int tipoPessoa)
        {
            int tipoCliente = (EnumTipoPessoa)tipoPessoa == EnumTipoPessoa.Fisica ? (int)EnumTipoCliente.PF : (int)EnumTipoCliente.PJ;

            TipoClienteService tipoClienteService = new TipoClienteService();
            TBL_LOGIN_INTEGRADO_TIPOCLIENTE loginTipoCliente = tipoClienteService.Get(tipoCliente);

            if (valutaDAO.Exist_ParametrosCliente(login))
                valutaDAO.Update(login,
                                                  loginTipoCliente.ValutaRecebimentoMN,
                                                  loginTipoCliente.ValutaRecebimentoME,
                                                  loginTipoCliente.ValutaEnvioMN,
                                                  loginTipoCliente.ValutaEnvioME);
            else
                valutaDAO.Insert(login,
                                        loginTipoCliente.ValutaRecebimentoMN,
                                        loginTipoCliente.ValutaRecebimentoME,
                                        loginTipoCliente.ValutaEnvioMN,
                                        loginTipoCliente.ValutaEnvioME);
        }

        public ValutaDTO Obter(string login, int tipoCliente, string tipoOperacao, string codigoMoeda, DateTime data)
        {
            ValutaDTO valutaDTO = new ValutaDTO();

            ObterDiasParametrizados(tipoCliente, login, valutaDTO);
            ObterDatasMoeda(tipoOperacao, codigoMoeda, data, valutaDTO);

            return valutaDTO;
        }

        private void ObterDatasMoeda(string tipoOperacao, string codigoMoeda, DateTime data, ValutaDTO valutaDTO)
        {
            string horarioCorte = Retorno.GetConfigParamProdutos("HORARIO_CORTE");
            int hora = 23, minuto = 59;
            if (horarioCorte.Split(':').Length > 1)
            {
                if (int.TryParse(horarioCorte.Split(':')[0], out hora))
                    hora = 23;
                if (int.TryParse(horarioCorte.Split(':')[1], out minuto))
                    minuto = 59;
            }

            string[] DataMnMe = Retorno.Get_Proximo_Dia_Util(data, hora, minuto, "SP", codigoMoeda, valutaDTO.ValutaEnvioMN, valutaDTO.ValutaEnvioME, tipoOperacao, Retorno.Retorna_Varejo_Parametros("HorarioDeCorteMudaDataValuta").ToString());
            DateTime.TryParse(DataMnMe[1], out DateTime DataMN);
            DateTime.TryParse(DataMnMe[2], out DateTime DataME);

            valutaDTO.DataMN = DataMN;
            valutaDTO.DataME = DataME;
        }

        private void ObterDiasParametrizados(int tipoCliente, string login, ValutaDTO valutaDTO)
        {
            TBL_COL_PARAMCLI parametrosCliente = valutaDAO.Get_ParametrosCliente(login);
            if (parametrosCliente == null)
            {
                TBL_LOGIN_INTEGRADO_TIPOCLIENTE objTipoCliente = new TipoClienteDAO().Get(tipoCliente);
                valutaDTO = new ValutaDTO()
                {
                    ValutaRecebimentoMN = objTipoCliente.ValutaRecebimentoMN,
                    ValutaRecebimentoME = objTipoCliente.ValutaRecebimentoME,
                    ValutaEnvioMN = objTipoCliente.ValutaEnvioMN,
                    ValutaEnvioME = objTipoCliente.ValutaEnvioME
                };
            }
            else
            {
                valutaDTO = new ValutaDTO()
                {
                    ValutaRecebimentoMN = parametrosCliente.PARAM_DIASLIQ_COMPRAS,
                    ValutaRecebimentoME = parametrosCliente.PARAM_DIASLIQ_COMPRASME,
                    ValutaEnvioMN = parametrosCliente.PARAM_DIASLIQ_VENDAS,
                    ValutaEnvioME = parametrosCliente.PARAM_DIASLIQ_VENDASME
                };
            }
            valutaDTO.Valuta = $"D{valutaDTO.ValutaEnvioMN}D{valutaDTO.ValutaEnvioME}";


        }
    }
}