﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rendimento.Portal.CambioOnline.Negocios.DTO
{
    public class ValutaDTO
    {
        public int ValutaEnvioME { get; set; }
        public int ValutaEnvioMN { get; set; }
        public int ValutaRecebimentoME { get; set; }
        public int ValutaRecebimentoMN { get; set; }
        public string Valuta { get; set; }
        public DateTime DataME { get; set; }
        public DateTime DataMN { get; set; }
      
    }
}
