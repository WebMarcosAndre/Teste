﻿using Rendimento.Portal.CambioOnline.DAO;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class TipoClienteService
    {
        public TBL_LOGIN_INTEGRADO_TIPOCLIENTE Get(int id)
        {
            TipoClienteDAO tipoClienteDao = new TipoClienteDAO();
            return tipoClienteDao.Get(id);
        }

    }
}
