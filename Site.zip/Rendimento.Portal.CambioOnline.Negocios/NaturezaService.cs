﻿using Rendimento.Portal.CambioOnline.DAO;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class NaturezaService
    {
        public TBL_NATUREZA Get(int id)
        {
            NaturezaDAO naturezaDao = new NaturezaDAO();
            return naturezaDao.Get(id);
        }
    }
}
