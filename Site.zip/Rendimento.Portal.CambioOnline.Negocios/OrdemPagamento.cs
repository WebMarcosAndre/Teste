﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Data.SqlClient;
using Rendimento.Portal.CambioOnline.DAO;
using System.Collections.Generic;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class OrdemPagamento
    {

        static private string strConexao = Executar.obterStringConexao("Rendimento.Portal.CambioOnline.Modelos.ModelosCambio.*");

        private int id_ordem, id_cliente, id_usuario, ano, codigo_moeda, tipo, formato;
        private string origem, cod_moeda, sender_swift, receiver_swift, tipo_identificacao, tipo_ident_corresp;
        private string C20_referencia, C23B_op_code;

        private DateTime C32A_data;
        private DateTime? data_liberacao;
        private string C32A_moeda;
        private decimal C32A_valor;

        private string C33B_moeda;
        private decimal C33B_valor;

        private string C50K_nome, C50K_numdoc, C50K_endereco, C50K_bairro, C50K_cidade, C50K_estado, C50K_cep;
        private string C50K_cod_banco, C50K_nome_banco, C50K_agencia, C50K_conta_corrente;
        private string C52_nome, C52_numdoc, C52_endereco, C52_cidade, C52_estado, C52_cep;
        private string C56A_conta, C56A_swift_code, C56A_nome, C56A_endereco;
        private string C56D_aba, C56D_nome, C56D_endereco;
        private string C57A_swift_code, C57A_nome, C57A_endereco;
        private string C57D_aba, C57D_nome, C57D_endereco;
        private string C59_conta, C59_nome, C59_endereco, C59_pais, C59_nome_pais, C59_iban;
        private string C70_info, C71A_details, C72_sender_receiver;
        private string mensagem;

        //---------------------
        //-- Construtor
        //---------------------
        public OrdemPagamento()
        {
        }

        //--------------------
        //-- Propriedades
        //--------------------
        #region Propriedades

        public int op_id_ordem
        {
            get { return id_ordem; }
            set { id_ordem = value; }
        }

        public int op_id_cliente
        {
            get { return id_cliente; }
            set { id_cliente = value; }
        }

        public int op_id_usuario
        {
            get { return id_usuario; }
            set { id_usuario = value; }
        }

        public int op_ano
        {
            get { return ano; }
            set { ano = value; }
        }

        public int op_codigo_moeda
        {
            get { return codigo_moeda; }
            set { codigo_moeda = value; }
        }

        public string op_cod_moeda
        {
            get { return cod_moeda; }
            set { cod_moeda = value; }
        }

        public int op_tipo
        {
            get { return tipo; }
            set { tipo = value; }
        }

        public int op_formato
        {
            get { return formato; }
            set { formato = value; }
        }

        public string op_origem
        {
            get { return origem; }
            set { origem = value; }
        }

        public string op_sender_swift
        {
            get { return sender_swift; }
            set { sender_swift = value; }
        }

        public string op_receiver_swift
        {
            get { return receiver_swift; }
            set { receiver_swift = value; }
        }

        public string op_tipo_identificacao
        {
            get { return tipo_identificacao; }
            set { tipo_identificacao = value; }
        }

        public string op_tipo_ident_corresp
        {
            get { return tipo_ident_corresp; }
            set { tipo_ident_corresp = value; }
        }

        public string op_C20_referencia
        {
            get { return C20_referencia; }
            set { C20_referencia = value; }
        }

        public string op_C23B_op_code
        {
            get { return C23B_op_code; }
            set { C23B_op_code = value; }
        }

        public DateTime op_C32A_data
        {
            get { return C32A_data; }
            set { C32A_data = value; }
        }

        public DateTime? op_data_liberacao
        {
            get { return data_liberacao; }
            set { data_liberacao = value; }
        }

        public string op_C32A_moeda
        {
            get { return C32A_moeda; }
            set { C32A_moeda = value; }
        }

        public decimal op_C32A_valor
        {
            get { return C32A_valor; }
            set { C32A_valor = value; }
        }

        public string op_C33B_moeda
        {
            get { return C33B_moeda; }
            set { C33B_moeda = value; }
        }

        public decimal op_C33B_valor
        {
            get { return C33B_valor; }
            set { C33B_valor = value; }
        }

        public string op_C50K_nome
        {
            get { return C50K_nome; }
            set { C50K_nome = value; }
        }

        public string op_C50K_numdoc
        {
            get { return C50K_numdoc; }
            set { C50K_numdoc = value; }
        }

        public string op_C50K_endereco
        {
            get { return C50K_endereco; }
            set { C50K_endereco = value; }
        }

        public string op_C50K_bairro
        {
            get { return C50K_bairro; }
            set { C50K_bairro = value; }
        }

        public string op_C50K_cidade
        {
            get { return C50K_cidade; }
            set { C50K_cidade = value; }
        }

        public string op_C50K_estado
        {
            get { return C50K_estado; }
            set { C50K_estado = value; }
        }

        public string op_C50K_cep
        {
            get { return C50K_cep; }
            set { C50K_cep = value; }
        }

        public string op_C50K_cod_banco
        {
            get { return C50K_cod_banco; }
            set { C50K_cod_banco = value; }
        }

        public string op_C50K_nome_banco
        {
            get { return C50K_nome_banco; }
            set { C50K_nome_banco = value; }
        }

        public string op_C50K_agencia
        {
            get { return C50K_agencia; }
            set { C50K_agencia = value; }
        }

        public string op_C50K_conta_corrente
        {
            get { return C50K_conta_corrente; }
            set { C50K_conta_corrente = value; }
        }

        public string op_C52_nome
        {
            get { return C52_nome; }
            set { C52_nome = value; }
        }

        public string op_C52_numdoc
        {
            get { return C52_numdoc; }
            set { C52_numdoc = value; }
        }

        public string op_C52_endereco
        {
            get { return C52_endereco; }
            set { C52_endereco = value; }
        }

        public string op_C52_cidade
        {
            get { return C52_cidade; }
            set { C52_cidade = value; }
        }

        public string op_C52_estado
        {
            get { return C52_estado; }
            set { C52_estado = value; }
        }

        public string op_C52_cep
        {
            get { return C52_cep; }
            set { C52_cep = value; }
        }

        public string op_C56A_conta
        {
            get { return C56A_conta; }
            set { C56A_conta = value; }
        }

        public string op_C56A_swift_code
        {
            get { return C56A_swift_code; }
            set { C56A_swift_code = value; }
        }

        public string op_C56A_nome
        {
            get { return C56A_nome; }
            set { C56A_nome = value; }
        }

        public string op_C56A_endereco
        {
            get { return C56A_endereco; }
            set { C56A_endereco = value; }
        }

        public string op_C56D_aba
        {
            get { return C56D_aba; }
            set { C56D_aba = value; }
        }

        public string op_C56D_nome
        {
            get { return C56D_nome; }
            set { C56D_nome = value; }
        }

        public string op_C56D_endereco
        {
            get { return C56D_endereco; }
            set { C56D_endereco = value; }
        }

        public string op_C57A_swift_code
        {
            get { return C57A_swift_code; }
            set { C57A_swift_code = value; }
        }

        public string op_C57A_nome
        {
            get { return C57A_nome; }
            set { C57A_nome = value; }
        }

        public string op_C57A_endereco
        {
            get { return C57A_endereco; }
            set { C57A_endereco = value; }
        }

        public string op_C57D_aba
        {
            get { return C57D_aba; }
            set { C57D_aba = value; }
        }

        public string op_C57D_nome
        {
            get { return C57D_nome; }
            set { C57D_nome = value; }
        }

        public string op_C57D_endereco
        {
            get { return C57D_endereco; }
            set { C57D_endereco = value; }
        }

        public string op_C59_conta
        {
            get { return C59_conta; }
            set { C59_conta = value; }
        }

        public string op_C59_iban
        {
            get { return C59_iban; }
            set { C59_iban = value; }
        }

        public string op_C59_nome
        {
            get { return C59_nome; }
            set { C59_nome = value; }
        }

        public string op_C59_endereco
        {
            get { return C59_endereco; }
            set { C59_endereco = value; }
        }

        public string op_C59_pais
        {
            get { return C59_pais; }
            set { C59_pais = value; }
        }

        public string op_C59_nome_pais
        {
            get { return C59_nome_pais; }
            set { C59_nome_pais = value; }
        }

        public string op_C70_info
        {
            get { return C70_info; }
            set { C70_info = value; }
        }

        public string op_C71A_details
        {
            get { return C71A_details; }
            set { C71A_details = value; }
        }

        public string op_C72_sender_receiver
        {
            get { return C72_sender_receiver; }
            set { C72_sender_receiver = value; }
        }

        public string op_mensagem
        {
            get { return mensagem; }
            set { mensagem = value; }
        }
        #endregion

        //---------------------
        //-- Métodos
        //---------------------
        public bool Carregar()
        {

            SqlDataReader dr = null;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[2];

                strParametros[0] = new SqlParameter("@ID_ORDEM", SqlDbType.Int);
                strParametros[0].Value = id_ordem;

                strParametros[1] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
                strParametros[1].Value = "LISTAR";

                dr = SqlHelper.ExecuteReader(strConexao, CommandType.StoredProcedure, "SPCOL_Ordem_Pagamento", strParametros);

                if (dr.HasRows)
                {
                    dr.Read();

                    id_cliente = Convert.ToInt32(dr["ID_CLIENTE"]);
                    id_usuario = Convert.ToInt32(dr["ID_USUARIO"]);

                    ano = Convert.ToInt32(dr["ANO"]);
                    codigo_moeda = Convert.ToInt32(dr["CODIGO_MOEDA"]);
                    tipo = Convert.ToInt32(dr["TIPO"]);
                    formato = Convert.ToInt32(dr["FORMATO"]);
                    origem = Convert.ToString(dr["ORIGEM"]).Trim();
                    cod_moeda = Convert.ToString(dr["COD_MOEDA"]).Trim();
                    sender_swift = Convert.ToString(dr["SENDER_SWIFT"]).Trim();
                    receiver_swift = Convert.ToString(dr["RECEIVER_SWIFT"]).Trim();
                    tipo_identificacao = Convert.ToString(dr["TIPO_IDENTIFICACAO"]).Trim();
                    tipo_ident_corresp = Convert.ToString(dr["TIPO_IDENT_CORRESP"]).Trim();

                    C20_referencia = Convert.ToString(dr["C20_REFERENCIA"]).Trim();

                    C23B_op_code = Convert.ToString(dr["C23B_OP_CODE"]).Trim();

                    C32A_data = Convert.ToDateTime(dr["C32A_DATA"]);
                    C32A_moeda = Convert.ToString(dr["C32A_MOEDA"]).Trim();
                    C32A_valor = Convert.ToDecimal(dr["C32A_VALOR"]);

                    try
                    {
                        data_liberacao = Convert.ToDateTime(dr["DATA_LIBERACAO"]);
                    }
                    catch
                    {
                        data_liberacao = null;
                    }

                    C33B_moeda = Convert.ToString(dr["C33B_MOEDA"]).Trim();
                    C33B_valor = Convert.ToDecimal(dr["C33B_VALOR"]);

                    C50K_nome = Convert.ToString(dr["C50K_NOME"]).Trim();
                    C50K_numdoc = Convert.ToString(dr["C50K_NUMDOC"]).Trim();
                    C50K_endereco = Convert.ToString(dr["C50K_ENDERECO"]).Trim();
                    C50K_bairro = Convert.ToString(dr["C50K_BAIRRO"]).Trim();
                    C50K_cidade = Convert.ToString(dr["C50K_CIDADE"]).Trim();
                    C50K_estado = Convert.ToString(dr["C50K_ESTADO"]).Trim();
                    C50K_cep = Convert.ToString(dr["C50K_CEP"]).Trim();
                    C50K_cod_banco = Convert.ToString(dr["C50K_COD_BANCO"]).Trim();
                    C50K_nome_banco = Convert.ToString(dr["C50K_NOME_BANCO"]).Trim();
                    C50K_agencia = Convert.ToString(dr["C50K_AGENCIA"]).Trim();
                    C50K_conta_corrente = Convert.ToString(dr["C50K_CONTA_CORRENTE"]).Trim();

                    C52_nome = Convert.ToString(dr["C52_NOME"]).Trim();
                    C52_numdoc = Convert.ToString(dr["C52_NUMDOC"]).Trim();
                    C52_endereco = Convert.ToString(dr["C52_ENDERECO"]).Trim();
                    C52_cidade = Convert.ToString(dr["C52_CIDADE"]).Trim();
                    C52_estado = Convert.ToString(dr["C52_ESTADO"]).Trim();
                    C52_cep = Convert.ToString(dr["C52_CEP"]).Trim();

                    C56A_conta = Convert.ToString(dr["C56A_CONTA"]).Trim();
                    C56A_swift_code = Convert.ToString(dr["C56A_SWIFT_CODE"]).Trim();
                    C56A_nome = Convert.ToString(dr["C56A_NOME"]).Trim();
                    C56A_endereco = Convert.ToString(dr["C56A_ENDERECO"]).Trim();

                    C56D_aba = Convert.ToString(dr["C56D_ABA"]).Trim();
                    C56D_nome = Convert.ToString(dr["C56D_NOME"]).Trim();
                    C56D_endereco = Convert.ToString(dr["C56D_ENDERECO"]).Trim();

                    C57A_swift_code = Convert.ToString(dr["C57A_SWIFT_CODE"]).Trim();
                    C57A_nome = Convert.ToString(dr["C57A_NOME"]).Trim();
                    C57A_endereco = Convert.ToString(dr["C57A_ENDERECO"]).Trim();

                    C57D_aba = Convert.ToString(dr["C57D_ABA"]).Trim();
                    C57D_nome = Convert.ToString(dr["C57D_NOME"]).Trim();
                    C57D_endereco = Convert.ToString(dr["C57D_ENDERECO"]).Trim();

                    C59_conta = Convert.ToString(dr["C59_CONTA"]).Trim();
                    C59_nome = Convert.ToString(dr["C59_NOME"]).Trim();
                    C59_endereco = Convert.ToString(dr["C59_ENDERECO"]).Trim();
                    C59_pais = Convert.ToString(dr["C59_PAIS"]).Trim();
                    C59_nome_pais = Convert.ToString(dr["C59_NOME_PAIS"]).Trim();

                    C59_iban = Convert.ToString(dr["C59_IBAN"]).Trim();

                    C70_info = Convert.ToString(dr["C70_INFO"]).Trim();

                    C71A_details = Convert.ToString(dr["C71A_DETAILS"]).Trim();

                    C72_sender_receiver = Convert.ToString(dr["C72_SENDER_RECEIVER"]).Trim();

                }
                else
                {
                    mensagem = "Ordem de Pagamento não encontrada.";
                    return false;
                }

            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: Carregar()", "Arquivo: OrdemPagamento.cs");
                mensagem = ex.Message;
                return false;
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                        dr.Dispose();
                    }
                }
            }

            return true;
        }

        public bool Validar()
        {
            //-------------------------------------------------------------------
            // Regra 1: EURO Dentro da Alemanha: OUR | EURO Fora da Alemanha: SHA
            //-------------------------------------------------------------------
            op_C71A_details = null;
            //op_C71A_details = "OUR";

            //if (cod_moeda.Equals("EURO") && !C59_pais.Equals("230"))
            //{
            //    op_C71A_details = "SHA";
            //}

            //----------------------------------------------------------
            //-- Regra 2:
            //----------------------------------------------------------

            return true;
        }

        public bool Salvar()
        {
            try
            {
                int i = 0;

                SqlParameter[] strParametros = new SqlParameter[59];

                strParametros[i] = new SqlParameter("@ANO", SqlDbType.Int);
                strParametros[i++].Value = ano;

                strParametros[i] = new SqlParameter("@TIPO", SqlDbType.Int);
                strParametros[i++].Value = tipo;

                strParametros[i] = new SqlParameter("@ORIGEM", SqlDbType.Char, 1);
                strParametros[i++].Value = origem;

                strParametros[i] = new SqlParameter("@FORMATO", SqlDbType.Char, 3);
                strParametros[i++].Value = formato;

                strParametros[i] = new SqlParameter("@SENDER_SWIFT", SqlDbType.VarChar, 20);
                strParametros[i++].Value = sender_swift;

                strParametros[i] = new SqlParameter("@RECEIVER_SWIFT", SqlDbType.VarChar, 20);
                strParametros[i++].Value = receiver_swift;

                strParametros[i] = new SqlParameter("@CODIGO_MOEDA", SqlDbType.Int);
                strParametros[i++].Value = codigo_moeda;

                strParametros[i] = new SqlParameter("@C20_REFERENCIA", SqlDbType.VarChar, 50);
                strParametros[i++].Value = C20_referencia;

                strParametros[i] = new SqlParameter("@C23B_OP_CODE", SqlDbType.VarChar, 10);
                strParametros[i++].Value = C23B_op_code;

                strParametros[i] = new SqlParameter("@C32A_DATA", SqlDbType.DateTime);
                strParametros[i++].Value = C32A_data;

                strParametros[i] = new SqlParameter("@DATA_LIBERACAO", SqlDbType.DateTime);
                strParametros[i++].Value = data_liberacao;

                strParametros[i] = new SqlParameter("@C32A_MOEDA", SqlDbType.Char, 10);
                strParametros[i++].Value = C32A_moeda;

                strParametros[i] = new SqlParameter("@C32A_VALOR", SqlDbType.Money);
                strParametros[i++].Value = C32A_valor;

                strParametros[i] = new SqlParameter("@C33B_MOEDA", SqlDbType.Char, 10);
                strParametros[i++].Value = C33B_moeda;

                strParametros[i] = new SqlParameter("@C33B_VALOR", SqlDbType.Money);
                strParametros[i++].Value = C33B_valor;

                strParametros[i] = new SqlParameter("@C50K_NOME", SqlDbType.VarChar, 34);
                strParametros[i++].Value = C50K_nome;

                strParametros[i] = new SqlParameter("@C50K_NUMDOC", SqlDbType.VarChar, 25);
                strParametros[i++].Value = C50K_numdoc;

                strParametros[i] = new SqlParameter("@C50K_ENDERECO", SqlDbType.VarChar, 34);
                strParametros[i++].Value = C50K_endereco;

                strParametros[i] = new SqlParameter("@C50K_BAIRRO", SqlDbType.VarChar, 34);
                strParametros[i++].Value = C50K_bairro;

                strParametros[i] = new SqlParameter("@C50K_CIDADE", SqlDbType.VarChar, 34);
                strParametros[i++].Value = C50K_cidade;

                strParametros[i] = new SqlParameter("@C50K_ESTADO", SqlDbType.VarChar, 2);
                strParametros[i++].Value = C50K_estado;

                strParametros[i] = new SqlParameter("@C50K_CEP", SqlDbType.VarChar, 8);
                strParametros[i++].Value = C50K_cep;

                strParametros[i] = new SqlParameter("@C50K_COD_BANCO", SqlDbType.VarChar, 10);
                strParametros[i++].Value = C50K_cod_banco;

                strParametros[i] = new SqlParameter("@C50K_NOME_BANCO", SqlDbType.VarChar, 100);
                strParametros[i++].Value = C50K_nome_banco;

                strParametros[i] = new SqlParameter("@C50K_AGENCIA", SqlDbType.VarChar, 10);
                strParametros[i++].Value = C50K_agencia;

                strParametros[i] = new SqlParameter("@C50K_CONTA_CORRENTE", SqlDbType.VarChar, 10);
                strParametros[i++].Value = C50K_conta_corrente;

                strParametros[i] = new SqlParameter("@C52_NOME", SqlDbType.VarChar, 100);
                strParametros[i++].Value = C52_nome;

                strParametros[i] = new SqlParameter("@C52_NUMDOC", SqlDbType.VarChar, 25);
                strParametros[i++].Value = C52_numdoc;

                strParametros[i] = new SqlParameter("@C52_ENDERECO", SqlDbType.VarChar, 175);
                strParametros[i++].Value = C52_endereco;

                strParametros[i] = new SqlParameter("@C52_CIDADE", SqlDbType.VarChar, 34);
                strParametros[i++].Value = C52_cidade;

                strParametros[i] = new SqlParameter("@C52_ESTADO", SqlDbType.VarChar, 2);
                strParametros[i++].Value = C52_estado;

                strParametros[i] = new SqlParameter("@C52_CEP", SqlDbType.VarChar, 8);
                strParametros[i++].Value = C52_cep;

                strParametros[i] = new SqlParameter("@C56A_CONTA", SqlDbType.VarChar, 20);
                strParametros[i++].Value = C56A_conta;

                strParametros[i] = new SqlParameter("@C56A_SWIFT_CODE", SqlDbType.VarChar, 20);
                strParametros[i++].Value = C56A_swift_code;

                strParametros[i] = new SqlParameter("@C56A_NOME", SqlDbType.VarChar, 100);
                strParametros[i++].Value = C56A_nome;

                strParametros[i] = new SqlParameter("@C56A_ENDERECO", SqlDbType.VarChar, 175);
                strParametros[i++].Value = C56A_endereco;

                strParametros[i] = new SqlParameter("@C56D_ABA", SqlDbType.VarChar, 20);
                strParametros[i++].Value = C56D_aba;

                strParametros[i] = new SqlParameter("@C56D_NOME", SqlDbType.VarChar, 100);
                strParametros[i++].Value = C56D_nome;

                strParametros[i] = new SqlParameter("@C56D_ENDERECO", SqlDbType.VarChar, 175);
                strParametros[i++].Value = C56D_endereco;

                strParametros[i] = new SqlParameter("@C57A_SWIFT_CODE", SqlDbType.VarChar, 20);
                strParametros[i++].Value = C57A_swift_code;

                strParametros[i] = new SqlParameter("@C57A_NOME", SqlDbType.VarChar, 100);
                strParametros[i++].Value = C57A_nome;

                strParametros[i] = new SqlParameter("@C57A_ENDERECO", SqlDbType.VarChar, 175);
                strParametros[i++].Value = C57A_endereco;

                strParametros[i] = new SqlParameter("@C57D_ABA", SqlDbType.VarChar, 20);
                strParametros[i++].Value = C57D_aba;

                strParametros[i] = new SqlParameter("@C57D_NOME", SqlDbType.VarChar, 100);
                strParametros[i++].Value = C57D_nome;

                strParametros[i] = new SqlParameter("@C57D_ENDERECO", SqlDbType.VarChar, 175);
                strParametros[i++].Value = C57D_endereco;

                strParametros[i] = new SqlParameter("@C59_NOME", SqlDbType.VarChar, 50);
                strParametros[i++].Value = C59_nome;

                strParametros[i] = new SqlParameter("@C59_ENDERECO", SqlDbType.VarChar, 68);
                strParametros[i++].Value = C59_endereco;

                strParametros[i] = new SqlParameter("@C59_PAIS", SqlDbType.VarChar, 10);
                strParametros[i++].Value = C59_pais;

                strParametros[i] = new SqlParameter("@C59_IBAN", SqlDbType.VarChar, 34);
                strParametros[i++].Value = C59_iban;

                strParametros[i] = new SqlParameter("@C59_CONTA", SqlDbType.VarChar, 34);
                strParametros[i++].Value = C59_conta;

                strParametros[i] = new SqlParameter("@C70_INFO", SqlDbType.VarChar, 300);
                strParametros[i++].Value = C70_info;

                strParametros[i] = new SqlParameter("@C71A_DETAILS", SqlDbType.Char, 300);
                strParametros[i++].Value = C71A_details;

                strParametros[i] = new SqlParameter("@C72_SENDER_RECEIVER", SqlDbType.VarChar, 300);
                strParametros[i++].Value = C72_sender_receiver;

                strParametros[i] = new SqlParameter("@TIPO_IDENTIFICACAO", SqlDbType.VarChar, 10);
                strParametros[i++].Value = tipo_identificacao;

                strParametros[i] = new SqlParameter("@TIPO_IDENT_CORRESP", SqlDbType.VarChar, 10);
                strParametros[i++].Value = tipo_ident_corresp;

                strParametros[i] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                strParametros[i++].Value = id_cliente;

                strParametros[i] = new SqlParameter("@ID_USUARIO", SqlDbType.Int);
                strParametros[i++].Value = id_usuario;

                strParametros[i] = new SqlParameter("@ID_ORDEM", SqlDbType.Int);
                strParametros[i++].Value = Convert.ToInt32(id_ordem);

                strParametros[i] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
                strParametros[i++].Value = "ATUALIZAR";

                SqlHelper.ExecuteNonQuery(strConexao, CommandType.StoredProcedure, "SPCOL_Ordem_Pagamento", strParametros);

                //DAO.Funcoes.gra(id_cliente, "Usuário editou a Ordem de Pagamento: " + id_ordem.ToString() + ".");

            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: Salvar()", "Arquivo: OrdemPagamento.cs");
                return false;
            }


            return true;
        }

        public bool Incluir()
        {
            try
            {
                int i = 0;

                SqlParameter[] strParametros = new SqlParameter[58];

                strParametros[i] = new SqlParameter("@ANO", SqlDbType.Int);
                strParametros[i++].Value = ano;

                strParametros[i] = new SqlParameter("@TIPO", SqlDbType.Int);
                strParametros[i++].Value = tipo;

                strParametros[i] = new SqlParameter("@ORIGEM", SqlDbType.Char, 2);
                strParametros[i++].Value = origem;

                strParametros[i] = new SqlParameter("@FORMATO", SqlDbType.Char, 5);
                strParametros[i++].Value = formato;

                strParametros[i] = new SqlParameter("@SENDER_SWIFT", SqlDbType.VarChar, 20);
                strParametros[i++].Value = sender_swift;

                strParametros[i] = new SqlParameter("@RECEIVER_SWIFT", SqlDbType.VarChar, 20);
                strParametros[i++].Value = receiver_swift;

                strParametros[i] = new SqlParameter("@CODIGO_MOEDA", SqlDbType.Int);
                strParametros[i++].Value = codigo_moeda;

                strParametros[i] = new SqlParameter("@C20_REFERENCIA", SqlDbType.VarChar, 50);
                strParametros[i++].Value = C20_referencia;

                strParametros[i] = new SqlParameter("@C23B_OP_CODE", SqlDbType.VarChar, 10);
                strParametros[i++].Value = C23B_op_code;

                strParametros[i] = new SqlParameter("@C32A_DATA", SqlDbType.DateTime);
                strParametros[i++].Value = C32A_data;

                strParametros[i] = new SqlParameter("@DATA_LIBERACAO", SqlDbType.DateTime);
                strParametros[i++].Value = data_liberacao;

                strParametros[i] = new SqlParameter("@C32A_MOEDA", SqlDbType.Char, 10);
                strParametros[i++].Value = C32A_moeda;

                strParametros[i] = new SqlParameter("@C32A_VALOR", SqlDbType.Money);
                strParametros[i++].Value = C32A_valor;

                strParametros[i] = new SqlParameter("@C33B_MOEDA", SqlDbType.Char, 10);
                strParametros[i++].Value = C33B_moeda;

                strParametros[i] = new SqlParameter("@C33B_VALOR", SqlDbType.Money);
                strParametros[i++].Value = C33B_valor;

                strParametros[i] = new SqlParameter("@C50K_NOME", SqlDbType.NVarChar, 34);
                strParametros[i++].Value = C50K_nome;

                strParametros[i] = new SqlParameter("@C50K_NUMDOC", SqlDbType.VarChar, 25);
                strParametros[i++].Value = C50K_numdoc;

                strParametros[i] = new SqlParameter("@C50K_ENDERECO", SqlDbType.VarChar, 34);
                strParametros[i++].Value = C50K_endereco;

                strParametros[i] = new SqlParameter("@C50K_BAIRRO", SqlDbType.VarChar, 34);
                strParametros[i++].Value = C50K_bairro;

                strParametros[i] = new SqlParameter("@C50K_CIDADE", SqlDbType.VarChar, 34);
                strParametros[i++].Value = C50K_cidade;

                strParametros[i] = new SqlParameter("@C50K_ESTADO", SqlDbType.VarChar, 2);
                strParametros[i++].Value = C50K_estado;

                strParametros[i] = new SqlParameter("@C50K_CEP", SqlDbType.VarChar, 8);
                strParametros[i++].Value = C50K_cep;

                strParametros[i] = new SqlParameter("@C50K_COD_BANCO", SqlDbType.NVarChar, 4);
                strParametros[i++].Value = C50K_cod_banco;

                strParametros[i] = new SqlParameter("@C50K_NOME_BANCO", SqlDbType.VarChar, 100);
                strParametros[i++].Value = C50K_nome_banco;

                strParametros[i] = new SqlParameter("@C50K_AGENCIA", SqlDbType.NVarChar, 4);
                strParametros[i++].Value = C50K_agencia;

                strParametros[i] = new SqlParameter("@C50K_CONTA_CORRENTE", SqlDbType.VarChar, 10);
                strParametros[i++].Value = C50K_conta_corrente;

                strParametros[i] = new SqlParameter("@C52_NOME", SqlDbType.VarChar, 100);
                strParametros[i++].Value = C52_nome;

                strParametros[i] = new SqlParameter("@C52_NUMDOC", SqlDbType.VarChar, 25);
                strParametros[i++].Value = C52_numdoc;

                strParametros[i] = new SqlParameter("@C52_ENDERECO", SqlDbType.VarChar, 175);
                strParametros[i++].Value = C52_endereco;

                strParametros[i] = new SqlParameter("@C52_CIDADE", SqlDbType.VarChar, 34);
                strParametros[i++].Value = C52_cidade;

                strParametros[i] = new SqlParameter("@C52_ESTADO", SqlDbType.VarChar, 2);
                strParametros[i++].Value = C52_estado;

                strParametros[i] = new SqlParameter("@C52_CEP", SqlDbType.VarChar, 8);
                strParametros[i++].Value = C52_cep;

                strParametros[i] = new SqlParameter("@C56A_CONTA", SqlDbType.VarChar, 25);
                strParametros[i++].Value = C56A_conta;

                strParametros[i] = new SqlParameter("@C56A_SWIFT_CODE", SqlDbType.VarChar, 20);
                strParametros[i++].Value = C56A_swift_code;

                strParametros[i] = new SqlParameter("@C56A_NOME", SqlDbType.VarChar, 100);
                strParametros[i++].Value = C56A_nome;

                strParametros[i] = new SqlParameter("@C56A_ENDERECO", SqlDbType.VarChar, 175);
                strParametros[i++].Value = C56A_endereco;

                strParametros[i] = new SqlParameter("@C56D_ABA", SqlDbType.VarChar, 20);
                strParametros[i++].Value = C56D_aba;

                strParametros[i] = new SqlParameter("@C56D_NOME", SqlDbType.VarChar, 100);
                strParametros[i++].Value = C56D_nome;

                strParametros[i] = new SqlParameter("@C56D_ENDERECO", SqlDbType.VarChar, 175);
                strParametros[i++].Value = C56D_endereco;

                strParametros[i] = new SqlParameter("@C57A_SWIFT_CODE", SqlDbType.VarChar, 20);
                strParametros[i++].Value = C57A_swift_code;

                strParametros[i] = new SqlParameter("@C57A_NOME", SqlDbType.VarChar, 100);
                strParametros[i++].Value = C57A_nome;

                strParametros[i] = new SqlParameter("@C57A_ENDERECO", SqlDbType.VarChar, 175);
                strParametros[i++].Value = C57A_endereco;

                strParametros[i] = new SqlParameter("@C57D_ABA", SqlDbType.VarChar, 20);
                strParametros[i++].Value = C57D_aba;

                strParametros[i] = new SqlParameter("@C57D_NOME", SqlDbType.VarChar, 100);
                strParametros[i++].Value = C57D_nome;

                strParametros[i] = new SqlParameter("@C57D_ENDERECO", SqlDbType.VarChar, 175);
                strParametros[i++].Value = C57D_endereco;

                strParametros[i] = new SqlParameter("@C59_NOME", SqlDbType.VarChar, 50);
                strParametros[i++].Value = C59_nome;

                strParametros[i] = new SqlParameter("@C59_ENDERECO", SqlDbType.VarChar, 68);
                strParametros[i++].Value = C59_endereco;

                strParametros[i] = new SqlParameter("@C59_PAIS", SqlDbType.VarChar, 10);
                strParametros[i++].Value = C59_pais;

                strParametros[i] = new SqlParameter("@C59_IBAN", SqlDbType.VarChar, 34);
                strParametros[i++].Value = C59_iban;

                strParametros[i] = new SqlParameter("@C59_CONTA", SqlDbType.VarChar, 34);
                strParametros[i++].Value = C59_conta;

                strParametros[i] = new SqlParameter("@C70_INFO", SqlDbType.VarChar, 300);
                strParametros[i++].Value = C70_info;

                strParametros[i] = new SqlParameter("@C71A_DETAILS", SqlDbType.Char, 300);
                strParametros[i++].Value = C71A_details;

                strParametros[i] = new SqlParameter("@C72_SENDER_RECEIVER", SqlDbType.VarChar, 300);
                strParametros[i++].Value = C72_sender_receiver;

                strParametros[i] = new SqlParameter("@TIPO_IDENTIFICACAO", SqlDbType.VarChar, 10);
                strParametros[i++].Value = tipo_identificacao;

                strParametros[i] = new SqlParameter("@TIPO_IDENT_CORRESP", SqlDbType.VarChar, 10);
                strParametros[i++].Value = tipo_ident_corresp;

                strParametros[i] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                strParametros[i++].Value = id_cliente;

                strParametros[i] = new SqlParameter("@ID_USUARIO", SqlDbType.Int);
                strParametros[i++].Value = id_usuario;

                strParametros[i] = new SqlParameter("@ACAO", SqlDbType.VarChar, 25);
                strParametros[i++].Value = "INSERIR";

                SqlHelper.ExecuteNonQuery(strConexao, CommandType.StoredProcedure, "SPCOL_Ordem_Pagamento", strParametros);

                //Funcoes_CCME.ccme.GravarLog(id_cliente, "Usuário incluiu um Swift no valor de " + C32A_moeda + " " + String.Format("{0:N2}", C32A_valor) + ".");

                mensagem = "Ordem de Pagamento incluída com sucesso!";

            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: Incluir()", "Arquivo: OrdemPagamento.cs");
                return false;
            }

            return true;

        }

        public bool Aprovar(int id_lancamento, string bloquear_swift, string li_corretora)
        {
            try
            {

                Carregar();

                SqlParameter[] strParametros = new SqlParameter[6];

                strParametros[0] = new SqlParameter("@ID_ORDEM", SqlDbType.Int);
                strParametros[0].Value = id_ordem;

                strParametros[1] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                strParametros[1].Value = id_cliente;

                strParametros[2] = new SqlParameter("@ID_USUARIO", SqlDbType.Int);
                strParametros[2].Value = id_usuario;

                strParametros[3] = new SqlParameter("@ID_LANCAMENTO", SqlDbType.Int);
                strParametros[3].Value = id_lancamento;

                strParametros[4] = new SqlParameter("@STATUS_SWIFT", SqlDbType.Char, 1);
                strParametros[4].Value = bloquear_swift;

                strParametros[5] = new SqlParameter("@CORRETORA", SqlDbType.Char, 1);
                strParametros[5].Value = li_corretora;

                SqlHelper.ExecuteNonQuery(strConexao, CommandType.StoredProcedure, "SPBCCME_Aprovar_Envio_Swift", strParametros);

                //Funcoes_CCME.ccme.GravarLog(id_usuario, "Usuário aprovou o envio do swift: " + id_ordem.ToString() + " no valor de " + String.Format("{0:N2}", C32A_valor) + ".");

                mensagem = "Ordem de Pagamento foi aprovada com sucesso!";

            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: Incluir()", "Arquivo: OrdemPagamento.cs");
                return false;
            }

            return true;
        }

        public static DataSet ListarMotivoEnvio(int id_natureza, string empresa, string tipo_documento)
        {
            return ListarMotivoEnvio(id_natureza, empresa, tipo_documento, null);
        }

        public static DataSet ListarMotivoEnvio(int id_natureza, string empresa, string tipo_documento, string codigo_pagador, bool vendaGoogle = false)
        {
            try
            {

                SqlParameter[] strParametros = new SqlParameter[3];

                strParametros[0] = new SqlParameter("@ID_NATUREZA", SqlDbType.Int);
                strParametros[0].Value = id_natureza;

                strParametros[1] = new SqlParameter("@EMPRESA", SqlDbType.Char);
                strParametros[1].Value = empresa;

                strParametros[2] = new SqlParameter("@CL_TIP_DOC", SqlDbType.VarChar, 4);
                strParametros[2].Value = tipo_documento;

                //strParametros[3] = new SqlParameter("@COD_PAGADOR", SqlDbType.NVarChar, 10);
                //if (!string.IsNullOrWhiteSpace(codigo_pagador))
                //{
                //    strParametros[3].Value = codigo_pagador;
                //}
                //else 
                //{
                //    strParametros[3].Value = DBNull.Value;
                //}

                var motivosEnvio = SqlHelper.ExecuteDataset(strConexao, CommandType.StoredProcedure, "SPCOL_LISTAR_MOTIVO_ENVIO", strParametros);

                if (vendaGoogle)
                {
                    var dataSet = motivosEnvio.Clone();
                    var dataTable = motivosEnvio.Tables[0];

                    foreach (DataRow row in dataTable.Rows)
                    {
                        if (row["cod_pagador"].ToString() == "05")
                            dataSet.Tables[0].Rows.Add(row.ItemArray[0], row.ItemArray[1], row.ItemArray[2]);
                    }

                    return dataSet;
                }
                else
                    return motivosEnvio;
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: ListarMotivoEnvio()", "Arquivo: OrdemPagamento.cs");
                return null;
            }
        }

        public static DataSet ListarAcompanhamentos(DateTime dtIni, DateTime dtFim, string tipo, int status, int id_cliente)
        {
            DataSet ds = null;

            try
            {
            
                dtFim = dtFim.AddHours(23).AddMinutes(59).AddSeconds(59);

                SqlParameter[] strParametros = new SqlParameter[5];
                strParametros[0] = new SqlParameter("@DATA_INICIO", SqlDbType.DateTime);
                strParametros[0].Value = dtIni;

                strParametros[1] = new SqlParameter("@DATA_FIM", SqlDbType.DateTime);
                strParametros[1].Value = dtFim;

                strParametros[2] = new SqlParameter("@TIPO", SqlDbType.Char);
                strParametros[2].Value = tipo;

                strParametros[3] = new SqlParameter("@STATUS", SqlDbType.Int);
                strParametros[3].Value = status;

                strParametros[4] = new SqlParameter("@ID_CLIENTE", SqlDbType.Int);
                strParametros[4].Value = id_cliente;

                ds = SqlHelper.ExecuteDataset(strConexao, CommandType.StoredProcedure, "SPCOL_LISTAR_ACOMPANHAMENTOS", strParametros);

                return ds;

            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: ListarAcompanhamentos()", "Arquivo: OrdemPagamento.cs");
                return null;
            }
        }

        public static int RetornarStatus(int op_n_boleto)
        {
            DataSet ds = null;

            try
            {
                ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("SELECT dbo.fn_GetFaseCompra({0}, 1) as Fase", op_n_boleto));

                return ds.Tables[0] != null ? (int)ds.Tables[0].Rows[0][0] : 0;

            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: RetornarStatus()", "Arquivo: OrdemPagamento.cs");
                return 0;
            }
        }

        public static int RetornarStatus(int op_n_boleto, int campo)
        {
            DataSet ds = null;

            try
            {
                ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("SELECT dbo.fn_GetFaseCompra({0}, {1}) as Fase", op_n_boleto, campo));

                return ds.Tables[0] != null ? (int)ds.Tables[0].Rows[0][0] : 0;

            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: RetornarStatus()", "Arquivo: OrdemPagamento.cs");
                return 0;
            }
        }

        public static List<string> RetornaDocumentosNatureza(int idnatureza)
        {
            List<string> retorno = new List<string>();

            try
            {
                //SPCOL_DOCUMENTOS_NATUREZA
                SqlParameter[] parametros = new SqlParameter[1];
                parametros[0] = new SqlParameter("@ID_NATUREZA", SqlDbType.Int);
                parametros[0].Direction = ParameterDirection.Input;
                parametros[0].Value = idnatureza;
                SqlDataReader dr = SqlHelper.ExecuteReader(strConexao, CommandType.StoredProcedure, "SPCOL_DOCUMENTOS_NATUREZA", parametros);

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        retorno.Add(dr.GetString(dr.GetOrdinal("doc_descricao")));
                    }
                }

                return retorno;

            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: RetornaDocumentosNatureza()", "Arquivo: OrdemPagamento.cs");
                return retorno;
            }
        }

        public static int RetornarMensagemAcompanhamento(int op_n_boleto)
        {
            DataSet ds = null;

            try
            {
                ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text, string.Format("SELECT dbo.fn_RetornarMensagemAcompanhamento({0}) as Total", op_n_boleto));

                return ds.Tables[0] != null ? (int)ds.Tables[0].Rows[0][0] : 0;

            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: RetornarMensagemAcompanhamento()", "Arquivo: OrdemPagamento.cs");
                return 0;
            }
        }
    }
}
