﻿

using Rendimento.Portal.CambioOnline.DAO;
using System.Data;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class PermissaoAcesso
    {
        private static string strConexao = Executar.obterStringConexao("Rendimento.Portal.CambioOnline.Modelos.ModelosCambio.*");
        public static bool RealizaEnvioRemessa(Modelos.ModelosCambio.TBL_CLIENTES_LOGIN objLogin)
        {
            bool retorno = false;

            if (objLogin.cl_tip_doc != null)
                if (objLogin.cl_tip_doc.Trim().Contains("CPF"))
                {
                    DataSet ds = SqlHelper.ExecuteDataset(strConexao, CommandType.Text,
                                               string.Format(@"
                                            SELECT 1
                                            WHERE
                                                EXISTS(
                                                            SELECT TOP 1 1
                                                            FROM IK_VAREJO.DBO.TBL_PRE_BOLETO   (NOLOCK)
                                                            WHERE id_cliente = {0} AND sistema_origem = 'PC'
                                                            )
                                                OR NOT EXISTS(
                                                            SELECT TOP 1 1
                                                            FROM IK_VAREJO.DBO.TBL_PRE_BOLETO   (NOLOCK)
                                                            WHERE id_cliente = {0} AND sistema_origem = 'SF'
                                                            AND pre_boleto_status IN(0, 1, 4, 5)
                                                        )
                                            ", objLogin.id_cliente.ToString())
                    );
                    if (ds.Tables != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                        retorno = true;

                }
                else retorno = true;


            return retorno;
        }
    }
}
