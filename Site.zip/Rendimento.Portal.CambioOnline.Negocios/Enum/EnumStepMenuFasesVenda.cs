﻿

namespace Rendimento.Portal.CambioOnline.Negocios.Enum
{
    public enum EnumStepMenuFasesVenda
    {
        stepNegociarTaxa = 10,
        stepDadosBancarios = 20,
        stepUploadBoleto = 30,
        stepAssinatura = 40,
        stepUploadDocumento = 50,
        stepComprovanteOperacao = 90
    }
}
