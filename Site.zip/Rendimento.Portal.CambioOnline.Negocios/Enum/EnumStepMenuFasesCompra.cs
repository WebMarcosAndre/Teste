﻿
namespace Rendimento.Portal.CambioOnline.Negocios.Enum
{
    public enum EnumStepMenuFasesCompra
    {
        stepNegociarTaxa = 1,
        stepDadosBancarios = 2,
        stepUploadDocumentos = 3,
        stepAssinatura = 4,
        stepClienteContaRendimento = 5,
        stepComprovanteOperacao = 6
    }
}
