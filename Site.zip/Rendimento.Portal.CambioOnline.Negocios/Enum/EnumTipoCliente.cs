﻿
namespace Rendimento.Portal.CambioOnline.Negocios.Enum
{
    public enum EnumTipoCliente
    {
        CORRETORA = 0,
        AGENCIA = 1,
        INTERCAMBIO = 2,
        PJ = 3,
        PF = 4,
        EMBAIXADA = 5,
        DIPLOMATA = 6,
        ORGANISMOS = 7
    }
}
