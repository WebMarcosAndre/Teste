﻿namespace Rendimento.Portal.CambioOnline.Negocios.Enum
{
    public enum EnumSistemaCBP
    {
      PortalCambioRendimento = 1,
      PortalCambioCotacao = 2,
      CambioOnLineRendimento = 3,
      CambioOnLineCotacao = 4   
    }
}
