﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rendimento.Portal.CambioOnline.Negocios.Enums
{
    public enum StatusProcuracaoDigital
    {
        Aprovada,
        Cancelada,
        Verificando
    }
}
