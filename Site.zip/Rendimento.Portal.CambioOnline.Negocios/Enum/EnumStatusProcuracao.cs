﻿namespace Rendimento.Portal.CambioOnline.Negocios.Enum
{
    public enum EnumStatusProcuracao : int
    {
        AguardandoUpload = 0,
        EmValidacao = 1,
        EmAprovacao = 2,
        Aprovado = 3,
        Cancelado = 4,
        Inexistente = 1000
    }
}
