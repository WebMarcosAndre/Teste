﻿namespace Rendimento.Portal.CambioOnline.Negocios.Enum
{
    public enum EnumEmpresa
    {
        CambioRendimento = 1,
        CambioCotacao = 2
    }
}
