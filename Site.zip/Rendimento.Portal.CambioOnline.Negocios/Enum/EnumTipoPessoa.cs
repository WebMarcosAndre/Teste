﻿

namespace Rendimento.Portal.CambioOnline.Negocios.Enum
{
    public enum EnumTipoPessoa
    {
        Fisica = 1,
        Juridica = 2
    }
}
