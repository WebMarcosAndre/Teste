﻿namespace Rendimento.Portal.CambioOnline.Negocios.Enum
{
    public enum EnumStatusDoSistema
    {
        AtivoEOperacional = 1,
        AtivoeFechadoParaOperacoes = 2,
        Inativo = 3,
        Desativado = 4

    }
}
