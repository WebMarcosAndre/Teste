﻿
namespace Rendimento.Portal.CambioOnline.Negocios.Enum
{
    public enum EnumTokenTimer
    {
        DEFAULT = 1,
        Portal_CORRETORA = 2,
        Portal_AGENCIA = 3,
        Portal_INTERCAMBIO = 4,
        Portal_PJ = 5,
        Portal_PF = 6,
        Portal_EMBAIXADA = 7,
        Portal_DIPLOMATA = 8,
        Portal_ORGANISMOS = 9,
        Cotacao_CORRETORA = 10,
        Cotacao_AGENCIA = 11,
        Cotacao_INTERCAMBIO = 12,
        Cotacao_PJ = 13,
        Cotacao_PF = 14,
        Cotacao_EMBAIXADA = 15,
        Cotacao_DIPLOMATA = 16,
        Cotacao_ORGANISMOS = 17
    }
}
