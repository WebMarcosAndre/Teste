﻿
namespace Rendimento.Portal.CambioOnline.Negocios.Enum
{
   
        public enum EnumSistemaAcesso
        {
            CambioOnline = 0,
            CCME = 1,
            EContrato = 2,
            Hidden = 3,
            CambioOnlinePreCotado = 4
        
    }
}
