﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Net;
using System.Linq;

/// <summary>
/// Summary description for BuscaCep
/// </summary>
public class BuscaCep
{
    private string cep_uf;
    private string cep_cidade;
    private string cep_bairro;
    private string cep_tipo_logradouro;
    private string cep_logradouro;
    private string cep_resultado;
    private string cep_resultato_txt;

    public string UF
    {
        get { return cep_uf; }
    }

    public string Cidade
    {
        get { return cep_cidade; }
    }

    public string Bairro
    {
        get { return cep_bairro; }
    }

    public string TipoLogradouro
    {
        get { return cep_tipo_logradouro; }
    }

    public string Logradouro
    {
        get { return cep_logradouro; }
    }

    public string Resultado
    {
        get { return cep_resultado; }
    }

    public string ResultadoTXT
    {
        get { return cep_resultato_txt; }
    }

    public BuscaCep(string CEP)
    {
        cep_uf = "";
        cep_cidade = "";
        cep_bairro = "";
        cep_tipo_logradouro = "";
        cep_logradouro = "";
        cep_resultado = "0";
        cep_resultato_txt = "CEP não encontrado";
        bool novaBuscaCEp = false;

        string url = string.Empty;
        DataSet ds = new DataSet();

        try
        {
            url = "http://republicavirtual.com.br/web_cep.php?cep=" + CEP.Replace("-", "").Trim() + "&formato=xml";
            //DataSet ds = new DataSet();
            WebRequest wRequest = WebRequest.Create(url);

            int tempoDeEsperaBuscaCep = ConfigurationManager.AppSettings.AllKeys.Contains("tempoDeEsperaBuscaCep") ?
                Convert.ToInt32(ConfigurationManager.AppSettings["tempoDeEsperaBuscaCep"]) : 10;
            wRequest.Timeout = tempoDeEsperaBuscaCep * 1000;

            WebResponse wResponse = wRequest.GetResponse();
            ds.ReadXml(wResponse.GetResponseStream());

            if (ds != null)
            {

                if (ds.Tables[0].Rows.Count > 0)
                {
                    cep_resultado = ds.Tables[0].Rows[0]["resultado"].ToString();
                    switch (cep_resultado)
                    {
                        case "1":
                            cep_uf = ds.Tables[0].Rows[0]["uf"].ToString().Trim();
                            cep_cidade = ds.Tables[0].Rows[0]["cidade"].ToString().Trim();
                            cep_bairro = ds.Tables[0].Rows[0]["bairro"].ToString().Trim();
                            cep_tipo_logradouro = ds.Tables[0].Rows[0]["tipo_logradouro"].ToString().Trim();
                            cep_logradouro = ds.Tables[0].Rows[0]["logradouro"].ToString().Trim();
                            cep_resultato_txt = "CEP completo";
                            break;
                        case "2":
                            cep_uf = ds.Tables[0].Rows[0]["uf"].ToString().Trim();
                            cep_cidade = ds.Tables[0].Rows[0]["cidade"].ToString().Trim();
                            cep_bairro = "";
                            cep_tipo_logradouro = "";
                            cep_logradouro = "";
                            cep_resultato_txt = "CEP único";
                            break;
                        default:
                            cep_uf = "";
                            cep_cidade = "";
                            cep_bairro = "";
                            cep_tipo_logradouro = "";
                            cep_logradouro = "";
                            cep_resultato_txt = "O CEP: " + CEP.Trim().ToString() + " não foi encontrado!";
                            break;
                    }
                }
            }
        }
        catch
        {
            novaBuscaCEp = true;
        }

        if (novaBuscaCEp)
        {
            try
            {
                url = "http://viacep.com.br/ws/" + CEP.Replace("-", "").Trim() + "/xml";

                //DataSet ds = new DataSet();
                WebRequest wRequest = WebRequest.Create(url);

                int tempoDeEsperaBuscaCep = ConfigurationManager.AppSettings.AllKeys.Contains("tempoDeEsperaBuscaCep") ?
                    Convert.ToInt32(ConfigurationManager.AppSettings["tempoDeEsperaBuscaCep"]) : 10;
                wRequest.Timeout = tempoDeEsperaBuscaCep * 1000;

                WebResponse wResponse = wRequest.GetResponse();
                ds.ReadXml(wResponse.GetResponseStream());

                if (ds != null)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {

                        cep_resultado = "1";

                        cep_uf = ds.Tables[0].Rows[0]["uf"].ToString().Trim();
                        cep_cidade = ds.Tables[0].Rows[0]["localidade"].ToString().Trim();
                        cep_bairro = ds.Tables[0].Rows[0]["bairro"].ToString().Trim();
                        cep_tipo_logradouro = "";
                        cep_logradouro = ds.Tables[0].Rows[0]["logradouro"].ToString().Trim();
                        cep_resultato_txt = "CEP completo";
                    }
                }
            }
            catch
            {
                cep_resultado = "0";
                cep_uf = "";
                cep_cidade = "";
                cep_bairro = "";
                cep_tipo_logradouro = "";
                cep_logradouro = "";
                cep_resultato_txt = "Não encontramos este CEP em nossa base, favor informar o endereço completo para prosseguir com o cadastro.";
            }
        }

    }



}
