﻿using System;
using System.Data;
using System.Data.SqlClient;
using Rendimento.Portal.CambioOnline.DAO;
using System.Linq;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class ClienteMensagens
    {
        static private string strConexao = Executar.obterStringConexao("Rendimento.Portal.CambioOnline.Modelos.ModelosCambio.*");
        private int id_cliente;
        private DateTime? Data_Desativada;

        public int int_id_cliente
        {
            get { return id_cliente; }
            set { id_cliente = value; }
        }

        public DateTime? str_Data_Desativada
        {
            get { return Data_Desativada; }
            set { Data_Desativada = value; }
        }

        public DataSet ValidaClienteCadastrado()
        {
            DataSet ds = null;

            try
            {
                SqlParameter[] strParametros = new SqlParameter[01];

                // Cliente
                strParametros[0] = new SqlParameter("@id_Cliente", SqlDbType.Int);
                if (!int_id_cliente.Equals("0"))
                    strParametros[0].Value = Convert.ToInt32(int_id_cliente);
                else
                    strParametros[0].Value = DBNull.Value;


                ds = SqlHelper.ExecuteDataset(strConexao, CommandType.StoredProcedure, "SP_VALIDA_CLIENTE_CADASTRADO", strParametros);


                return ds;
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: Incluir()", "Arquivo: ClienteMensagens.cs");
                return null;
            }
        }

        public bool ValidaExisteCliente()
        {
            try
            {

                SqlParameter[] strParametros = new SqlParameter[1];

                strParametros[0] = new SqlParameter("@id_Cliente", SqlDbType.Int);
                strParametros[0].Value = int_id_cliente;

                SqlHelper.ExecuteNonQuery(strConexao, CommandType.StoredProcedure, "SP_VALIDA_CLIENTE_EXISTE", strParametros);

            }
            catch (Exception ex)
            {
                Funcoes.GravarErro(ex, "Erro: Incluir()", "Arquivo: ClienteMensagens.cs");
                return false;
            }

            return true;
        }

        

        public static DataSet VerificarBoletosPendentes(int id_cliente)
        {
            try
            {
                return OrdemPagamento.ListarAcompanhamentos(DateTime.Now.AddYears(-20), DateTime.Now, "C", 1, id_cliente);
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: VerificarBoletosPendentes()", $@"Arquivo: ClienteMensagens.cs | DataIni : {DateTime.Now.AddYears(-20)} - DataFim: {DateTime.Now} - id_cliente : {id_cliente}");
                return null;
            }
        }
        public static DataSet VerificarBoletosPendentesAcaoCliente(int id_cliente)
        {

            try
            {
                DataSet dsRecebidas = VerificarBoletosPendentes(id_cliente);
                int[] idStatusComLink = new int[] { 10, 20, 30, 40, 50 }; //MESMA REGRA DA TELA DE VendaPreBoleto.aspx
                if (dsRecebidas != null && dsRecebidas.Tables.Count > 0 && dsRecebidas.Tables[0].Rows.Count > 0)
                {
                    DataTable dtRecebidas = dsRecebidas.Tables[0];
                    dtRecebidas = dtRecebidas.AsEnumerable().Where(i =>
                            (!i.Field<bool?>("PRE_FASE_CONCLUIDO").HasValue || !i.Field<bool?>("PRE_FASE_CONCLUIDO").Value)
                            &&
                            (!i.Field<int?>("ID_STATUS").HasValue || idStatusComLink.Contains(i.Field<int?>("ID_STATUS").Value))
                            ).CopyToDataTable();
                    dsRecebidas.Tables.Clear();
                    if (dtRecebidas.Rows.Count > 0)
                        dsRecebidas.Tables.Add(dtRecebidas);
                }
                return dsRecebidas;

            }
            catch (Exception ex)
            {
                Funcoes.GravarErro(ex, "Erro: VerificarBoletosPendentes()", "Arquivo: ClienteMensagens.cs");
                return null;
            }
        }
        public static DataSet VerificarBoletosVendaPendentes(int id_cliente)
        {
            try
            {
                return DAO.Funcoes.ListarAcompanhamento(id_cliente, "A", DateTime.Now.AddYears(-20).ToString("yyyy-MM-dd"), DateTime.Now.ToString("yyyy-MM-dd"));
            }
            catch (Exception ex)
            {
                DAO.Funcoes.GravarErro(ex, "Erro: VerificarBoletosPendentes()", "Arquivo: ClienteMensagens.cs");
            }

            return null;
        }
    }
}
