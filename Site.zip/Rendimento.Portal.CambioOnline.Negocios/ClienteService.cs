﻿using System;
using Rendimento.Portal.CambioOnline.DAO;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;
using Rendimento.Portal.CambioOnline.Negocios.DTO;
using Rendimento.Portal.CambioOnline.Negocios.Enum;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class ClienteService
    {
        ClienteDAO clienteDao = new ClienteDAO();
        public TBL_CLIENTES Get(int id)
        {
            return clienteDao.Get(id);
        }

       
    }
}
