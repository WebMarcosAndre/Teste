﻿using System;
using System.Configuration;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;
using Rendimento.Portal.CambioOnline.Negocios.Enum;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class AcessarSistema
    {
        private static int empresa = Convert.ToInt32(ConfigurationManager.AppSettings.Get("EMPRESA"));
        public static int PermitirAcessar(int sistemaId, out string mensagem)
        {
            mensagem = string.Empty;
            Cbp cbp = new Cbp();
            StatusSistema statusSistema = cbp.StatusSistema(sistemaId);

            switch ((EnumStatusDoSistema)statusSistema.id)
            {
                case EnumStatusDoSistema.Desativado:
                    mensagem = "Site fora do ar";
                    break;
                case EnumStatusDoSistema.Inativo:
                    //Retorno.GetParamEmpresas("EMPRESA", Empresa) Retornar o nome da empresa parametrizada na base
                    string sistemaDescr = string.Empty;

                    if (
                            (EnumSistemaCBP)sistemaId == EnumSistemaCBP.PortalCambioCotacao
                            || (EnumSistemaCBP)sistemaId == EnumSistemaCBP.PortalCambioRendimento
                        )
                        sistemaDescr = "Portal de Câmbio";
                    else if (
                           (EnumSistemaCBP)sistemaId == EnumSistemaCBP.CambioOnLineCotacao
                           || (EnumSistemaCBP)sistemaId == EnumSistemaCBP.CambioOnLineRendimento
                       )
                        sistemaDescr = "Câmbio Online";

                    //mensagem = $"O {sistemaDescr} está em manutenção. Tente novamente em alguns instantes.";
                    mensagem = $"Sistema em manutenção. Tente novamente em alguns instantes.";

                    break;
                case EnumStatusDoSistema.AtivoeFechadoParaOperacoes:
                    mensagem = "Acessar em horário comercial";
                    break;
            }

            return statusSistema.id;

        }        
    }
}
