﻿using System;
using System.Configuration;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class Cbp
    {
        HttpClient client = new HttpClient();

        #region Consumir Tarifa
        public CbpModel Tarifa(string tipoPessoa, int sistemaId, decimal valorOperacao, string nomePais, string codigoMoedaRemessa,int clienteId,string tipoOperacao, string formaEntrega )
        {
            var tarifa = new CbpModel();
            try
            {
                string endereco = ConfigurationManager.AppSettings.Get("KeyCbp") + "Tarifa/BuscarMenorTarifa";
                endereco = AjustarEnderecoTarifa(endereco, tipoPessoa, sistemaId, valorOperacao, nomePais, codigoMoedaRemessa, clienteId,tipoOperacao,formaEntrega);
                client.DefaultRequestHeaders.Add("Token", ConfigurationManager.AppSettings.Get("KeyCbpToken"));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                Task<string> response = client.GetStringAsync(new Uri(endereco));
                //if(response.)
                tarifa = JsonConvert.DeserializeObject<CbpModel>(response.Result);
                
            }
            catch (Exception ex)
            {
                Retorno.GravarErro(ex, "Cbp.cs", $"Tarifa() - valorOperacao: {valorOperacao}, nomePais{nomePais}, codigoMoedaRemessa{codigoMoedaRemessa}");
                throw ex;
            }
            return tarifa;
        }

        public static string AjustarEnderecoTarifa(string endereco, string tipoPessoa, int sistemaId, decimal valorOperacao, string nomePais, string codigoMoedaRemessa, int clienteId,string tipoOperacao, string formaEntrega)
        {
            string uri = $@"{endereco}?tipoPessoa={tipoPessoa}&sistemaId={sistemaId}&valorOperacao={valorOperacao.ToString().Replace(",", ".")}&nomePais={nomePais}&codigoMoedaRemessa={codigoMoedaRemessa}&clienteID={clienteId}&tipoOp={tipoOperacao}&formaEntrega={formaEntrega}";
            return uri;
        }
        #endregion

        #region Status Horário
        public StatusSistema StatusSistema(int id)
        {
            var status = new StatusSistema();
            try
            {               
                string endereco = ConfigurationManager.AppSettings.Get("KeyCbp");
                endereco = AjustarEnderecoStatus(endereco + "Sistema/StatusSistema", id);
                client.DefaultRequestHeaders.Add("Token", ConfigurationManager.AppSettings.Get("KeyCbpToken"));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                Task<string> response = client.GetStringAsync(new Uri(endereco));
                status = ConverteJSonParaObject<StatusSistema>(response.Result);

            }
            catch (Exception ex)
            {
                Retorno.GravarErro(ex, "Cbp.cs", $"StatusSistema() - Id: {id}");
                //throw ex;
            }
            return status;
        }

        public static T ConverteJSonParaObject<T>(string jsonString)
        {
            try
            {
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(T));
                MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(jsonString));
                T obj = (T)serializer.ReadObject(ms);
                return obj;
            }
            catch (Exception ex)
            {
                Retorno.GravarErro(ex, "Cbp.cs", $"ConverteJSonParaObject() - jsonString: {jsonString}");
                throw ex;
                //return default(T);
            }

        }
        public static string AjustarEnderecoStatus(string endereco, int id)
        {
            string uri = ($"{endereco}?id={id}");
            return uri;
        }
        #endregion


        #region Over
        public ParametroRemessa BuscarOver(int id, int empresa, string remessa, DateTime horario, string tipoPessoa)
        {
            var parametro = new ParametroRemessa();
            try
            {
                string endereco = ConfigurationManager.AppSettings.Get("KeyCbp");
                endereco = AjustarEnderecoOver(endereco + "Sistema/Buscar", id, empresa, remessa, horario, tipoPessoa);
                client.DefaultRequestHeaders.Add("Token", ConfigurationManager.AppSettings.Get("KeyCbpToken"));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                Task<string> response = client.GetStringAsync(new Uri(endereco));
                parametro = ConverteJSonParaObject<ParametroRemessa>(response.Result);
            }
            catch (Exception ex)
            {
                Retorno.GravarErro(ex, "Cbp.cs", $"ParametroRemessa() - id: {id}, empresa{empresa}, remessa{remessa}, horario{horario}");
                throw ex;
            }
            return parametro;
        }

        public static string AjustarEnderecoOver(string endereco, int id, int empresa, string remessa, DateTime horario, string tipoPessoa)
        {
            string uri = ($"{endereco}?id={id}&empresa={empresa}&remessa={remessa}&horario={horario.ToString("yyyy-MM-dd HH:mm:ss")}&tipoPessoa={tipoPessoa}");
            //string uri = ($"{endereco}?id={id}&empresa={empresa}&remessa={remessa}&horario={horario}&tipoPessoa={tipoPessoa}");
            return uri;
        }


        #endregion

    }
}