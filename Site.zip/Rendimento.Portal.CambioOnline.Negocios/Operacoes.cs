﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class Operacoes
    {
        public static Int64 Inserir(object obj)
        {
            return DAO.Executar.Inserir(obj);
        }

        public static Int64 Inserir(object obj, Transacao objTrans)
        {
            return DAO.Executar.Inserir(obj, objTrans);
        }

        public static ArrayList Obter(object obj, string condicao)
        {
            return DAO.Executar.Obter(obj, condicao);
        }

        public static ArrayList Obter(object obj, string condicao, Transacao objTrans)
        {
            return DAO.Executar.Obter(obj, condicao, objTrans);
        }

        public static int Excluir(object obj, string condicao)
        {
            return DAO.Executar.Excluir(obj, condicao);
        }

        public static int Excluir(object obj, string condicao, Transacao objTrans)
        {
            return DAO.Executar.Excluir(obj, condicao, objTrans);
        }

        public static Int64 InserirRetornaMaxId(Object obj)
        {
            return DAO.Executar.InserirRetornaMaxId(obj, "");
        }

        public static DataTable ObterDataTable(Object obj, string strCondicao, string strOrdem, Transacao objTrans)
        {
            return DAO.Executar.ObterDataTable(obj, strCondicao, strOrdem, objTrans);
        }

        public static Int64 Atualizar(Object obj, string condicao, string[] arrCampos, Transacao objTrans)
        {
            return DAO.Executar.Atualizar(obj, condicao, arrCampos, objTrans);
        }

    }
}
