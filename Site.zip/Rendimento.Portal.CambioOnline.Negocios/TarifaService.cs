﻿using Rendimento.Portal.CambioOnline.DAO;
using System.Data;


namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class TarifaService
    {
        public static decimal GetValueSpread(string li_doc, string moe_simbolo, decimal valor, string tipo_op, string tipo_entrega)
        {
            /*
               LI_DOC = "00001510177",
                MOE_SIMBOLO = "USD",
                VALOR = "10000",
                TIPO_OP = "C",
                TIPO_ENTREGA = "TELE"
              
             */

            var retorno = CommonDAO.Get(@"SPCOL_Box_Cotacao_Especifica", new
            {
                LI_DOC = li_doc,
                MOE_SIMBOLO = moe_simbolo,
                VALOR = valor,
                TIPO_OP = tipo_op,
                TIPO_ENTREGA = tipo_entrega
            }, CommandType.StoredProcedure);

            if (retorno.VALORSPREAD == null /*|| !decimal.TryParse(retorno.VALORSPREAD, out decimal retornoDecimal)*/)
                return 0;
            return retorno.VALORSPREAD;

        }

    }
}
