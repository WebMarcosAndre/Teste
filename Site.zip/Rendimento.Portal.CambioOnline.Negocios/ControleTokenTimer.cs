﻿using Rendimento.Portal.CambioOnline.DAO;
using Rendimento.Portal.CambioOnline.Modelos;
using Rendimento.Portal.CambioOnline.Negocios.Enum;

namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class ControleTokenTimer
    {
        private ControleTokenTimerDAO controleTokenTimerDAO = new ControleTokenTimerDAO();
        public TokenTimerConfig GetTokenTimerConfig(EnumTokenTimer enumTokenTimer)
        {
            return controleTokenTimerDAO.Get((int)enumTokenTimer);
        }

        public void CreateTokenTimer(TokenTimer tokenTimer)
        {            
            controleTokenTimerDAO.Insert(tokenTimer);
        }
        public void SetTokenAsUsed(TokenTimer tokenTimer)
        {
            tokenTimer.Utilizado = true;
            controleTokenTimerDAO.SetTokenAsUsed(tokenTimer);
        }

        public EnumTokenTimer SetEnumTokenConfig(EnumTipoCliente tipoCliente, bool sistemaOrigemCotacao)
        {
            EnumTokenTimer retorno = EnumTokenTimer.DEFAULT;
            switch (tipoCliente)
            {
                case EnumTipoCliente.CORRETORA:
                    retorno = sistemaOrigemCotacao ? EnumTokenTimer.Cotacao_CORRETORA : EnumTokenTimer.Portal_CORRETORA;
                    break;
                case EnumTipoCliente.AGENCIA:
                    retorno = sistemaOrigemCotacao ? EnumTokenTimer.Cotacao_AGENCIA : EnumTokenTimer.Portal_AGENCIA;
                    break;
                case EnumTipoCliente.INTERCAMBIO:
                    retorno = sistemaOrigemCotacao ? EnumTokenTimer.Cotacao_INTERCAMBIO : EnumTokenTimer.Portal_INTERCAMBIO;
                    break;
                case EnumTipoCliente.PJ:
                    retorno = sistemaOrigemCotacao ? EnumTokenTimer.Cotacao_PJ : EnumTokenTimer.Portal_PJ;
                    break;
                case EnumTipoCliente.PF:
                    retorno = sistemaOrigemCotacao ? EnumTokenTimer.Cotacao_PF : EnumTokenTimer.Portal_PF;
                    break;
                case EnumTipoCliente.EMBAIXADA:
                    retorno = sistemaOrigemCotacao ? EnumTokenTimer.Cotacao_EMBAIXADA : EnumTokenTimer.Portal_EMBAIXADA;
                    break;
                case EnumTipoCliente.DIPLOMATA:
                    retorno = sistemaOrigemCotacao ? EnumTokenTimer.Cotacao_DIPLOMATA : EnumTokenTimer.Portal_DIPLOMATA;
                    break;
                case EnumTipoCliente.ORGANISMOS:
                    retorno = sistemaOrigemCotacao ? EnumTokenTimer.Cotacao_ORGANISMOS : EnumTokenTimer.Portal_ORGANISMOS;
                    break;
            }
            return retorno;
        }

    }
}
