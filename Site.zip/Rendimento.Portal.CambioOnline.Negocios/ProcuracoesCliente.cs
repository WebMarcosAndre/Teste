﻿
using System;
using System.Data;
using System.Data.SqlClient;
using Rendimento.Portal.CambioOnline.DAO;
using Rendimento.Portal.CambioOnline.Negocios.Enum;


namespace Rendimento.Portal.CambioOnline.Negocios
{
    public class ProcuracoesCliente
    {
        public static string BuscarModeloProcuracao(int idcliente)
        {
            var tabelaModeloProcuracao = ProcuracoesClienteDAO.BuscarModeloProcuracao(idcliente);

            if (tabelaModeloProcuracao != null && tabelaModeloProcuracao.Rows.Count > 0)
                return tabelaModeloProcuracao.Rows[0]["TXT_MODELO"].ToString();
            return null;
        }
        public static int CancelarProcuracaoPorId(int idprocuracao)
        {
            return ProcuracoesClienteDAO.AtualizaStatusProcuracaoPorId(idprocuracao, (int)EnumStatusProcuracao.Cancelado);
        }
        public static int? IncluirProcuracaoDigital(int idCliente, int idUpload, string ip)
        {
            ProcuracoesClienteDAO.DesativarProcuracoesDigitais(idCliente, "D");

            return ProcuracoesClienteDAO.IncluirProcuracao(idCliente, idUpload, ip, "D", (int)EnumStatusProcuracao.EmValidacao, null);
        }

        public static int? IncluirProcuracaoEletronica(int idCliente, int idUpload, string ip, string hash)
        {
            ProcuracoesClienteDAO.DesativarProcuracoesDigitais(idCliente, "A");

            return ProcuracoesClienteDAO.IncluirProcuracao(idCliente, idUpload, ip, "A", (int)EnumStatusProcuracao.Aprovado, hash);
        }

        public static bool AtualizarProcuracaoDigital(int idProcuracao, int idCliente, int idupload, string ip)
        {
            var linhas = ProcuracoesClienteDAO.AtualizaProcuracaoDigital(idProcuracao, idCliente, idupload, ip, (int)EnumStatusProcuracao.EmValidacao);

            if (linhas > 0)
                return true;
            return false;
        }

        public static DateTime? BuscarDataExpiracaoLinkProcuracaoDigitalAtiva(int idprocuracao, int idcliente)
        {
            var tabela = ProcuracoesClienteDAO.BuscarProcuracoesAtivas(idprocuracao, idcliente, "D", null);

            if (tabela != null && tabela.Rows.Count > 0)
            {

                if (System.Enum.TryParse(tabela.Rows[0]["STATUS"].ToString(), out EnumStatusProcuracao status))
                {
                    if (EnumStatusProcuracao.Cancelado != status)
                    {
                        if (DateTime.TryParse(tabela.Rows[0]["DT_EXPIRA_LINK"].ToString(), out DateTime dataexpiracao))
                        {
                            return dataexpiracao;
                        }
                    }
                }
            }
            
            return null;
        }

        public static bool ExisteProcuracaoDigitalVigente(int idcliente, out EnumStatusProcuracao statusAtual)
        {
            statusAtual = EnumStatusProcuracao.Inexistente;

            var dt = ProcuracaoDigitalVigenteStatus(idcliente);

            if (dt != null && dt.Rows.Count > 0 && dt.Rows[0]["STATUS"] != DBNull.Value)
            {
                if (System.Enum.TryParse(dt.Rows[0]["STATUS"].ToString(), out EnumStatusProcuracao status))
                {
                    statusAtual = status;

                    if (EnumStatusProcuracao.Cancelado != status && EnumStatusProcuracao.AguardandoUpload != status)
                        return true;
                }
            }

            return false;
        }

        public static DataTable ProcuracaoDigitalVigenteStatus(int idcliente)
        {
            return ProcuracoesClienteDAO.BuscarProcuracoesAtivas(null, idcliente, "D", null);
        }

        public static DataTable ProcuracaoEletronicaStatusAtiva(int idcliente)
        {
            return ProcuracoesClienteDAO.BuscarProcuracoesAtivas(null, idcliente, "A", (int)EnumStatusProcuracao.Aprovado);
        }

        public static string BuscarTipoProcuracaoAtiva(int idcliente)
        {
            var dt = ProcuracoesClienteDAO.BuscarProcuracoesAtivas(null, idcliente, null, (int)EnumStatusProcuracao.Aprovado);

            if (dt != null && dt.Rows[0]["TIPO_PROCURACAO"] != DBNull.Value)
                return dt.Rows[0]["TIPO_PROCURACAO"].ToString().Trim();

            return null;
        }

        public static string BuscarTipoProcuracaoAtiva(int idcliente, SqlTransaction transacao)
        {
            var dt = ProcuracoesClienteDAO.BuscarProcuracoesAtivas(null, idcliente, null, (int)EnumStatusProcuracao.Aprovado, transacao);

            if (dt != null && dt.Rows[0]["TIPO_PROCURACAO"] != DBNull.Value)
                return dt.Rows[0]["TIPO_PROCURACAO"].ToString().Trim();

            return null;
        }
        public static int GravarLogCRM(int idcliente, int? idusuario, int? idcorretora, string ocorrencia, int? numeroboleto, string passaporte, string campos, int? idfilial, int? idoperacao)
        {
            return ProcuracoesClienteDAO.GravarLogCRM(idcliente, idusuario, idcorretora, ocorrencia, numeroboleto, passaporte, campos, idfilial, idoperacao);
        }
    }
}
