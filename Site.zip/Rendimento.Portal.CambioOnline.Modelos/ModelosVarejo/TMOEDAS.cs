﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosVarejo
{
    public class TMOEDAS : BaseModelo
    {
        public string cod_moeda;
        public decimal tx_banco;
        public decimal tx_venda;
        public decimal tx_compra;
        public decimal paridade;
        public string Codigo_Moeda;

        public TMOEDAS()
        {
        }
    }
}
