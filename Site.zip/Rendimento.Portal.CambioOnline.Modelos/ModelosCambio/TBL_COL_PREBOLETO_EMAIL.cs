﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_COL_PREBOLETO_EMAIL : BaseModelo
    {
        public TBL_COL_PREBOLETO_EMAIL()
        {
            this.autoId = true;
            this.nomeIdentificador = "ID";
        }

        public int ID;
        public int ID_CLIENTE;
        public string NOME;
        public string EMAIL;
        public DateTime DATA;
        public bool EMAIL_INATIVO;
    }
}
