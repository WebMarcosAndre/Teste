﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_MOEDA : BaseModelo
    {
        public int id_moedas;
        public string moe_simbolo;
        public int moe_codigo;
        public string moe_nome;
        public string moe_cambio_online;

        public TBL_MOEDA()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_moedas";
        }
    }
}
