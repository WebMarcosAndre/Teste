﻿using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_MEWEB_CONTAS_CADASTRADAS : BaseModelo
    {
        public int id_cliente { get; set; }
        public int id_conta { get; set; }
        public string MT_SWIFT { get; set; }
        public string C50K_NOME { get; set; }
        public string C50K_NUM_DOC { get; set; }
        public string C50K_ENDERECO { get; set; }
        public string C50K_BAIRRO { get; set; }
        public string C50K_CIDADE { get; set; }
        public string C50K_ESTADO { get; set; }
        public string C50K_CEP { get; set; }
        public string C50K_COD_BANCO { get; set; }
        public string C50K_AGENCIA { get; set; }
        public string C50K_CONTA_CORRENTE { get; set; }
        public string C59_NUM_CONTA { get; set; }
        public string C59_NOME { get; set; }
        public string C59_ENDERECO { get; set; }
        public string C59_PAIS { get; set; }
        public string TIPO_IDENTIFICACAO { get; set; }
        public string C57_SWIFT_CODE { get; set; }
        public string C57_ABA { get; set; }
        public string C57_CONTA { get; set; }
        public string C57_NOME { get; set; }
        public string C57_ENDERECO { get; set; }
        public string TIPO_IDENT_CORRESP { get; set; }
        public string C56_SWIFT_CODE { get; set; }
        public string C56_ABA { get; set; }
        public string C56_CONTA { get; set; }
        public string C56_NOME { get; set; }
        public string C56_ENDERECO { get; set; }
        public string C56_CONTA_RECEBEDOR { get; set; }        

    }
}



