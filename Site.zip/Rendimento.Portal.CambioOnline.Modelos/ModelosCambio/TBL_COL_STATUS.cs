﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_COL_STATUS : BaseModelo
    {
        public int ID_STATUS;
        public string STATUS;

        public TBL_COL_STATUS() { }
    }
}
