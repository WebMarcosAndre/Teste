﻿using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_EMPRESAS : BaseModelo
    {
        public TBL_EMPRESAS()
        {
        }

        public int ID_SEFIC_EMPRESA;
        public string Empresa;
        public string Razao_Social;
        public string Endereco;
        public string Telefone1;
        public string Telefone2;
        public string Telefone3;
        public string Departamento;
        public string OuvidoriaEmail;
        public string OuvidoriaTelefone;
        public string Link_Portal_Redirect;
    }
}
