﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_NATUREZA : BaseModelo
    {
        public int id_natureza;
        public string nat_codigo;
        public string nat_descricao;
        public string nat_obs;
        public decimal nat_val_contrato;
        public string nat_status;
        public decimal portal_valor;
        public string portal_titulo;
        public string portal_roteiro;
        public string portal_documentos;
        public string portal_documentos_ccme;
        public string IOF_Isento;
        public string IOF_ISENTO_COMPRA;
        public string IOF_ISENTO_VENDA;
        public decimal nat_taxa_iof_compra;
        public decimal nat_taxa_iof_venda;
        public string portal_cod_comprador;
        public string portal_cod_pagador;
        public string tipo_nat;
        public string nat_InformacaoAdicionalIOF;
        public bool nat_obriga_doc;
        public string portal_natureza_sobre_compra;
        public string portal_titulo_compra;
        public string portal_natureza_sobre;
        public string portal_documentos_compra;
        public string portal_roteiro_compra;
        public bool nat_obriga_bol_assinado;
        



        public TBL_NATUREZA()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_natureza";
        }
    }
}
