﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_CPFS : BaseModelo
    {
        public string cpf_num;
        public string cpf_status;
        public string cpf_st_receita;
        public string cl_passaporte;

        public TBL_CPFS()
        {
        }
    }
}
