﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_LOG_RECEITA : BaseModelo
    {
        public int id_log;
        public string log_cpf;
        public string log_status;
        public string log_nome;
        public int log_us;
        public int log_corretora;
        public DateTime log_data;

        public TBL_LOG_RECEITA()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_log";
        }
    }
}

