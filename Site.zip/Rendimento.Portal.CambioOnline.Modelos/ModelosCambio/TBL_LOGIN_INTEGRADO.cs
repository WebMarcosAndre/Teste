﻿using System;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_LOGIN_INTEGRADO : BaseModelo
    {
        public int li_id;
        public string li_doc;
        public string li_senha;
        public string li_nome;

        public string li_status;
        public int li_erros;
        public DateTime li_dtinclusao;
        public DateTime li_dtalteracao;
        public int li_sistema;
        public int li_alterarsenha;
        public string li_pesquisa;
        public decimal li_valor_max_ap;
        public decimal li_valor_max_op;
        public DateTime li_validade;
        public string li_opera_vol;
        public string li_tipo;
        public string li_email;
        public int li_acesso;
        public string li_corretora;
        public string li_primeiro_acesso;
        public string li_acesso_ccmeweb;
        public string li_acesso_cambioonline;
        public string li_acesso_econtratos;
        public string li_termo_assinado;
        public string li_termo_ass_eletr;
        public DateTime li_data_ass_termo;
        public DateTime li_data_envio_senha;
        public DateTime li_data_primeiro_acesso;
        public DateTime li_data_ultimo_acesso;
        public int li_idcliente;
        public string li_tipocliente;
        public string li_cpf;
        public string li_cpf_responsavel;
        public string FLAG_HABILITA_CAMBIO_COTACAO;
        public bool LI_HABILITA_INTEGRACAO;

        public TBL_LOGIN_INTEGRADO()
        {
            this.autoId = true;
            this.nomeIdentificador = "li_id";
        }
    }
}
