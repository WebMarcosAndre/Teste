﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_CLI_BANCO_COMERCIO : BaseModelo
    {
        public int id_bc;
        public Int64 id_cliente;
        public string bc_tel_banco;
        public string bc_contato_banco;

        public string bc_banco;
        public string bc_cod_banco;
        public string bc_tipo_conta;
        public string bc_agencia;
        public string bc_conta;
        public DateTime bc_data_abertura;

        public string bc_banco2;
        public string bc_cod_banco2;
        public string bc_tipo_conta2;
        public string bc_agencia2;
        public string bc_conta2;
        public DateTime bc_data_abertura2;

        public string bc_banco3;
        public string bc_cod_banco3;
        public string bc_tipo_conta3;
        public string bc_agencia3;
        public string bc_conta3;
        public DateTime bc_data_abertura3;

        public TBL_CLI_BANCO_COMERCIO()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_bc";
        }

    }
}
