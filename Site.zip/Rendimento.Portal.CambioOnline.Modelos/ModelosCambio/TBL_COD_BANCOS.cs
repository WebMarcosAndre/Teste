﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_COD_BANCOS : BaseModelo
    {
        public string cod_banco;
        public string nome_banco;
        public string abrev_banco;

        public TBL_COD_BANCOS()
        {
        }

    }
}
