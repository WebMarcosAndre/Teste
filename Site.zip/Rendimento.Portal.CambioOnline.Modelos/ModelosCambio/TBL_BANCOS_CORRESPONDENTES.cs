﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_BANCOS_CORRESPONDENTES : BaseModelo
    {
        public string bco_codigo;
        public string bco_nome;
        public string bco_nome_usual;

        public TBL_BANCOS_CORRESPONDENTES()
        {
        }

    }
}
