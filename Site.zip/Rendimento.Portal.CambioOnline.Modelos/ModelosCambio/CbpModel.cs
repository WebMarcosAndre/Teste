﻿using System;
using System.Collections.Generic;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class CbpModel
    {
        public string codigoMoeda { get; set; }
        public decimal valorTarifa { get; set; }
        public string codigoTipoTarifa { get; set; }
        public Tarifa tarifa { get; set; }

        public decimal valorCustoTarifa { get; set; }
        public decimal valorCustoTarifaDolar { get; set; }
    }

    public class Empresa
    {
        public string codigoEmpresa { get; set; }
    }

    public class Tarifa
    {
        public Empresa empresa { get; set; }     

    }

    public class Sistema
    {
        public string nomeSistema { get; set; }
        public string urlSistema { get; set; }
        public int statusSistema { get; set; }
    }

    public class StatusSistema
    {
        public StatusSistema()
        {
            Sistema = new HashSet<Sistema>();
        }
        public string nomeStatusSistema { get; set; }
        public int id { get; set; }
        public string codigoStatusSistema { get; set; }
        public ICollection<Sistema> Sistema { get; set; }
    }

    public class ParametroRemessa
    {
        public int id { get; set; }
        public int sistemaId { get; set; }
        public int tipoPeriodoId { get; set; }
        public string horaInicioPeriodo { get; set; }
        public string horaFimPeriodo { get; set; }
        public decimal? valorOverSpread { get; set; }
        public int numeroOperacaoCliente { get; set; }        
        public decimal? valorLimitePeriodo { get; set; }
        public decimal? valorLimiteOperacao { get; set; }
        public int empresaGrupoId { get; set; }
        public string codigoTipoRemessa { get; set; }
    }
}
