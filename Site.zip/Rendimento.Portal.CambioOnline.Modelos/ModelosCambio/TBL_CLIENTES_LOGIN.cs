﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public sealed class TBL_CLIENTES_LOGIN : BaseModelo
    {
        public Int32 id_cliente { get; set; }
        public String cl_nome { get; set; }
        public String cl_num_doc { get; set; }
        public String cl_razao_social { get; set; }
        public String cl_tipo { get; set; }
        public String cl_tip_doc { get; set; }
        public String cl_bairro { get; set; }
        public String cl_cod_vendendor { get; set; }
        public Int32 li_id { get; set; }
        public String li_doc { get; set; }
        public String li_nome { get; set; }
        public Int32 li_sistema { get; set; }
        public String li_tipo { get; set; }
        public String li_acesso { get; set; }
        public String li_corretora { get; set; }
        public String li_tipocliente { get; set; }
        public String li_email { get; set; }
        public Int32 li_idcliente { get; set; }
        public String li_acesso_ccmeweb { get; set; }
        public String li_acesso_econtratos { get; set; }
        public String flg_assina_digitalmente { get; set; }
        public Int32 li_habilita_op_col { get; set; }
        public bool ir_saida { get; set; }
    }
}
