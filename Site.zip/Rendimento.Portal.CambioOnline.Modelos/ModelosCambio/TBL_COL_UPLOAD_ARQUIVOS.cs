﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_COL_UPLOAD_ARQUIVOS : BaseModelo
    {
        public int ID_UPLOAD;
        public string NR_DOCTO;
        public string NOME_ARQUIVO;
        public DateTime DATA_UPLOAD;
        public int STATUS;
        public int Tamanho;
        public int id_sistema;
        public int ID_TIPO_ARQUIVO;
        public string TIPO_OPERACAO;
        public string COMENTARIOS;

        public TBL_COL_UPLOAD_ARQUIVOS()
        {
        }
    }
}
