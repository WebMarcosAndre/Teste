﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_TARIFAS_PADRAO : BaseModelo
    {
        public int id_tp;
        public string tp_tipo;
        public string tp_operacao;
        public string tp_moeda;
        public decimal tp_val_tarifa;
        public decimal tp_val_minimo;
        public decimal tp_val_maximo;

        public TBL_TARIFAS_PADRAO()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_tp";
        }
    }
}
