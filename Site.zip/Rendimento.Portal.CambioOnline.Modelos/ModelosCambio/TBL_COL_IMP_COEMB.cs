﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_COL_IMP_COEMB : BaseModelo
    {
        public int id_operacao;
        public int op_n_boleto;
        public string op_num_coembarque;

        public TBL_COL_IMP_COEMB()
        {
        }
    }
}
