﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_REGRAS_TARIFAS_CLI : BaseModelo
    {
        public int id_rc;
        public int id_cliente;
        public string rc_tipo;
        public string rc_operacao;
        public string rc_moeda;
        public decimal rc_val_minimo;
        public decimal rc_val_maximo;
        public decimal rc_val_tarifa;

        public TBL_REGRAS_TARIFAS_CLI()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_rc";
        }
    }
}
