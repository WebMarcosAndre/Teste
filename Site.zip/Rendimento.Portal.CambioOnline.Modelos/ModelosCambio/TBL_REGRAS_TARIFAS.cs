﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_REGRAS_TARIFAS : BaseModelo
    {
        public int id_rt;
        public string rt_tipo;
        public string rt_operacao;
        public string rt_moeda;
        public decimal rt_val_tarifa;

        public TBL_REGRAS_TARIFAS()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_rt";
        }
    }
}
