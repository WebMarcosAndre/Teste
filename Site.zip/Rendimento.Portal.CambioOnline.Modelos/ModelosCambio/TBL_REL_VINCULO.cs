﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_REL_VINCULO : BaseModelo
    {
        public int ID_Vinculo;
        public string Descricao;

        public TBL_REL_VINCULO()
        {
        }
    }
}

