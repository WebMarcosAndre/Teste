﻿using System;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_LOGIN_INTEGRADO_TIPOCLIENTE
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public DateTime DataCriacao { get; set; }
        public int ValutaEnvioME { get; set; }
        public int ValutaEnvioMN { get; set; }
        public int ValutaRecebimentoME { get; set; }
        public int ValutaRecebimentoMN { get; set; }
    }
}
