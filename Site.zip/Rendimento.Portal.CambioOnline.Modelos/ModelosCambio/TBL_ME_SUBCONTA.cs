﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_ME_SUBCONTA : BaseModelo
    {
        public int id_sub_conta;
        public int id_cliente;
        public string cod_moeda;
        public string sub_status;

        public TBL_ME_SUBCONTA()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_sub_conta";
        }
    }
}
