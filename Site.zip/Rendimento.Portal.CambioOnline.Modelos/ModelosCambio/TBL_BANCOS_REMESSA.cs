﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_BANCOS_REMESSA : BaseModelo
    {
        public int id;
        public string Uid;
        public string Nome;
        public string Swift_Code;
        public int Pais;
        public string Endereco;
        public string Status;
        public string Tipo;

        public TBL_BANCOS_REMESSA()
        {
        }

    }
}
