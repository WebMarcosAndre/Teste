﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_COL_STATUS_PRE_BOLETO : BaseModelo
    {
        public int id_status_pre_boleto;
        public int id_status;
        public int op_n_boleto;
        public DateTime data_hora;

        public TBL_COL_STATUS_PRE_BOLETO()
        {
            autoId = true;
            nomeIdentificador = "id_status_pre_boleto";
        }
    }
}
