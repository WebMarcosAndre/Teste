﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_PAISES : BaseModelo
    {
        public string Codigo;
        public string Pais;
        public string Codigo_ISO;

        public TBL_PAISES()
        {
        }
    }
}
