﻿using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;
using System;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_PROCURACAO_CLIENTE : BaseModelo
    {
        public int ID;
        public int ID_CLIENTE;
        public int ID_ARQUIVO_UPLOAD;
        public int ID_USUARIO_APROVACAO;
        public string TIPO_PROCURACAO;
        public string STATUS;
        //public string STATUS_PROCURACAO_DIGITALIZADA;
        public string IP_ACEITE_PROCURACAO;
        public string HASH_PROCURACAO;
        public DateTime DT_ATIVACAO;
        public DateTime DT_APROVAVACAO;
        public DateTime DT_REVOGACAO;
        public DateTime DT_INCLUSAO;
        public DateTime DT_EXPIRA_LINK;
    }
}
