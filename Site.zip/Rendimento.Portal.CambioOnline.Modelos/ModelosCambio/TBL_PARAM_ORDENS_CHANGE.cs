﻿using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_PARAM_ORDENS_CHANGE : BaseModelo
    {
        public TBL_PARAM_ORDENS_CHANGE()
        {
            this.autoId = true;
            this.nomeIdentificador = "ID_param";
        }

        public int ID_param;
        public decimal valor_param;
        public int natureza_param1;
        public int natureza_param2;
        public int IdNatureza;
        public int IdVinculo;
        public string CodVendedor;
        public int RRMCCIid;
        public string CodPagador;
        public string TipoPessoa;
        public string IOFIsentoCompra;
        public decimal TaxaIOFCompra;
    }
}
