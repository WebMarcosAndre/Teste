﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_CONFIGURACOES : BaseModelo
    {
        public int id_config;
        public string config_tipo;
        public decimal config_valor;
        public string config_op;

        public TBL_CONFIGURACOES()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_config";
        }
    }
}
