﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_CLI_EMPRESAS : BaseModelo
    {
        public int id_empresa;
        public Int64 id_cliente;
        public string em_nome;
        public string em_complemento;
        public string em_cargo;
        public string em_bairro;
        public string em_cep;
        public string em_cidade;
        public string em_endereco;
        public string em_pais;

        public TBL_CLI_EMPRESAS()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_empresa";
        }
    }
}
