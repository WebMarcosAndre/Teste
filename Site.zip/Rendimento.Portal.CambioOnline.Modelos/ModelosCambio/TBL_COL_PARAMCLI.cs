﻿using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_COL_PARAMCLI : BaseModelo
    {
        public string LI_DOC;
        public string param_status_col;
        public string param_nivel_complice;
        public string param_autoriza_nivel_complice;
        public string param_proc_eletronica;
        public string param_spread_especial;
        public string param_grupo_spread;
        public decimal param_taxa_spread;
        public decimal param_limite_operacao;
        public string param_operacao_compra;
        public string param_operacao_venda;
        public string param_msg_especifica;
        public string PARAM_EMAIL_AUTOMATICO;
        public int PARAM_DIASLIQ_VENDAS;
        public int PARAM_DIASLIQ_VENDASME;
        public int PARAM_DIASLIQ_COMPRAS;
        public int PARAM_DIASLIQ_COMPRASME;
        public bool PARAM_DIASLIQ_COMPRA_MN_STATUS;
        public bool PARAM_DIASLIQ_COMPRA_ME_STATUS;
        public bool PARAM_DIASLIQ_VENDA_MN_STATUS;
        public bool PARAM_DIASLIQ_VENDA_ME_STATUS;
    }
}
