﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_CLIENTES : BaseModelo
    {
        public TBL_CLIENTES()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_cliente";
        }

        public int id_cliente;
        public int id_corretora;
        public int id_assessor;
        public int id_apresentante;
        public string cl_nome;
        public string cl_sobrenome;
        public string cl_num_doc;
        public string cl_tip_doc;
        public string cl_razao_social;
        public string cl_nome_fantasia;
        public string cl_insc_estadual;
        public string cl_insc_municipal;
        public string cl_contato;
        public string cl_nome_grupo;
        public string cl_empresa_sucede;
        public DateTime cl_dt_sucessao;
        public string cl_filiais;
        public string cl_sistema_origem;
        public string CL_STATUS_CADASTRO;
        public string cl_status;
        public string CL_COD_VENDEDOR;
        public string CL_COD_PAGADOR;
        public string flg_assina_digitalmente;
        public DateTime doc_recebido;
        public DateTime doc_vencimento;

        // pessoa fisica
        public string cl_tel_res;
        public DateTime cl_dt_nasc;
        public string cl_tel_com;
        public string cl_local_nasc;
        public string cl_celular;
        public string cl_nacionalidade;
        public string nome_pai;
        public string nome_mae;
        public string cl_estado_civil;
        public string cl_rg;
        public string cl_orgao_exp;
        public string cl_profissao;
        public string cl_residente;
        public string cl_passaporte;
        public string cl_email;

        // endereco
        public string cl_endereco;
        public string cl_complemento;
        public string cl_bairro;
        public string cl_cidade;
        public string cl_estado;
        public string cl_cep;
        public string cl_pais;

        // dados bancarios
        public string cl_banco;
        public string cl_cod_banco;
        public string cl_agencia;
        public string cl_conta;
        public string cl_tipo_conta;
        public DateTime cl_data_abertura;

        public string cl_banco2;
        public string cl_cod_banco2;
        public string cl_agencia2;
        public string cl_conta2;
        public string cl_tipo_conta2;
        public DateTime cl_data_abertura2;

        public string cl_banco3;
        public string cl_cod_banco3;
        public string cl_agencia3;
        public string cl_conta3;
        public string cl_tipo_conta3;
        public DateTime cl_data_abertura3;

        // ramo
        public string cl_ramo_ativ;
        public int cl_num_empregados;
        public string cl_imp_exp;
        public decimal cl_faturamento;

        // textos
        public string cl_breve_relato;
        public string cl_como_conheceu;

        // tarifas
        public string cl_tarifa;

        // limites
        public string cl_nivel_compliance;
        public string cl_nivel_credito;
        public decimal comp_mes;
        public decimal comp_ano;
        public decimal cr_limite;

        public string flg_aceita_efet_auto_ordem;
        public DateTime data_aceita_efet_auto_ordem;
        public string cl_OperaSomenteBanco;
        public string iof_isento;
        public string flg_valor_diferenciado; // Indica se possui procuração antiga
        public string flg_ProcessaGooglePortal;
        public string ir_saida;


    }
}
