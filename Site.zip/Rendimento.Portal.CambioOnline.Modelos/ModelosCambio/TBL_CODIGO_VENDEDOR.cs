﻿using System;
using System.Collections.Generic; 
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_CODIGO_VENDEDOR : BaseModelo
    {
        public int    id;
        public string cod_vendedor;
        public string descricao;
        public bool   ativo;
        public bool   utilizado_col;
        public string tipo_cliente;
        public string cod_natureza;

        public TBL_CODIGO_VENDEDOR()
        {
            this.autoId = true;
            this.nomeIdentificador = "id";
        }
    }
}
