﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_CLI_COMP_ACIONARIA : BaseModelo
    {
        public int id_ca;
        public Int64 id_cliente;
        public string ca_nome;
        public string ca_cpf_cnpj;
        public decimal ca_porcentagem;

        public TBL_CLI_COMP_ACIONARIA()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_ca";
        }
    }
}
