﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_COL_PARAM_PRODUTOS : BaseModelo
    {
        public int TEMPOEXPIRACAOTAXA;
        public int TEMPO_PREENCHIMENTO;
        public decimal VALORLIMITE_OPER;
        public decimal VALOR_APROVACAO_AUTO;
        public int DIASLIQ_COMPRAS;
        public int DIASLIQ_VENDAS;
        public string HORARIO_CORTE;
        public string ID_CORRETORA;
        public int ID_FILIAL;
        public decimal ADIC_SPREAD_DTLIQ;
        public string LINK_PROCURACAO;
        public int DIASLIQ_COMPRASME;
        public int DIASLIQ_VENDASME;
        public int ID_ASSESSOR;
        public string FLG_HABILITAR_OPERACAO;

        public bool FLAG_DIAS_UTEIS;
        public bool FLAG_SABADOS; 
        public bool FLAG_DOMINGOS;
        public bool FLAG_FERIADOS;
        public string HORARIO_DIAS_UTEIS_DE;
        public string HORARIO_DIAS_UTEIS_ATE;
        public string HORARIO_SABADOS_DE;
        public string HORARIO_SABADOS_ATE;
        public string HORARIO_DOMINGOS_DE;
        public string HORARIO_DOMINGOS_ATE;
        public string HORARIO_FERIADOS_DE;
        public string HORARIO_FERIADOS_ATE;

        public TBL_COL_PARAM_PRODUTOS()
        {
        }

    }
}
