﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_IDENT_CHEQUE : BaseModelo
    {
        public int id_ident_cheque;
        public int ident_cliente;
        public string ident_banco;
        public string ident_cheque;
        public string ident_pais;
        public decimal ident_valor;
        public DateTime ident_data;
        public decimal ident_tarifa;
        public int ident_op;
        public string ident_arquivo;
        public string ident_remetente;

        public TBL_IDENT_CHEQUE()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_ident_cheque";
        }

    }
}
