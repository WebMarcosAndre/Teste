﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_CLI_DADOS_CONJUGE : BaseModelo
    {
        public int id_conjuge;
        public Int64 id_cliente;
        public string con_nome;
        public string con_empresa;
        public DateTime con_dt_nasc;
        public string con_cargo;
        public string con_local_nasc;
        public DateTime con_dt_admissao;
        public string con_rg;
        public string con_tel;

        public TBL_CLI_DADOS_CONJUGE()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_conjuge";
        }
    }
}
