﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Rendimento.Framework.Nucleo.Master.entInfraestrutura.Servico;

namespace Rendimento.Portal.CambioOnline.Modelos.ModelosCambio
{
    public class TBL_CRM : BaseModelo
    {
        public int id_crm;
        public int id_usuario;
        public int id_corretora;
        public string crm_cpf_cnpj;
        public string crm_ocorrencia;
        public int crm_nboleto;
        public DateTime crm_data;
        public string CRM_PASSAPORTE;
        public string CRM_CAMPOS;
        public int ID_FILIAL;
        public double crm_id_operacao;
        public string crm_ap;

        public TBL_CRM()
        {
            this.autoId = true;
            this.nomeIdentificador = "id_crm";
        }
    }
}

