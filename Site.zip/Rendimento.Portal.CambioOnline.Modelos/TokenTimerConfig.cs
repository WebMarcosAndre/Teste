﻿
using System;


namespace Rendimento.Portal.CambioOnline.Modelos
{
    public class TokenTimerConfig
    {
        public int ID { get; set; }
        public int TipoClienteID { get; set; }
        public string Descricao { get; set; }

        private DateTime _valor { get; set; }
        public string Valor
        {
            get
            {
                return _valor.ToString("mm:ss");
            }
            set { _valor = Convert.ToDateTime(value); }
        }

        //public DateTime Valor        { get; set; }
        public DateTime DataCriacao { get; set; }
    }
}
