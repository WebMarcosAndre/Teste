﻿
using System;
using Rendimento.Portal.CambioOnline.Modelos.ModelosCambio;

namespace Rendimento.Portal.CambioOnline.Modelos
{
    public class TokenTimer
    {
        public string Token{ get; }
        public TBL_LOGIN_INTEGRADO LoginIntegrado { get;  }
        public TokenTimerConfig TokenTimerConfig { get; set; }
        public TBL_MOEDAS Moeda { get; set; }
        public decimal Quantidade { get; set; }
        public decimal Taxa { get; set; }
        public decimal IOF { get; set; }
        public bool Utilizado { get; set; }
        public DateTime DataCriacao{ get; set; }
        public TBL_PRE_BOLETO PreBoleto { get; set; }

        public TokenTimer( TBL_LOGIN_INTEGRADO _loginIntegrado, TBL_MOEDAS _Moeda, decimal _Quantidade, decimal _Taxa, decimal _IOF, bool _Utilizado) {
            Token = Guid.NewGuid().ToString();
            LoginIntegrado = _loginIntegrado;
            Moeda = _Moeda;
            Quantidade = _Quantidade;
            Taxa = _Taxa;
            IOF = _IOF;
            Utilizado = _Utilizado;
            DataCriacao = DateTime.Now;
        }
    }
}
